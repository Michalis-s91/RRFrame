//
//  DoubleViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 02/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class DoubleViewCell: UITableViewCell , UITextFieldDelegate{

    @IBOutlet var firstLabel: UILabel!
    @IBOutlet var firstInputTextField: UITextField!
    @IBOutlet var firstRequiredLabel: UILabel!
    @IBOutlet var firstDropDownImage: UIImageView!
    @IBOutlet var cellBackground: UIView!
    @IBOutlet var firstDropDownImageWidth: NSLayoutConstraint!
    @IBOutlet var firstLabelWidth: NSLayoutConstraint!
    
    @IBOutlet var secondLabel: UILabel!
    @IBOutlet var secondInputTextField: UITextField!
    @IBOutlet var secondRequiredLabel: UILabel!
    @IBOutlet var secondDropDownImage: UIImageView!
    @IBOutlet var secondDropDownImageWidth: NSLayoutConstraint!
    @IBOutlet var secondLabelWidth: NSLayoutConstraint!
    
    @IBOutlet var line1: UIView!
    @IBOutlet var line2: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
