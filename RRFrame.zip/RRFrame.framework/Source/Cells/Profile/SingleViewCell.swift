//
//  SingeViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 02/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class SingleViewCell: UITableViewCell,UITextFieldDelegate {

    
    @IBOutlet var label: UILabel!
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var requiredLabel: UILabel!
    @IBOutlet var dropDownImage: UIImageView!
    @IBOutlet var cellBackground: UIView!
    
    @IBOutlet var textFieldTrailing: NSLayoutConstraint!
    @IBOutlet var dropDownImageWidth: NSLayoutConstraint!
    
    
    @IBOutlet var codeTextField: UITextField!
    @IBOutlet var enterCodeLabel: UILabel!
    @IBOutlet var verifyButton: UIButton!
    @IBOutlet var resendButton: UIButton!
    @IBOutlet var textFieldBorder1: UIView!
    @IBOutlet var textFieldBorder2: UIView!
    @IBOutlet var textFieldBorder3: UIView!
    @IBOutlet var line: UIView!
    
    @IBOutlet var resendButtonHeight: NSLayoutConstraint!
    @IBOutlet var verifyButtonHeight: NSLayoutConstraint!
    @IBOutlet var resendButtonWidth: NSLayoutConstraint!
    @IBOutlet var verifyButtonWidth: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

