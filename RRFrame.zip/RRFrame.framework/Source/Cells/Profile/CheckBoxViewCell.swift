//
//  CheckBoxViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 28/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class CheckBoxViewCell: UITableViewCell {

    @IBOutlet var checkBox: DLRadioButton!
    @IBOutlet var checkBox2: DLRadioButton!
    @IBOutlet var label: UILabel!
    @IBOutlet var checkBoxView: UIView!
    @IBOutlet var checkBoxImage: UIImageView!
    @IBOutlet var checkBoxClickView: UIView!
    @IBOutlet var checkBoxClickView2: UIView!
    @IBOutlet var cellBackground: UIView!
    
    @IBOutlet var checkBoxWidth: NSLayoutConstraint!
    @IBOutlet var checkBoxWidth2: NSLayoutConstraint!
    @IBOutlet weak var checkBoxLeading1: NSLayoutConstraint!
    @IBOutlet weak var checkBoxTrailing2: NSLayoutConstraint!
    @IBOutlet weak var itemLeading: NSLayoutConstraint!
    @IBOutlet weak var itemTrailing: NSLayoutConstraint!
    @IBOutlet var imageHeight: NSLayoutConstraint!
    @IBOutlet weak var itemlWidth: NSLayoutConstraint!
    @IBOutlet weak var itemCenter: NSLayoutConstraint!
    
    //@IBOutlet var labelCenter: NSLayoutConstraint!
    //var con : NSLayoutConstraint!
    var itemCenterStrong : NSLayoutConstraint!
    var checkBoxModel : CheckBoxModel!
    var viewController : ViewController!
    var viewController2 : UserProfileViewController2!
    var viewModel : UserProfileViewModel2!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        itemCenterStrong = itemCenter
        
        let onCheckBoxClick = UITapGestureRecognizer(target: self, action: #selector(CheckBoxViewCell.onCheckBoxClick))
        checkBoxClickView.isUserInteractionEnabled = true
        checkBoxClickView.addGestureRecognizer(onCheckBoxClick)
        
        let onCheckBoxClick2 = UITapGestureRecognizer(target: self, action: #selector(CheckBoxViewCell.onCheckBoxClick))
        checkBoxClickView2.isUserInteractionEnabled = true
        checkBoxClickView2.addGestureRecognizer(onCheckBoxClick2)
        
        //if(checkBoxModel != nil && checkBoxModel.link != nil)
        //{
            let onLinkClick = UITapGestureRecognizer(target: self, action: #selector(CheckBoxViewCell.onLinkClick))
            checkBoxView.isUserInteractionEnabled = true
            checkBoxView.addGestureRecognizer(onLinkClick)
        //}
    }
    
    override func didMoveToSuperview() {
        if(checkBoxModel != nil && checkBoxModel.connectionID != nil)
        {
            if(viewModel != nil && viewModel.acceptNews != nil)
            {
                if(checkBoxModel.connectionID == 1)
                {
                    checkBoxModel.isChecked = viewModel.acceptNews.acceptNews1 == 1 ? true : false
                }
                else if(checkBoxModel.connectionID == 2)
                {
                    checkBoxModel.isChecked = viewModel.acceptNews.acceptNews2 == 1 ? true : false
                }
                else if(checkBoxModel.connectionID == 3)
                {
                    checkBoxModel.isChecked = viewModel.acceptNews.acceptNews3 == 1 ? true : false
                }
                else if(checkBoxModel.connectionID == 4)
                {
                    checkBoxModel.isChecked = viewModel.acceptNews.acceptNews4 == 1 ? true : false
                }
                else if(checkBoxModel.connectionID == 5)
                {
                    checkBoxModel.isChecked = viewModel.acceptNews.acceptNews5 == 1 ? true : false
                }
                /*else if(checkBoxModel.connectionID == 6)
                 {
                 checkBoxModel.isChecked = viewModel.acceptNews.acceptNews6 == 1 ? true : false
                 }
                 else if(checkBoxModel.connectionID == 7)
                 {
                 checkBoxModel.isChecked = viewModel.acceptNews.acceptNews7 == 1 ? true : false
                 }
                 else if(checkBoxModel.connectionID == 8)
                 {
                 checkBoxModel.isChecked = viewModel.acceptNews.acceptNews8 == 1 ? true : false
                 }*/
            }
            
            switch(checkBoxModel.connectionID)
            {
            case CheckBoxConnectionID.IsAdult.rawValue:
                checkBoxModel.isChecked = viewController2.appUser!.isAdult
            case CheckBoxConnectionID.ReceiveCardSMS.rawValue:
                checkBoxModel.isChecked = viewController2.appUser!.shouldReceiveSms
            case CheckBoxConnectionID.ReceiveEmail.rawValue:
                checkBoxModel.isChecked = viewController2.appUser!.shouldReceiveEmail
            case CheckBoxConnectionID.ReceiveCardSMS.rawValue:
                checkBoxModel.isChecked = viewController2.appUser!.shouldReceiveLoyaltyCardNumberBySMS
            default:
                break
            }
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        checkBox.isSelected =  checkBoxModel.isChecked
        checkBox2.isSelected =  checkBoxModel.isChecked
        
        if(checkBoxModel != nil && checkBoxModel!.alignment == CheckBoxAlignment.Center.rawValue)
        {
            itemCenter = itemCenterStrong
        }

    }
    
    @objc func onCheckBoxClick(_ sender: UITapGestureRecognizer) {
        if(viewController2.isRegistered)
        {
            viewController2.areUnsavedChanges = true
        }
        
        setCheckbox()
    }
    
    func setCheckbox()
    {
        if(!viewController2.isUserProfileSynced)
        {
            viewController2.syncUserProfile()
        }
        else
        {
            checkBox.isSelected =  !checkBoxModel.isChecked
            checkBox2.isSelected =  !checkBoxModel.isChecked
            
            checkBoxModel.isChecked = !checkBoxModel.isChecked
            
            viewModel.areAcceptNewsChanged = true
            
            if(checkBoxModel != nil)
            {
                switch checkBoxModel.connectionID {
                case 1:
                    viewModel.acceptNews.acceptNews1 = checkBoxModel.isChecked ? 1 : 0
                case 2:
                    viewModel.acceptNews.acceptNews2 = checkBoxModel.isChecked ? 1 : 0
                case 3:
                    viewModel.acceptNews.acceptNews3 = checkBoxModel.isChecked ? 1 : 0
                case 4:
                    viewModel.acceptNews.acceptNews4 = checkBoxModel.isChecked ? 1 : 0
                case 5:
                    viewModel.acceptNews.acceptNews5 = checkBoxModel.isChecked ? 1 : 0
                    /*case 6:
                     viewModel.acceptNews.acceptNews6 = checkBoxModel.isChecked ? 1 : 0
                     case 7:
                     viewModel.acceptNews.acceptNews7 = checkBoxModel.isChecked ? 1 : 0
                     case 8:
                     viewModel.acceptNews.acceptNews8 = checkBoxModel.isChecked ? 1 : 0*/
                default:
                    break
                }
            }
        }
        
        /*if(submitButtonPressed && checkBoxModel.isRequired && !checkBoxModel.isChecked)
        {
            cell.checkBox.iconColor = UIColor("#ff0000")
        }
        else
        {
            cell.checkBox.iconColor = UIColor(checkBoxModel!.tintColor)
        }*/
    }
    
    @objc func onLinkClick(_ sender: UIButton) {
        if(checkBoxModel != nil && checkBoxModel.link != nil)
        {
            if(checkBoxModel.link.isNumeric)
            {
                let tabID = Int(checkBoxModel.link)
                
                for t in leftDrawer.leftDrawerTabsList
                {
                    if(tabID == t.id)
                    {
                        leftDrawer.selectTab(tabString: t.name)
                        viewController.showView(tab: t, index: 0, isEmbeded : true)
                    }
                }
            }
            else
            {
                //restartApp = false
                UIApplication.shared.openURL(NSURL(string: checkBoxModel.link)! as URL)
            }
        }
        else
        {
            viewController2.areUnsavedChanges = true
            setCheckbox()
        }
    }

}
