//
//  PartnerViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 06/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// PartnerViewCell is a cell that is been used at partners table
class PartnerViewCell: UITableViewCell {
    @IBOutlet var infoView: UIView!
    @IBOutlet var optInViewHeight: NSLayoutConstraint!
    @IBOutlet var optInViewTop: NSLayoutConstraint!
    
    @IBOutlet var categoryView: UIView!
    @IBOutlet var categoryLabel: UILabel!
    @IBOutlet var categoryViewheight: NSLayoutConstraint!
    
    @IBOutlet var partnerImage: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    
    @IBOutlet var optInView: UIView!
    @IBOutlet var optinDateLabel: UILabel!
    
    @IBOutlet var favouriteView: UIView!
    @IBOutlet var isFavouriteImage: UIImageView!
    @IBOutlet var optInTypeLabel: UILabel!
    
    @IBOutlet var loyaltyView: UIView!
    @IBOutlet var loyaltyImage: UIImageView!
    @IBOutlet var loyaltyPointsLabel: UILabel!
    
    @IBOutlet var offersView: UIView!
    @IBOutlet var offersImage: UIImageView!
    
    @IBOutlet var loyaltyViewWidth: NSLayoutConstraint!
    @IBOutlet var offersViewWidth: NSLayoutConstraint!
    @IBOutlet var loyaltyImageWidth: NSLayoutConstraint!
    @IBOutlet var offersImageWidth: NSLayoutConstraint!
    
    weak var partner : PartnerModel!
    weak var viewModel : AllPartnersViewModel!
    weak var viewController : AllPartnersView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        let onFavouriteClick = UITapGestureRecognizer(target: self, action: #selector(PartnerViewCell.onFavouriteClick))
        favouriteView.isUserInteractionEnabled = true
        favouriteView.addGestureRecognizer(onFavouriteClick)
        
        let onLoyaltyClick = UITapGestureRecognizer(target: self, action: #selector(PartnerViewCell.onLoyaltyClick))
        loyaltyView.isUserInteractionEnabled = true
        loyaltyView.addGestureRecognizer(onLoyaltyClick)
        
        let onOffersClick = UITapGestureRecognizer(target: self, action: #selector(PartnerViewCell.onOffersClick))
        offersView.isUserInteractionEnabled = true
        offersView.addGestureRecognizer(onOffersClick)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    @objc func onFavouriteClick(sender:UITapGestureRecognizer) {
        do
        {
            if(!(localDatabase.isAPKRegistered(bussinessID: clientID))!)
            {
                let s = ShowRegistrationDialog()
                s.viewController = viewController
                s.showRegistrationDialog()
            }
            else
            {
                if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                {
                    if (!partner.isRoot)
                    {
                        if (partner.isLoyalty && partner.IsFavourite)
                        {
                            let toast = CustomToast()
                            toast.setToast(viewController: viewController, message: NSLocalizedString("changeLoyaltyPartnerStatusNotAllowed", comment: ""))
                            toast.show()
                        }
                        else
                        {
                            DispatchQueue.global(qos: .background).async {
                                self.task()
                            }
                        }
                    }
                    else
                    {
                        let toast = CustomToast()
                        toast.setToast(viewController: self.viewController, message: NSLocalizedString("changeLoyaltyPartnerStatusNotAllowed", comment: ""))
                        toast.show()
                    }
                }
                else
                {
                    let toast =  CustomToast()
                    toast.setToast(viewController: viewController,message: NSLocalizedString("internetIsRequired", comment: ""))
                    toast.show()
                }
            }
        }
        catch
        {
        }
    }
    
    @objc func onLoyaltyClick(sender:UITapGestureRecognizer) {
            if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
            {
                if(partner != nil)
                {
                    isViewPushed = true
                    let LoyaltyStatementStoryBoard : UIStoryboard = UIStoryboard(name: "LoyaltyStatementView", bundle: nil)
                    let loyaltyStatementView =  LoyaltyStatementStoryBoard.instantiateViewController(withIdentifier: "LoyaltyStatementViewController") as! LoyaltyStatementViewController
                    loyaltyStatementView.partnerTemp = partner
                    self.viewController.navigationController?.pushViewController(loyaltyStatementView, animated: true)
                }
            }
            else
            {
                let toast =  CustomToast()
                toast.setToast(viewController: viewController,message: NSLocalizedString("internetIsRequired", comment: ""))
                toast.show()
            }
    }
    
    @objc func onOffersClick(sender:UITapGestureRecognizer) {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            
            let task = WebApiTask(viewController: viewController, action: loadPartnerOffers , displayToast: true)
            
            task.failureAction = failureAction
            task.start()
        }
        else
        {
            let toast =  CustomToast()
            toast.setToast(viewController: viewController,message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
        
    }
    
    /// Task for changing favourite option for partner.
    func task()
    {
        if (partner.IsFavourite)
        {
            partner.IsFavourite = false
        }
        else
        {
            partner.IsFavourite = true
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            if (!self.partner.IsFavourite)
            {
                self.isFavouriteImage.image = UIImage(named: "ic_favourite")
                self.optInTypeLabel.text = self.partner.optInType
            }
            else
            {
                self.isFavouriteImage.image = UIImage(named: "ic_favourite_filled")
                self.optInTypeLabel.text = self.partner.optInType
            }
        })
        
        do
        {
            try viewModel.modifyFavourites( partner: partner, isFavourite: !partner.IsFavourite)
        }
        catch
        {
            partner.IsFavourite =  !(partner.IsFavourite)
            
            DispatchQueue.main.async(execute: {() -> Void in
                if (self.partner.IsFavourite)
                {
                    self.isFavouriteImage.image = UIImage(named: "ic_favourite")
                    self.optInTypeLabel.text = self.partner.optInType
                } else
                {
                    self.isFavouriteImage.image = UIImage(named: "ic_favourite_filled")
                    self.optInTypeLabel.text = self.partner.optInType
                }
                
                let toast = CustomToast()
                toast.setToast(viewController: self.viewController, message: NSLocalizedString("congestedServerNetworkTryAgain", comment: ""))
                toast.show()
            })
            
        }
        
    }
    
    /// Sets the failure action.
    func failureAction()
    {
        viewController.ignorePartnersListViewClicks = false
    }
    
    /// Loads partner offers.
    func loadPartnerOffers()
    {
        if (!isActivityActive(viewController: viewController))
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            isViewPushed = true
            self.viewController.ignorePartnersListViewClicks = false
            let OffersStoryBoard : UIStoryboard = UIStoryboard(name: "OffersView", bundle: nil)
            let offersView =  OffersStoryBoard.instantiateInitialViewController() as! OffersViewController
            //self.viewController.addChildViewController(offersView)
            self.viewController.navigationController?.pushViewController(offersView, animated: true)
            
            offersView.setOffersView(partner : self.partner)
        })
    }
    
}
