//
//  TicketTotalViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 14/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// TicketItemViewCell is a cell that is been used at loyalty ticket table and shows the ticket total
class TicketTotalViewCell: UITableViewCell {

    
    @IBOutlet var totalHeaderLabel: UILabel!
    @IBOutlet var totalGrossLabel: UILabel!
    @IBOutlet var totalDiscountLabel: UILabel!
    @IBOutlet var totalLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
