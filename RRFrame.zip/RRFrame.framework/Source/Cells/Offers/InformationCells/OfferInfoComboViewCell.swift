//
//  OfferInfoComboViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 27/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher

/// OfferInfoTitleViewCell set the cell wich has combo offer for information table
class OfferInfoComboViewCell: UITableViewCell, UIScrollViewDelegate {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var previousImage: UIImageView!
    @IBOutlet var nextImage: UIImageView!
    @IBOutlet var imageGallery: UIScrollView!
    
    var imagesUrls : [String]! = []
    var offersList : [OfferItemModel]!
    var appOfferID : Int!
    var currentIndex = 0
    var isImagePressed = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.imageGallery.delegate = self
        previousImage.isHidden = true
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        previousImage.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi))
        
        let onPreviousClick = UITapGestureRecognizer(target: self, action: #selector(OfferInfoComboViewCell.onPreviousClick))
        previousImage.isUserInteractionEnabled = true
        previousImage.addGestureRecognizer(onPreviousClick)
        
        let onNextClick = UITapGestureRecognizer(target: self, action: #selector(OfferInfoComboViewCell.onNextClick))
        nextImage.isUserInteractionEnabled = true
        nextImage.addGestureRecognizer(onNextClick)
    }
    
    @objc func onPreviousClick (sender:UITapGestureRecognizer) {
        isImagePressed = true
        currentIndex -= 1
        self.titleLabel.text = self.offersList[currentIndex].name
        nextImage.isHidden = false
        imageGallery.setContentOffset(CGPoint(x: CGFloat(currentIndex) * imageGallery.frame.width, y: 0), animated: true)
        
        if(currentIndex == 0)
        {
            previousImage.isHidden = true
        }
    }
    
    @objc func onNextClick (sender:UITapGestureRecognizer) {
        isImagePressed = true
        currentIndex += 1
        self.titleLabel.text = self.offersList[currentIndex].name
        previousImage.isHidden = false
        imageGallery.setContentOffset(CGPoint(x: CGFloat(currentIndex) * imageGallery.frame.width, y: 0), animated: true)
        
        if(currentIndex == imagesUrls.count - 1 )
        {
            nextImage.isHidden = true
        }
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        currentIndex = page
        self.titleLabel.text = self.offersList[page].name
        
        if(page == 0)
        {
            previousImage.isHidden = true
            nextImage.isHidden = false
        }
        else if (page == imagesUrls.count - 1) {
            nextImage.isHidden = true
            previousImage.isHidden = false
        }
        else
        {
            nextImage.isHidden = false
            previousImage.isHidden = false
        }
    }
    
    /// Sets the imgaes of combo offers.
    func setImages()
    {
        let task = WebApiTask(viewController: nil, action: loadImages)
        task.start()
    }
    
    /// Loads the images of combo offers.
    func loadImages()
    {
        offersList =  OfferItemsWebApi.getOfferItems( userPhone: (localDatabase.getAppUser()?.phoneNumber)!,appOfferID: appOfferID)
        
        var i = 0
        while( i < offersList.count)
        {
            imagesUrls.append(offersList[i].imageUrl)
            i += 1
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.titleLabel.text = self.offersList[0].name
            
            for i in 0..<self.imagesUrls.count
            {
                let image = self.imagesUrls[i]
                let url = URL(string: percentEncode(s: image))
                let imageView : UIImageView = UIImageView()
                imageView.kf.setImage(with: url)
                
                imageView.frame = CGRect(x: (CGFloat(i) * self.imageGallery.frame.width) + (self.imageGallery.frame.width - 130)/2 , y: 0, width: 130, height: 130)
                self.imageGallery.addSubview(imageView)
            }
            self.imageGallery.contentSize.width = self.imageGallery.frame.width * CGFloat(self.imagesUrls.count)
        })
        
    }
    
}
