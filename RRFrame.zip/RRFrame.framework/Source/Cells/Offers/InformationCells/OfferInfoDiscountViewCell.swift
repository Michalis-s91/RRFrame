//
//  OfferInfoDiscountViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 15/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// OfferInfoDiscountViewCell set the cell wich has discount description for information table
class OfferInfoDiscountViewCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var splitter: UIView!
    @IBOutlet var originalPriceTitleLabel: UILabel!
    @IBOutlet var originalPriceTextLabel: UILabel!
    @IBOutlet var offerDescriptionTextLabel: UILabel!
    @IBOutlet var offerNewPriceLabel: UILabel!
    @IBOutlet var strike: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        titleLabel.font = UIFont.boldSystemFont(ofSize: 15.0)
        titleLabel.textColor = Colors.sectionTextColor
        splitter.backgroundColor = Colors.sectionTextUnderlineColor
        originalPriceTextLabel.textColor = Colors.red
        offerNewPriceLabel.textColor = Colors.green
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
