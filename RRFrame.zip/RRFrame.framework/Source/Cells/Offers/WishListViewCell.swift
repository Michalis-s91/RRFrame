//
//  WishListViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// WishListViewCell is a cell that is been used at wish list table
class WishListViewCell: UITableViewCell {
    @IBOutlet var infoView: UIView!
    
    @IBOutlet var offerImage: UIImageView!
    
    @IBOutlet var partnerNameLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    
    @IBOutlet var avoidOfferDetailView: UIView!
    @IBOutlet var generalOfferTitleLabel: UILabel!
    @IBOutlet var offerNewValueLabel: UILabel!
    
    @IBOutlet var isNotGeneralOfferView: UIView!
    @IBOutlet var priceLabel: UILabel!
    @IBOutlet var originalPriceLabel: UILabel!
    @IBOutlet var strikeView: UIView!
    @IBOutlet var offerDescriptionView: UIView!
    @IBOutlet var offerDescriptionLabel: UILabel!
    @IBOutlet var offerNewValueLabel2: UILabel!
    
    @IBOutlet var validLabel: UILabel!
    @IBOutlet var durationTextLabel: UILabel!
    
    @IBOutlet var wishListImage: UIImageView!
    @IBOutlet var wishListButton: UIButton!
    
    @IBOutlet var avoidOfferViewWidth: NSLayoutConstraint!
    @IBOutlet var isNotGeneralOfferViewWidth: NSLayoutConstraint!
    
    var viewModel : WishListViewModel!
    var offer : OfferModel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        //let onWishListClick = UITapGestureRecognizer(target: self, action: #selector(OfferViewCell.onWishClick))
        //wishListImage.isUserInteractionEnabled = true
        //wishListImage.addGestureRecognizer(onWishListClick)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @objc func onWishListClick (sender:UITapGestureRecognizer) {
        offer.isItemWatched = !(offer.isItemWatched)
        viewModel.removeFromWishList(offer: offer)
        viewModel.loadWishList()
    }
    
    @IBAction func onWishListClick(_ sender: UIButton) {
        offer.isItemWatched = !(offer.isItemWatched)
        viewModel.removeFromWishList(offer: offer)
        viewModel.loadWishList()
    }
    
}
