//
//  OfferViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 08/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// OfferViewCell is a cell that is been used at offers table
class OfferViewCell: UITableViewCell {
    @IBOutlet var infoView: UIView!
    
    @IBOutlet var offerImage: UIImageView!
    
    @IBOutlet var descriptionLabel: UILabel!
    
    @IBOutlet var avoidOfferDetailView: UIView!
    @IBOutlet var generalOfferTitleLabel: UILabel!
    @IBOutlet var offerNewValueLabel: UILabel!
    
    @IBOutlet var isNotGeneralOfferView: UIView!
    @IBOutlet var priceLabel: UILabel!
    @IBOutlet var originalPriceLabel: UILabel!
    @IBOutlet var strikeView: UIView!
    @IBOutlet var offerDescriptionView: UIView!
    @IBOutlet var offerDescriptionLabel: UILabel!
    @IBOutlet var offerNewValueLabel2: UILabel!
    
    @IBOutlet var validLabel: UILabel!
    @IBOutlet var durationTextLabel: UILabel!
    @IBOutlet var durationView: UIView!
    
    @IBOutlet var wishListImage: UIImageView!
    @IBOutlet var wihshListButton: UIButton!
    
    @IBOutlet var avoidOfferViewWidth: NSLayoutConstraint!
    @IBOutlet var isNotGeneralOfferViewWidth: NSLayoutConstraint!
    @IBOutlet var validDateViewBottom: NSLayoutConstraint!
    
    @IBOutlet var wishListView: UIView!
    
    @IBOutlet var isSeenLabel: UILabel!
    
    var viewModel : PartnersOffersViewModel!
    var offer: OfferModel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        if(originalPriceLabel != nil)
        {
            originalPriceLabel.textColor = Colors.red
        }
        
        if(offerNewValueLabel2 != nil)
        {
            offerNewValueLabel2.textColor = Colors.green
        }
        
        isSeenLabel.textColor = Colors.holo_red_dark
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    @IBAction func inWishListClick(_ sender: UIButton) {
        if(APK == APKsEnum.RichReach.rawValue)
        {
            viewModel.modifyWishList(offer: offer)
            offer.isItemWatched = !(offer.isItemWatched)
            
            if(offer.isItemWatched)
            {
                wihshListButton.setImage(UIImage(named: "ic_shopping_bag_filled"), for: .normal)
            }
            else
            {
                wihshListButton.setImage(UIImage(named: "ic_wish_list_empty_bag"), for: .normal)
            }
        }
    }
    
    @IBOutlet var a: UIView!
    
    @objc func onWishClick (sender:UITapGestureRecognizer) {
        viewModel.modifyWishList(offer: offer)
        offer.isItemWatched = !(offer.isItemWatched)
        
        if(offer.isItemWatched)
        {
            wihshListButton.setImage(UIImage(named: "ic_shopping_bag_filled"), for: .normal)
        }
        else
        {
            wihshListButton.setImage(UIImage(named: "ic_wish_list_empty_bag"), for: .normal)
        }
    }

}
