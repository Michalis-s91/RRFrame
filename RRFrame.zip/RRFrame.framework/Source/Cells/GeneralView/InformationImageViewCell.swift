//
//  InformationImageViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 16/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// InformationImageViewCell is a cell that is been used for showing an image with or without title.
class InformationImageViewCell: UITableViewCell {
    
    @IBOutlet var cellImage: UIImageView!
    @IBOutlet var cellTitle: UILabel!
    @IBOutlet var titleHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet var buttonBorder: UIView!
    @IBOutlet var cellButton: UIButton!
    
    @IBOutlet var buttonHeight: NSLayoutConstraint!
    @IBOutlet var buttonWidth: NSLayoutConstraint!
    @IBOutlet var borderWidth: NSLayoutConstraint!
    @IBOutlet var borderHeight: NSLayoutConstraint!
    @IBOutlet var borderY: NSLayoutConstraint!
    @IBOutlet var borderX: NSLayoutConstraint!
    @IBOutlet var imageWidth: NSLayoutConstraint!
    
    var link : String!
    var viewController : ViewController!
    var button : ButtonModel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        if(!isNullOrEmpty(string: link))
        {
            let onImageClick = UITapGestureRecognizer(target: self, action: #selector(InformationImageViewCell.onImageClick))
            cellImage.isUserInteractionEnabled = true
            cellImage.addGestureRecognizer(onImageClick)
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @IBAction func showView(_ sender: UIButton) {
        if(button.link != nil)
        {
            //restartApp = false
            UIApplication.shared.openURL(NSURL(string: button.link)! as URL)
        }
        else
        {
            loadTab(tabID: self.button.tabID, viewController : self.viewController)
        }
    }
    
    @objc func onImageClick(sender:UITapGestureRecognizer) {
        if(!isNullOrEmpty(string: link))
        {
            if(link.isNumeric)
            {
                loadTab(tabID: Int(link)!, viewController : self.viewController)
            }
            else
            {
                //restartApp = false
                UIApplication.shared.openURL(NSURL(string: link)! as URL)
            }
        }
    }
}
