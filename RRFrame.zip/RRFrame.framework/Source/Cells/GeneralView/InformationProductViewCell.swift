//
//  InformationProductViewCell.swift
//  RichReach
//
//  Created by Eumbrella on 25/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit

class InformationProductViewCell: UITableViewCell {

    @IBOutlet var productImage: UIImageView!
    @IBOutlet var productDescription: UILabel!
    @IBOutlet var plusIcon: UIImageView!
    @IBOutlet var plusIconView: UIView!
    
    @IBOutlet var imageHeight: NSLayoutConstraint!
    
    var product : ProductModel!
    var parentView : GeneralInformationViewController!
    var tableView : UITableView!
    //var areInformationsDisplayed = false
    var productInformationsList : [GeneralInformation2] = []
    //var itemPosition : Int!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        if(product != nil)
        {
            let onPlusClick = UITapGestureRecognizer(target: self, action: #selector(InformationProductViewCell.onPlusClick))
            plusIconView.isUserInteractionEnabled = true
            plusIconView.addGestureRecognizer(onPlusClick)
            //var productModel = productsDB.getProduct(barcode: product.)
        }
    }

    @objc func onPlusClick (sender:UITapGestureRecognizer) {
        var itemPosition = 0
        
        for i in parentView.informationsList
        {
            if(i.type == SlotType.Product.rawValue && i.product.itemNo == self.product.itemNo)
            {
                break
            }
            
            itemPosition += 1
        }
        
        if(product.areInformationsDisplayed)
        {
            for i in productInformationsList
            {
                if(i.type == SlotType.Text.rawValue)
                {
                    parentView.informationsList.remove(at: itemPosition + 1)
                }
            }
            
            product.areInformationsDisplayed = false
        }
        else
        {
            var index = itemPosition + 1
            for i in productInformationsList
            {
                if(i.type == SlotType.Text.rawValue)
                {
                    i.index = itemPosition + index + 1
                    parentView.informationsList.insert(i, at: index)
                    index += 1
                }
            }
            
            product.areInformationsDisplayed = true
        }
        
        tableView.reloadData()
        
        /*if(product.areInformationsDisplayed)
        {
            DispatchQueue.main.async(execute: {() -> Void in
                self.tableView.scrollToRow(at: IndexPath(row: 0, section: itemPosition), at: UITableViewScrollPosition.top, animated: true)
            })
        }
        else
        {
            DispatchQueue.main.async(execute: {() -> Void in
                //self.tableView.scrollToRow(at: IndexPath(row: 0, section: self.itemPosition), at: UITableViewScrollPosition.bottom, animated: true)
            })
        }*/
        
    }
}
