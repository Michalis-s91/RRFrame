//
//  RelatedArticleViewCell.swift
//  RichReach
//
//  Created by Eumbrella on 05/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit

class RelatedArticleViewCell: UITableViewCell {

    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var articleImage: UIImageView!
    @IBOutlet var articleTitleLabel: UILabel!
    //@IBOutlet var articleCategoryLabel: UILabel!
    @IBOutlet var articleDateLabel: UILabel!
    @IBOutlet var splitter: UIView!
    
    @IBOutlet var articleImageHeight: NSLayoutConstraint!
    @IBOutlet var titleLabelTop: NSLayoutConstraint!
    @IBOutlet var articleTitleHeight: NSLayoutConstraint!
    @IBOutlet var splitterTop: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
