//
//  InformationTitleViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 28/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// InformationTitleViewCell is a cell that is been used for showing a title.
class InformationTitleViewCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var splitter: UIView!
    @IBOutlet var expandImage: UIImageView!
    @IBOutlet var cellBackground: UIView!
    
    @IBOutlet weak var titleHeight: NSLayoutConstraint!
    @IBOutlet var titleWidth: NSLayoutConstraint!
    @IBOutlet weak var expandImageWidth: NSLayoutConstraint!
    
    var title : TitleModel!
    var viewController : UserProfileViewController2!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        if(title != nil && title.isSection)
        {
            expandImageWidth.constant = 15
            
            let onClick = UITapGestureRecognizer(target: self, action: #selector(self.onSectionClick))
            titleLabel.isUserInteractionEnabled = true
            titleLabel.addGestureRecognizer(onClick)
            
            if(title.isSectionExpanded)
            {
                expandImage.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                expandImage.tintColor = UIColor(title.titleColor)
            }
            else
            {
                expandImage.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                expandImage.tintColor = UIColor(title.titleColor)
            }
        }
        else
        {
            if(expandImageWidth != nil)
            {
                expandImageWidth.constant = 0
            }
        }
        // Configure the view for the selected state
    }
    
    @objc func onSectionClick(sender: UITapGestureRecognizer) {
        if(title.isSectionExpanded)
        {
            var index = 0
            for i in viewController.visibleItems
            {
                if(i.type == UserProfileCellType.Title.rawValue && i.title.id == title.id)
                {
                    index += 1
                    while(true)
                    {
                        if(index >= viewController.visibleItems.count || (viewController.visibleItems[index].type == UserProfileCellType.Title.rawValue && viewController.visibleItems[index].title.isSection) || index == viewController.visibleItems.count || viewController.visibleItems[index].type == UserProfileCellType.Button.rawValue)
                        {
                            break
                        }
                        else
                        {
                            viewController.visibleItems.remove(at: index)
                        }
                    }
                    
                    break
                }
                
                index += 1
            }
            
            expandImage.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
            expandImage.tintColor = UIColor(title.titleColor)
        }
        else
        {
            var index2 = 0
            for i in viewController.items
            {
                if(i.type == UserProfileCellType.Title.rawValue && i.title.id == title.id)
                {
                    break
                }
                
                index2 += 1
            }
            
            var index = 0
            for i in viewController.visibleItems
            {
                if(i.type == UserProfileCellType.Title.rawValue && i.title.id == title.id)
                {
                    while(true)
                    {
                        index += 1
                        index2 += 1
                        
                        if(index2 >=  viewController.items.count || (viewController.items[index2].type == UserProfileCellType.Title.rawValue && viewController.items[index2].title.isSection) || index2 == viewController.items.count || viewController.items[index2].type == UserProfileCellType.Button.rawValue)
                        {
                            break
                        }
                        else
                        {
                            viewController.visibleItems.insert(viewController.items[index2], at: index)
                        }
                    }
                    
                    break
                }
                
                index += 1
            }
            
            expandImage.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
            expandImage.tintColor = UIColor(title.titleColor)
        }
        
        viewController.profileTableView.reloadData()
        title.isSectionExpanded = !title.isSectionExpanded
    }

}
