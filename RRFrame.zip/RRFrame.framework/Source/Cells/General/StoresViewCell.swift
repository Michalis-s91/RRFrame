//
//  StoresViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// StoresViewCell set the cell for stores table
class StoresViewCell: UITableViewCell {

    @IBOutlet var storeNameLabel: UILabel!
    @IBOutlet var storeAddressLabel: UILabel!
    @IBOutlet var storePhoneLabel: UILabel!
    
    @IBOutlet var phoneImage: UIImageView!
    @IBOutlet var mapImage: UIImageView!
    
    @IBOutlet var phoneView: UIView!
    @IBOutlet var mapView: UIView!
    
    var navigationController: UINavigationController!
    
    var storeLatitude : String!
    var storeLongitude : String!
    var address : String!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let phoneImage = UIImage(named: "ic_phone")?.withRenderingMode(.alwaysTemplate)
        self.phoneImage.tintColor = Colors.bckg_main_color_new
        self.phoneImage.image = phoneImage
        
        let mapImage = UIImage(named: "ic_map")?.withRenderingMode(.alwaysTemplate)
        self.mapImage.tintColor = Colors.bckg_main_color_new
        self.mapImage.image = mapImage
        
        
        let onTelephoneClick1 = UITapGestureRecognizer(target: self, action: #selector(StoresViewCell.onTelephoneClick))
        phoneView.isUserInteractionEnabled = true
        phoneView.addGestureRecognizer(onTelephoneClick1)
        
        let onTelephoneClick2 = UITapGestureRecognizer(target: self, action: #selector(StoresViewCell.onTelephoneClick2))
        storePhoneLabel.isUserInteractionEnabled = true
        storePhoneLabel.addGestureRecognizer(onTelephoneClick2)
        
        let onMapClick = UITapGestureRecognizer(target: self, action: #selector(StoresViewCell.onMapClick))
        mapView.isUserInteractionEnabled = true
        mapView.addGestureRecognizer(onMapClick)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    @objc func onTelephoneClick (sender:UITapGestureRecognizer) {
        UIApplication.shared.openURL(URL(string: "tel://" + storePhoneLabel.text!)!) //open(URL(string: "tel://" + storePhoneLabel.text!)! , options: [:], completionHandler: nil)
    }
    
    @objc func onTelephoneClick2 (sender:UITapGestureRecognizer) {
        UIApplication.shared.openURL(URL(string: "tel://" + storePhoneLabel.text!)!) //UIApplication.shared.open(URL(string: "tel://" + storePhoneLabel.text!)! , options: [:], completionHandler: nil)
    }
    
    @objc func onMapClick (sender:UITapGestureRecognizer) {
        isViewPushed = true
        let MapStoryBoard : UIStoryboard = UIStoryboard(name: "MapView", bundle: nil)
        let mapView =  MapStoryBoard.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
        mapView.longitude = storeLongitude
        mapView.latitude = storeLatitude
        mapView.name = storeNameLabel.text!
        mapView.address = address
        self.navigationController?.pushViewController(mapView, animated: true)
        
       //openMapForPlace(latitude: storeLatitude, longitude: storeLongitude, name : storeNameLabel.text! )
    }
}
