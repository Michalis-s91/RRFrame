//
//  ButtonViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 03/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class ButtonViewCell: UITableViewCell {

    @IBOutlet var button: UIButton!
    @IBOutlet var cellBackground: UIView!
    
    @IBOutlet var buttonWidth: NSLayoutConstraint!
    @IBOutlet var buttonHeight: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
