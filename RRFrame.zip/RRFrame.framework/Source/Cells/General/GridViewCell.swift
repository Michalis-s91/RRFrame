//
//  GridViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 26/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// GridViewCell ia a cell that is been used at grid table
class GridViewCell: UITableViewCell {

    @IBOutlet var button1: UIButton!
    @IBOutlet var button2: UIButton!
    @IBOutlet var button3: UIButton!
    @IBOutlet var button4: UIButton!
    @IBOutlet var button5: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    @IBAction func onClickButton1(_ sender: UIButton) {
        GridDialog.selectedYear = sender.tag
        GridDialog.dismissDialog()
    }
    
    @IBAction func onClickButton2(_ sender: UIButton) {
        GridDialog.selectedYear = sender.tag
        GridDialog.dismissDialog()
    }

    @IBAction func onClickButton3(_ sender: UIButton) {
        GridDialog.selectedYear = sender.tag
        GridDialog.dismissDialog()
    }
    
    @IBAction func onClickButton4(_ sender: UIButton) {
        GridDialog.selectedYear = sender.tag
        GridDialog.dismissDialog()
    }
    
    @IBAction func onClickButton5(_ sender: UIButton) {
        GridDialog.selectedYear = sender.tag
        GridDialog.dismissDialog()
    }
}
