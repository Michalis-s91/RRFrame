//
//  NotificationViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 27/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// NotificationViewCell is a cell that is been used at notifications table.
class NotificationViewCell: UITableViewCell {

    @IBOutlet var partnerImage: UIImageView!
    @IBOutlet var partnerNameLabel: UILabel!
    @IBOutlet var timeStampLabel: UILabel!
    @IBOutlet var messageLabel: UILabel!
    @IBOutlet var isSeenLabel: UILabel!
    @IBOutlet var isSeenImage: UIImageView!
    @IBOutlet var productsImage: UIImageView!
    
    @IBOutlet var infoView: UIView!
    @IBOutlet var isNotSeenView: UIView!
    
    var viewController : ViewController!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        isSeenLabel.textColor = Colors.holo_red_dark
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
