//
//  SupportTypeViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 21/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// SupportTypeViewCell is a cell that is been used at support types table
class SupportTypeViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
