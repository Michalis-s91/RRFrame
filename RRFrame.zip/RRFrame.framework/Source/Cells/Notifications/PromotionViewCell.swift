//
//  PromotionViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 06/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class PromotionViewCell: UITableViewCell {

    @IBOutlet var promotionImage: UIImageView!
    @IBOutlet var promotionShortDescription: UILabel!
    @IBOutlet var promotionDate: UILabel!
    @IBOutlet var isSeenLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        isSeenLabel.textColor = Colors.holo_red_dark
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
