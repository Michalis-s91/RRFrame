//
//  StoreHolidayViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 06/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class StoreHolidayViewCell : UITableViewCell
{
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var hoursLabel: UILabel!
    
    @IBOutlet var top: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
