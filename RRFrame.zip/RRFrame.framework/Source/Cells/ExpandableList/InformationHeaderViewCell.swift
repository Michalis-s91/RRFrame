//
//  InformationHeaderViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 29/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// InformationHeaderViewCell is a cell that is been used at store information view and shows store address,status and telephone number.
class InformationHeaderViewCell: UITableViewCell {

    @IBOutlet var addressLabel: UILabel!
    @IBOutlet var statusLabel: UILabel!
    @IBOutlet var phoneLabel: UILabel!
    @IBOutlet var findUsLabel: UILabel!
    
    @IBOutlet var phoneImage: UIImageView!
    @IBOutlet var mapImage: UIImageView!
    @IBOutlet var hoursHeader: UILabel!
    
    @IBOutlet var phoneView: UIView!
    @IBOutlet var mapView: UIView!
    
    @IBOutlet var mapImageWidth: NSLayoutConstraint!
    @IBOutlet var mapLabelLeading: NSLayoutConstraint!
    
    var store : StoreModel!
    var navigationController : UINavigationController!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let onPhoneClick = UITapGestureRecognizer(target: self, action: #selector(InformationHeaderViewCell.onPhoneClick))
        phoneView.isUserInteractionEnabled = true
        phoneView.addGestureRecognizer(onPhoneClick)
        
        let onMapClick = UITapGestureRecognizer(target: self, action: #selector(InformationHeaderViewCell.onMapClick))
        mapView.isUserInteractionEnabled = true
        mapView.addGestureRecognizer(onMapClick)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @objc func onPhoneClick (sender: UITapGestureRecognizer) {
        if(phoneLabel.text != nil)
        {
            UIApplication.shared.openURL(URL(string: "tel://" + phoneLabel.text!)!)
        }
    }
    
    @objc func onMapClick (sender:UITapGestureRecognizer) {
        if(store.latitude != nil && store.longitude != nil)
        {
            isViewPushed = true
            let MapStoryBoard : UIStoryboard = UIStoryboard(name: "MapView", bundle: nil)
            let mapView =  MapStoryBoard.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
            mapView.longitude = store.longitude
            mapView.latitude = store.latitude
            mapView.name = store.description
            mapView.address = store.address1
            navigationController?.pushViewController(mapView, animated: true)
        }
    }

}
