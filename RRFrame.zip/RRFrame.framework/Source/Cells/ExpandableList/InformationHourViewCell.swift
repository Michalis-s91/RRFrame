//
//  InformationHourViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 25/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// InformationHourViewCell is a cell that is been used for showing the hours for specific date that a store is open.
class InformationHourViewCell: UITableViewCell {

    @IBOutlet var dayLabel: UILabel!
    @IBOutlet var hoursLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        hoursLabel.sizeToFit()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        //hoursLabel.sizeToFit()
        // Configure the view for the selected state
    }

}
