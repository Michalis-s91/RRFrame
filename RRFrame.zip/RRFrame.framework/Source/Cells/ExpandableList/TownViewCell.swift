//
//  TownViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 21/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class TownViewCell: UITableViewCell {

    @IBOutlet var cityLabel: UILabel!
    @IBOutlet var expandImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
