//
//  TownViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 23/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// TownViewCell is a cell that is been used in stores locator view and shows a available town for specific business.
class ExpandableParentViewCell: UITableViewCell {

    @IBOutlet var parentLabel: UILabel!
    @IBOutlet var expandImage: UIImageView!
    @IBOutlet var parentImage: UIImageView!
    @IBOutlet var backgroundImage: UIImageView!
    @IBOutlet var indicator: UIActivityIndicatorView!
    
    @IBOutlet var parentImageHeight: NSLayoutConstraint!
    @IBOutlet var expandImageHeight: NSLayoutConstraint!
    @IBOutlet var labelWidth: NSLayoutConstraint!
    @IBOutlet var labelHeight: NSLayoutConstraint!
    @IBOutlet var parentImageBottom: NSLayoutConstraint!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
