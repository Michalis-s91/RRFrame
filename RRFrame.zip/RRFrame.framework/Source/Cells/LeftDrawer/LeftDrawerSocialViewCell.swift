//
//  LeftDrawerSocialViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 09/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class LeftDrawerSocialViewCell: LeftDrawerViewCell {

    @IBOutlet var firstImage: UIImageView!
    @IBOutlet var secondmage: UIImageView!
    @IBOutlet var thirdmage: UIImageView!
    @IBOutlet var fourthmage: UIImageView!
    
    
    @IBOutlet var firstimageLeading: NSLayoutConstraint!
    @IBOutlet var secondImageLeading: NSLayoutConstraint!
    @IBOutlet var thirdImageLeading: NSLayoutConstraint!
    @IBOutlet var fourthImageLeading: NSLayoutConstraint!
    
    @IBOutlet var firstImageWidth: NSLayoutConstraint!
    @IBOutlet var secondImageWidth: NSLayoutConstraint!
    @IBOutlet var thirdImageWidth: NSLayoutConstraint!
    @IBOutlet var fourthImageWidth: NSLayoutConstraint!
    
    var socialMedia : [SocialMediaModel]! = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        let onFirstimageclick = UITapGestureRecognizer(target: self, action: #selector(LeftDrawerSocialViewCell.onFirstimageclick))
        firstImage.isUserInteractionEnabled = true
        firstImage.addGestureRecognizer(onFirstimageclick)
        
        let onSecondimageclick = UITapGestureRecognizer(target: self, action: #selector(LeftDrawerSocialViewCell.onSecondimageclick))
        secondmage.isUserInteractionEnabled = true
        secondmage.addGestureRecognizer(onSecondimageclick)
        
        let onThirdimageclick = UITapGestureRecognizer(target: self, action: #selector(LeftDrawerSocialViewCell.onThirdimageclick))
        thirdmage.isUserInteractionEnabled = true
        thirdmage.addGestureRecognizer(onThirdimageclick)
        
        let onFourthimageclick = UITapGestureRecognizer(target: self, action: #selector(LeftDrawerSocialViewCell.onFourthimageclick))
        fourthmage.isUserInteractionEnabled = true
        fourthmage.addGestureRecognizer(onFourthimageclick)
        
        /*socialMedia = parameterizationDatabase.getSocialMedia()
        
        var i = 0
        var imageWidth = Int(self.contentView.frame.width / CGFloat(socialMedia.count))
        for s in socialMedia
        {
            let image = UIImageView()
            
            switch s.type
            {
                case SocialMediaTypes.Facebook.rawValue:
                    image.image = UIImage(named: "ic_facebook")?.withRenderingMode(.alwaysTemplate)
                case SocialMediaTypes.Instangram.rawValue:
                    image.image = UIImage(named: "ic_instangram")?.withRenderingMode(.alwaysTemplate)
                case SocialMediaTypes.Twitter.rawValue:
                    image.image = UIImage(named: "ic_twitter")?.withRenderingMode(.alwaysTemplate)
                case SocialMediaTypes.Internet.rawValue:
                    image.image = UIImage(named: "ic_internet")?.withRenderingMode(.alwaysTemplate)
                default:
                    break
            }
            
            image.tintColor = Colors.leftDrawerTintColor
            
            image.frame = CGRect(x: (i * imageWidth) + ((i + 1) * 10) , y: Int((contentView.frame.size.height - 30) / 2), width: 30, height: 30)
            
            i += 1
        }*/
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @objc func onFirstimageclick (sender:UITapGestureRecognizer) {
        //restartApp = false
        if(socialMedia.count > 0 && NSURL(string: socialMedia[0].link) != nil)
        {
            UIApplication.shared.openURL(NSURL(string: self.socialMedia[0].link)! as URL)
        }
    }
    
    @objc func onSecondimageclick (sender:UITapGestureRecognizer) {
        //restartApp = false
        if(socialMedia.count > 1 && NSURL(string: socialMedia[1].link) != nil)
        {
            UIApplication.shared.openURL(NSURL(string:socialMedia[1].link)! as URL)
        }
    }
    
    @objc func onThirdimageclick (sender:UITapGestureRecognizer) {
        //restartApp = false
        if(socialMedia.count > 2 && NSURL(string: socialMedia[2].link) != nil)
        {
            UIApplication.shared.openURL(NSURL(string: socialMedia[2].link)! as URL)
        }
    }
    
    @objc func onFourthimageclick (sender:UITapGestureRecognizer) {
        //restartApp = false
        if(socialMedia.count > 3 && NSURL(string: socialMedia[3].link) != nil)
        {
            UIApplication.shared.openURL(NSURL(string: socialMedia[3].link)! as URL)
        }
    }
}
