//
//  LeftDrawerViewCell.swift
//  RichReach2
//
//  Created by Eumbrella on 08/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// LeftDrawerViewCell is a cell that is been used for left drawer groups
class LeftDrawerViewCell: UITableViewCell {

    @IBOutlet weak var leftDrawerLabel: UILabel!
    @IBOutlet weak var leftDrawerImage: UIImageView!
    @IBOutlet weak var leftDrawerExpand: UIImageView!
    @IBOutlet var line: UIView!
    
    @IBOutlet var leftDrawerImageWidth: NSLayoutConstraint!
    @IBOutlet var lableLeadingSpace: NSLayoutConstraint!
    @IBOutlet var lineLeading: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
