//
//  HelpAndSupportViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 21/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// HelpAndSupportViewModel holds the local database, support types, selected support type, name, message and verification message.
class HelpAndSupportViewModel {
    let supportTypes = StaticDataRepository.getSupportTypesStrings()
    var selectedType : String!
    var name : String!
    var message : String = ""
    var verificationMessage : String!
    
    
    /// Constructor. Sets the selected support type.
    init(){
        selectedType = supportTypes[0].textStr
    }
    
    
    /// Submit the message using API
    func submitMessage()
    {
        let appUser = localDatabase.getAppUser()
        
        DispatchQueue.main.async(execute: {() -> Void in
            do{
                if(appUser != nil)
                {
                    if( isNullOrEmpty(string : appUser?.name)  && isNullOrEmpty(string : appUser?.surname))
                    {
                        self.name = "RichReach"
                    }
                    else if(!isNullOrEmpty(string : appUser?.name) && isNullOrEmpty(string : appUser?.surname))
                    {
                        self.name = (appUser?.name)!
                    }
                    else if(isNullOrEmpty(string : appUser?.name) && !isNullOrEmpty(string : appUser?.surname))
                    {
                        self.name = (appUser?.surname)!
                    }
                    else
                    {
                        self.name = (appUser?.name)! + " " + (appUser?.surname)!
                    }
                    
                    let httpRequest = HttpRequest()
                    
                    do
                    {
                        try httpRequest.post3(url: "http://www.commtor.com/webapi/CommunicationApi/SubmitMessage/", params: "ClientTelephone=\(appUser?.phoneNumber  ?? "")&Name=\(self.name ?? "")&Message=\(self.message)&Support=\(self.selectedType ?? "")")
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    self.verificationMessage = httpRequest.requestResponse
                    
                    if (self.verificationMessage == nil)
                    {
                        self.verificationMessage = NSLocalizedString("helpAndSupportResponseError", comment: "")
                    }
                    else
                    {
                        self.verificationMessage = removeQuotesCharacters(message: self.verificationMessage)
                    }
                }
                else
                {
                    self.verificationMessage = NSLocalizedString("missingData", comment: "")
                }
            }
            catch
            {
                self.verificationMessage = NSLocalizedString("messageNotTransmitted", comment: "")
            }
        })
    }
}
