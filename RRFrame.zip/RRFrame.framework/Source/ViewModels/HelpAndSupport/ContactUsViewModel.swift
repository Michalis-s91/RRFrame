//
//  ContactUsViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 23/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ContactUsViewModel
{
    var types : [String] = []
    var selectedType : String!
    var model : ContactUsModel!
    var verificationMessage : String!
    
    func loadFromDB()
    {
        let contactUsViewId = viewsDB.findContactUsViewID(tabID : selectedTab.id)
        if(contactUsViewId != -1)
        {
            let  model : ContactUsModel! = viewsDB.getContactUsView(id : contactUsViewId)
            
            self.model = model
        }
    }
    
    func submitMessage(type : String, message : String )
    {
        let appUser = localDatabase.getAppUser()
        
        DispatchQueue.main.async(execute: {() -> Void in
            do{
                if(appUser != nil)
                {
                    let httpRequest = HttpRequest()
                    
                    do
                    {
                        try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplication/api/SupportApi/SubmitApkEmailMessage",params: "ApkID=\(businessID!)&PhoneNumber=\(appUser?.phoneNumber ?? "")&Name=\(appUser?.name ?? "")&Surname=\(appUser?.surname ?? "")&EmailAddress=\(appUser?.emailAddress ?? "")&Type=\(type ?? "")&Message=\(message ?? "")")
                    }
                    catch
                    {
                        self.verificationMessage = NSLocalizedString("messageNotTransmitted", comment: "")
                    }
                    
                    self.verificationMessage = httpRequest.requestResponse
                    
                    if (self.verificationMessage == nil)
                    {
                        self.verificationMessage = NSLocalizedString("helpAndSupportResponseError", comment: "")
                    }
                    else
                    {
                        self.verificationMessage = removeQuotesCharacters(message: self.verificationMessage)
                    }
                }
                else
                {
                    self.verificationMessage = NSLocalizedString("missingData", comment: "")
                }
            }
            catch
            {
                self.verificationMessage = NSLocalizedString("messageNotTransmitted", comment: "")
            }
        })
    }
}
