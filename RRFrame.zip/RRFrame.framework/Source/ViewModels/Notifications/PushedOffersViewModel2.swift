//
//  PushedOffersViewModel2.swift
//  RichReach
//
//  Created by Eumbrella on 23/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit


/// PushedOffersViewModel associated to the pushed offers view. It saves data about pushed offers and loads them from API.
class PushedOffersViewModel2
{
    static var offersPageToLoad = 0
    var partnerName : String!
    var campaingID : Int64!
    var selectedOffer : Offer!
    var offersList : [OfferModel] = []
    var noInternetConnectionAvailable = false
    var pushedOfferTable : UITableView!
    
    
    /// Constructor. Sets the page to load.
    init()
    {
        PushedOffersViewModel.offersPageToLoad = 2
    }
    
    
    /// Loads pushed offers from internet and returns them into a list.
    ///
    /// - Returns: A list with pushed offers.
    func loadFromInternet() -> [OfferModel]!
    {
        var items = NotificationsWebApi.getNotificationOffers(userPhone: (localDatabase.getAppUser()?.phoneNumber)!, pageNumber: 1)
        
        if(items != nil)
        {
            for i in items!
            {
                let isFavourite = localDatabase.isFavouriteOffer(offerID: i.appOfferID)
                
                i.isItemWatched = isFavourite
            }

            return items
        }
        else
        {
            return nil
        }
    }
    
    
    /// Insert/Delete pushed offers from. local database
    ///
    /// - Parameter offer: The offer we want to delete/add.
    func ModifyWishList(offer : OfferModel)
    {
        if (!offer.isItemWatched)
        {
            localDatabase.insertFavouriteOffer(offer: offer)
        }
        else
        {
            localDatabase.deleteFavouriteOfferByID(offerID: offer.appOfferID)
        }
    }
    
    
    /// Loads more pushed offers from internet. This function is been called when user reach the last vissible item of pushed offers list view.
    func loadMoreFromInternet()
    {
        let moreItems = NotificationsWebApi.getNotificationOffers(userPhone: localDatabase.getAppUser()!.phoneNumber, pageNumber: PushedOffersViewModel.offersPageToLoad)
        
        if(moreItems != nil)
        {
            for i in moreItems!
            {
                let isFavourite = localDatabase.isFavouriteOffer(offerID: i.appOfferID)
                
                let offerModel = OfferModel()
                
                offerModel.appOfferID = i.appOfferID
                offerModel.Description = i.Description
                offerModel.imageUrl = i.imageUrl
                offerModel.largeImageUrl = i.largeImageUrl
                offerModel.originalPrice = i.originalPrice
                offerModel.offerDescription = i.offerDescription
                offerModel.offerNewPrice = i.offerNewPrice
                offerModel.isStrikethrough = i.isStrikethrough
                offerModel.isItemWatched = isFavourite
                offerModel.partnerName = i.partnerName
                offerModel.isPrivate = i.isPrivate
                offerModel.isGeneralOffer = i.isGeneralOffer
                offerModel.duration = i.duration
                offerModel.isNoPriceToShowOffer = i.isNoPriceToShowOffer
                offerModel.isPriceListOffer = i.isPriceListOffer
                offerModel.isSetOffer = i.isSetOffer
                
                offersList.append(offerModel)
            }
            
            DispatchQueue.main.async(execute: {() -> Void in
                self.pushedOfferTable.reloadData()
            })
            
            if (moreItems != nil && (moreItems?.count)! > 0)
            {
                PushedOffersViewModel.offersPageToLoad += 1
            }
        }
    }
}
