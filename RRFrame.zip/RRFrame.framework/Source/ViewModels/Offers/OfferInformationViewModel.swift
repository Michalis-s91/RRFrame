//
//  OfferInformationViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// OfferInformationViewModel is the view model associated to the offer informations view. It is used for loading from internet offer information and setting stores info list.
class OfferInformationViewModel
{
    var offer : OfferModel
    
    var  informationsList : [GeneralInformation] = []
    
    var campaignID : Int64!
    static var orderProduct : OrderProduct!
    static var orderProductBrandName : String!
    var title : String!
    var offerDuration : String!
    var imageUrl : String!
    var productInformationSectionTitle : String
    var originalPrice : String!
    var originalPriceTitle : String!
    var barcode : String!
    var erpReferenceCode : String!
    var description : String!
    var offerDescription : String!
    var stores : [StoresInfo]!
    var offerNewPrice : String!
    var isStrikeThrough : Bool!
    var isPriceListOffer : Bool!
    var isNoPriceToShowOffer : Bool!
    var isSetOffer : Bool!
    var isGeneralOffer : Bool!
    var isOrderProduct : Bool!
    var isOfferProduct : Bool!
    private var isNotGeneralOffer : Bool!
    var IsNotGeneralOffer : Bool!
    {
        get
        {
            if (isSetOffer)
            {
                isNotGeneralOffer = false
                return isNotGeneralOffer
            }
            
            isNotGeneralOffer = !ToAvoidOfferDetails
            return isNotGeneralOffer
        }
        
        set (isNotGeneralOffer)
        {
            self.isNotGeneralOffer = isNotGeneralOffer
        }
    }
    var hasExtendedDescription = false
    var hasTermsAndConditions = false
    private var toAvoidOfferDetails : Bool!
    var ToAvoidOfferDetails : Bool!
    {
        get
        {
            if (isGeneralOffer || isPriceListOffer || isNoPriceToShowOffer)
            {
                toAvoidOfferDetails = true
            }
            else
            {
                toAvoidOfferDetails = false
            }
            
            return toAvoidOfferDetails
        }
        
        set (toAvoidOfferDetails)
        {
            self.toAvoidOfferDetails = toAvoidOfferDetails
        }
    }
    var isOfferInformationLoaded = false
    private var termsAndConditions : String!
    var TermsAndConditions : String!
    {
        get
        {
            return self.termsAndConditions
        }
        
        set (termsAndConditions)
        {
            self.termsAndConditions = termsAndConditions
            if(isNullOrEmpty(string: termsAndConditions))
            {
                hasTermsAndConditions = false
            }
            else
            {
                self.termsAndConditions = removeBackSlashSpecialCharacters(str: termsAndConditions)
                hasTermsAndConditions = true
            }
        }
    }
    
    private var extendedDescription : String!
    var ExtendedDescription : String!
    {
        get
        {
            return self.extendedDescription
        }
        
        set (extendedDescription)
        {
            self.extendedDescription = extendedDescription
            if (isNullOrEmpty(string: extendedDescription))
            {
                hasExtendedDescription = false
            }
            else
            {
                self.extendedDescription = removeBackSlashSpecialCharacters(str: extendedDescription)
                hasExtendedDescription = true
            }
        }
    }
    var offersList : [OfferItemModel]!
    var imagesUrls : [String]!
    
    
    /// Consrtuctor. Sets the offer and view controller.
    ///
    /// - Parameters:
    ///   - offer: The offers
    ///   - viewController: The current view controller.
    init(offer : inout OfferModel, viewController : UIViewController)
    {
        if (offer == nil || isNullOrEmpty(string: offer.Description) )
        {
            productInformationSectionTitle = NSLocalizedString("productInformation", comment:"")
            isOfferProduct = false
            
            offer = OfferModel()
            
            offer.productID = OfferInformationViewModel.orderProduct.productID
            offer.Description = OfferInformationViewModel.orderProduct.productDescription
            offer.imageUrl = OfferInformationViewModel.orderProduct.imageUrl
            offer.originalPrice = OfferInformationViewModel.orderProduct.priceInclVatStr
            offer.isGeneralOffer = true
            offer.partnerName = OfferInformationViewModel.orderProductBrandName
            offer.offerDescription = (OfferInformationViewModel.orderProduct.priceInclVatStr + (OfferInformationViewModel.orderProduct.lineDiscount != 0.0 ? " (-" + OfferInformationViewModel.orderProduct.lineDiscountStr + ")" : ""))
            
            barcode = OfferInformationViewModel.orderProduct.barcode
            erpReferenceCode = OfferInformationViewModel.orderProduct.ERPReferenceCode
            OfferInformationViewModel.orderProduct = nil
            OfferInformationViewModel.orderProductBrandName = nil
        }
        else
        {
            if(APK == APKsEnum.RichReach.rawValue)
            {
                productInformationSectionTitle = NSLocalizedString("productServiceInformation", comment:"")
            }
            else
            {
                productInformationSectionTitle = "Description"
            }
            
            isOfferProduct = true
        }
        
        isOrderProduct = !isOfferProduct
        
        self.offer = offer
        self.title = offer.partnerName
        self.originalPrice = offer.originalPrice
        
        self.description = offer.Description
        self.offerDescription = offer.offerDescription
        if (!isNullOrEmpty(string: offerDescription) && offerDescription.starts(with: "Price"))
        {
            var offerDescriptionTokens = offerDescription.split(separator: " ")
            offerDescription = String(offerDescriptionTokens[1])
        }
        
        if (!isNullOrEmpty(string: offer.largeImageUrl))
        {
            imageUrl = offer.largeImageUrl
        }
        else
        {
            imageUrl = offer.imageUrl
        }
        
        self.offerNewPrice = offer.offerNewPrice
        self.isStrikeThrough = offer.isStrikethrough
        self.isGeneralOffer = offer.isGeneralOffer
        self.isNoPriceToShowOffer = offer.isNoPriceToShowOffer
        self.isPriceListOffer = offer.isPriceListOffer
        self.isSetOffer = offer.isSetOffer
    }
    
    
    /// Replaces backslash related special characters (e.g. "\n\r") with the proper value.
    ///
    /// - Parameter str: The input string.
    /// - Returns: The new string.
    func removeBackSlashSpecialCharacters(str : String) -> String
    {
        return replaceBackslashSpecialCharacters(str: str)
    }
    
    
    /// Creates the offer description to be shared along with the offer image (if one exists).
    ///
    /// - Returns: The offer description to be shared.
    func getOfferShareDescription() -> String
    {
        var description : String
        description = self.title + "\n" +  self.description + "\n"
        
        if(ToAvoidOfferDetails)
        {
            let s = NSLocalizedString("downloadRichReachForAndroid", comment: "")
            description = "\(description)\(offerDuration)\n\(offerDescription)\n\(s)"
        }
        else if(isSetOffer)
        {
            description = description + offerDuration + "\n" + NSLocalizedString("downloadRichReachForAndroid", comment: "")
        }
        else
        {
            let s = NSLocalizedString("downloadRichReachForAndroid", comment: "")
            description = "\(description)\(offerDuration)\n\(originalPriceTitle)  \(originalPrice) \(offerDescription)  \(offerNewPrice)\n\(s)"
        }
        
        return description
    }
    
    
    /// Returns the original price title.
    ///
    /// - Returns: The original price title.
    func getOriginalPriceTitle() -> String
    {
        if (isStrikeThrough)
        {
            return NSLocalizedString("priceTitleStrikeThrough", comment: "")
        }
        else
        {
            return NSLocalizedString("priceTitleNotStrikeThrough", comment: "")
        }
    }
    
    
    /// Load offer information from internet.
    func loadFromInternet()
    {
        if(isOfferProduct)
        {
            loadOfferInformation()
        }
        else
        {
            loadOrderProductInformation()
        }
        
        if (isNullOrEmpty(string: offerDuration))
        {
            offerDuration = NSLocalizedString("noAvailableInformation", comment: "")
        }
        
        if (isNullOrEmpty(string: extendedDescription))
        {
            extendedDescription = NSLocalizedString("noAvailableInformation", comment: "")
        }
        
        if (isNullOrEmpty(string: termsAndConditions))
        {
            termsAndConditions = NSLocalizedString("noAvailableInformation", comment: "")
        }
        
        
        
        if(isSetOffer)
        {
            //loadComboOfferInformation()
            informationsList.append(GeneralInformation(type : 6, appOfferID: offer.appOfferID))
        }
        else
        {
            informationsList.append(GeneralInformation(type : 0, title: description))
            informationsList.append(GeneralInformation(type : 1, imageUrl: imageUrl))
        }
        
        if(erpReferenceCode != nil)
        {
            informationsList.append(GeneralInformation(type : 2, title: "ERP Reference Code", description : erpReferenceCode))
        }
        
        if(barcode != nil)
        {
            informationsList.append(GeneralInformation(type : 2, title: "Barcode", description : barcode))
        }
        
        if(APK == APKsEnum.RichReach.rawValue)
        {
            if(ToAvoidOfferDetails)
            {
                informationsList.append(GeneralInformation(type : 2, title: "Price", description : offerDescription))
            }
            else
            {
                if(isSetOffer)
                {
                    informationsList.append(GeneralInformation(type : 3, title: "Price",originalPriceTitle : "Before" , originalPriceText : originalPrice , offerDescriptionText : "Now" , offerNewPrice : offerNewPrice))
                }
                else
                {
                    informationsList.append(GeneralInformation(type : 3, title: "Price",originalPriceTitle : getOriginalPriceTitle() , originalPriceText : originalPrice , offerDescriptionText : offerDescription , offerNewPrice : offerNewPrice))
                }

            }
        }
        
        if(ExtendedDescription != nil)
        {
            informationsList.append(GeneralInformation(type : 2, title: productInformationSectionTitle, description : ExtendedDescription))
        }
        
        informationsList.append(GeneralInformation(type : 2, title: "Offer Availability", description : offerDuration))
        
        if(APK == APKsEnum.RichReach.rawValue)
        {
            informationsList.append(GeneralInformation(type : 4, title: "Points of Sale", stores : stores))
        }
        
        informationsList.append(GeneralInformation(type : 2, title: "Terms & Conditions", description : termsAndConditions))
    }
    
    
    /// Loads offer information. Is been called when user attempts to view the product information from within the offers section.
    func loadOfferInformation()
    {
        //let infoData = OrderProductsWebApi.getOfferAvailability(userPhone: (localDatabase.getAppUser()?.phoneNumber)!, appOfferID: offer.appOfferID)
        let infoData = OrderProductsWebApi.getOfferInformation(campaignID: offer.campaignID, phoneNumber: (localDatabase.getAppUser()?.phoneNumber)!, storeOfferForAppID: offer.appOfferID)
        
        isOfferInformationLoaded = true
        offerDuration = infoData?.duration
        ExtendedDescription = infoData?.extendedDescription
        termsAndConditions = infoData?.termsAndConditions
        stores = infoData?.stores
    }
    
    
    /// Loads the product information. Is been called when user attempts to view product information from within the eOrdering section.
    func loadOrderProductInformation()
    {
        let productInformation = OrderProductsWebApi.getOrderProductInformation(productID: offer.productID)
        ExtendedDescription = productInformation?.extendedDescription
        
        var tmpStores : [StoresInfo] = []
        let storesListSize : Int = (productInformation?.storesList.count)!
        if(productInformation?.storesList != nil && storesListSize > 0)
        {
            for store in (productInformation?.storesList)!
            {
                let storesInfo =  StoresInfo(name: store.description ,address: store.address ,phone: store.contactPhone,latitude: store.latitude,longitude: store.longitude)
                tmpStores.append(storesInfo)
            }
        }
        
        stores = tmpStores
    }
    
    
    /// If the offer is combo offer we load informations for each item of offer.
    func loadComboOfferInformation()
    {
        offersList =  OfferItemsWebApi.getOfferItems( userPhone: (localDatabase.getAppUser()?.phoneNumber)!,appOfferID: offer.appOfferID)
        imagesUrls = []
        
        //create list with images URLs
        var i = 0
        while( i < offersList.count)
        {
            imagesUrls.append(offersList[i].imageUrl)
            i += 1
        }
        
    }
    
}
