//
//  AllPartnersViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// AllPartnersViewModel is the view model associated to the all partners view. It is used for loading from internet partners and setting partners list.
class AllPartnersViewModel {

    var viewController : UIViewController!
    static var partnersPageToLoad = 0
    var currentAppVersion = ""
    var currentAppBuildVersion = ""
    var partnersList : [PartnerModel]! = []
    var requestNumber = 0
    var selectedPartner : PartnerModel!
    
    
    /// Constructor. Sets the view controller.
    ///
    /// - Parameter viewController: The current view controller.
    init(viewController : UIViewController)
    {
        self.viewController = viewController
    }

    
    /// Loads from internet only loyalty partners if loadLoyaltyPartnersOnly flag is true, otherwise loads all partners.
    /// And then will return the result into a list.
    ///
    /// - Parameter loadLoyaltyPartnersOnly: The loadLoyaltyPartnersOnly flag.
    /// - Returns: The list with partners.
    func loadFromInternet(loadLoyaltyPartnersOnly : Bool = false) -> [PartnerModel]!
    {
        var partnersList : [PartnerModel]! = []
        
        var phoneNumber = localDatabase.getAppUser()?.phoneNumber
        AllPartnersViewModel.partnersPageToLoad = 2
        
        if(!(localDatabase.isAPKRegistered(bussinessID: clientID)))
        {
            phoneNumber = ""
        }
        
        if(loadLoyaltyPartnersOnly)
        {
            partnersList = PartnersWebApi.getAllLoyaltyPartners( userPhone: phoneNumber!, isTesting: false, pageNumber: 1)
        }
        else
        {
            partnersList = PartnersWebApi.getPartners( userPhone: phoneNumber!, isTesting: false, pageNumber: 1, currentAppVersion: currentAppVersion, currentAppBuildVersion: currentAppBuildVersion)
        }
        
        return partnersList
    }
    
    
    /// Loads from internet only loyalty partners if loadLoyaltyPartnersOnly flag is true, otherwise loads all partners.
    /// And then we add the result to partners list which will return.
    ///
    /// - Parameter loadLoyaltyPartnersOnly: The loadLoyaltyPartnersOnly flag.
    func loadPartners(loadLoyaltyPartnersOnly : Bool)
    {
        var phoneNumber = localDatabase.getAppUser()?.phoneNumber
        var moreItems : [PartnerModel]!
        
        if(!(localDatabase.isAPKRegistered(bussinessID: clientID)))
        {
            phoneNumber = ""
        }
        
        if (loadLoyaltyPartnersOnly)
        {
            moreItems = PartnersWebApi.getAllLoyaltyPartners( userPhone: phoneNumber!, isTesting: false, pageNumber: AllPartnersViewModel.partnersPageToLoad)
        }
        else
        {
            moreItems = PartnersWebApi.getPartners( userPhone: phoneNumber!, isTesting: false, pageNumber: AllPartnersViewModel.partnersPageToLoad, currentAppVersion: currentAppVersion, currentAppBuildVersion: currentAppBuildVersion)
        }
        
        if (moreItems != nil)
        {
            for d in moreItems
            {
                var p = PartnerModel()
                
                p.partnerID =  d.partnerID
                p.name = d.name
                p.IsFavourite = d.IsFavourite
                p.isRoot = d.isRoot
                p.isLoyalty = d.isLoyalty
                p.loyaltyPoints = d.loyaltyPoints
                p.Information = d.Information
                p.imageUri = d.imageUri
                p.optInDate = d.optInDate
                p.storeInfo = d.storeInfo
                p.imageLargeUri = d.imageLargeUri
                p.website = d.website
                
                setOptInType( partner: &p)
                
                partnersList.append(p)
            }
            
            //If more items loaded more paging index to the next page
            if (moreItems.count > 0)
            {
                AllPartnersViewModel.partnersPageToLoad += 1
            }
        }
        
        requestNumber += 1
    }
    
    
    /// Sets the opt in type for the input partner.
    ///
    /// - Parameter partner: The input partner.
    private func setOptInType(partner : inout PartnerModel)
    {
        if (partner.isRoot)
        {
            partner.optInType = NSLocalizedString("OptInTypePreferred", comment: "")
        }
        else if (partner.IsFavourite)
        {
            partner.optInType = NSLocalizedString("OptInTypeFavourite", comment: "")
        }
        else
        {
            partner.optInType = NSLocalizedString("OptInTypeNone", comment: "")
        }
    }
    
    
    /// Loads shops information from internet and return them.
    ///
    /// - Parameter partner: Shops information.
    func getShopsInformation(partner : inout PartnerModel)
    {
        PartnersWebApi.getPartnerInformation( userPhone: localDatabase.getAppUser()!.phoneNumber, partner: &partner, language: "en")
        selectedPartner = partner
    }
    
    
    /// Cahnge isFavourite flag for input partner on local database.
    ///
    /// - Parameters:
    ///   - partner: The partner model.
    ///   - isFavourite: he isFavourite flag.
    /// - Throws: error
    func modifyFavourites(partner : PartnerModel , isFavourite : Bool) throws
    {
        let phoneNumber =  localDatabase.getAppUser()?.phoneNumber
        
        do
        {
            try PartnersWebApi.optInPartner(userPhone: phoneNumber!, partnerID: partner.partnerID, isOptin: !isFavourite)
        }
        catch
        {
            throw Errors.error
        }
        /*
        if (!isFavourite)
        {
            localDatabase.insertFavouritePartner( partner)
        }
        else
        {
            localDatabase.deleteFavouritePartnerByID( partner.partnerID)
        }*/
    }

}
