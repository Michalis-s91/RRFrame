//
//  WishListViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// WishListViewModel associated to the wish list view. It saves data about wish list and loads wish list from local database.
class WishListViewModel
{
    var favouriteOffersList : [OfferModel] = []
    var isWishListEmpty : Bool!
    var notAvailableView : NotAvailableViewController!
    var wishListTableView : UITableView!
    var container : UIView!
    var view : WishListView
    
    
    /// Constructor. Sets the not available view, wish list table view, container and the view.
    ///
    /// - Parameters:
    ///   - notAvailableView: The not available view.
    ///   - wishListTableView: The wish list table view.
    ///   - container: The container.
    ///   - view: The wish list view.
    init(notAvailableView : NotAvailableViewController!, wishListTableView : UITableView, container : UIView , view : WishListView)
    {
        self.notAvailableView = notAvailableView
        self.wishListTableView = wishListTableView
        self.container = container
        self.view = view
    }
    
    
    /// Loads wish list from local database and saves the result in favouriteOffersList list.
    func loadWishList()
    {
        let favourites = localDatabase.getAllFavouriteOffers()
        favouriteOffersList.removeAll()
        
        if(favourites != nil && favourites.count > 0)
        {
            isWishListEmpty = false
            
            for f in favourites
            {
                let offer = OfferModel()
                
                offer.appOfferID = f.appOfferID
                offer.Description = f.description
                offer.imageUrl = f.imageUrl
                offer.originalPrice = f.originalPrice
                offer.offerDescription = f.offerDescription
                offer.offerNewPrice = f.offerNewPrice
                offer.isStrikethrough = f.isStrikethrough
                offer.partnerName = f.partnerName
                offer.isItemWatched = true
                offer.isGeneralOffer = f.isGeneralOffer
                offer.isPrivate = f.isPrivate
                offer.duration = f.duration
                offer.isNoPriceToShowOffer = f.isNoPriceToShowOffer
                offer.isPriceListOffer = f.isPriceListOffer
                offer.isSetOffer = f.isSetOffer
                offer.largeImageUrl = f.largeImageUrl
                
                if(isOfferExpired(offerDuration: offer.duration))
                {
                    removeFromWishList(offer: offer, loadWishList: false)
                }
                else
                {
                    favouriteOffersList.append(offer)
                }
            }
        }
        else
        {
            isWishListEmpty = true
        }
        
        if(favouriteOffersList.count == 0)
        {
            isWishListEmpty = true
        }
        
        wishListTableView.reloadData()
        
        if(isWishListEmpty)
        {
            self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: view, container: container!, text: NSLocalizedString("noProductsInWishList", comment: ""))
            //self.notAvailableView.view.layer.zPosition = 0.5
        }
        else
        {
            if(notAvailableView != nil)
            {
                self.notAvailableView.view.removeFromSuperview()
                /*container.setNeedsLayout()
                container.layoutIfNeeded()
                self.view.viewDidLoad()
                self.view.viewWillAppear(true)*/
                //self.view.view.bringSubview(toFront: self.view.view )
                //self.notAvailableView.view.layer.zPosition = -1
                //self.view.viewDidLayoutSubviews()
                //self.view.view.layer.zPosition = 1
                //self.view.wishListTableView.layer.zPosition = 1
            }
        }
    }
    
    
    /// Returns whether the offer has expired or not.
    ///
    /// - Parameter offerDuration: Offer duration.
    /// - Returns: True if the offer has expired, otherwise false.
    func isOfferExpired(offerDuration : String) -> Bool
    {
        if(isNullOrEmpty(string: offerDuration))
        {
            return false
        }
        
        do
        {
            var tokens = offerDuration.split(separator:  " ")
            let endDateString = tokens[tokens.count - 1]
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yy"
            
            let endDate = dateFormatter.date(from: String(endDateString))
            let currentDate = Date()
            
            if (currentDate > endDate!)
            {
                return true
            }
        }
        catch
        {
        }
        
        return false
    }
    
    
    /// Removes given offer from wish list.
    ///
    /// - Parameters:
    ///   - offer: The offer we want to remove.
    ///   - loadWishList: Indicates if we have to load the change to wish list or not.
    func removeFromWishList(offer : OfferModel, loadWishList : Bool = false )
    {
        localDatabase.deleteFavouriteOfferByID(offerID: offer.appOfferID)
        var deletedObject : OfferModel!
        
        if(loadWishList)
        {
            for o in favouriteOffersList
            {
                if(o.appOfferID == offer.appOfferID)
                {
                    deletedObject = o
                }
            }
            
            if(deletedObject != nil)
            {
                favouriteOffersList.remove(at: favouriteOffersList.index(of: deletedObject)!)
                wishListTableView.reloadData()
            }
        }
    }
}
