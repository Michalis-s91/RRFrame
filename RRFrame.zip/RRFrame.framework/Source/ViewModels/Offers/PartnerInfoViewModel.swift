//
//  PartnerInfoViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 15/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// PartnerInfoViewModel associated to the partner info view. It saves data about partner information.
class PartnerInfoViewModel
{
    var information : String!
    var website : String!
    var facebookPage : String!
    var facebookPageID : String!
    var partner : PartnerModel!
    var stores : [StoresInfo]! = []
    var imageUri : String!
    
    var title : String!
    var informationsList : [GeneralInformation] = []
    
    
    /// Constructor. Sets partner model.
    ///
    /// - Parameter partner: The partner model.
    init(partner : PartnerModel)
    {
        self.partner = partner
        
        information = partner.Information
        
        if (!isNullOrEmpty(string: partner.imageLargeUri))
        {
            imageUri = partner.imageLargeUri
        }
        else
        {
            imageUri = partner.imageUri
            partner.imageLargeUri = imageUri
        }
        
        stores = partner.storeInfo
        website = partner.website
        facebookPage = partner.facebookPage
        facebookPageID = partner.facebookPageID
        title = partner.shortName
        
        if (isNullOrEmpty(string: information))
        {
            information = NSLocalizedString("noAvailableInformation", comment: "")
            partner.Information = information
        }
        
        if (isNullOrEmpty(string: website))
        {
            website = NSLocalizedString("noAvailableWebsite", comment: "")
            partner.website = website
        }
        
        informationsList.append(GeneralInformation(type: 1, imageUrl: imageUri) )
        informationsList.append(GeneralInformation(type: 2, title: "About", description : information))
        informationsList.append(GeneralInformation(type: 5, title: "Websites/Social Media Links", website : website, isHasFacebookPage : isHasFacebookPage(), facebookPage : facebookPage, facebookPageID : facebookPageID ))
        informationsList.append(GeneralInformation(type: 4, title: "Offices and Points of Sale", stores: stores))
    }
    
    
    /// Indicates wher partner has facebook page or not.
    ///
    /// - Returns: True if partner has facebook page, otherwise false.
    func isHasFacebookPage() -> Bool
    {
        if(isNullOrEmpty(string: facebookPage))
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    
    /// Modifies isFavourite field for specific partner. Also, informs local database and api for the change.
    ///
    /// - Parameter isFavourite: The isFavourite flag.(True if now partner is favourite, otherwise false)
    /// - Throws: error
    func modifyFavourites(isFavourite : Bool) throws
    {
        let phoneNumber = localDatabase.getAppUser()?.phoneNumber
        
        do
        {
            try PartnersWebApi.optInPartner(userPhone: phoneNumber!, partnerID: partner.partnerID, isOptin: !isFavourite)
        }
        catch
        {
            throw Errors.error
        }
        /*if (!isFavourite)
        {
            localDatabase.insertFavouritePartner(partner)
        }
        else
        {
            localDatabase.deleteFavouritePartnerByID(partner.getPartnerID())
        }*/
    }
}
