//
//  OffersViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 22/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// OffersViewModel is the view model associated to the offers view. It is used for loading offers from internet.
class OffersViewModel
{
    var informationsList : [GeneralInformation2] = []

    
    /// Constructor. Initialises the properties of class.
    init()
    {

    }
    
    func loadFromInternet() -> [GeneralInformation2]!
    {
        let string = "{\"GeneralInformationList\":[{\"Type\":1,\"Photo\":{\"Url\":\"http://93.109.209.42/Images/offer1.jpg\",\"Link\":\"https://beautyline.com.cy\",\"AspectRatio\":0.285}},{\"Type\":1,\"Photo\":{\"Url\":\"http://93.109.209.42/Images/offer2.png\",\"Link\":\"https://beautyline.com.cy\",\"AspectRatio\":0.285}},{\"Type\":1,\"Photo\":{\"Url\":\"http://93.109.209.42/Images/offer3.png\",\"Link\":\"https://beautyline.com.cy\",\"AspectRatio\":0.285}},{\"Type\":1,\"Photo\":{\"Url\":\"http://93.109.209.42/Images/offer4.JPG\",\"Link\":\"https://beautyline.com.cy\",\"AspectRatio\":0.285}},{\"Type\":1,\"Photo\":{\"Url\":\"http://93.109.209.42/Images/offer5.JPG\",\"Link\":\"https://beautyline.com.cy\",\"AspectRatio\":0.7}}]}"
        
        do
        {
            let decoder = JSONDecoder()
            let informations = try decoder.decode(Informations.self, from : (string.data(using: .utf8))!)
            
            informationsList = informations.informationsList
            
            return informationsList
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
}
