//
//  BarcodeViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 14/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation
import SQLite


/// BarcodeViewModel is the view model associated to the barcode view. It is used for creating a barcode ID using the user's phone number.
class BarcodeViewModel : BaseViewModel {
    
    var barcodeID : String = ""
    var barcodeView : BarcodeModel2!
    
    
    /// Constructor. Sets the barcode ID.
    override init() {
        
        if(APK != APKsEnum.BeautyLine.rawValue)
        {
            barcodeID = "CU" + (localDatabase.getAppUser()?.phoneNumber)!
        }
        
        if(viewsDB != nil)
        {
            barcodeView = viewsDB.getBarcodeView()
        }
    }
    
}
