//
//  HomeViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 15/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// HomeViewModel is the view model associated to the home view.
class GeneralViewViewModel
{
    var informationsList : [GeneralInformation2]! = []
    var view : ViewController!
    
    /*func loadFromInternet() -> [GeneralInformation2]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetGeneralView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let informations = try decoder.decode(Informations.self, from : (response.data(using: .utf8))!)
                
                informationsList = informations.informationsList
                
                return informations.informationsList
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }*/
    
    func loadFromLocalDB() -> [GeneralInformation2]!
    {
        do
        {
            //print("loading from local db")
            let generalInformations = viewsDB.getGenealInformations(tabID: selectedTab.id)
            //print("loaded from local db")
            return generalInformations
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
    
}


/// Helper class for deserialisation.
class Informations : Codable
{
    var informationsList : [GeneralInformation2]!
    
    private enum CodingKeys : String, CodingKey {
        case informationsList = "GeneralInformationList"
    }
}
