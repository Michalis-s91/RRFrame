//
//  DatePickerDialogViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 24/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// DatePickerDialogViewModel is the view model associated to the date picker dialog view.
class DatePickerDialogViewModel {
    var day : String!
    var Day : String {
        get
        {
            return self.day
        }
        
        set (day)
        {
            self.day = day
            SetFullDay()
        }
    }
    var month : String!
    var year : String!
    var errorMessage : String!
    var fullDay: String!
    var shouldDisplayErrorMessage = false
    var ShouldDisplayErrorMessage : Bool
    {
        get
        {
            return self.shouldDisplayErrorMessage
        }
        
        set (shouldDisplayErrorMessage)
        {
            self.shouldDisplayErrorMessage = shouldDisplayErrorMessage
            if (shouldDisplayErrorMessage)
            {
                viewController.errorMessageLabelHeight.constant = 20
                viewController.fullDayTopConstraint.constant = 15
            }
            else
            {
                viewController.errorMessageLabelHeight.constant = 0
                viewController.fullDayTopConstraint.constant = 0
                
            }
        }
    }
    var viewController : DatePickerDialog!
    
    var shouldDisplayFullDay = false
    var ShouldDisplayFullDay : Bool {
        get
        {
            return self.shouldDisplayFullDay
        }
        
        set (shouldDisplayFullDay)
        {
            self.shouldDisplayFullDay = shouldDisplayFullDay
            if (shouldDisplayFullDay)
            {
                viewController.fullDayHeightConstraint.constant = 17
                viewController.dayTopConstraint.constant = 8
                viewController.monthTopConstraint.constant = 8
                viewController.yearTopConstraint.constant = 8
            }
            else
            {
                viewController.fullDayHeightConstraint.constant = 0
                viewController.dayTopConstraint.constant = 0
                viewController.monthTopConstraint.constant = 0
                viewController.yearTopConstraint.constant = 0

            }
            
            viewController.fullDayLabel.text = fullDay
            
            viewController.dateView.layoutIfNeeded()
            viewController.dialogView.layoutIfNeeded()
            viewController.datePickerDialog.layoutIfNeeded()
        }
    }
    
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameter viewController: Current view controller.
    init(viewController : DatePickerDialog){
        month = NSLocalizedString("monthSpinnerViewDefaultText", comment: "")
        year = NSLocalizedString("yearSpinnerViewDefaultText", comment: "")
        errorMessage = NSLocalizedString("pleaseCompleteAllInformation", comment: "")
        self.viewController = viewController
        
        ShouldDisplayErrorMessage = false
    }
    
    
    /// Checks and returns whether the date specified by the user is valid or not.
    ///
    /// - Returns: True if the date is valid, otherwise false.
    func isDateValid(isYearRequired : Bool = true) -> Bool
    {
        if(isNullOrEmpty(string : day) || isNullOrEmpty(string : month) || (isNullOrEmpty(string : year) && isYearRequired)
            || month == NSLocalizedString("monthSpinnerViewDefaultText", comment: "") || (year ==  NSLocalizedString("yearSpinnerViewDefaultText", comment: "") && isYearRequired) )
        {
            return false
        }
        
        return true
    }
    
    
    /// Sets the full day.
    func SetFullDay(){
        if (isDateValid())
        {
            let dateTimeOperator = DateTimeOperator()
            
            var day = self.day
            
            if(day != nil && day?.count == 1)
            {
                day = "0" + day!
            }
            
            let month = dateTimeOperator.getMonthNumberFromMonthName(monthName: self.month)
            let dateStr = day! + "/" + month! + "/" + year!
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            

            if let date = dateFormatter.date(from: dateStr)
            {
                dateFormatter.dateFormat = "EEEE"
                fullDay = dateFormatter.string(from : date)
                
                ShouldDisplayFullDay =  true
            }
            else
            {
                ShouldDisplayFullDay = false
            }
        }
        else
        {
            ShouldDisplayFullDay = false
        }
    }
}

