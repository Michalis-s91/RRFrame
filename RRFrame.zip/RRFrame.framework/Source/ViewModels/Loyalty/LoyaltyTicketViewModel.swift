//
//  LoyaltyTicketViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 14/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// LoyaltyTicketViewModel is the view model associated to the loyalty ticket view. It is used for setting loyalty ticket list.
class LoyaltyTicketViewModel
{
    var partner : PartnerModel!
    static var ticket : LoyaltyStatementModel!
    static var loyaltyTicketPageToLoad = 0
    
    var ticketNo : String!
    var ticketDate : String!
    var previousPoints : String!
    var rewardPoints : String!
    var redemptionPoints : String!
    var totalPoints : String!
    var discountAmount : Double! = 0
    var totalAmount : String!
    var totalDiscountAmount : Double! = 0
    var totalGross : Double! = 0
    var hasDiscountAmount : Bool!
    private var loyaltyTicketList : [LoyaltyTicketModel] = []
    var LoyaltyTicketList : [LoyaltyTicketModel]!
    {
        get
        {
            return self.loyaltyTicketList
        }
        
        set (loyaltyTicketList)
        {
            self.loyaltyTicketList = loyaltyTicketList
            if (loyaltyTicketList == nil || loyaltyTicketList.count == 0)
            {
                isLoyaltyTicketNotAvailable = true
                isLoyaltyTicketAvailable = false
            }
            else
            {
                isLoyaltyTicketNotAvailable = false
                isLoyaltyTicketAvailable = true
            }
        }
    }
    var isLoyaltyTicketNotAvailable = false
    var isLoyaltyTicketAvailable = false
    var title : String!

    
    /// Constructor. Sets the local database and the partner.
    ///
    /// - Parameter partner: The partner.
    init(partner : PartnerModel)
    {
        self.partner = partner
        
        title = NSLocalizedString("loyaltyTicketTitle2", comment: "") //partner != nil && !isNullOrEmpty(string: partner.name) ? partner.name + " - " + NSLocalizedString("loyaltyTicketTitle", comment: "") : NSLocalizedString("loyaltyTicketTitle", comment: "")
        
        LoyaltyTicketViewModel.loyaltyTicketPageToLoad = 2
    }
    
    
    /// Loads loyalty tickets from internet.
    func loadFromInternet()
    {
        do
        {
            let list = try LoyaltyWebApi.getLoyaltyTicket(userPhone: (localDatabase.getAppUser()?.phoneNumber)!,
                                                       partnerID: Int64(partner.partnerID), ticketNo: LoyaltyTicketViewModel.ticket.ticketNo)

            if (list != nil && list.count > 0)
            {
                var hasReadDiscountAndTotalAmount = false
                
                for listItem in list
                {
                    loyaltyTicketList.append(listItem)
                    
                    if (!hasReadDiscountAndTotalAmount)
                    {
                        hasReadDiscountAndTotalAmount = true
                        totalAmount = listItem.amountWithVAT
                        
                        if(!isNullOrEmpty(string: listItem.discountAmount) && !(listItem.discountAmount == "0,00") && !(listItem.discountAmount == "0.00"))
                        {
                            hasDiscountAmount = true
                            discountAmount = Double(listItem.discountAmount)
                        }
                        
                        ticketNo = listItem.ticketNo
                        ticketDate = listItem.transDate
                        previousPoints = String(Int(LoyaltyTicketViewModel.ticket.balance)! + Int(listItem.redeemedPoints)! - Int(listItem.earnedPoints)!)
                        rewardPoints = listItem.earnedPoints
                        
                        if (listItem.redeemedPoints != nil && (listItem.redeemedPoints == "0"))
                        {
                            redemptionPoints = listItem.redeemedPoints
                        }
                        else
                        {
                            redemptionPoints = "-" + listItem.redeemedPoints
                        }
                        
                        totalPoints = listItem.totalPoints
                    }
                    
                    
                }
            }
        }
        catch
        {
            
        }
    }
}
