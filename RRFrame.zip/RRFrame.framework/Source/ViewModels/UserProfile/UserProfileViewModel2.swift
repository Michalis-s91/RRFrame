//
//  UserProfileViewModel2.swift
//  RichReach2
//
//  Created by Eumbrella on 26/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class UserProfileViewModel2
{
    var appUser : AppUser!
    var partnerCode = ""
    var registrationSourceType : Int!
    var fields : [FieldModel]!
    var vissibleField : FieldModel!
    var items : [UserProfileCellModel]! = []
    var verificationMessage : String!
    var viewController : ViewController!
    var isBlocked : Bool! = false
    var verificationType = 0
    var areAcceptNewsChanged = false
    var acceptNews : AcceptNewsModel!
    var serverResponse : VerificationResponseModel!
    
    /// Gets the user's profile information from our server and saves it to the device's local database.
    func getUserProfileInformationFromServer()
    {
        if(appUser == nil)
        {
            appUser = localDatabase.getAppUser()
        }
        
        let userProfile = RegistrationWebApi.getUserProfile(phone: (appUser?.phoneNumber)!)
        
        appUser.name = userProfile?.name
        appUser.surname = userProfile?.surname
        appUser.gender = userProfile?.gender
        appUser.emailAddress = userProfile?.emailAddress
        appUser.province = userProfile?.province
        appUser.city = userProfile?.city
        appUser.homeAddress = userProfile?.homeAddress
        appUser.postCode = userProfile?.postCode
        appUser.birthDate = userProfile?.birthDate
        appUser.hasLoyaltyProfile = true
        //appUser.hasVerifiedEmailAddress = (userProfile?.hasVerifiedEmailAddress)!
        
        localDatabase.updateAppUser(appUser: appUser)
    }
    
    /// Checks and returns whether the user information is already up-to-date or not.
    ///
    /// - Returns: True if the user information is already up-to-date, otherwise false.
    func isUserProfileInformationUpToDate() -> Bool
    {
        //let appUser = localDatabase.getAppUser()
        
        
        /*if(
         !areEqual(object1: appUser?.name as AnyObject?,object2: self.name as AnyObject?) ||
         !areEqual(object1: appUser?.surname as AnyObject?,object2: self.surname as AnyObject?) ||
         !areEqual(object1: appUser?.gender as AnyObject?,object2: self.selectedGender as AnyObject?) ||
         !areEqual(object1: appUser?.emailAddress as AnyObject?,object2: self.emailAddress as AnyObject?) ||
         (!((appUser?.province == nil || appUser?.province == "") && self.selectedProvinceStr == NSLocalizedString("provinceDefaultText", comment: "")) && (!areEqual(object1: appUser?.province as AnyObject?,object2: self.selectedProvinceStr as AnyObject?))) ||
         !areEqual(object1: appUser?.city  as AnyObject?,object2: self.city  as AnyObject?) ||
         !areEqual(object1: appUser?.homeAddress as AnyObject? ,object2: self.homeAddress  as AnyObject?) ||
         !areEqual(object1: appUser?.postCode  as AnyObject?,object2: self.postCode  as AnyObject?) ||
         ((!((appUser!.birthDate == "" ||  appUser!.birthDate == nil) && self.birthDate == NSLocalizedString("birthDateDefaultText", comment: ""))) && (!areEqual(object1: appUser?.birthDate  as AnyObject? ,object2: self.birthDate  as AnyObject?))))
         {
         return false
         }*/
        
        return true
    }
    
    /// Updates the user's profile information on both local and remote database.
    func updateUserProfile()
    {
        
    }
    
    /// Resends the verification code to the user.
    ///
    /// - Returns: The response of request.
    func resendVerificationCode() -> String
    {
        var mServerResponse = ""
        
        let appUser = localDatabase.getAppUser()
        
        if (appUser != nil)
        {
            do
            {
                mServerResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                //return mServerResponse
            }
            catch
            {
                
            }
        }
        
        return mServerResponse
        //return !IsNullOrEmpty.isNullOrEmpty(mServerResponse) ? mServerResponse : ""
    }
    
    var emailValidationStatus : EmailValidationStatus!
    
    func quickRegistration(appUser : AppUser)
    {
        RegistrationWebApi.quickRegistration(phoneNumber: appUser.phoneNumber, emailAddress: "", prefix: "357", carrier: (appUser.networkOperator), deviceID: (appUser.deviceID)!, applicationLanguage: "en")
    }
    
    /// Registers user
    func registerUser(updateAppUser : Bool = true) -> Bool
    {
        var result = true
        var appUser = localDatabase.getAppUser()
        
        if(appUser == nil)
        {
            appUser = AppUser()
        }
        
        /*for f in fields
         {
         switch f.type
         {
         case  UserProfileFieldType.Phoneumber.rawValue :
         if(verificationType == 0)
         {
         verificationType = VerificationType.PhoneNumber.rawValue
         }
         else if (verificationType == 2)
         {
         verificationType = VerificationType.PhoneNumberAndEmail.rawValue
         }
         case  UserProfileFieldType.Email.rawValue :
         if(verificationType == 0)
         {
         verificationType = 2 //VerificationType.Email.rawValue
         }
         else if(verificationType == 1)
         {
         verificationType = VerificationType.PhoneNumberAndEmail.rawValue
         }
         default:
         break
         }
         }*/
        
        
        if(!vissibleField.isVerified)
        {
            switch vissibleField.type
            {
            case  UserProfileFieldType.Phoneumber.rawValue :
                appUser?.phoneNumber = vissibleField.value
                appUser?.isPending = true
                
                quickRegistration(appUser: appUser!)
            case  UserProfileFieldType.Email.rawValue :
                if(updateAppUser)
                {
                    appUser?.emailAddress = vissibleField.value
                    appUser?.isPendingEmail = true
                }
                else
                {
                    appUser?.temporaryEmailAddress = vissibleField.value
                }
                
                //RegistrationWebApi.updateEmailAddress(phoneNumber: appUser!.phoneNumber, emailAddress: appUser?.emailAddress)
                emailValidationStatus = RegistrationWebApi.updateInitialRegistrationEmailAddress(phoneNumber: appUser!.phoneNumber, emailAddress: vissibleField.value)

                if(emailValidationStatus != nil)
                {
                    result = emailValidationStatus.isSuccessful
                }
                else
                {
                    result = false
                }
                
                /*case  UserProfileFieldType.Title.rawValue :
                 appUser?.title = f.value
                 case  UserProfileFieldType.Name.rawValue :
                 appUser?.name = f.value
                 case  UserProfileFieldType.Surname.rawValue :
                 appUser?.surname = f.value
                 case  UserProfileFieldType.Gender.rawValue :
                 appUser?.gender = Int(f.value)
                 case  UserProfileFieldType.Birthday.rawValue :
                 appUser?.birthDate = f.value
                 case  UserProfileFieldType.Address1.rawValue :
                 appUser?.homeAddress = f.value
                 case  UserProfileFieldType.Address2.rawValue :
                 appUser?.homeAddress2 = f.value
                 case  UserProfileFieldType.City.rawValue :
                 appUser?.city = f.value
                 case  UserProfileFieldType.PostCode.rawValue :
                 appUser?.postCode = f.value
                 case  UserProfileFieldType.District.rawValue :
                 appUser?.province = f.value
                 case  UserProfileFieldType.Country.rawValue :
                 appUser?.country = f.value*/
            default :
                break
            }
        }
        

        localDatabase.updateAppUser(appUser: appUser!)
    
        return result
        //localDatabase.insertPendingAPK(bussinessID: clientID)
    }
    
    
    
    /// Returns whether the user has received a verification code or not.
    ///
    /// - Returns: True if the user has received a verification code, otherwise false.
    func hasUserReceivedRegistrationVerificationCode() -> Bool
    {
        let appUser = localDatabase.getAppUser()
        if(appUser != nil)
        {
            return appUser!.hasReceivedRegistrationVerificationCode()
        }
        
        return false
    }
    
    
    /// Gets the verification code.
    func getVerificationCodePost()
    {
        
        
    }
    
    
    /// Verifies the code provided by the user.
    func verifyVerificationCode(field : FieldModel, isEditingField : Bool! = false)
    {
        verificationType = 0
        
        for f in fields
        {
            switch f.type
            {
            case  UserProfileFieldType.Phoneumber.rawValue :
                if(verificationType == 0)
                {
                    verificationType = VerificationType.PhoneNumber.rawValue
                }
                else if (verificationType == 2)
                {
                    verificationType = VerificationType.PhoneNumberAndEmail.rawValue
                }
            case  UserProfileFieldType.Email.rawValue :
                if(verificationType == 0)
                {
                    verificationType = 2 //VerificationType.Email.rawValue
                }
                else if(verificationType == 1)
                {
                    verificationType = VerificationType.PhoneNumberAndEmail.rawValue
                }
            default:
                break
            }
        }
        
        verificationMessage = nil
        let appUSer = localDatabase.getAppUser()
        if (appUSer != nil)
        {
            serverResponse = nil
            
            switch field.type
            {
            case  UserProfileFieldType.Phoneumber.rawValue :
                serverResponse = RegistrationWebApi.verifyPhoneNumber(phoneNumber: (appUSer?.phoneNumber)!, code: field.verificationCode, deviceID: (appUSer?.deviceID)!, partnerCode: partnerCode,  registrationSourceType: registrationSourceType, verificationType: verificationType)
            case  UserProfileFieldType.Email.rawValue :
                serverResponse = RegistrationWebApi.verifyEmailAddress(phoneNumber: (appUSer?.phoneNumber)!, emailAddress : !isNullOrEmpty(string: appUSer?.temporaryEmailAddress) ? appUSer!.temporaryEmailAddress : (appUSer?.emailAddress)! , code: field.verificationCode, deviceID: (appUSer?.deviceID)!, partnerCode: partnerCode,  registrationSourceType: registrationSourceType, verificationType: self.verificationType)
            default:
                break
            }
            
            if(serverResponse != nil)
            {
                if (serverResponse.verificationStatus ==  ApiResponseEnumType.OK.rawValue)
                {
                    //appUSer?.verificationTimeStamp = Date()
                    //appUSer?.isPending = false
                    //appUSer?.isRegistered = true
                    //appUSer?.partnerCode = partnerCode
                    
                    //serverResponse.phoneNumberCount = 0
                    //serverResponse.emailAddressCount = 2
                    
                    switch field.type {
                    case UserProfileFieldType.Phoneumber.rawValue:
                        serverResponse.fieldCount = serverResponse.phoneNumberCount
                        
                        appUSer?.phoneNumberCount = serverResponse.phoneNumberCount
                        appUSer?.hasVerifiedPhoneNumber = true
                        appUSer?.mobilePhoneVerifiedIPAddress = serverResponse.userIPAddress
                        appUSer?.mobilePhoneVerifiedDatetime = serverResponse.verificationDate
                        appUSer?.emailAddressCount = serverResponse.emailAddressCount
                        /*if(APK != Bundle.main.bundleIdentifier! && APK != APKsEnum.Test.rawValue)
                        {
                            self.loadUserOptins()
                            self.loadUserProfileInformation()
                            self.loadUserDefaultOptions()
                            
                            localDatabase.insertVerifiedAPK(bussinessID: ClientIDs.RichReach.rawValue , isBlocked: false)
                            localDatabase.insertRegisteredAPK(bussinessID: ClientIDs.RichReach.rawValue)
                            
                            //AppDelegate.registerForPushNotifications(application: appApplication)
                        }*/
                        
                    case UserProfileFieldType.Email.rawValue:
                        serverResponse.fieldCount = serverResponse.emailAddressCount
                        
                        appUSer?.emailAddressCount = serverResponse.emailAddressCount
                        appUSer?.hasVerifiedEmailAddress = true
                        appUSer?.emailVerifiedIPAddress = serverResponse.userIPAddress
                        appUSer?.emailVerifiedDatetime = serverResponse.verificationDate
                    default:
                        break
                    }
                    
                    if(isEditingField)
                    {
                        appUSer?.emailAddress = appUSer?.temporaryEmailAddress
                        appUSer?.temporaryEmailAddress = ""
                    }
                    
                    localDatabase.updateAppUser(appUser: appUSer!)
                    field.isVerified = true
                }
                else
                {
                    updateVerificationMessage(serverResponse: serverResponse.verificationStatus)
                }
            }
            else
            {
                updateVerificationMessage(serverResponse: -2)
            }
        }
        else
        {
            verificationMessage =  NSLocalizedString("accountNotFound", comment: "")
        }
    }
    
    /// Loads the user's optins.
    func loadUserOptins()
    {
        do
        {
            let partners = RegistrationWebApi.getOptinPartners(phoneNumber: (localDatabase.getAppUser()?.phoneNumber)!)
            
            if (partners != nil && (partners?.count)! > 0)
            {
                for partnerModel in partners!
                {
                    if(partnerModel.isRoot)
                    {
                        let tempTap = selectedTab
                        let appUser = localDatabase.getAppUser()
                        appUser?.partnerID = partnerModel.partnerID
                        appUser?.partnerName = partnerModel.name
                        appUser?.partnerShortName = partnerModel.shortName
                        appUser?.partnerImageUri = partnerModel.imageUri
                        
                        appUser?.displayWhiteLabelPartner = true
                        appUser?.isPromocodeApplied = true
                        
                        ViewController.displayWhiteLabelPartner = true
                        localDatabase.updateAppUser(appUser: appUser!)
                        
                        for tab in leftDrawer.leftDrawerTabsList
                        {
                            if(tab.type == LeftDrawerTabsType.Preferred.rawValue)
                            {
                                tab.isVissible = true
                                parameterizationDatabase.updateLeftDrawerTab(tab : tab)
                                
                                LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
                                LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
                                
                                let initializer = APKInitializer()
                                APKInitializer.setProperties()
                                
                                leftDrawer.viewDidLoad()
                                leftDrawer.tableView.reloadData()
                                
                                //                            for tab in leftDrawer.leftDrawerTabsList
                                //                            {
                                //                                if(tab.type == LeftDrawerTabsType.Profile.rawValue)
                                //                                {
                                //                                    selectedTab = tab
                                //                                }
                                //                            }
                                DispatchQueue.main.async(execute: {() -> Void in
                                    leftDrawer.selectTab(tabString: (tempTap?.name)!)
                                    
                                    for t in leftDrawer.leftDrawerTabsList
                                    {
                                        if(t.type == LeftDrawerTabsType.Profile.rawValue)
                                        {
                                            //leftDrawer.showView(tab: t, index : i)
                                            leftDrawer.currentTab = t.name
                                            selectedTab = t
                                            break
                                        }
                                    }
                                })
                            }
                        }
                    }
                    
                    partnerModel.IsFavourite = true
                    partnerModel.id = partnerModel.partnerID
                    localDatabase.insertFavouritePartner(partner: partnerModel)
                }
            }
        }
        catch
        {
            
        }
    }
    
    
    /// Loads the user's profile information from our server.
    func loadUserProfileInformation()
    {
        do
        {
            let userProfileViewModel = UserProfileViewModel(viewController: nil)
            userProfileViewModel.getUserProfileInformationFromServer()
        }
        catch
        {
            
        }
    }
    
    
    /// Loads the user's default options.
    func loadUserDefaultOptions()
    {
        do
        {
            let appUser = localDatabase.getAppUser()
            
            let defaultOptions = RegistrationWebApi.getUserDefaultOptions(phoneNumber: (appUser?.phoneNumber)!)
            if (defaultOptions != nil)
            {
                appUser?.hasAccessToOrdering = defaultOptions?.HasAccessToOrdering
                appUser?.isOrderCustomer = defaultOptions?.IsOrderCustomer
                
                localDatabase.updateAppUser(appUser: appUser!)
            }
        }
        catch
        {
            
        }
    }
    
    /// Updates the verification message.
    ///
    /// - Parameter serverResponse: The server's response.
    func updateVerificationMessage(serverResponse : Int)
    {
        if (serverResponse == ApiResponseEnumType.VerificationPasswordExpired.rawValue)
        {
            verificationMessage = NSLocalizedString("passwordExpired", comment: "")
        }
        else if (serverResponse == ApiResponseEnumType.VerificationError.rawValue)
        {
            verificationMessage = NSLocalizedString("verificationFailed", comment: "")
        }
    }
    
    
    func checkIfUserExists(items : [UserProfileCellModel], timeout : Double)
    {
        let appUser = localDatabase.getAppUser()
        var userInformations : UserProfileModel2!

        userInformations = UserProfileWebApi.getUserProfile2(clientID: clientID, phoneNumber: appUser?.phoneNumber, emailAddress: (appUser?.hasVerifiedEmailAddress)! ? appUser?.emailAddress : "", mustUserBelongToBusiness: false, apkID: businessID, timeout: timeout)
        
        if(userInformations != nil)
        {
            var isRequiredFieldEmpty = false
            let acceptNews = AcceptNewsModel()
            
            acceptNews.acceptNews1 = userInformations.acceptNews1 == nil ? 0 : userInformations.acceptNews1
            acceptNews.acceptNews2 = userInformations.acceptNews2 == nil ? 0 : userInformations.acceptNews2
            acceptNews.acceptNews3 = userInformations.acceptNews3 == nil ? 0 : userInformations.acceptNews3
            acceptNews.acceptNews4 = userInformations.acceptNews4 == nil ? 0 : userInformations.acceptNews4
            acceptNews.acceptNews5 = userInformations.acceptNews5 == nil ? 0 : userInformations.acceptNews5
            acceptNews.acceptNews6 = userInformations.acceptNews6 == nil ? 0 : userInformations.acceptNews6
            acceptNews.acceptNews7 = userInformations.acceptNews7 == nil ? 0 : userInformations.acceptNews7
            acceptNews.acceptNews8 = userInformations.acceptNews8 == nil ? 0 : userInformations.acceptNews8
            
            self.acceptNews = acceptNews
            localDatabase.insertAcceptNews(bussinessID: clientID, acceptedNews: acceptNews)
            
            if(userInformations.gender != nil)
            {
                userInformations.gender -= 1
            }
            
            //appUser.accountID = userInformations.accountID
            appUser?.isAdult = userInformations.isAdult
            appUser?.languageID = userInformations.preferredLanguageID
            appUser?.shouldReceiveEmail = userInformations.shouldReceiveEmail
            appUser?.shouldReceiveSms = userInformations.shouldReceiveSms
            appUser?.shouldReceiveLoyaltyCardNumberBySMS = userInformations.shouldReceiveLoyaltyCardNumberBySMS
            appUser?.isLoyaltyUser = userInformations.isLoyaltyUser == nil ? false : userInformations.isLoyaltyUser
            
            for i in items
            {
                if(i.fields != nil)
                {
                    for f in i.fields
                    {
                        switch f.type
                        {
                        case  UserProfileFieldType.Phoneumber.rawValue :
                            if(!(appUser?.hasVerifiedPhoneNumber)!)
                            {
                                appUser?.phoneNumber = userInformations.mobile
                            }
                            
                            f.value =  appUser?.phoneNumber
                        case  UserProfileFieldType.Email.rawValue :
                            if(!(appUser?.hasVerifiedEmailAddress)!)
                            {
                                appUser?.emailAddress = userInformations.email
                                if(userInformations.hasVerifiedEmailAddress)
                                {
                                    appUser?.hasVerifiedEmailAddress = true
                                    appUser?.emailVerifiedIPAddress = userInformations.emailVerifiedIPAddress
                                    appUser?.emailVerifiedDatetime = userInformations.emailVerifiedDatetime
                                }
                                else
                                {
                                    appUser?.needEmailVerification = false
                                }
                            }
                            
                            f.value = appUser?.emailAddress
                        case  UserProfileFieldType.Title.rawValue :
                            f.value = userInformations.gender == 1 ? "Ms." : "Mr."
                            
                            if(appUser?.titleID == nil)
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    appUser?.titleID = UserTitle.Ms.rawValue
                                }
                            }
                            else
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    if(!isTitleFemale(titleID: (appUser?.titleID)!))
                                    {
                                        appUser?.titleID = UserTitle.Ms.rawValue
                                    }
                                }
                            }
                            
                            //appUser?.titleID = appUser?.titleID != nil ? (userInformations.gender == 0 ? UserTitle.Mr.rawValue : UserTitle.Ms.rawValue) :
                            appUser?.title = f.value
                            appUser?.gender = userInformations.gender == 1 ? 1 : 0
                            
                        case  UserProfileFieldType.Name.rawValue :
                            f.value = userInformations.name
                            appUser?.name = userInformations.name
                        case  UserProfileFieldType.Surname.rawValue :
                            f.value = userInformations.surname
                            appUser?.surname = userInformations.surname
                        case  UserProfileFieldType.Gender.rawValue :
                            f.value = userInformations.gender == 0 ? "Male" : "Female"
                            appUser?.gender = userInformations.gender == 1 ? 1 : 0
                            
                            if(appUser?.titleID == nil)
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    appUser?.titleID = UserTitle.Ms.rawValue
                                }
                            }
                            else
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    if(!isTitleFemale(titleID: (appUser?.titleID)!))
                                    {
                                        appUser?.titleID = UserTitle.Ms.rawValue
                                    }
                                }
                            }
                        case  UserProfileFieldType.Birthday.rawValue :
                            if(!isNullOrEmpty(string: userInformations.birthDateString))
                            {
                                //let dateFormatter = DateFormatter()
                                //dateFormatter.dateFormat = "dd/MM/yyyy"
                                f.value = userInformations.birthDateString //dateFormatter.string(from: userInformations.birthDate)
                                appUser?.birthDate = userInformations.birthDateString //f.value
                            }
                        case  UserProfileFieldType.Address1.rawValue :
                            if(f.inputType == InputType.TextOnly.rawValue)
                            {
                                if(userInformations.address1 != nil)
                                {
                                    userInformations.address1 = userInformations.address1.components(separatedBy: CharacterSet.decimalDigits).joined()
                                }
                            }
                            
                            f.value = userInformations.address1
                            appUser?.homeAddress = userInformations.address1
                        case  UserProfileFieldType.Address2.rawValue :
                            if(f.inputType == InputType.TextOnly.rawValue)
                            {
                                userInformations.address2 = userInformations.address2.components(separatedBy: CharacterSet.decimalDigits).joined()
                            }
                            
                            f.value = userInformations.address2
                            appUser?.homeAddress2 = userInformations.address2
                        case  UserProfileFieldType.City.rawValue :
                            f.value = userInformations.city
                            appUser?.city = f.value//userInformations.city
                        case  UserProfileFieldType.PostCode.rawValue :
                            f.value = userInformations.postCode
                            appUser?.postCode = userInformations.postCode
                        case  UserProfileFieldType.District.rawValue :
                            f.value = userInformations.region
                            appUser?.province = userInformations.region
                        case  UserProfileFieldType.Country.rawValue :
                            //f.value = userInformations.countryID == 57 ? "Cyprus" : ""
                            userInformations.country = userInformations.country
                            f.value = userInformations.country
                            appUser?.country = f.value
                        case  UserProfileFieldType.CommunicationLanguage.rawValue :
                            f.value = userInformations.preferredLanguageID == 2 ?  "English" : "Greek"
                            //appUser?.preferredLanguageID = userInformations.preferredLanguageID
                            appUser?.languageID = userInformations.preferredLanguageID
                            appUser?.communicationLanguage = f.value
                        case  UserProfileFieldType.ReferredName.rawValue :
                            f.value = userInformations.referedName
                            appUser?.referedName = f.value
                        case  UserProfileFieldType.FlatHouseName.rawValue :
                            f.value = userInformations.flatHouseName
                            appUser?.flatHouseName = f.value
                        case  UserProfileFieldType.HouseNo.rawValue :
                            f.value = userInformations.houseNo
                            appUser?.houseNo = f.value
                        default :
                            break
                        }
                        
                        if(f.isDropDown)
                        {
                            var itemFound = false
                            for i in f.dropDownItemsModel!
                            {
                                if(f.value == i.textStr)
                                {
                                    itemFound = true
                                    break
                                }
                            }
                            
                            if(!itemFound)
                            {
                                f.value = nil
                            }
                        }
                        
                        if(f.inputType == InputType.TextOnly.rawValue)
                        {
                            if(f.value != nil)
                            {
                                f.value = f.value.components(separatedBy: CharacterSet.decimalDigits).joined()
                            }
                        }
                        else if(f.inputType == InputType.Number.rawValue)
                        {
                            if(f.value != nil)
                            {
                                f.value = f.value.components(separatedBy: CharacterSet.letters).joined()
                            }
                        }
                        
                        if(f.isRequirement && isNullOrEmpty(string: f.value))
                        {
                            isRequiredFieldEmpty = true
                        }
                        
                        switch f.type
                        {
                            
                        case  UserProfileFieldType.Email.rawValue :
                            if(!(appUser?.hasVerifiedEmailAddress)!)
                            {
                                appUser?.emailAddress = f.value
                            }
                        case  UserProfileFieldType.Title.rawValue :
                            if(appUser?.titleID == nil)
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    appUser?.titleID = UserTitle.Ms.rawValue
                                }
                            }
                            else
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    if(!isTitleFemale(titleID: (appUser?.titleID)!))
                                    {
                                        appUser?.titleID = UserTitle.Ms.rawValue
                                    }
                                }
                            }
                            
                            //appUser?.titleID = appUser?.titleID != nil ? (userInformations.gender == 0 ? UserTitle.Mr.rawValue : UserTitle.Ms.rawValue) :
                            appUser?.title = f.value
                            appUser?.gender = userInformations.gender == 1 ? 1 : 0
                            
                        case  UserProfileFieldType.Name.rawValue :
                            appUser?.name = f.value
                        case  UserProfileFieldType.Surname.rawValue :
                            appUser?.surname = f.value
                        case  UserProfileFieldType.Gender.rawValue :
                            appUser?.gender = userInformations.gender == 1 ? 1 : 0
                            
                            if(appUser?.titleID == nil)
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    appUser?.titleID = UserTitle.Ms.rawValue
                                }
                            }
                            else
                            {
                                if(userInformations.gender == UserGender.Male.rawValue)
                                {
                                    appUser?.titleID = UserTitle.Mr.rawValue
                                }
                                else
                                {
                                    if(!isTitleFemale(titleID: (appUser?.titleID)!))
                                    {
                                        appUser?.titleID = UserTitle.Ms.rawValue
                                    }
                                }
                            }
                        case  UserProfileFieldType.Birthday.rawValue :
                            if(!isNullOrEmpty(string: userInformations.birthDateString))
                            {
                                appUser?.birthDate = userInformations.birthDateString //f.value
                            }
                        case  UserProfileFieldType.Address1.rawValue :
                            appUser?.homeAddress = f.value
                        case  UserProfileFieldType.Address2.rawValue :
                            appUser?.homeAddress2 = f.value
                        case  UserProfileFieldType.City.rawValue :
                            appUser?.city = f.value
                            break
                        case  UserProfileFieldType.PostCode.rawValue :
                            appUser?.postCode = f.value
                        case  UserProfileFieldType.District.rawValue :
                            appUser?.province = f.value
                        case  UserProfileFieldType.Country.rawValue :
                            appUser?.country = f.value
                        case  UserProfileFieldType.CommunicationLanguage.rawValue :
                            //appUser?.preferredLanguageID = userInformations.preferredLanguageID
                            appUser?.languageID = userInformations.preferredLanguageID
                            appUser?.communicationLanguage = f.value
                        case  UserProfileFieldType.ReferredName.rawValue :
                            appUser?.referedName = f.value
                        case  UserProfileFieldType.FlatHouseName.rawValue :
                            appUser?.flatHouseName = f.value
                        case  UserProfileFieldType.HouseNo.rawValue :
                            appUser?.houseNo = f.value
                        default :
                            break
                        }
                    }
                }
                else if(i.type == UserProfileCellType.CheckBox.rawValue)
                {
                    if(i.checkBox.connectionID != nil)
                    {
                        switch(i.checkBox.connectionID)
                        {
                        case CheckBoxConnectionID.IsAdult.rawValue:
                            if(userInformations.isAdult != nil && userInformations.isAdult)
                            {
                                i.checkBox.isChecked = true
                                appUser?.isAdult = true
                                viewsDB.setCheckBoxCheckedFlag(checkBox: i.checkBox )
                            }
                        case CheckBoxConnectionID.ReceiveSms.rawValue:
                            if(userInformations.shouldReceiveSms != nil && userInformations.shouldReceiveSms)
                            {
                                i.checkBox.isChecked = true
                                appUser?.shouldReceiveSms = true
                                viewsDB.setCheckBoxCheckedFlag(checkBox: i.checkBox )
                            }
                        case CheckBoxConnectionID.ReceiveEmail.rawValue:
                            if(userInformations.shouldReceiveEmail != nil && userInformations.shouldReceiveEmail)
                            {
                                i.checkBox.isChecked = true
                                appUser?.shouldReceiveEmail = true
                                viewsDB.setCheckBoxCheckedFlag(checkBox: i.checkBox )
                            }
                        case CheckBoxConnectionID.ReceiveCardSMS.rawValue:
                            if(userInformations.shouldReceiveLoyaltyCardNumberBySMS != nil && userInformations.shouldReceiveLoyaltyCardNumberBySMS)
                            {
                                i.checkBox.isChecked = true
                                appUser?.shouldReceiveLoyaltyCardNumberBySMS = true
                                viewsDB.setCheckBoxCheckedFlag(checkBox: i.checkBox )
                            }
                        default:
                            break
                        }
                    }
                }
            }
            
            print("try to update user")
            localDatabase.updateAppUser(appUser: appUser!)
            
            if(!userInformations.isBlocked)
            {
                self.items = items
                isBlocked = false
                
                if(appUser!.isLoyaltyUser)
                {
                    DispatchQueue.global(qos: .background).async {
                        APKChanger.getPointsStatementAndBalance()
                    }
                }
                
                /*if(!isRequiredFieldEmpty)
                {
                    localDatabase.insertRegisteredAPK(bussinessID: clientID)
                    
                    DispatchQueue.global(qos: .background).async {
                        APKChanger.getPointsStatementAndBalance()
                    }
                }*/
            }
            else //if(userInformations.blocked == 1)
            {
                let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.viewController.present(dialog,animated:true)
                })
                dialog.setDialogView(title: NSLocalizedString("blockedTitle", comment: ""), description: NSLocalizedString("blockedDescription", comment: ""), buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside : false)
                isBlocked = true
            }
            /*else if(userInformations.blocked == 2)
            {
                statusModel.isPointsStatementSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
                
                statusModel.areTicketsSaved = true
                statusDB.insertStatus(status : statusModel, apk : APK)
                
                let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.viewController.present(dialog,animated:true)
                })
                dialog.setDialogView(title: "Not registered", description: "You are not registered. Please enter your information in order to registered.", buttonName: "Ok", dismissWhenClickOutside: false)
                isBlocked = false
                
                let acceptNews = AcceptNewsModel()
                
                self.acceptNews = acceptNews
                localDatabase.insertAcceptNews(bussinessID: clientID, acceptedNews: acceptNews)
            }*/
        }
        else
        {
            let acceptNews = AcceptNewsModel()
            
            self.acceptNews = acceptNews
            localDatabase.insertAcceptNews(bussinessID: clientID, acceptedNews: acceptNews)
        }
        
    }
}
