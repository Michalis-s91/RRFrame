//
//  UserProfileViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 22/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// UserProfileViewModel is the view model associated to the User Profile view. It is responsible for creating, loading and updating user's information.
class UserProfileViewModel  {
    var viewController : UserProfileViewController!
    var appUser : AppUser!
    
    var phoneNumber : String!
    var name : String!
    var surname : String!
    var hasVerifiedEmailAddress = false
    var hasNotVerifiedEmailAddress = true
    var verifiedEmailAddress : String!
    var homeAddress : String!
    var city : String!
    var postCode : String!
    var selectedProvinceStr : String!
    var titleID : Int!
    
    var genders : [SingleTextModel] = []
    var provinces : [SingleTextModel] = []
    
    var updateStatusText : String!
    var hasLoyaltyProfile : Bool = false
    var submitButtonText : String = ""
    var selectedGenderStr : String = ""
    
    var birthDate : String!
    var BirthDate : String! {
        get
        {
            return self.birthDate
        }
        
        set(birthDate)
        {
            self.birthDate = birthDate
            viewController.dateOfBirthText.text = birthDate
        }
    }
    
    var emailAddress : String!
    var EmailAddress : String! {
        get
        {
            return self.emailAddress
        }
        
        set(emailAddress)
        {
            self.emailAddress = emailAddress
            
            /*
             if (!isNullOrEmpty(string: emailAddress))
             {
             if (!(emailAddress == verifiedEmailAddress))
             {
             hasVerifiedEmailAddress = false
             }
             else
             {
             hasVerifiedEmailAddress = true
             }
             }
             
             hasNotVerifiedEmailAddress = !hasVerifiedEmailAddress
             
             if (hasVerifiedEmailAddress)
             {
             viewController.verifyEmailView.isHidden = false
             viewController.notVerifyEmailView.isHidden = true
             }
             else
             {
             viewController.verifyEmailView.isHidden = true
             viewController.notVerifyEmailView.isHidden = false
             }
             */
        }
    }
    
    var selectedGender : Int!
    var SelectedGender : Int!
    {
        get
        {
            return self.selectedGender
        }
        
        set (selectedGender)
        {
            self.selectedGender = selectedGender
            viewController.genderText.text = genders[selectedGender].textStr
            selectedGenderStr = genders[selectedGender].textStr
        }
    }
    
    var selectedProvince : Int!
    var SelectedProvince : Int!
    {
        get
        {
            return self.selectedProvince
        }
        
        set (selectedProvince)
        {
            self.selectedProvince = selectedGender
            viewController.provincesText.text = provinces[selectedProvince].textStr
            selectedProvinceStr = provinces[selectedProvince].textStr
        }
    }
    
    init(viewController : UserProfileViewController!){
        self.viewController = viewController
        appUser = localDatabase.getAppUser()
    }
    
    init(){
        appUser = localDatabase.getAppUser()
    }
    
    /// Gets the user's profile information from our server and saves it to the device's local database.
    func getUserProfileInformationFromServer()
    {
        if(appUser == nil)
        {
            appUser = localDatabase.getAppUser()
        }
        
        let userProfile = RegistrationWebApi.getUserProfile(phone: (appUser?.phoneNumber)!)
        
        appUser.name = userProfile?.name
        appUser.surname = userProfile?.surname
        appUser.gender = userProfile?.gender
        appUser.emailAddress = userProfile?.emailAddress
        appUser.province = userProfile?.province
        appUser.city = userProfile?.city
        appUser.homeAddress = userProfile?.homeAddress
        appUser.postCode = userProfile?.postCode
        appUser.birthDate = userProfile?.birthDate
        appUser.hasLoyaltyProfile = true
        //appUser.hasVerifiedEmailAddress = (userProfile?.hasVerifiedEmailAddress)!
        appUser.titleID = userProfile?.titleID
        
        localDatabase.updateAppUser(appUser: appUser)
    }
    
    
    /// Initializes the view model properties.
    func initializeProperties()
    {
        phoneNumber = appUser.phoneNumber
        name = appUser.name
        surname = appUser.surname
        emailAddress = appUser.emailAddress
        city = appUser.city
        homeAddress = appUser.homeAddress
        postCode = appUser.postCode
        
        genders = StaticDataRepository.getUserGenders()
        provinces = StaticDataRepository.getProvinces()
        
        if(!isNullOrEmpty(string: phoneNumber))
        {
            self.viewController.telephoneText.text = phoneNumber
        }
        
        if (!isNullOrEmpty(string : name))
        {
            viewController.nameText.text = name
        }
        
        if (!isNullOrEmpty(string : surname))
        {
            viewController.surnameText.text = surname
        }
        
        if (appUser.gender != nil)
        {
            viewController.genderText.text =  StaticDataRepository.getUserGenders()[appUser.gender].textStr
            SelectedGender = appUser.gender
        }
        else
        {
            selectedGenderStr = NSLocalizedString("genderDefaultText", comment: "")
            viewController.genderText.text = selectedGenderStr
        }
        
        if (!isNullOrEmpty(string : appUser.birthDate))
        {
            birthDate = appUser.birthDate
            viewController.dateOfBirthText.text = birthDate
        }
        else
        {
            birthDate = NSLocalizedString("birthDateDefaultText", comment: "")
            viewController.dateOfBirthText.text = birthDate
        }
        
        if (!isNullOrEmpty(string : emailAddress))
        {
            viewController.emailText.text = emailAddress
        }
        
        if (!isNullOrEmpty(string : appUser.province))
        {
            selectedProvinceStr = appUser.province
            viewController.provincesText.text =  selectedProvinceStr
        }
        else
        {
            selectedProvinceStr = NSLocalizedString("provinceDefaultText", comment: "")
            viewController.provincesText.text = selectedProvinceStr
        }
        
        if (!isNullOrEmpty(string : city))
        {
            viewController.cityText.text = city
        }
        
        if (!isNullOrEmpty(string : homeAddress))
        {
            viewController.addressText.text = homeAddress
        }
        
        if (!isNullOrEmpty(string : postCode))
        {
            viewController.postCodeText.text = postCode
        }
        
        hasLoyaltyProfile = appUser.hasLoyaltyProfile
        if(hasLoyaltyProfile)
        {
            submitButtonText = NSLocalizedString("submitButtonUpdateText", comment: "")
            viewController.submitButton.setTitle(submitButtonText, for: .normal)
        }
        else
        {
            submitButtonText = NSLocalizedString("submitButtonSubmitText", comment: "")
            viewController.submitButton.setTitle(submitButtonText, for: .normal)
        }
    }
    
    
    /// Makes the appropriate checks and returns whether the information provided by the user is correct or not.
    ///
    /// - Returns: True if the information provided by the user is OK, otherwise false.
    func isUserProfileInformationValid() -> Bool
    {
        if(isNullOrEmpty(string: name) && isNullOrEmpty(string: surname))
        {
            updateStatusText = NSLocalizedString("pleaseEnterNameSurname", comment: "")
            return false
        }
        else if(isNullOrEmpty(string: name))
        {
            updateStatusText = NSLocalizedString("pleaseEnterName", comment: "")
            return false
        }
        else if(isNullOrEmpty(string: surname))
        {
            updateStatusText = NSLocalizedString("pleaseEnterSurname", comment: "")
            return false
        }
        
        if(!isNullOrEmpty(string: emailAddress))
        {
            if(!isEmailAddressValid(address: emailAddress))
            {
                updateStatusText = NSLocalizedString("pleaseEnterValidEmailAddress", comment: "")
                return false
            }
        }
        
        return true
    }
    
    
    /// Checks and returns whether the user information is already up-to-date or not.
    ///
    /// - Returns: True if the user information is already up-to-date, otherwise false.
    func isUserProfileInformationUpToDate() -> Bool
    {
        let appUser = localDatabase.getAppUser()
    
        
        if(
            !areEqual(object1: appUser?.name as AnyObject?,object2: self.name as AnyObject?) ||
                !areEqual(object1: appUser?.surname as AnyObject?,object2: self.surname as AnyObject?) ||
                !areEqual(object1: appUser?.gender as AnyObject?,object2: self.selectedGender as AnyObject?) ||
                !areEqual(object1: appUser?.emailAddress as AnyObject?,object2: self.emailAddress as AnyObject?) ||
                (!((appUser?.province == nil || appUser?.province == "") && self.selectedProvinceStr == NSLocalizedString("provinceDefaultText", comment: "")) && (!areEqual(object1: appUser?.province as AnyObject?,object2: self.selectedProvinceStr as AnyObject?))) ||
                !areEqual(object1: appUser?.city  as AnyObject?,object2: self.city  as AnyObject?) ||
                !areEqual(object1: appUser?.homeAddress as AnyObject? ,object2: self.homeAddress  as AnyObject?) ||
                !areEqual(object1: appUser?.postCode  as AnyObject?,object2: self.postCode  as AnyObject?) ||
                ((!((appUser!.birthDate == "" ||  appUser!.birthDate == nil) && self.birthDate == NSLocalizedString("birthDateDefaultText", comment: ""))) && (!areEqual(object1: appUser?.birthDate  as AnyObject? ,object2: self.birthDate  as AnyObject?))))
        {
            return false
        }
        
        return true
    }
    
    
    /// Updates the user's profile information on both local and remote database.
    func updateUserProfile()
    {
        if(isUserProfileInformationValid())
        {
            if (!isUserProfileInformationUpToDate())
            {
                let userProfile = UserProfileModel()
                
                userProfile.phoneNumber = phoneNumber
                userProfile.name = name
                userProfile.surname = surname
                userProfile.gender = selectedGender == nil ? nil : selectedGender + 1
                userProfile.titleID = titleID
                userProfile.emailAddress = emailAddress
                
                if(self.selectedProvinceStr ==  NSLocalizedString("provinceDefaultText", comment: ""))
                {
                    userProfile.province = nil
                }
                else
                {
                    userProfile.province = selectedProvinceStr
                }
                
                
                userProfile.city = city
                userProfile.homeAddress = homeAddress
                userProfile.postCode = postCode
                
                if(birthDate == NSLocalizedString("birthDateDefaultText", comment: ""))
                {
                    userProfile.birthDate = nil
                }
                else
                {
                    userProfile.birthDate = birthDate
                }
                
                do
                {
                    try UserProfileWebApi.updateUserProfile(userProfile: userProfile)
                } catch
                {
                    updateStatusText = NSLocalizedString("synchronizationFailedPleaseTryAgain", comment: "")
                    return
                }
                
                let appUser = localDatabase.getAppUser()
                appUser?.name = name
                appUser?.surname = surname
                appUser?.gender =  selectedGender
                appUser?.titleID = titleID
                appUser?.emailAddress = emailAddress
                
                if (selectedProvinceStr == NSLocalizedString("provinceDefaultText", comment: ""))
                {
                    appUser?.province = ""
                }
                else
                {
                    appUser?.province = selectedProvinceStr
                }
                
                appUser?.city = city
                appUser?.homeAddress = homeAddress
                appUser?.postCode = postCode
                appUser?.birthDate = birthDate
                
                if (!(appUser?.hasLoyaltyProfile)!)
                {
                    updateStatusText = NSLocalizedString("profileInformationSubmittedSuccessfully", comment: "")
                } else
                {
                    updateStatusText = NSLocalizedString("profileInformationUpdatedSuccessfully", comment: "")
                }
                
                appUser?.hasLoyaltyProfile = true
                
                localDatabase.updateAppUser(appUser: appUser!)
                
                submitButtonText = NSLocalizedString("submitButtonUpdateText", comment: "")
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.viewController.submitButton.setTitle(self.submitButtonText, for: .normal)
                })
            }
            else
            {
                updateStatusText = NSLocalizedString("profileAlreadyUpToDate", comment: "")
            }
        }
    }
    
    
    
    
    
    
    //Registration view model
    var termsAndPoliciesLink : String!
    var shouldDisplayRegistrationView : Bool!
    var shouldDisplayVerificationView : Bool!
    var networkISO : String!
    var networkName : String!
    var deviceID : String!
    var serverResponse : String!
    var verificationCode : String!
    var registrationSourceType : Int!
    var partnerCode = ""
    var isVerified = false
    var verificationMessage : String!
    
    
    /// Constructor. Sets the dataService and the activity.
    ///
    /// - Parameter registrationViewController: The registration view controller.
    init(registrationViewController : RegistrationViewController!)
    {
        termsAndPoliciesLink = NSLocalizedString("termsAndPoliciesLink", comment: "")
    }
    
    /// Resends the verification code to the user.
    ///
    /// - Returns: The response of request.
    func resendVerificationCode() throws -> String
    {
        var mServerResponse = ""
        
        let appUser = localDatabase.getAppUser()
        
        if (appUser != nil)
        {
            do
            {
                mServerResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                //return mServerResponse
            }
            catch
            {
                throw Errors.error
            }
        }
        
        return mServerResponse
        //return !IsNullOrEmpty.isNullOrEmpty(mServerResponse) ? mServerResponse : ""
    }
    
    
    /// Registers user to RichReach.
    func registerUser()
    {
        print("quick registration3")
        let isUserAddedToLocalDatabase = IsUserAddedToLocalDatabase(shouldAddUserToLocalDatabase : true)
        if (isUserAddedToLocalDatabase)
        {
            RegistrationWebApi.quickRegistration(phoneNumber: phoneNumber, prefix: "357", carrier: networkName, deviceID: deviceID, applicationLanguage: "en")
            let appUSer = localDatabase.getAppUser()
            appUSer?.isPending = true
            localDatabase.updateAppUser(appUser: appUSer!)
        }
    }
    
    
    /// Returns whether the user info has been already added to the local database or not. If not, then if the input flag
    /// is set to true the user's info is added to the local database.
    ///
    /// - Parameter shouldAddUserToLocalDatabase: The input flag that indicates whether the user's info should be added to the local database in case it hasn't been added yet.
    /// - Returns: True if the user info has been already added to the local database, otherwise false.
    func IsUserAddedToLocalDatabase(shouldAddUserToLocalDatabase : Bool = false) -> Bool
    {
        
        if (shouldAddUserToLocalDatabase)
        {
            let appUser = AppUser()
            appUser.phoneNumber = phoneNumber
            appUser.deviceID = deviceID
            
            localDatabase.updateAppUser(appUser: appUser)
            
            return true
        }
        
        return false
    }
    
    
    /// Returns whether the user has received a verification code or not.
    ///
    /// - Returns: True if the user has received a verification code, otherwise false.
    func hasUserReceivedRegistrationVerificationCode() -> Bool
    {
        let appUser = localDatabase.getAppUser()
        if(appUser != nil)
        {
            return appUser!.hasReceivedRegistrationVerificationCode()
        }
        
        return false
    }
    
    
    /// Gets the verification code.
    func getVerificationCodePost() throws
    {
        do
        {
            print("get verification code")
            
            let appUser = localDatabase.getAppUser()
            //serverResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
            serverResponse = try RegistrationWebApi.getVerificationCodeViaIncomingCall(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
            
            appUser?.hasUserReceivedRegistrationVerificationCode = true
            localDatabase.updateAppUser(appUser: appUser!)
        }
        catch
        {
            throw Errors.error
        }
    }
    
    
    /// Verifies the code provided by the user.
    func verifyVerificationCode()
    {
        let appUSer = localDatabase.getAppUser()
        if (appUSer != nil)
        {
            let serverResponse = RegistrationWebApi.verifyPhoneNumber(phoneNumber: (appUSer?.phoneNumber)!, code: verificationCode, deviceID: (appUSer?.deviceID)!, partnerCode: partnerCode, registrationSourceType: registrationSourceType, verificationType: 1)
            
            //quickRegistrationVerification(phoneNumber: (appUSer?.phoneNumber)!, code: verificationCode, deviceID: (appUSer?.deviceID)!, partnerCode: partnerCode, registrationSourceTypeEnum: registrationSourceType)
            
            if(serverResponse != nil)
            {
                if (serverResponse?.verificationStatus ==  ApiResponseEnumType.OK.rawValue)
                {
                    appUSer?.verificationTimeStamp = Date()
                    appUSer?.isPending = false
                    //appUSer?.isRegistered = true
                    appUSer?.hasVerifiedPhoneNumber = true
                    appUSer?.partnerCode = partnerCode
                    
                    localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked: false)
                    localDatabase.insertRegisteredAPK(bussinessID: clientID)
                    
                    localDatabase.updateAppUser(appUser: appUSer!)
                    isVerified = true
                }
                else
                {
                    updateVerificationMessage(serverResponse: (serverResponse?.verificationStatus)!)
                }
            }
            else
            {
                updateVerificationMessage(serverResponse: -2)
            }
        }
        else
        {
            verificationMessage =  NSLocalizedString("accountNotFound", comment: "")
        }
    }
    
    
    /// Updates the verification message.
    ///
    /// - Parameter serverResponse: The server's response.
    func updateVerificationMessage(serverResponse : Int)
    {
        if (serverResponse == ApiResponseEnumType.VerificationPasswordExpired.rawValue)
        {
            verificationMessage = NSLocalizedString("passwordExpired", comment: "")
        }
        else if (serverResponse == ApiResponseEnumType.VerificationError.rawValue)
        {
            verificationMessage = NSLocalizedString("verificationFailed", comment: "")
        }
    }
    
    
    /// Loads the user's optins.
    func loadUserOptins()
    {
        let partners = RegistrationWebApi.getOptinPartners(phoneNumber: (localDatabase.getAppUser()?.phoneNumber)!)
        
        if (partners != nil && (partners?.count)! > 0)
        {
            
            for partnerModel in partners!
            {
                if(partnerModel.isRoot)
                {
                    let tempTap = selectedTab
                    let appUser = localDatabase.getAppUser()
                    appUser?.partnerID = partnerModel.partnerID
                    appUser?.partnerName = partnerModel.name
                    appUser?.partnerShortName = partnerModel.shortName
                    appUser?.partnerImageUri = partnerModel.imageUri
                    
                    appUser?.displayWhiteLabelPartner = true
                    appUser?.isPromocodeApplied = true
                    
                    ViewController.displayWhiteLabelPartner = true
                    localDatabase.updateAppUser(appUser: appUser!)
                    
                    for tab in leftDrawer.leftDrawerTabsList
                    {
                        if(tab.type == LeftDrawerTabsType.Preferred.rawValue)
                        {
                            tab.isVissible = true
                            parameterizationDatabase.updateLeftDrawerTab(tab : tab)
                            
                            LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
                            LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
                            
                            let initializer = APKInitializer()
                            APKInitializer.setProperties()
                            
                            leftDrawer.viewDidLoad()
                            leftDrawer.tableView.reloadData()
                            
//                            for tab in leftDrawer.leftDrawerTabsList
//                            {
//                                if(tab.type == LeftDrawerTabsType.Profile.rawValue)
//                                {
//                                    selectedTab = tab
//                                }
//                            }
                            DispatchQueue.main.async(execute: {() -> Void in
                                leftDrawer.selectTab(tabString: (tempTap?.name)!)
                                
                                for t in leftDrawer.leftDrawerTabsList
                                {
                                    if(t.type == LeftDrawerTabsType.Profile.rawValue)
                                    {
                                        //leftDrawer.showView(tab: t, index : i)
                                        leftDrawer.currentTab = t.name
                                        selectedTab = t
                                        break
                                    }
                                }
                            })
                        }
                    }
                }
                
                partnerModel.IsFavourite = true
                partnerModel.id = partnerModel.partnerID
                localDatabase.insertFavouritePartner(partner: partnerModel)
            }
        }
    }
    
    
    /// Loads user's default options such as the option that indicates whether user has access to use the Ordering functionality.
    func loadUserDefaultOptions()
    {
        let appUser = localDatabase.getAppUser()
        
        let defaultOptions = RegistrationWebApi.getUserDefaultOptions(phoneNumber: (appUser?.phoneNumber)!)
        if (defaultOptions != nil)
        {
            appUser?.hasAccessToOrdering = defaultOptions?.HasAccessToOrdering
            appUser?.isOrderCustomer = defaultOptions?.IsOrderCustomer
            
            localDatabase.updateAppUser(appUser: appUser!)
        }
    }
}
