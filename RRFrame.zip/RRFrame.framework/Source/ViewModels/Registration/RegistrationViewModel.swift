//
//  RegistrationViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 16/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// RegistrationViewModel is the view model associated to the  Registration view.
class RegistrationViewModel
{
    var termsAndPoliciesLink : String!
    var shouldDisplayRegistrationView : Bool!
    var shouldDisplayVerificationView : Bool!
    var networkISO : String!
    var networkName : String!
    var deviceID : String!
    var phone : String!
    var serverResponse : String!
    var verificationCode : String!
    var registrationSourceType : Int!
    var partnerCode = ""
    var isVerified = false
    var verificationMessage : String!
    var registrationViewController : RegistrationViewController!
    
    
    /// Constructor. Sets the dataService and the activity.
    ///
    /// - Parameter registrationViewController: The registration view controller.
    init(registrationViewController : RegistrationViewController!)
    {
        termsAndPoliciesLink = NSLocalizedString("termsAndPoliciesLink", comment: "")
        self.registrationViewController = registrationViewController
        
        setVisibleView()
    }
    
    
    /// Sets which view should be displayed. If user has been registered but not verified yet, the verification view
    /// should be displayed. Otherwise, the registration view should be displayed.
    func setVisibleView()
    {
        if(registrationViewController != nil)
        {
            if(!localDatabase.isCreated())
            {
                registrationViewController.verificationView.isHidden = true
                registrationViewController.registrationView.isHidden = false
            }
            else
            {
                let appUser = localDatabase.getAppUser()
                
                if((appUser?.isPending)!)
                {
                    registrationViewController.verificationView.isHidden = false
                    registrationViewController.registrationView.isHidden = true
                }
                else if(!(appUser?.isRegistered)!)
                {
                    registrationViewController.verificationView.isHidden = true
                    registrationViewController.registrationView.isHidden = false
                }
            }
        }
    }
    
    
    /// Deletes the user's info from the local database in order for the user to provide a different telephone number.
    func resetTelephoneNumber()
    {
        localDatabase.deleteAppUser()
        
        registrationViewController.verificationView.isHidden = true
        registrationViewController.registrationView.isHidden = false
    }
    
    
    /// Resends the verification code to the user.
    ///
    /// - Returns: The response of request.
    func resendVerificationCode() -> String
    {
        var mServerResponse = ""
        
        let appUser = localDatabase.getAppUser()
        
        if (appUser != nil)
        {
            do
            {
                mServerResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                //return mServerResponse
            }
            catch
            {
                
            }
        }
        
        return mServerResponse
        //return !IsNullOrEmpty.isNullOrEmpty(mServerResponse) ? mServerResponse : ""
    }
    
    
    /// Registers user to RichReach.
    func registerUser()
    {
        let isUserAddedToLocalDatabase = IsUserAddedToLocalDatabase(shouldAddUserToLocalDatabase : true)
        if (isUserAddedToLocalDatabase)
        {
            RegistrationWebApi.quickRegistration(phoneNumber: phone, prefix: "357", carrier: networkName, deviceID: deviceID, applicationLanguage: "en")
            let appUSer = localDatabase.getAppUser()
            appUSer?.isPending = true
            localDatabase.updateAppUser(appUser: appUSer!)
            DispatchQueue.main.async(execute: {() -> Void in
                self.registrationViewController.verificationView.isHidden = false
                self.registrationViewController.registrationView.isHidden = true
            })
        }
    }
    
    
    /// Returns whether the user info has been already added to the local database or not. If not, then if the input flag
    /// is set to true the user's info is added to the local database.
    ///
    /// - Parameter shouldAddUserToLocalDatabase: The input flag that indicates whether the user's info should be added to the local database in case it hasn't been added yet.
    /// - Returns: True if the user info has been already added to the local database, otherwise false.
    func IsUserAddedToLocalDatabase(shouldAddUserToLocalDatabase : Bool = false) -> Bool
    {
        
        if (!localDatabase.isCreated())
        {
            if (shouldAddUserToLocalDatabase)
            {
                let appUser = AppUser()
                appUser.phoneNumber = phone
                appUser.deviceID = deviceID
                
                localDatabase.addAppUser(appUser: appUser)
                
                return true
            }
            
            return false
        }
        
        return false
    }
    
    
    /// Returns whether the user has received a verification code or not.
    ///
    /// - Returns: True if the user has received a verification code, otherwise false.
    func hasUserReceivedRegistrationVerificationCode() -> Bool
    {
        let appUser = localDatabase.getAppUser()
        if(appUser != nil)
        {
            return appUser!.hasReceivedRegistrationVerificationCode()
        }
        
        return false
    }
    
    
    /// Gets the verification code.
    func getVerificationCodePost()
    {
        do
        {
            let appUser = localDatabase.getAppUser()
            serverResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
            
            appUser?.hasUserReceivedRegistrationVerificationCode = true
            localDatabase.updateAppUser(appUser: appUser!)
        }
        catch
        {
            
        }
    }
    
    
    /// Verifies the code provided by the user.
    func verifyVerificationCode()
    {
        let appUSer = localDatabase.getAppUser()
        if (appUSer != nil)
        {
            let serverResponse = RegistrationWebApi.quickRegistrationVerification(phoneNumber: (appUSer?.phoneNumber)!, code: verificationCode, deviceID: (appUSer?.deviceID)!, partnerCode: partnerCode, registrationSourceTypeEnum: registrationSourceType)
            
            if (Int(serverResponse) ==  ApiResponseEnumType.OK.rawValue)
            {
                appUSer?.verificationTimeStamp = Date()
                appUSer?.isPending = false
                appUSer?.isRegistered = true
                appUSer?.partnerCode = partnerCode
                localDatabase.updateAppUser(appUser: appUSer!)
                isVerified = true
            }
            else
            {
                updateVerificationMessage(serverResponse: serverResponse)
            }
        }
        else
        {
            verificationMessage =  NSLocalizedString("accountNotFound", comment: "")
        }
    }
    
    
    /// Updates the verification message.
    ///
    /// - Parameter serverResponse: The server's response.
    func updateVerificationMessage(serverResponse : Int)
    {
        if (serverResponse == ApiResponseEnumType.VerificationPasswordExpired.rawValue)
        {
            verificationMessage = NSLocalizedString("passwordExpired", comment: "")
        }
        else if (serverResponse == ApiResponseEnumType.VerificationError.rawValue)
        {
            verificationMessage = NSLocalizedString("verificationFailed", comment: "")
        }
    }
    
    
    /// Loads the user's optins.
    func loadUserOptins()
    {
        let partners = RegistrationWebApi.getOptinPartners(phoneNumber: (localDatabase.getAppUser()?.phoneNumber)!)
        
        if (partners != nil && (partners?.count)! > 0)
        {
            
            for partnerModel in partners!
            {
                if(partnerModel.isRoot)
                {
                    let appUser = localDatabase.getAppUser()
                    appUser?.partnerID = partnerModel.partnerID
                    appUser?.partnerName = partnerModel.name
                    appUser?.partnerShortName = partnerModel.shortName
                    appUser?.partnerImageUri = partnerModel.imageUri
                    
                    appUser?.displayWhiteLabelPartner = true
                    appUser?.isPromocodeApplied = true
                    
                    ViewController.displayWhiteLabelPartner = true
                    localDatabase.updateAppUser(appUser: appUser!)
                    
                }
                
                partnerModel.IsFavourite = true
                partnerModel.id = partnerModel.partnerID
                localDatabase.insertFavouritePartner(partner: partnerModel)
            }
        }
    }
    
    
    /// Loads user's default options such as the option that indicates whether user has access to use the Ordering functionality.
    func loadUserDefaultOptions()
    {
        let appUser = localDatabase.getAppUser()
        
        let defaultOptions = RegistrationWebApi.getUserDefaultOptions(phoneNumber: (appUser?.phoneNumber)!)
        if (defaultOptions != nil)
        {
            appUser?.hasAccessToOrdering = defaultOptions?.HasAccessToOrdering
            appUser?.isOrderCustomer = defaultOptions?.IsOrderCustomer
            
            localDatabase.updateAppUser(appUser: appUser!)
        }
    }
}
