//
//  UserProfileCellType.swift
//  RichReach2
//
//  Created by Eumbrella on 04/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


enum UserProfileCellType : Int
{
    case Title = 1
    case Field = 2
    case Button = 3
    case RadioButton = 4
    case CheckBox = 5
    case AlreadyReceived = 6
    case Switch = 7
}

