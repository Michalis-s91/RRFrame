//
//  RegistrationSourceTypeEnum.swift
//  RichReach2
//
//  Created by Eumbrella on 19/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// RegistrationSourceTypeEnum is used for determining the user's registration type (e.g. iOS, Android, Web etc.).
enum RegistrationSourceTypeEnum : Int
{
    case Web = 1
    case NoSmartPhone = 2
    case HelloCard = 3
    case InstantTeleconference = 4
    case TelesalesOpenAccount = 5
    case CoverCash = 6
    case SmartPhone = 7
    case RichReach = 8
    case RichReachAndroid = 9
    case RichReachIphone = 10
    //case SyncSucceed = -3
}
