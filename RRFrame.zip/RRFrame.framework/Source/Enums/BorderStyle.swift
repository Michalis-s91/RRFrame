//
//  BorderStyle.swift
//  RichReach
//
//  Created by Eumbrella on 13/03/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum BorderStyle : Int
{
    case NoBorder = 0
    case SingleLine = 1
    case Full = 2
}
