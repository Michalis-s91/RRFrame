//
//  BusinessIDs.swift
//  BeautyLine
//
//  Created by Eumbrella on 04/12/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum BusinessIDs : Int
{
    case RichReach = 54
    case BeautyLine = 44
    case HollandAndBarrett = 1074
}
