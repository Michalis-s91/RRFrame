//
//  LegtDrawerChilds.swift
//  RichReach2
//
//  Created by Eumbrella on 12/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum LeftDrawerOffersChilds:Int
{
    case Businesses = 1
    case WishList = 2
    case History = 3
    case Settings = 4
}
