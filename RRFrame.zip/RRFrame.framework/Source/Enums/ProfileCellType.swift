//
//  ProfileCellType.swift
//  RichReach2
//
//  Created by Eumbrella on 09/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum ProfileCellType : Int
{
    case Field = 1
    case Title = 2
    case Button = 3
    case Radio = 4
}
