//
//  InputType.swift
//  RichReach2
//
//  Created by Eumbrella on 02/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum InputType : Int
{
    case Text = 0
    case Number = 1
    case Phone = 2
    case Email = 3
    case Date = 4
    case TextOnly = 5
}
