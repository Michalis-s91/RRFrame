//
//  AligmentType.swift
//  RichReach2
//
//  Created by Eumbrella on 18/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// AlignmentType is used to indicate the type of alignment.
enum AlignmentType : Int,Codable
{
    case Left = 0
    case Center = 1
    case Justified = 2
}
