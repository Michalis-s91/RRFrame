//
//  StoresLocatorItemType.swift
//  RichReach2
//
//  Created by Eumbrella on 01/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// StoresLocatorItemType is used to indicate the type of item at stores locator table view.
enum StoresLocatorItemType : Int
{
    case City = 1
    case Store = 2
}
