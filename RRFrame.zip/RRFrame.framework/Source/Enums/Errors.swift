//
//  Errors.swift
//  RichReach2
//
//  Created by Eumbrella on 22/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Using this enum we can return error in functions.
enum Errors: Error {
    case error
}
