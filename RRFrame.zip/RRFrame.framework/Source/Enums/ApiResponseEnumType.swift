//
//  ApiResponseEnumType.swift
//  RichReach2
//
//  Created by Eumbrella on 16/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Saves api responses types.
///
/// - OK: The data posted successfully.
/// - VerificationPasswordExpired: Verication password has expired.
/// - VerificationError: Verification error.
/// - SyncFailed: Synchronisation failed.
enum ApiResponseEnumType : Int
{
    case OK = 0
    case VerificationPasswordExpired = -1
    case VerificationError = -2
    case SyncFailed = -3
    //case SyncSucceed = -3
}
