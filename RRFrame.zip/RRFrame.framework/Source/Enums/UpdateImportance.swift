//
//  UpdateImportance.swift
//  RichReach
//
//  Created by Eumbrella on 08/04/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum UpdateImportance : Int
{
    case Low = 1
    case High = 2
    case Critical = 3
}
