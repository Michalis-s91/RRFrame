//
//  PointsTypeEnum.swift
//  RichReach
//
//  Created by Eumbrella on 29/05/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum PointsType : Int
{
    case PointsOnly = 1
    case AmountOnly = 2
    case PointsAndAmount = 3
}
