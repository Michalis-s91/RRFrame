//
//  PhoneType.swift
//  RichReach
//
//  Created by Eumbrella on 10/04/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum PhoneType : Int
{
    case Android = 1
    case iOS = 2
}
