//
//  NotificationMessageType.swift
//  RichReach2
//
//  Created by Eumbrella on 27/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// NotificationMessageType is used to specify what type of notification is sent to the user (e.g. Update or Campaign).
enum NotificationMessageType : Int
{
    case Update = 1
    case Campaign = 2
    case EnableOrdering = 3
    case PendingOrder = 4
    case OrderConfirmation = 5
    case CostaPendingOrder = 6
    case CostaOrderConfirmation = 7
    case EmailVerifiedSilent = 8
    case EmailVerified = 9
    case EnableOrderCustomer = 10
    case PendingReturnDocument = 11
    case ReturnDocumentConfirmation = 12
    case SimpleMessage = 13
    case SyncAPKParameters = 17
    case SyncAPKOffers = 18
}
