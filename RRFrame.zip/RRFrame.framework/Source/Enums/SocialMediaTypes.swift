//
//  SocialMediaTypes.swift
//  RichReach2
//
//  Created by Eumbrella on 05/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum SocialMediaTypes : Int
{
    case Facebook = 1
    case Instangram = 2
    case Twitter = 3
    case Internet = 4
    case Pinterest = 5
    case Youtube = 6
}
