//
//  OfferTypeEnum.swift
//  RichReach2
//
//  Created by Eumbrella on 06/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// OfferTypeEnum is used to specify offer type (e.g. General offer).
enum OfferTypeEnum : Int
{
    case Uknown = 0
    case Discount = 1
    case SpecialPrice = 2
    case FreeUnits = 3
    case MoreSamePrice = 4
    case GeneralOffer = 5
    case PriceListOffer = 6
    case NoPriceToShow = 7
    case SetOffer = 8
}
