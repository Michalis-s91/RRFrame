//
//  ProductInfoType.swift
//  RichReach2
//
//  Created by Eumbrella on 17/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum ProductInfoType : Int
{
    case Title = 1
    case Image = 2
    case Price = 3
    case OverView = 4
    case Ingredients = 5
    case HowToUse = 6
    case OfferAvailability = 7
    case TermsAndConditions = 8
    case Brand = 9
    case Barcode = 10
    case ItemCode = 11
}
