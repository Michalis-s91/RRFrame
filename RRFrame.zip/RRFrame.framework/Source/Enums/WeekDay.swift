//
//  WeekDay.swift
//  RichReach2
//
//  Created by Eumbrella on 24/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// WeekDay is used to indicate the numbers of week days.
enum WeekDay : Int
{
    case Sunday = 1
    case Monday = 2
    case Tuesday = 3
    case Wednesday = 4
    case Thursday = 5
    case Friday = 6
    case Saturday = 7
}
