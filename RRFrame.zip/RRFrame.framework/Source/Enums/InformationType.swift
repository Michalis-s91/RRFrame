//
//  InformationType.swift
//  RichReach2
//
//  Created by Eumbrella on 14/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// InformationType is used to specify information type (e.g. title, image) at informations views (offer information view and partner information view).
enum InformationType : Int
{
    case Title = 0
    case Image = 1
    case Description = 2
    case Discount = 3
    case Stores = 4
    case Facebook = 5
    case Combo = 6
    case Video = 7
    case Carusel = 8
}
