//
//  RightDrawerType.swift
//  RichReach2
//
//  Created by Eumbrella on 03/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// RightDrawerType is used to specify the type of input (e.g. switch, ratio) for specific cell at right drawer table view.
enum RightDrawerType : Int
{
    case Switch = 0
}
