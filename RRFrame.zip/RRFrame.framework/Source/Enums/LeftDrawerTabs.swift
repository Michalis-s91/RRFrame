//
//  LeftDrawerGroups.swift
//  RichReach2
//
//  Created by Eumbrella on 12/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Int enumeration for left drawer tabs.
enum LeftDrawerTabsType : Int
{
    case Offers = 1
    case Loyalty = 2
    case Notifications = 3
    case SalesOrdering = 4
    case PurchaseOrdering = 5
    case HelpAndSupport = 6
    case Profile = 7
    case Barcode = 8
    case About = 9
    case Preferred = 10
    case Businesses = 11
    case WishList = 12
    case History = 13
    case Settings = 14
    case OrderReturnNow = 15
    case OrderReturnHistory = 16
    case OrderSettings = 17
    case Suppliers = 18
    
    case DirectLink = 19
    case SocialMedia = 20
    
    case BeautyLineUnderConstruction = 21
    case GeneralView = 22
    case BenefitsCard = 23
    case ExpandableList = 24
    case BarcodeScan = 25
    case ContactUs = 26
    case LoyaltyStatement = 27
    case Profile2 = 28
    case Feedback = 29
    case PromotionNotifications = 30
    case Blog = 34
    
    //case TermsAndConditions = 26
    //case About2 = 27
    

}
