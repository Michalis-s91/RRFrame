//
//  APKsEnum.swift
//  RichReach2
//
//  Created by Eumbrella on 08/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum APKsEnum : String
{
    case RichReach = "com.eumbrellacorp.richreach"
    case BeautyLine = "com.eumbrellacorp.beautyline"
    case HollandAndBarrett = "com.eumbrellacorp.hollandandbarrett"
    case Test = "com.eumbrellacorp.test"
}
