//
//  AppModeType.swift
//  RichReach2
//
//  Created by Eumbrella on 19/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Used for specifying the app mode type (It helps us check whether the app is running in debug or release mode).
///
/// - Debug: Debuge mode.
/// - Release: Release mode.
enum AppModeType : Int
{
    case Debug = 0
    case Release = 1
}

