//
//  InformationType2.swift
//  RichReach2
//
//  Created by Eumbrella on 22/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// InformationType is used to specify the type of information (e.g. title, image) for specific cell at table view. (
enum SlotType : Int
{
    case Photo = 1
    case Video = 2
    case Text = 3
    case Carousel = 4
    case Title = 5
    case PDF = 6
    case Header = 7
    case Hour = 8
    case Article = 9
    case Product = 10
    case RelatedArticle = 11
    case Share = 12
}
