//
//  ExpandableListChildType.swift
//  RichReach2
//
//  Created by Eumbrella on 07/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum ExpandableListItemType : Int
{
    case Parent = 0
    case BarcodeScan = 1
    case Search = 2
    case Category = 3
    case Brand = 4 
    case Store = 5
    case Product = 6
    case Category2 = 7
}

