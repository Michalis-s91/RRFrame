//
//  CouponStatusType.swift
//  RichReach
//
//  Created by George Rousou on 11/07/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

enum CouponStatusType : Int
{
    case COUPON_EXISTS = 0
    case NEW_COUPON_CREATED = 1
    case ERROR = -1
}
