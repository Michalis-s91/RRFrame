//
//  ClientIDs.swift
//  RichReach2
//
//  Created by Eumbrella on 03/10/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum ClientIDs : Int64
{
    case RichReach = 23715
    case BeautyLine = 20651
    case HollandAndBarrett = 33796
}
