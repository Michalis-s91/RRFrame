//
//  UserProfileFieldType.swift
//  RichReach2
//
//  Created by Eumbrella on 16/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

enum UserProfileFieldType : Int
{
    case Phoneumber = 1
    case Title = 2
    case Name = 3
    case Surname = 4
    case Gender = 5
    case Email = 6
    case Birthday = 7
    case Address1 = 8
    case Address2 = 9
    case City = 10
    case PostCode = 11
    case District = 12
    case Country = 13
    case CommunicationLanguage = 14
    case ReferredName = 15
    case HouseNo = 16
    case FlatHouseName = 17
    
}
