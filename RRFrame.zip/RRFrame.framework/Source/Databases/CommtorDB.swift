//
//  CommtorDB.swift
//  RichReach2
//
//  Created by Eumbrella on 20/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation
import SQLite

/// CommtorDB is used to copy the commtor.sql local DB (the one that was used in the Xamarin.iOS version) to the RichReach local database.
class CommtorDB
{
    let TABLE_COMMTOR_USER = Table("CommtorClient")
    let TABLE_PARTNER = Table("Partner")
    let TABLE_OFFER = Table("Offer")
    
    let TABLE_COMMTOR_USER_NAME = "CommtorClient"
    let TABLE_PARTNER_NAME = "Partner"
    let TABLE_OFFER_NAME = "Offer"
    
    let COMMTOR_DATABASE_NAME = "commtor"
    
    var localDatabase : Database
    var connection : Connection!
    
    init (localDatabase : Database )
    {
        self.localDatabase = localDatabase
    }
    
    /// Checks whether the user is a valid Commtor DB user (the user has already registered to the app using the Xamarin.iOS version).
    /// In case the user is registered, then this operation copies the Commtor DB into the RichReach database.
    ///
    /// - Returns: True in case the user is already registered to Commtor DB ---AND--- the user's information is transferred successfully to the RichReach database.
    func isValidCommtorUser() -> Bool
    {
        if(openCommtorDatabaseConnection())
        {
            do
            {
                let users = try self.connection.prepare(self.TABLE_COMMTOR_USER)
                
                if(users != nil)
                {
                    for row in users
                    {
                        
                        if ( try isUserRegisteredToCommtorDB(row : row))
                        {
                            if(try transferCommtorUserInfoToRichReach(appUserRow : row))
                            {
                                return true
                            }
                        }
                        break
                    }
                }
            }
            catch
            {
                print(error)
                return false
            }
        }
        
        return false
    }
    
    /// Attempts to open a connection to the Commtor DB. In case of success it returns true, otherwise false.
    ///
    /// - Returns: True in case the connection opens, otherwise false.
    func openCommtorDatabaseConnection() -> Bool
    {
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(COMMTOR_DATABASE_NAME).appendingPathExtension("sql")
            
            connection  = try Connection(fileUrl.path)
            return true
        }
        catch
        {
            do
            {
                let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                let fileUrl = documentDirectory.appendingPathComponent(COMMTOR_DATABASE_NAME).appendingPathExtension("sqlite3")
                
                connection  = try Connection(fileUrl.path.replacingOccurrences(of: "databases", with: "files"))
                return true
            }
            catch
            {
                
            }
        }
        
        return false
    }
    
    /// Returns true in case the user has already registered to the app.
    ///
    /// - Parameter row: The row that points to the CommtorClient table within Commtor database.
    /// - Returns: True in case the user has already registered to the app, otherwise false.
    /// - Throws: error
    func isUserRegisteredToCommtorDB(row : Row) throws -> Bool
    {
        var isPending : Bool! = true
        var isRegistered : Bool! = false
        
        
        do
        {
            if (try connection.exists(column: "IsPending", in: TABLE_COMMTOR_USER_NAME))
            {
                isPending = row[Expression<Bool?>("IsPending")]
            }
            
            if (try connection.exists(column: "IsRegistered", in: TABLE_COMMTOR_USER_NAME))
            {
                isRegistered = row[Expression<Bool?>("IsRegistered")]
            }
        }
        catch
        {
            throw Errors.error
        }
        
        if(isPending)
        {
            return false
        }
        else if(!isRegistered)
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    /// Transfers the Commtor DB into the RichReach database.
    ///
    /// - Parameter appUserRow: The row.
    /// - Returns: True in case of success, otherwise false.
    /// - Throws: error
    func transferCommtorUserInfoToRichReach(appUserRow : Row) throws -> Bool
    {
        do
        {
            if(!(try transferAppUserTable(row : appUserRow)))
            {
                return false
            }
            
            try transferPartnersTable()
            try transferOffersTable()
            
            return true
        }
        catch
        {
            throw Errors.error
        }
        
        //return false
    }
    
    /// Transfers the app user table (CommtorClient -> AppUser) from the Commtor DB to the RichReach database.
    ///
    /// - Parameter row: The row.
    /// - Returns: True in case of success, otherwise false.
    /// - Throws: error
    func transferAppUserTable(row : Row ) throws -> Bool
    {
        if(row != nil)
        {
            do
            {
                let appUser = try getAppUser(row : row)
                localDatabase.addAppUser(appUser: appUser)//addAPKAppUser(clientID: clientID, appUser: appUser) //addAppUser(appUser: appUser)
                return true
            }
            catch
            {
                throw Errors.error
            }
        }
        
        return false
    }
    
    /// Gets the app user record information that the cursor points to.
    ///
    /// - Parameter row: The row
    /// - Returns: The app user record information that the cursor points to.
    /// - Throws: error
    func getAppUser(row : Row) throws -> AppUser
    {
        let appUser = AppUser()
        
        do
        {
            if (try connection.exists(column: "IsPending", in: TABLE_COMMTOR_USER_NAME) &&   connection.exists(column: "IsRegistered", in: TABLE_COMMTOR_USER_NAME) &&  connection.exists(column: "IsUserRegisteredToAPNS", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "PhoneNumber", in: TABLE_COMMTOR_USER_NAME) &&  connection.exists(column: "Name", in: TABLE_COMMTOR_USER_NAME) &&  connection.exists(column: "Surname", in: TABLE_COMMTOR_USER_NAME) &&  connection.exists(column: "Gender", in: TABLE_COMMTOR_USER_NAME) &&  connection.exists(column: "EmailAddress", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "Province", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "City", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "HomeAddress", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "PostCode", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "BirthDate", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "PartnerID", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "PartnerName", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "PertnerShortName", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "PartnerImageUri", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "DisplayWhiteLabelPartner", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "IsPromocodeApplied", in: TABLE_COMMTOR_USER_NAME) && connection.exists(column: "DisplayWhiteLabelPartner", in: TABLE_COMMTOR_USER_NAME))
            {
                
                
                if(row[Expression<Bool?>("IsPending")] != nil)
                {
                    appUser.isPending = row[Expression<Bool?>("IsPending")]!
                }
                else
                {
                    appUser.isPending = false
                }
                
                if(row[Expression<Bool?>("IsRegistered")] != nil)
                {
                    appUser.isRegistered = row[Expression<Bool?>("IsRegistered")]!
                }
                else
                {
                    appUser.isRegistered = false
                }
                
                appUser.hasAccessToOrdering = false
                appUser.isOrderCustomer = false
                
                /*if ( row[Expression<Bool?>("HasAccessToOrdering")] != nil)
                 {
                 appUser.hasAccessToOrdering = row[Expression<Bool?>("HasAccessToOrdering")]
                 }
                 else
                 {
                 appUser.hasAccessToOrdering = false
                 }
                 
                 if(row[Expression<Bool?>("IsOrderCustomer")] != nil)
                 {
                 appUser.isOrderCustomer = row[Expression<Bool?>("IsOrderCustomer")]
                 }
                 else
                 {
                 appUser.isOrderCustomer = false
                 }*/
                
                
                if(row[Expression<Bool?>("IsUserRegisteredToAPNS")] != nil)
                {
                    appUser.isUserRegisteredToAPNS = row[Expression<Bool?>("IsUserRegisteredToAPNS")]!
                }
                else
                {
                    appUser.isUserRegisteredToAPNS = false
                }
                
                
                appUser.phoneNumber = row[Expression<String?>("PhoneNumber")]
                
                
                appUser.name = row[Expression<String?>("Name")]
                
                
                appUser.surname = row[Expression<String?>("Surname")]
                
                if(row[Expression<Int?>("Gender")] != nil)
                {
                    appUser.gender = row[Expression<Int?>("Gender")]! - 1
                }
                
                appUser.emailAddress = row[Expression<String?>("EmailAddress")]
                appUser.province = row[Expression<String?>("Province")]
                appUser.city = row[Expression<String?>("City")]
                appUser.homeAddress = row[Expression<String?>("HomeAddress")]
                appUser.postCode = row[Expression<String?>("PostCode")]
                appUser.birthDate = row[Expression<String?>("BirthDate")]
                
                
                appUser.hasVerifiedEmailAddress = false
                
                /*if(row[Expression<Bool?>("HasVerifiedEmailAddress")] != nil)
                 {
                 appUser.hasVerifiedEmailAddress = row[Expression<Bool?>("HasVerifiedEmailAddress")]!
                 }
                 else
                 {
                 appUser.hasVerifiedEmailAddress = false
                 }*/
                
                appUser.hasLoyaltyProfile = true
                
                appUser.partnerID = row[Expression<Int?>("PartnerID")]
                appUser.partnerName = row[Expression<String?>("PartnerName")]
                appUser.partnerShortName = row[Expression<String?>("PertnerShortName")]
                appUser.partnerImageUri = row[Expression<String?>("PartnerImageUri")]
                
                if (row[Expression<Bool?>("DisplayWhiteLabelPartner")] != nil)
                {
                    appUser.displayWhiteLabelPartner = row[Expression<Bool?>("DisplayWhiteLabelPartner")]!
                }
                else
                {
                    appUser.displayWhiteLabelPartner = false
                }
                
                if( row[Expression<Bool?>("IsPromocodeApplied")] != nil)
                {
                    appUser.isPromocodeApplied = row[Expression<Bool?>("IsPromocodeApplied")]!
                }
                else
                {
                    appUser.isPromocodeApplied = false
                }
                
                ViewController.displayWhiteLabelPartner = row[Expression<Bool?>("DisplayWhiteLabelPartner")]
            }
            else
            {
                throw Errors.error
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return appUser
    }
    
    /// Transfers the partner table from the Commtor database to the RichReach database.
    ///
    /// - Throws: error
    func transferPartnersTable() throws
    {
        do
        {
            let partners = try self.connection.prepare(self.TABLE_PARTNER)
            
            if(partners != nil)
            {
                for partner in partners
                {
                    try localDatabase.insertFavouritePartner(partner: getPartner(row : partner))
                }
            }
        }
        catch
        {
            throw Errors.error
        }
    }
    
    /// Gets the partner record information that the cursor points to.
    ///
    /// - Parameter row: The row.
    /// - Returns: The partner record information that the cursor points to.
    /// - Throws: error
    func getPartner(row : Row) throws -> PartnerModel
    {
        let partner = PartnerModel()
        do
        {
            if (try connection.exists(column: "PartnerID", in: TABLE_PARTNER_NAME) &&   connection.exists(column: "IsRoot", in: TABLE_PARTNER_NAME) &&  connection.exists(column: "IsFavourite", in: TABLE_PARTNER_NAME))
            {
                partner.id = row[Expression<Int?>("PartnerID")]
                
                if(row[Expression<Bool?>("IsRoot")] != nil)
                {
                    partner.isRoot = row[Expression<Bool?>("IsRoot")]!
                }
                else
                {
                    partner.isRoot = false
                }
                
                if(row[Expression<Bool?>("IsFavourite")] != nil)
                {
                    partner.IsFavourite = row[Expression<Bool?>("IsFavourite")]!
                }
                else
                {
                    partner.IsFavourite = false
                }
            }
            else
            {
                throw Errors.error
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return partner
    }
    
    /// Transfers the offer table from the Commtor database to the RichReach database.
    ///
    /// - Throws: error
    func transferOffersTable() throws
    {
        do
        {
            let offers = try self.connection.prepare(self.TABLE_OFFER)
            
            if(offers != nil)
            {
                for offer in offers
                {
                    try localDatabase.insertFavouriteOffer(offer: getOffer(row : offer))
                }
            }
        }
        catch
        {
            throw Errors.error
        }
        
    }
    
    /// Gets the offer record information that the cursor points to.
    ///
    /// - Parameter row: The row.
    /// - Returns: The offer record information that the cursor points to.
    /// - Throws: error
    func getOffer(row : Row) throws -> OfferModel
    {
        let offer = OfferModel()
        
        do
        {
            if (try connection.exists(column: "AppOfferID", in: TABLE_OFFER_NAME) && connection.exists(column: "Description", in: TABLE_OFFER_NAME) && connection.exists(column: "IsGeneralOffer", in: TABLE_OFFER_NAME) && connection.exists(column: "ImageUrl", in: TABLE_OFFER_NAME) && connection.exists(column: "OriginalPrice", in: TABLE_OFFER_NAME) && connection.exists(column: "OfferDescription", in: TABLE_OFFER_NAME) && connection.exists(column: "OfferNewPrice", in: TABLE_OFFER_NAME) && connection.exists(column: "IsStrikethrough", in: TABLE_OFFER_NAME) && connection.exists(column: "PartnerName", in: TABLE_OFFER_NAME) && connection.exists(column: "IsPrivate", in: TABLE_OFFER_NAME) && connection.exists(column: "Duration", in: TABLE_OFFER_NAME) && connection.exists(column: "IsNoPriceToShowOffer", in: TABLE_OFFER_NAME) && connection.exists(column: "IsPriceListOffer", in: TABLE_OFFER_NAME) && connection.exists(column: "IsSetOffer", in: TABLE_OFFER_NAME) && connection.exists(column: "LargeImageUrl", in: TABLE_OFFER_NAME)  )
            {
                offer.appOfferID = row[Expression<Int?>("AppOfferID")]
                offer.Description = row[Expression<String?>("Description")]
                if(row[Expression<Bool?>("IsGeneralOffer")] != nil)
                {
                    offer.isGeneralOffer = row[Expression<Bool?>("IsGeneralOffer")]!
                }
                else
                {
                    offer.isGeneralOffer = false
                }
                offer.imageUrl = row[Expression<String?>("ImageUrl")]
                offer.originalPrice = row[Expression<String?>("OriginalPrice")]
                offer.offerDescription = row[Expression<String?>("OfferDescription")]
                offer.offerNewPrice = row[Expression<String?>("OfferNewPrice")]
                if(row[Expression<Bool?>("IsStrikethrough")] != nil)
                {
                    offer.isStrikethrough = row[Expression<Bool?>("IsStrikethrough")]
                }
                else
                {
                    offer.isStrikethrough = false
                }
                
                offer.partnerName = row[Expression<String?>("PartnerName")]
                
                if(row[Expression<Bool?>("IsPrivate")] != nil)
                {
                    offer.isPrivate = row[Expression<Bool?>("IsPrivate")]
                }
                else
                {
                    offer.isPrivate = false
                }
                
                offer.duration = row[Expression<String?>("Duration")]
                
                if(row[Expression<Bool?>("IsNoPriceToShowOffer")] != nil)
                {
                    offer.isNoPriceToShowOffer = row[Expression<Bool?>("IsNoPriceToShowOffer")]
                }
                else
                {
                    offer.isNoPriceToShowOffer = false
                }
                
                if(row[Expression<Bool?>("IsPriceListOffer")] != nil)
                {
                    offer.isPriceListOffer = row[Expression<Bool?>("IsPriceListOffer")]
                }
                else
                {
                    offer.isPriceListOffer = false
                }
                
                if(row[Expression<Bool?>("IsSetOffer")] != nil)
                {
                    offer.isSetOffer = row[Expression<Bool?>("IsSetOffer")]
                }
                else
                {
                    offer.isSetOffer = false
                }
                
                offer.largeImageUrl = row[Expression<String?>("LargeImageUrl")]
            }
            else
            {
                throw Errors.error
            }
        }
        catch
        {
            throw Errors.error
        }
        return offer
    }
}
