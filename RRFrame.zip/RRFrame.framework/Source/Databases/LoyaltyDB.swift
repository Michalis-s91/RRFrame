//
//  LoyaltyDB.swift
//  RichReach2
//
//  Created by Eumbrella on 29/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import SQLite
import QuartzCore

class LoyaltyDB : NSObject
{
    let DATABASE_NAME = "LoyaltyDB"
    
    var database : Connection!
    var lock = NSObject()
    var version = 1
    
    var pointsStatementTable = Table("PointsStatementTable")
    var ticketsTable = Table("TicketsTable")
    var pointsStatementViewTable = Table("PointsStatementViewTable")
    var ticketViewTable = Table("TicketViewTable")
    var ticketStylesTable = Table("TicketStylesTable")
    var pointsBalanceTable = Table("PointsBalanceTable")
    var lastUpdateDatesTable = Table("LastUpdateDatesTable")
    
    //points statement columns
    let apk = Expression<String>("apk")
    let ticketNo = Expression<String>("ticketNo")
    let transDate = Expression<String>("transDate")
    let amount = Expression<String>("amount")
    let rewardPoints = Expression<String>("rewardPoints")
    let redemptionPoints = Expression<String>("redemptionPoints")
    let balance = Expression<String>("balance")
    let pointsStatementLastUpdateDate = Expression<Date?>("pointsStatementLastUpdateDate")
    
    //ticket columns
    let rowSerial = Expression<Int>("rowSerial")
    let ticketFlag = Expression<String>("ticketFlag")
    let previousPoints = Expression<String>("previousPoints")
    let redeemedPoints = Expression<String>("redeemedPoints")
    let earnedPoints = Expression<String>("earnedPoints")
    let totalPoints = Expression<String>("totalPoints")
    let shop = Expression<String>("shop")
    let discountAmount = Expression<String>("discountAmount")
    let vatPercentage = Expression<String>("vatPercentage")
    let vatAmount = Expression<String>("vatAmount")
    let amountWithVAT = Expression<String>("amountWithVAT")
    let barcode = Expression<String>("barcode")
    let quantity = Expression<String>("quantity")
    let price = Expression<String>("price")
    let lineDiscountAmount = Expression<String>("lineDiscountAmount")
    let lineVATPurcentage = Expression<String>("lineVATPurcentage")
    let lineVATAmount = Expression<String>("lineVATAmount")
    let lineAmountWithVAT = Expression<String>("lineAmountWithVAT")
    let descriptionText = Expression<String>("descriptionText")
    
    //points statement view columns
    let headerBackgroundColor = Expression<String>("headerBackgroundColor")
    let headerTextColor = Expression<String>("headerTextColor")
    let headerTextSize = Expression<Int>("headerTextSize")
    let headerFont = Expression<String>("headerFont")
    let style1 = Expression<Int>("style1")
    let style2 = Expression<Int?>("style2")
    
    //ticket view columns
    let detailsBackgroundColor = Expression<String>("detailsBackgroundColor")
    let detailsTextColor = Expression<String>("detailsTextColor")
    let detailsTextSize = Expression<Int>("detailsTextSize")
    let detailsFont = Expression<String>("detailsFont")
    let ticketStyle = Expression<Int>("ticketStyle")
    let ticketStyle2 = Expression<Int?>("ticketStyle2")
    
    //ticket styles column
    let id = Expression<Int>("id")
    let backgroundColor = Expression<String>("backgroundColor")
    let textColor = Expression<String>("textColor")
    let textSize = Expression<Int>("textSize")
    let font = Expression<String>("font")
    
    let balancePoints = Expression<Double>("balancePoints")
    let balanceAmount = Expression<Double>("balanceAmount")
    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        }
        catch
        {
            print(error)
        }
    }
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        createTables()
        
        switch database.userVersion {
        case 0:
            upgradeToVersion1()
        default:
            break
        }

        
        database.userVersion = version
    }
    
    /// Upgrade database to version 1.
    func upgradeToVersion1()
    {
        do
        {
            try database.run(self.ticketViewTable.addColumn(self.ticketStyle2))
        }
        catch
        {
            print(error)
        }
    }
    
    
    /// Creates the products database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createPointsStatementTable()
        createTicketsTable()
        createPointsStatementViewTable()
        createTicketViewTable()
        createTicketStylesTable()
        createPointsBalanceTable()
        createLastUpdateDatesTable()
        objc_sync_exit(lock)
    }
    
    /*********************************************************                  CREATES                  *********************************************************/
    func createPointsStatementTable()
    {
        let createPointsStatementTable = self.pointsStatementTable.create { (table) in
            table.column(self.apk)
            table.column(self.rowSerial)
            table.column(self.ticketNo)
            table.column(self.transDate)
            table.column(self.amount)
            table.column(self.rewardPoints)
            table.column(self.redemptionPoints)
            table.column(self.balance)
            
            table.primaryKey(self.apk, self.ticketNo)
        }
        
        do {
            try self.database.run(createPointsStatementTable)
        } catch {
            print(error)
        }
    }
    
    func createTicketsTable()
    {
        let createTicketsTable = self.ticketsTable.create { (table) in
            table.column(self.apk)
            table.column(self.rowSerial)
            table.column(self.ticketFlag)
            table.column(self.ticketNo)
            table.column(self.transDate)
            table.column(self.previousPoints)
            table.column(self.redeemedPoints)
            table.column(self.earnedPoints)
            table.column(self.totalPoints)
            table.column(self.shop)
            table.column(self.discountAmount)
            table.column(self.vatPercentage)
            table.column(self.vatAmount)
            table.column(self.amountWithVAT)
            table.column(self.barcode)
            table.column(self.quantity)
            table.column(self.price)
            table.column(self.lineDiscountAmount)
            table.column(self.lineVATPurcentage)
            table.column(self.lineVATAmount)
            table.column(self.lineAmountWithVAT)
            table.column(self.descriptionText)
            
            table.primaryKey(self.apk, self.ticketNo, self.rowSerial)
        }
        
        do {
            try self.database.run(createTicketsTable)
        } catch {
            print(error)
        }
    }
    
    
    func createPointsStatementViewTable()
    {
        let createPointsStatementViewTable = self.pointsStatementViewTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.headerBackgroundColor)
            table.column(self.headerTextColor)
            table.column(self.headerTextSize)
            table.column(self.headerFont)
            table.column(self.style1)
            table.column(self.style2)
        }
        
        do {
            try self.database.run(createPointsStatementViewTable)
        } catch {
            print(error)
        }
    }
    
    
    func createTicketViewTable()
    {
        let createTicketViewTable = self.ticketViewTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.headerBackgroundColor)
            table.column(self.headerTextColor)
            table.column(self.headerTextSize)
            table.column(self.headerFont)
            table.column(self.detailsBackgroundColor)
            table.column(self.detailsTextColor)
            table.column(self.detailsTextSize)
            table.column(self.detailsFont)
            table.column(self.ticketStyle)
            table.column(self.ticketStyle2)
        }
        
        do {
            try self.database.run(createTicketViewTable)
        } catch {
            print(error)
        }
    }
    
    func createTicketStylesTable()
    {
        let createTicketStylesTable = self.ticketStylesTable.create { (table) in
            table.column(self.id, primaryKey : true)
            table.column(self.backgroundColor)
            table.column(self.textColor)
            table.column(self.textSize)
            table.column(self.font)
            
        }
        
        do {
            try self.database.run(createTicketStylesTable)
        } catch {
            print(error)
        }
    }
    
    func createPointsBalanceTable()
    {
        let createTicketStylesTable = self.pointsBalanceTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.balanceAmount)
            table.column(self.balancePoints)
        }
        
        do {
            try self.database.run(createTicketStylesTable)
        } catch {
            print(error)
        }
    }
    
    func createLastUpdateDatesTable()
    {
        let createTicketStylesTable = self.lastUpdateDatesTable.create { (table) in
            table.column(self.apk, primaryKey : true)
            table.column(self.pointsStatementLastUpdateDate)
        }
        
        do {
            try self.database.run(createTicketStylesTable)
        } catch {
            print(error)
        }
    }
    
    /*********************************************************                  INSERTS                  *********************************************************/
    func insertPointsStatement(pointsStatement : [LoyaltyStatementModel]!)
    {
        objc_sync_enter(lock)
        var errorOccured = false
        do
        {
            if(pointsStatement != nil)
            {
                for p in pointsStatement
                {
                    let insertPointsStatement = self.pointsStatementTable.insert(or: .replace,
                                                                                 self.apk <- APK,
                                                                                 self.rowSerial <- p.rowSerial,
                                                                                 self.transDate <- p.transDate,
                                                                                 self.ticketNo <- p.ticketNo,
                                                                                 self.amount <- p.amount,
                                                                                 self.rewardPoints <- p.rewardPoints,
                                                                                 self.redemptionPoints <- p.redemptionPoints,
                                                                                 self.balance <- p.balance)
                    
                    
                    do
                    {
                        try self.database.run(insertPointsStatement)
                    }
                    catch
                    {
                        errorOccured = true
                        print(error)
                    }
                }
                
                if(!errorOccured)
                {
                    let insertPointsStatementLastUpdateDate = self.lastUpdateDatesTable.insert(or: .replace,
                                                                                               self.apk <- APK,
                                                                                               self.pointsStatementLastUpdateDate <-  Date())
                    try self.database.run(insertPointsStatementLastUpdateDate)
                    print("Points statement added")
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertTickets(tickets : [LoyaltyTicketModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(tickets != nil)
            {
                for t in tickets
                {
                    
                    
                    let insertTicket = self.ticketsTable.insert(or: .replace,
                                                                self.apk <- APK,
                                                                self.rowSerial <- t.rowSerial,
                                                                self.ticketFlag <- t.ticketFlag,
                                                                self.ticketNo <- t.ticketNo,
                                                                self.transDate <- t.transDate,
                                                                self.previousPoints <- t.previousPoints,
                                                                self.redeemedPoints <- t.redeemedPoints,
                                                                self.earnedPoints <- t.earnedPoints,
                                                                self.totalPoints <- t.totalPoints,
                                                                self.shop <- t.shop,
                                                                self.discountAmount <- t.discountAmount,
                                                                self.vatPercentage <- t.vatPercentage,
                                                                self.vatAmount <- t.vatAmount,
                                                                self.amountWithVAT <- t.amountWithVAT,
                                                                self.barcode <- t.barcode,
                                                                self.quantity <- t.Quantity,
                                                                self.price <- t.price,
                                                                self.lineDiscountAmount <- t.lineDiscountAmount,
                                                                self.lineVATPurcentage <- t.LineVATPurcentage,
                                                                self.lineVATAmount <- t.lineVATAmount,
                                                                self.lineAmountWithVAT <- t.lineAmountWithVAT,
                                                                self.descriptionText <- t.description)
                    
                    
                    do
                    {
                        try self.database.run(insertTicket)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Ticket added")
                }
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    
    func insertPointsStatementView(pointsStatementView : PointsStatementView!)
    {
        objc_sync_enter(lock)
        do
        {
            if(pointsStatementView != nil)
            {
                
                let insertPointsStatementView = self.pointsStatementViewTable.insert(or: .replace,
                                                                                     self.apk <- APK,
                                                                                     self.headerBackgroundColor <- pointsStatementView.headerBackgroundColor,
                                                                                     self.headerTextColor <- pointsStatementView.headerTextColor,
                                                                                     self.headerTextSize <- pointsStatementView.headerTextSize,
                                                                                     self.headerFont <- correctFontString(s: pointsStatementView.headerFont),
                                                                                     self.style1 <- pointsStatementView.style1,
                                                                                     self.style2 <- pointsStatementView.style2 == nil ? 0 : pointsStatementView.style2)
                
                
                try self.database.run(insertPointsStatementView)
                print("Points statement view added")
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertTicketView(ticketView : TicketView!)
    {
        objc_sync_enter(lock)
        do
        {
            if(ticketView != nil)
            {
                
                let insertTicket = self.ticketViewTable.insert(or: .replace,
                                                               self.apk <- APK,
                                                               self.headerBackgroundColor <- ticketView.headerBackgroundColor,
                                                               self.headerTextColor <- ticketView.headerTextColor,
                                                               self.headerTextSize <- ticketView.headerTextSize,
                                                               self.headerFont <- correctFontString(s: ticketView.headerFont) ,
                                                               self.detailsBackgroundColor <- ticketView.detailsBackgroundColor,
                                                               self.detailsTextColor <- ticketView.detailsTextColor,
                                                               self.detailsTextSize <- ticketView.detailsTextSize,
                                                               self.detailsFont <- correctFontString(s: ticketView.detailsFont) ,
                                                               self.ticketStyle <- ticketView.ticketStyle,
                                                               self.ticketStyle2 <- ticketView.ticketStyle2 == nil ? 0 : ticketView.ticketStyle2)
                
                
                try self.database.run(insertTicket)
                print("Ticket view added")
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertTicketStyles(ticketStyles : [TicketStyle]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(ticketStyles != nil)
            {
                for t in ticketStyles
                {
                    let insertTicket = self.ticketStylesTable.insert(or: .replace,
                                                                     self.id <- t.id,
                                                                     self.backgroundColor <- t.backgroundColor,
                                                                     self.font <- correctFontString(s: t.font) ,
                                                                     self.textSize <- t.textSize,
                                                                     self.textColor <- t.textColor)
                    
                    do
                    {
                        try self.database.run(insertTicket)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Ticket view added")
                }
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertPoitsBalance(pointsBalance : PointsBalanceModel!)
    {
        objc_sync_enter(lock)
        do
        {
            if(pointsBalance != nil)
            {
                    let insertPointsBalance = self.pointsBalanceTable.insert(or: .replace,
                                                                     self.apk <- APK,
                                                                     self.balancePoints <- pointsBalance.points,
                                                                     self.balanceAmount <- pointsBalance.amount)
                
                    try self.database.run(insertPointsBalance)
                    print("Points balance added")
                
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    /*func setPointsStatementLastUpdateDate() -> Date!
    {
        objc_sync_enter(lock)
        do {
            let insertPointsStatementLastUpdateDate = self.lastUpdateDatesTable.insert(or: .replace,
                                                                                       self.apk <- APK,
                                                                                       self.pointsStatementLastUpdateDate <-  nil)
            try self.database.run(insertPointsStatementLastUpdateDate)
            print("Points statement added")
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }*/
    
    /*********************************************************                  GETS                  *********************************************************/
    func getPointsStatementLastUpdateDate() -> Date!
    {
        objc_sync_enter(lock)
        do {
            let lastUpdateDate = try self.database.prepare(self.lastUpdateDatesTable.filter(self.apk == APK))
            
            for l in lastUpdateDate
            {
                objc_sync_exit(lock)
                return l[self.pointsStatementLastUpdateDate]
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getPointsStatement() -> [LoyaltyStatementModel]!
    {
        objc_sync_enter(lock)
        do {
            var pointsStatementModel : [LoyaltyStatementModel] = []
            
            let pointsStatement = try self.database.prepare(self.pointsStatementTable.filter(self.apk == APK).order(self.rowSerial))
            
            for p in pointsStatement
            {
                let points = LoyaltyStatementModel()
                
                points.ticketNo = p[self.ticketNo]
                points.transDate = p[self.transDate]
                points.amount = p[self.amount]
                points.rewardPoints = p[self.rewardPoints]
                points.redemptionPoints = p[self.redemptionPoints]
                points.balance = p[self.balance]
                
                pointsStatementModel.append(points)
            }
            
            objc_sync_exit(lock)
            return pointsStatementModel
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getTickets(ticketNo : String) -> [LoyaltyTicketModel]!
    {
        objc_sync_enter(lock)
        do {
            var ticketsModel : [LoyaltyTicketModel] = []
            
            let tickets = try self.database.prepare(self.ticketsTable.filter(self.apk == APK && ticketNo == self.ticketNo))
            
            for t in tickets
            {
                let ticket = LoyaltyTicketModel()
                
                ticket.ticketFlag = t[self.ticketFlag]
                ticket.ticketNo = t[self.ticketNo]
                ticket.transDate = t[self.transDate]
                ticket.previousPoints = t[self.previousPoints]
                ticket.redeemedPoints = t[self.redeemedPoints]
                ticket.earnedPoints = t[self.earnedPoints]
                ticket.totalPoints = t[self.totalPoints]
                ticket.shop = t[self.shop]
                ticket.discountAmount = t[self.discountAmount]
                ticket.vatPercentage = t[self.vatPercentage]
                ticket.vatAmount = t[self.vatAmount]
                ticket.amountWithVAT = t[self.amountWithVAT]
                ticket.barcode = t[self.barcode]
                ticket.Quantity = t[self.quantity]
                ticket.price = t[self.price]
                ticket.lineDiscountAmount = t[self.lineDiscountAmount]
                ticket.LineVATPurcentage = t[self.lineVATPurcentage]
                ticket.lineVATAmount = t[self.lineVATAmount]
                ticket.lineAmountWithVAT = t[self.lineAmountWithVAT]
                ticket.description = t[self.descriptionText]
                
                ticket.ERPReference = productsDB.getProductItemNoViaBarcode(barcode : ticket.barcode)
                
                ticketsModel.append(ticket)
            }
            
            objc_sync_exit(lock)
            return ticketsModel
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getPointsStatementView() -> PointsStatementView!
    {
        objc_sync_enter(lock)
        do {
            let pointsStatementViewModel = PointsStatementView()
            
            let pointsStatementView = try self.database.prepare(self.pointsStatementViewTable.filter(self.apk == APK))
            
            for p in pointsStatementView
            {
                pointsStatementViewModel.headerBackgroundColor = p[self.headerBackgroundColor]
                pointsStatementViewModel.headerTextColor = p[self.headerTextColor]
                pointsStatementViewModel.headerFont = p[self.headerFont]
                pointsStatementViewModel.headerTextSize = p[self.headerTextSize]
                pointsStatementViewModel.style1 = p[self.style1]
                pointsStatementViewModel.style2 = p[self.style2]
                
                pointsStatementViewModel.style1Model = getTicketStyle(id: pointsStatementViewModel.style1)
                pointsStatementViewModel.style2Model = getTicketStyle(id: pointsStatementViewModel.style2)
                
                objc_sync_exit(lock)
                return pointsStatementViewModel
            }
            

        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getTicketView() -> TicketView!
    {
        objc_sync_enter(lock)
        do {
            let ticketViewModel = TicketView()
            
            let ticketView = try self.database.prepare(self.ticketViewTable.filter(self.apk == APK))
            
            for t in ticketView
            {
                ticketViewModel.headerBackgroundColor = t[self.headerBackgroundColor]
                ticketViewModel.headerTextColor = t[self.headerTextColor]
                ticketViewModel.headerFont = t[self.headerFont]
                ticketViewModel.headerTextSize = t[self.headerTextSize]
                ticketViewModel.detailsBackgroundColor = t[self.detailsBackgroundColor]
                ticketViewModel.detailsFont = t[self.detailsFont]
                ticketViewModel.detailsTextSize = t[self.detailsTextSize]
                ticketViewModel.detailsTextColor = t[self.detailsTextColor]
                ticketViewModel.ticketStyle = t[self.ticketStyle]
                ticketViewModel.ticketStyle2 = t[self.ticketStyle2]
                
                ticketViewModel.ticketStyleModel =  getTicketStyle(id: ticketViewModel.ticketStyle)
                ticketViewModel.ticketStyleModel2 =  getTicketStyle(id: ticketViewModel.ticketStyle2)
                
                objc_sync_exit(lock)
                return ticketViewModel
            }
            
            
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getTicketStyle(id : Int) -> TicketStyle!
    {
        objc_sync_enter(lock)
        do {
            let tickeStyleModel = TicketStyle()
            
            let ticketStyle = try self.database.prepare(self.ticketStylesTable.filter(self.id == id))
            
            for t in ticketStyle
            {
                tickeStyleModel.backgroundColor = t[self.backgroundColor]
                tickeStyleModel.font = t[self.font]
                tickeStyleModel.textColor = t[self.textColor]
                tickeStyleModel.textSize = t[self.textSize]
                
                objc_sync_exit(lock)
                return tickeStyleModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getPointsBalance() -> PointsBalanceModel!
    {
        objc_sync_enter(lock)
        do {
            let pointsBalanceModel = PointsBalanceModel()
            
            let pointsBalance = try self.database.prepare(self.pointsBalanceTable.filter(self.apk == APK))
            
            for p in pointsBalance
            {
                pointsBalanceModel.amount = p[self.balanceAmount]
                pointsBalanceModel.points = p[self.balancePoints]
                
                objc_sync_exit(lock)
                return pointsBalanceModel
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    
    /*func deleteEntries(apk : String)
    {
        objc_sync_enter(lock)
        
        if(!statusModel.isPointsStatementSaved)
        {
            do{
                try self.database.run(self.pointsStatementTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if(!statusModel.areTicketsSaved)
        {
            do{
                try self.database.run(self.ticketsTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        objc_sync_exit(lock)
    }*/
    
}
