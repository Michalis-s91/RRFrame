//
//  StoresDB.swift
//  RichReach2
//
//  Created by Eumbrella on 27/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import SQLite
import QuartzCore

class StoresDB : NSObject
{
    let DATABASE_NAME = "StoresDB"
    
    var database : Connection!
    var lock = NSObject()
    var version = 3
    
    var storesTable = Table("StoreTable")
    var holidaysTable = Table("HolidaysTable")
    var shopHolidaysTable = Table("ShopHolidaysTable")
    var proximityOffersTable = Table("ProximityOffersTable")
    var storesAvailableOffersTable = Table("storesAvailableOffersTable")
    
    //Store columns
    let apk = Expression<String>("apk")
    let addressID = Expression<Int>("addressID")
    let storeDescription = Expression<String>("storeDescription")
    let address1 = Expression<String>("address1")
    let address2 = Expression<String?>("address2")
    let city = Expression<String>("city")
    let region = Expression<String?>("region")
    let postCode = Expression<String>("postCode")
    let contactPhone = Expression<String>("contactPhone")
    let contactPhone2 = Expression<String?>("contactPhone2")
    let contactFax = Expression<String?>("contactFax")
    let contactEmail = Expression<String?>("contactEmail")
    let latitude = Expression<String?>("latitude")
    let longitude = Expression<String?>("longitude")
    let contactMobile = Expression<String?>("contactMobile")
    let ERPCode = Expression<String>("ERPCode")
    let infoType = Expression<String>("infoType")
    let infoID = Expression<Int>("infoID")
    let hours = Expression<Data>("hours")
    let radius = Expression<Int!>("radius")
    let radius2 = Expression<Int?>("radius2")
    
    //holidays table columns
    let cliendID = Expression<Int64>("cliendID")
    let date = Expression<String>("date")
    let holidayDescription = Expression<String>("holidayDescription")
    
    //shop holidays table columns
    let holidayDate = Expression<String>("holidayDate")
    let startTime1 = Expression<String?>("startTime1")
    let endTime1 = Expression<String?>("endTime1")
    let startTime2 = Expression<String?>("startTime2")
    let endTime2 = Expression<String?>("endTime2")
    
    let url = Expression<String>("url")
    
    let businessID = Expression<Int>("businessID")
    let title = Expression<String>("title")
    let offerDescription = Expression<String>("offerDescription")
    let startDate = Expression<String>("startDate")
    let endDate = Expression<String>("endDate")
    let offerDuration = Expression<Int>("offerDuration")
    let termsAndConditions = Expression<String>("termsAndConditions")
    let offerImageUrl = Expression<String>("offerImageUrl")
    let couponCode = Expression<String>("couponCode")
    let isOfferAlreadyGiven = Expression<Bool>("isOfferAlreadyGiven")
    let numOfDaysForNextOffer = Expression<Int>("numOfDaysForNextOffer")
    let index = Expression<Int>("index")
    let offerID = Expression<Int?>("offerID")
    
    //stores available offers table columns
    let storeId = Expression<Int>("StoreId")
    
    override init(){
        do{
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent(DATABASE_NAME).appendingPathExtension("sqlite3")
            self.database = try Connection(fileUrl.path)
        }
        catch
        {
            print(error)
        }
    }
    
    /// Checks if database need to be upgraded, and upgrade it if needed.
    func checkForUpgrade()
    {
        createTables()
        
        switch database.userVersion {
        case 0:
            upgradeToVersion1()
            break
        case 1:
            upgradeToVersion2()
            break
        case 2:
            upgradeToVersion3()
        default:
            break
        }
        
        database.userVersion = version
    }
    
    /// Upgrade database to version 1.
    func upgradeToVersion1()
    {
        do
        {
            try database.run(self.storesTable.addColumn(self.radius))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion2()
    }
    
    func upgradeToVersion2()
    {
        do
        {
            try database.run(self.storesTable.addColumn(self.radius2))
        }
        catch
        {
            print(error)
        }
        
        upgradeToVersion3()
        
    }
    
    func upgradeToVersion3()
    {
        do
        {
            try database.run(self.proximityOffersTable.addColumn(self.offerID))
        }
        catch
        {
            print(error)
        }
    }
    
    /// Creates the products database tables.
    func createTables()
    {
        objc_sync_enter(lock)
        createsStoreTable()
        createsHolidaysTable()
        createsShopHolidaysTable()
        createsImagesTable()
        createProximityOffersTable()
        createStoresAvailableOffersTable()
        objc_sync_exit(lock)
    }
    
    
    /*********************************************************                  CREATES                  *********************************************************/
    func createsStoreTable()
    {
        let createsStoreTable = self.storesTable.create { (table) in
            table.column(self.apk)
            table.column(self.addressID, primaryKey : true)
            table.column(self.storeDescription)
            table.column(self.address1)
            table.column(self.address2)
            table.column(self.city)
            table.column(self.region)
            table.column(self.postCode)
            table.column(self.contactPhone)
            table.column(self.contactPhone2)
            table.column(self.contactFax)
            table.column(self.contactEmail)
            table.column(self.contactMobile)
            table.column(self.latitude)
            table.column(self.longitude)
            table.column(self.ERPCode)
            table.column(self.infoType)
            table.column(self.infoID)
            table.column(self.hours)
            table.column(self.radius2)
            
        }
        
        do {
            try self.database.run(createsStoreTable)
        } catch {
            print(error)
        }
    }
    
    func createsHolidaysTable()
    {
        let createsHolidaysTable = self.holidaysTable.create { (table) in
            table.column(self.cliendID)
            table.column(self.holidayDate)
            table.column(self.holidayDescription)
            
            table.primaryKey(self.cliendID, self.holidayDate)
        }
        
        do {
            try self.database.run(createsHolidaysTable)
        } catch {
            print(error)
        }
    }
    
    func createsShopHolidaysTable()
    {
        let createsShopHolidaysTable = self.shopHolidaysTable.create { (table) in
            table.column(self.addressID)
            table.column(self.holidayDate)
            table.column(self.startTime1)
            table.column(self.endTime1)
            table.column(self.startTime2)
            table.column(self.endTime2)
            
            table.primaryKey(self.addressID, self.holidayDate)
        }
        
        do {
            try self.database.run(createsShopHolidaysTable)
        } catch {
            print(error)
        }
    }
    
    func createProximityOffersTable()
    {
        let createProximityOffersTable = self.proximityOffersTable.create { (table) in
            table.column(self.businessID)
            table.column(self.index)
            table.column(self.title)
            table.column(self.offerDescription)
            table.column(self.startDate)
            table.column(self.endDate)
            table.column(self.offerDuration)
            table.column(self.termsAndConditions)
            table.column(self.offerImageUrl)
            table.column(self.couponCode)
            table.column(self.isOfferAlreadyGiven)
            table.column(self.numOfDaysForNextOffer)
            table.column(self.offerID)
            
            
            table.primaryKey(self.index, self.businessID)
        }
        
        do {
            try self.database.run(createProximityOffersTable)
            
        } catch {
            print(error)
        }
        
    }
    
    func createStoresAvailableOffersTable(){
        
        
        let createStoresAvailableOffersTable = self.storesAvailableOffersTable.create { (table) in
            table.column(self.apk)
            table.column(self.businessID)
            table.column(self.storeId)
            table.column(self.couponCode)
            table.column(self.index)
            
            table.primaryKey(self.index, self.businessID, self.storeId)
            
        }
        do {
            try self.database.run(createStoresAvailableOffersTable)
            
        } catch {
            print(error)
        }
        
    }
    
    var waitForNavImageToDownloaded = false
    var waitingForGettingImage = false
    var isGettingImagesFinished = false
    var storeImagesTable = Table("StoreImagesTable")
    let storeImage = Expression<Data>("storeImage")
    
    func createsImagesTable()
    {
        let createsStoreImagesTable = self.storeImagesTable.create { (table) in
            table.column(self.url)
            table.column(self.apk)
            table.column(self.storeImage)
            
            table.primaryKey(self.apk, self.url)
        }
        
        do {
            try self.database.run(createsStoreImagesTable)
        } catch {
            print(error)
        }
    }
    
    /*func downloadImage(url: String) {
     let urlTemp = URL(string: percentEncode(s: url))
     getDataFromUrl(url: urlTemp!) { data, response, error in
     guard let data = data, error == nil else
     {
     DispatchQueue.global(qos: .background).async {
     self.waitForNavImageToDownloaded = false
     }
     return
     }
     
     self.insertImage(url : url,str: data)
     self.waitForNavImageToDownloaded = false
     }
     }*/
    
    
    /*********************************************************                  INSERTS                  *********************************************************/
    func insertImage(url : String,str : Data)
    {
        if(str != nil)
        {
            objc_sync_enter(lock)
            do {
                let storeImage = self.storeImagesTable.insert(or: .replace,
                                                              self.url <- url,
                                                              self.apk <- APK,
                                                              self.storeImage <- str)
                
                try self.database.run(storeImage)
                print("Store image added")
            }
            catch
            {
                print(error)
            }
            
            objc_sync_exit(lock)
        }
    }
    
    func getImage(url : String) -> UIImage!
    {
        /*if(waitForNavImageToDownloaded)
         {
         waitingForGettingImage = true
         isGettingImagesFinished = false
         while(waitForNavImageToDownloaded)
         {
         
         }
         }*/
        
        
        objc_sync_enter(lock)
        print("insert image lock")
        do {
            let storeImage = try self.database.prepare(self.storeImagesTable.filter(self.apk == APK && self.url == url))
            
            for s in storeImage
            {
                
                isGettingImagesFinished = true
                print("image getted")
                let image = UIImage(data: s[self.storeImage])
                objc_sync_exit(lock)
                return image
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        print("image getted")
        isGettingImagesFinished = true
        return nil
    }
    
    func deleteImage(url : String)
    {
        //objc_sync_enter(lock)
        do{
            try self.database.run(self.storeImagesTable.filter(self.apk == APK && self.url == url).delete())
        } catch {
            print(error)
        }
        //objc_sync_exit(lock)
    }
    
    func insertStores(stores : [StoreModel]!, storesHours : [ListHoursModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(stores != nil && storesHours != nil)
            {
                for h in storesHours
                {
                    for s in stores
                    {
                        if (h.addressID == s.addressID)
                        {
                            switch Int(s.infoType)
                            {
                            case SlotType.Photo.rawValue:
                                s.photo.aspectRatio = calculateImageAspectRatio(imageUrl: s.photo.imageUrl)
                                viewsDB.insertPhoto(id: s.infoID, photo: s.photo, isStore: true)
                            case SlotType.Video.rawValue:
                                viewsDB.insertVideo(id: s.infoID, video: s.video)
                            case SlotType.Carousel.rawValue:
                                viewsDB.insertCarousel(id: s.infoID, carousel: s.carousel, isStore: true)
                            default:
                                break
                            }
                            
                            let jsonEncoder = JSONEncoder()
                            let jsonData = try jsonEncoder.encode(h)
                            if(!isNullOrEmpty(string: s.radiusString)){
                                s.radius = Int (s.radiusString)
                            }
                            
                            let insertStore = self.storesTable.insert(or: .replace,
                                                                      self.apk <- APK,
                                                                      self.addressID <- s.addressID,
                                                                      self.storeDescription <- s.description,
                                                                      self.address1 <- s.address1 == nil ? "" : s.address1,
                                                                      self.address2 <- s.address2,
                                                                      self.city <- s.city == nil ? "" : s.city,
                                                                      self.region <- s.region,
                                                                      self.postCode <- s.postCode == nil ? "" : s.postCode,
                                                                      self.contactPhone <- s.contactPhone  == nil ? "" : s.contactPhone,
                                                                      self.contactPhone2 <- s.contactPhone2,
                                                                      self.contactFax <- s.contactFax,
                                                                      self.contactEmail <- s.contactEmail,
                                                                      self.contactMobile <- s.contactMobile,
                                                                      self.latitude <- s.latitude,
                                                                      self.longitude <- s.longitude,
                                                                      self.ERPCode <- s.ERPCode == nil ? "" : s.ERPCode,
                                                                      self.infoType <- s.infoType == nil ? "0" : s.infoType,
                                                                      self.infoID <- s.infoID == nil ? 0 : s.infoID,
                                                                      self.hours <- jsonData,
                                                                      self.radius2 <- s.radius)
                            
                            
                            do
                            {
                                try self.database.run(insertStore)
                            }
                            catch
                            {
                                print(error)
                            }
                            
                            print("Store added")
                            break
                        }
                    }
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertHolidays(holidays : [YearlyHolidaysModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(holidays != nil)
            {
                for h in holidays
                {
                    let insertHoliday = self.holidaysTable.insert(or: .replace,
                                                                  self.cliendID <- cliendID,
                                                                  self.holidayDate <- h.holidayDate,
                                                                  self.holidayDescription <- h.description)
                    
                    
                    do
                    {
                        try self.database.run(insertHoliday)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Holiday added")
                    
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertShopHolidays(shopHolidays : [YearlyShopHolidaysModel]!)
    {
        objc_sync_enter(lock)
        do
        {
            if(shopHolidays != nil)
            {
                for h in shopHolidays
                {
                    let insertShopHolidays = self.shopHolidaysTable.insert(or: .replace,
                                                                           self.addressID <- h.addressID,
                                                                           self.holidayDate <- h.holidayDate,
                                                                           self.startTime1 <- h.startTime1,
                                                                           self.endTime1  <- h.endTime1,
                                                                           self.startTime2 <- h.startTime2,
                                                                           self.endTime2 <- h.endTime2)
                    
                    do
                    {
                        try self.database.run(insertShopHolidays)
                    }
                    catch
                    {
                        print(error)
                    }
                    
                    print("Shop holiday added")
                    
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertProximityOffers(proximityOffers : [ProximityOfferModel]!, businessID : Int!, apk : String!)
    {
        
        
        objc_sync_enter(lock)
        do
        {
            if(proximityOffers != nil)
            {
                var i : Int = 1
                for p in proximityOffers
                {
                    let insertProximityOffer = self.proximityOffersTable.insert(or: .replace,
                                                                                self.businessID <- businessID,
                                                                                self.title <- p.title,
                                                                                self.offerDescription <- p.offerDescription,
                                                                                self.startDate <- p.startDate,
                                                                                self.endDate <- p.endDate,
                                                                                self.offerDuration <- p.offerDuration,
                                                                                self.termsAndConditions <- p.termsAndConditions,
                                                                                self.offerImageUrl <- p.offerImageUrl,
                                                                                self.couponCode <- p.couponCode,
                                                                                self.isOfferAlreadyGiven <- false,
                                                                                self.numOfDaysForNextOffer <- p.numOfDaysForNextOffer,
                                                                                self.index <- p.index,
                                                                                self.offerID <- i)
                    
                    
                    
                    insertStoresAvailableOffers(proximityOfferModel: p, apk: APK, businessID: businessID)
                    do
                    {
                        try self.database.run(insertProximityOffer)
                    }
                    catch
                    {
                        print(error)
                    }
                    i+=1
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    func insertStoresAvailableOffers(proximityOfferModel : ProximityOfferModel!, apk : String, businessID : Int)
    {
        objc_sync_enter(lock)
        do{
            
            if (proximityOfferModel != nil && proximityOfferModel.storeIdList != nil){
                for s in proximityOfferModel.storeIdList
                {
                    if (s != nil){
                        let insertStoresAvailableOffer = self.storesAvailableOffersTable.insert(or: .replace,
                                                                                                self.apk <- apk,
                                                                                                self.businessID <- businessID,
                                                                                                self.storeId <- s,
                                                                                                self.couponCode <- proximityOfferModel.couponCode,
                                                                                                self.index <- proximityOfferModel.index)
                        
                        do
                        {
                            try self.database.run(insertStoresAvailableOffer)
                        }
                        catch
                        {
                            print(error)
                        }
                    }
                }
            }
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
    }
    
    /*********************************************************                  GETS                  *********************************************************/
    func getStores() -> [StoreModel]!
    {
        objc_sync_enter(lock)
        do {
            var storesModels : [StoreModel] = []
            
            let stores = try self.database.prepare(self.storesTable.filter(self.apk == APK))
            
            for s in stores
            {
                let storeModel = StoreModel()
                storeModel.addressID = s[self.addressID]
                storeModel.description = s[self.storeDescription]
                storeModel.address1 = s[self.address1]
                storeModel.address2 = s[self.address2]
                storeModel.city = s[self.city]
                storeModel.region = s[self.region]
                storeModel.postCode = s[self.postCode]
                storeModel.contactPhone = s[self.contactPhone]
                storeModel.contactPhone2 = s[self.contactPhone2]
                storeModel.contactEmail = s[self.contactEmail]
                storeModel.contactFax = s[self.contactFax]
                storeModel.contactMobile = s[self.contactMobile]
                storeModel.latitude = s[self.latitude]
                storeModel.longitude = s[self.longitude]
                storeModel.ERPCode = s[self.ERPCode]
                storeModel.infoType = s[self.infoType]
                storeModel.infoID = s[self.infoID]
                storeModel.radius = s[self.radius2]
                
                let hours = s[self.hours]
                let jsonDecoder = JSONDecoder()
                storeModel.hours = try jsonDecoder.decode(ListHoursModel.self, from: hours)
                
                switch Int(storeModel.infoType)
                {
                case SlotType.Photo.rawValue:
                    storeModel.photo = viewsDB.getPhoto(id: storeModel.infoID)
                case SlotType.Video.rawValue:
                    storeModel.video = viewsDB.getVideo(id: storeModel.infoID)
                case SlotType.Carousel.rawValue:
                    storeModel.carousel = viewsDB.getCarousel(id: storeModel.infoID)
                default:
                    break
                }
                
                storesModels.append(storeModel)
            }
            
            objc_sync_exit(lock)
            return storesModels
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getHolidays() -> [YearlyHolidaysModel]!
    {
        objc_sync_enter(lock)
        do {
            var holidaysModels : [YearlyHolidaysModel] = []
            
            let holidays = try self.database.prepare(self.holidaysTable.filter(self.cliendID == cliendID))
            
            for h in holidays
            {
                let holidayModel = YearlyHolidaysModel()
                
                holidayModel.holidayDate = h[self.holidayDate]
                holidayModel.description = h[self.holidayDescription]
                
                holidaysModels.append(holidayModel)
            }
            
            objc_sync_exit(lock)
            return holidaysModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    /*func getShopHolidays() -> [YearlyShopHolidaysModel]!
     {
     objc_sync_enter(lock)
     do {
     var shopHolidaysModels : [YearlyShopHolidaysModel] = []
     
     let holidays = try self.database.prepare(self.shopHolidaysTable.filter(self.cliendID == cliendID))
     
     for h in holidays
     {
     let shopHolidayModel = YearlyShopHolidaysModel()
     
     shopHolidayModel.addressID = h[self.addressID]
     shopHolidayModel.holidayDate = h[self.holidayDate]
     shopHolidayModel.startTime1 = h[self.startTime1]
     shopHolidayModel.endTime1 = h[self.endTime1]
     shopHolidayModel.startTime2 = h[self.startTime2]
     shopHolidayModel.endTime2 = h[self.endTime2]
     
     shopHolidaysModels.append(shopHolidayModel)
     }
     
     objc_sync_exit(lock)
     return shopHolidaysModels
     }
     catch
     {
     print(error)
     }
     
     objc_sync_exit(lock)
     return nil
     }*/
    
    func getShopHolidays(addressID: Int! ) -> [YearlyShopHolidaysModel]!
    {
        objc_sync_enter(lock)
        do {
            var shopHolidaysModels : [YearlyShopHolidaysModel] = []
            
            let holidays = try self.database.prepare(self.shopHolidaysTable.filter(self.addressID == addressID))
            
            for h in holidays
            {
                let shopHolidayModel = YearlyShopHolidaysModel()
                
                shopHolidayModel.addressID = h[self.addressID]
                shopHolidayModel.holidayDate = h[self.holidayDate]
                shopHolidayModel.startTime1 = h[self.startTime1]
                shopHolidayModel.endTime1 = h[self.endTime1]
                shopHolidayModel.startTime2 = h[self.startTime2]
                shopHolidayModel.endTime2 = h[self.endTime2]
                
                shopHolidaysModels.append(shopHolidayModel)
            }
            
            objc_sync_exit(lock)
            return shopHolidaysModels
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
    }
    
    func getProximityOffers(couponCodeList: [String]!) -> [ProximityOfferModel]!
    {
        objc_sync_enter(lock)
        
        var proximityOfferModels : [ProximityOfferModel] = []
        
        do {
            if (couponCodeList != nil)
            {
                for c in couponCodeList
                {
                    let proximityOffers = try self.database.prepare(self.proximityOffersTable.filter(self.businessID == businessID && self.couponCode == c))
                    
                    for p in proximityOffers
                    {
                        let proximityOfferModel = ProximityOfferModel()
                        
                        proximityOfferModel.title = p[self.title]
                        proximityOfferModel.offerDescription = p[self.offerDescription]
                        proximityOfferModel.startDate = p[self.startDate]
                        proximityOfferModel.endDate = p[self.endDate]
                        proximityOfferModel.offerDuration = p[self.offerDuration]
                        proximityOfferModel.termsAndConditions = p[self.termsAndConditions]
                        proximityOfferModel.offerImageUrl = p[self.offerImageUrl]
                        proximityOfferModel.couponCode = p[self.couponCode]
                        proximityOfferModel.isOfferAlreadyGiven = p[self.isOfferAlreadyGiven]
                        proximityOfferModel.numOfDaysForNextOffer = p[self.numOfDaysForNextOffer]
                        proximityOfferModel.index = p[self.index]
                        proximityOfferModel.offerID = p[self.offerID]
                        
                        proximityOfferModels.append(proximityOfferModel)
                    }
                }
            }
            objc_sync_exit(lock)
            return proximityOfferModels
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return proximityOfferModels
    }
    
    func getProximityOffersByBusinessID() -> [ProximityOfferModel]!
    {
        objc_sync_enter(lock)
        
        var proximityOfferModels : [ProximityOfferModel] = []
        
        do {
            
            let proximityOffers = try self.database.prepare(self.proximityOffersTable.filter(self.businessID == businessID))
            
            for p in proximityOffers
            {
                let proximityOfferModel = ProximityOfferModel()
                
                proximityOfferModel.title = p[self.title]
                proximityOfferModel.offerDescription = p[self.offerDescription]
                proximityOfferModel.startDate = p[self.startDate]
                proximityOfferModel.endDate = p[self.endDate]
                proximityOfferModel.offerDuration = p[self.offerDuration]
                proximityOfferModel.termsAndConditions = p[self.termsAndConditions]
                proximityOfferModel.offerImageUrl = p[self.offerImageUrl]
                proximityOfferModel.couponCode = p[self.couponCode]
                proximityOfferModel.isOfferAlreadyGiven = p[self.isOfferAlreadyGiven]
                proximityOfferModel.numOfDaysForNextOffer = p[self.numOfDaysForNextOffer]
                proximityOfferModel.index = p[self.index]
                proximityOfferModel.offerID = p[self.offerID]
                
                proximityOfferModels.append(proximityOfferModel)
            }
            
            objc_sync_exit(lock)
            return proximityOfferModels
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return proximityOfferModels
    }
    
    func getStoresAvailableOffer(storeID: Int!) -> ProximityOfferModel!{
        objc_sync_enter(lock)
        do {
            
            var couponCodeList : [String] = []
            var proximityOfferModelList : [ProximityOfferModel] = []
            var proximityOffer = ProximityOfferModel()
            
            let StoresAvailableOffers = try self.database.prepare(self.storesAvailableOffersTable.filter(self.businessID == businessID && self.storeId == storeID && self.apk == APK))
            
            for st in StoresAvailableOffers{
                couponCodeList.append(st[self.couponCode])
            }
            
            if (!couponCodeList.isEmpty){
                
                proximityOfferModelList = getProximityOffers(couponCodeList: couponCodeList)
                
                for p in proximityOfferModelList{
                    
                    if (!p.isOfferAlreadyGiven){
                        
                        var currentDate = Date()
                        currentDate.addTimeInterval(60 * 60 * 2)
                        
                        proximityOffer = p
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "dd/MM/yyyy" //Your date format
                        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
                        
                        
                        let startDate1 = dateFormatter.date(from: proximityOffer.startDate)
                        var endDate1 = dateFormatter.date(from: proximityOffer.endDate)
                        endDate1?.addTimeInterval(60 * 60 * 24)
                        
                        if(!isNullOrEmpty(string: proximityOffer.startDate) && !isNullOrEmpty(string: proximityOffer.endDate))
                        {
                            if(((endDate1 ?? Date()) < currentDate ?? Date()) || (currentDate ?? Date() < (startDate1 ?? Date())) )
                            {
                                continue
                            }
                        }
                        else if (!isNullOrEmpty(string: proximityOffer.startDate))
                        {
                            if currentDate ?? Date() < (startDate1 ?? Date())
                            {
                                continue
                            }
                        }
                        else if (!isNullOrEmpty(string: proximityOffer.endDate))
                        {
                            if (endDate1 ?? Date()) < currentDate ?? Date()
                            {
                                continue
                            }
                        }
                        
                        
                        return proximityOffer
                        
                        /*if((isNullOrEmpty(string: proximityOffer.startDate) && isNullOrEmpty(string: proximityOffer.endDate))
                         || (isNullOrEmpty(string: proximityOffer.startDate) && endDate1!.timeIntervalSinceNow.sign == .plus)
                         || (isNullOrEmpty(string: proximityOffer.endDate) && startDate1!.timeIntervalSinceNow.sign == .minus))
                         {
                         if (p.numOfDaysForNextOffer > 0){
                         let newStartDate = Calendar.current.date(byAdding: dateComponent, to: currentDate)
                         let newDate: String = dateFormatter.string(from: newStartDate!)
                         let updatedDate = dateFormatter.date(from: newDate)!
                         for pr in proximityOfferModelList{
                         let nextStartDate = dateFormatter.date(from: pr.startDate)!
                         if ((isNullOrEmpty(string: pr.startDate)) || updatedDate > nextStartDate){
                         updateNextAvailableProximityOfferStartDate(proximityOfferModel: pr, nextAvailableOfferDate: newDate)
                         }
                         }
                         }
                         return proximityOffer
                         }
                         else {
                         if (isNullOrEmpty(string: proximityOffer.startDate)) {
                         if (endDate1!.timeIntervalSinceNow.sign == .minus){
                         continue;
                         }
                         }
                         else if (isNullOrEmpty(string: proximityOffer.endDate)) {
                         if (startDate1!.timeIntervalSinceNow.sign == .plus){
                         continue;
                         }
                         }
                         else {
                         if (startDate1!.timeIntervalSinceNow.sign == .minus && endDate1!.timeIntervalSinceNow.sign == .plus){
                         if (p.numOfDaysForNextOffer > 0){
                         let newStartDate = Calendar.current.date(byAdding: dateComponent, to: currentDate)
                         let newDate: String = dateFormatter.string(from: newStartDate!)
                         let updatedDate = dateFormatter.date(from: newDate)!
                         for pr in proximityOfferModelList{
                         let nextStartDate = dateFormatter.date(from: pr.startDate)
                         if ((isNullOrEmpty(string: pr.startDate)) || updatedDate > nextStartDate!){
                         updateNextAvailableProximityOfferStartDate(proximityOfferModel: pr, nextAvailableOfferDate: newDate)
                         }
                         }
                         }
                         return proximityOffer
                         }
                         }
                         }*/
                    }
                }
            }
            
        }
        catch
        {
            print(error)
        }
        
        objc_sync_exit(lock)
        return nil
        
    }
    
    func updateNextAvailableProximityOfferStartDate(proximityOfferModel : ProximityOfferModel, nextAvailableOfferDate : String){
        
        let newFilter = self.proximityOffersTable.filter(self.index == proximityOfferModel.index && self.businessID == businessID)
        
        let updateNextAvailableOffer = newFilter.update(self.startDate <- nextAvailableOfferDate)
        
        do
        {
            try self.database.run(updateNextAvailableOffer)
        }
        catch
        {
            print(error)
        }
    }
    
    func updateProximityOffer(proximityOfferModel : ProximityOfferModel){
        
        let newFilter2 = self.proximityOffersTable.filter(self.index == proximityOfferModel.index && self.businessID == businessID)
        let updateProximityOffer =  newFilter2.update(self.isOfferAlreadyGiven <- true)
        
        do
        {
            try self.database.run(updateProximityOffer)
            
        }
        catch
        {
            print(error)
        }
        
        var proximityOfferModelList : [ProximityOfferModel] = []
        proximityOfferModelList = getProximityOffersByBusinessID()
        
        for offer in proximityOfferModelList{
            if (proximityOfferModel.offerID == offer.offerID){
                updateSameOfferId(proximityOfferModel: offer)
            }
        }
        
        
        if (proximityOfferModel.numOfDaysForNextOffer > 0){
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy" //Your date format
            dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
            
            var currentDate = Date()
            var dateComponent = DateComponents()
            dateComponent.day = proximityOfferModel.numOfDaysForNextOffer
            
            let newStartDate = Calendar.current.date(byAdding: dateComponent, to: currentDate)
            let newDate: String = dateFormatter.string(from: newStartDate!)
            //let updatedDate = dateFormatter.date(from: newDate)!
            
            for pr in proximityOfferModelList{
                let nextStartDate = dateFormatter.date(from: pr.startDate)
                if ((isNullOrEmpty(string: pr.startDate)) || newStartDate! > nextStartDate!){
                    updateNextAvailableProximityOfferStartDate(proximityOfferModel: pr, nextAvailableOfferDate: newDate)
                }
            }
        }
        
        
    }
    
    func updateSameOfferId(proximityOfferModel : ProximityOfferModel){
        let newFilter2 = self.proximityOffersTable.filter(self.index == proximityOfferModel.index && self.businessID == businessID)
        let updateProximityOffer =  newFilter2.update(self.isOfferAlreadyGiven <- true)
        
        do
        {
            try self.database.run(updateProximityOffer)
            
        }
        catch
        {
            print(error)
        }
    }
    
    
    func isOfferNearBy(latitude : Double, longitude : Double) -> ProximityOfferModel!
    {
        let stores = getStores()
        
        if(stores != nil)
        {
            for s in stores!
            {
                let distanceTest = distanceBetweenSpots(lat1: Double(s.latitude)!, lon1: Double (s.longitude)!, lat2: latitude, lon2: longitude, unit: "M")
                print(distanceTest)
                if(s.radius != nil && distanceTest <= s.radius)
                {
                    if (isShopOpen(store: s, holidays: s.closedHolidays)){
                        let offer = getStoresAvailableOffer(storeID: s.addressID)
                        
                        if(offer != nil)
                        {
                            offer!.givenOfferStoreID = s.addressID
                            print("offer returned")
                            return offer
                        }
                    }
                }
            }
        }
        
        return nil
    }
    
    
    func deleteEntries(apk : String)
    {
        objc_sync_enter(lock)
        
        if(!statusModel.areHolidaysSaved)
        {
            do{
                try self.database.run(self.holidaysTable.filter(self.cliendID == cliendID).delete())
            } catch {
                print(error)
            }
            
            do{
                let stores = try self.database.prepare(self.storesTable.filter(self.apk == apk))
                
                for s in stores
                {
                    try self.database.run(self.shopHolidaysTable.filter(self.addressID == s[self.addressID]).delete())
                }
            } catch {
                print(error)
            }
            
        }
        
        if(!statusModel.areStoresSaved)
        {
            do{
                let stores = try self.database.prepare(self.storesTable.filter(self.apk == apk))
                
                for s in stores
                {
                    switch Int(s[self.infoType])
                    {
                    case SlotType.Photo.rawValue:
                        viewsDB.deletePhoto(apk: APK, id: s[self.infoID])
                    case SlotType.Carousel.rawValue:
                        viewsDB.deleteCarousel(apk: APK, id: s[self.infoID])
                    default:
                        break
                    }
                }
                
                try self.database.run(self.storesTable.filter(self.apk == apk).delete())
            } catch {
                print(error)
            }
        }
        
        if (!statusModel.areProximityOffersSaved){
            do{
                try self.database.run(self.proximityOffersTable.filter(self.businessID == businessID).delete())
            } catch {
                print(error)
            }
            
            do{
                try self.database.run(self.storesAvailableOffersTable.filter(self.businessID == businessID && self.apk == APK).delete())
                
            } catch {
                print(error)
            }
        }
        
        
        
        objc_sync_exit(lock)
    }
}
