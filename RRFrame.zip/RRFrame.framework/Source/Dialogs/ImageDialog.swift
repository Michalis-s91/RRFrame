//
//  ImageDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 02/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ImageDialog: UIViewController {
    @IBOutlet var messageLabel: UILabel!
    @IBOutlet var yesNoMessageDialogView: UIView!
    @IBOutlet var backgroundView: UIView!
    @IBOutlet var dialogView: UIView!
    @IBOutlet var yesButton: CustomButton!
    @IBOutlet var noButton: CustomButton!
    @IBOutlet var dialogimage: UIImageView!
    
    @IBOutlet var splitter2: UIView!
    @IBOutlet var splitter3: UIView!
    
    var yesRaised : YesEventHandler?
    var noRaised : NoEventHandler?
    
    static var dialogDisappeared = false
    var dialogTitle : String!
    var message  : String!
    var yesButtonName : String!
    var noButtonName : String!
    var viewIsAppeared = false
    var imageData : Data!
    var imageUrl : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        YesNoMessageDialog.dialogDisappeared = false
        
        yesButton.setTitleColor(Colors.dialogTextColor, for: .normal)
        noButton.setTitleColor(Colors.dialogTextColor, for: .normal)
        
        yesButton.isSelectionColorTransparent = true
        noButton.isSelectionColorTransparent = true
        
        if(APK == APKsEnum.BeautyLine.rawValue)
        {
            splitter2.backgroundColor = UIColor("#002559")
            splitter3.backgroundColor = UIColor("#002559")
            
            messageLabel.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            messageLabel.textColor = Colors.dialogTextColor
            yesButton.titleLabel?.font = UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(FontsAndSizes.dialogTextSize))
            noButton.titleLabel?.font = UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(FontsAndSizes.dialogTextSize))
        }
        
        dialogView.sizeToFit()
        messageLabel.sizeToFit()
        
        let onBackgroundClicked = UITapGestureRecognizer(target: self, action: #selector(MessageDialog.onDismissClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClicked)
    }
    
    override func viewDidLayoutSubviews() {
        if(viewIsAppeared)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }
        else
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        messageLabel.text = message
        yesButton.setTitle(yesButtonName, for: .normal)
        noButton.setTitle(noButtonName, for: .normal)
        
        if(imageData.count > 0)
        {
            dialogimage.image = UIImage(data: imageData)
        }
        else
        {
            let url = URL(string: percentEncode(s:imageUrl))
            dialogimage.kf.setImage(with: url, completionHandler: {
                (image, error, cacheType, imageUrl) in
                // image: Image? `nil` means failed
                // error: NSError? non-`nil` means failed
                // cacheType: CacheType
                //                  .none - Just downloaded
                //                  .memory - Got from memory cache
                //                  .disk - Got from disk cache
                // imageUrl: URL of the image
                
                
            })
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewIsAppeared = true
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.yesNoMessageDialogView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion: nil)
        self.dialogView.isHidden = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        YesNoMessageDialog.dialogDisappeared = true
    }
    
    @IBAction func yesButtonClicked(_ sender: UIButton) {
        dismissDialog(isYesClicked: true)
    }
    
    @IBAction func noButtonClicked(_ sender: UIButton) {
        dismissDialog(isYesClicked: false)
    }
    
    @objc func onDismissClick(sender:UITapGestureRecognizer) {
        dismissDialog(isYesClicked: false)
    }
    
    /// Sets the dialog.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - message: The dialog message.
    ///   - yesButtonName: The text of yes button.
    ///   - noButtonName: The text of no button.
    func setDialogView(title: String, message: String, yesButtonName : String, noButtonName : String)
    {
        self.dialogTitle = title
        self.message = message
        self.yesButtonName = yesButtonName
        self.noButtonName = noButtonName
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog( isYesClicked: Bool ){
        UIView.animate(withDuration: 0.3, animations: {
            self.yesNoMessageDialogView.backgroundColor = UIColor.init(red: 1,
                                                                       green: 1,
                                                                       blue: 1,
                                                                       alpha: 0)
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion:{() in
                if(isYesClicked)
                {
                    self.yesRaised?.yesRaised()
                }
                else
                {
                    self.noRaised?.noRaised()
                }
            })
            
        })
    }
    
}
