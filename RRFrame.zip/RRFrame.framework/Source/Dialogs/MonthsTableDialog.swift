//
//  MonthsTableDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 26/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// MonthsTableDialog is used to display a list of all 12 months to the user using the bottom drawer facility.
class MonthsTableDialog: UIViewController , UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var dialogView: UIView!
    @IBOutlet var splitter: UIView!
    @IBOutlet var monthTableDialogView: UIView!
    @IBOutlet var monthsTableView: UITableView!
    @IBOutlet var backgroundView: UIView!
    
    @IBOutlet var scrollviewHeight: NSLayoutConstraint!
    @IBOutlet var tableViewHeight: NSLayoutConstraint!
    
    var types =  [SingleTextModel]()
    var delegate:ModalViewControllerDelegate?
    var selectedType = ""
    var selectedTypeInt : Int!
    var titleText : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        dialogView.sizeToFit()
        titleLabel.sizeToFit()
        titleLabel.numberOfLines = 0
        
        titleLabel.text = titleText
        titleLabel.textColor = Colors.dialogTextColor
        splitter.backgroundColor = Colors.dialogLineColor
        
        titleLabel.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        monthsTableView.delegate = self
        monthsTableView.dataSource = self
        
        let onBackgroundClick = UITapGestureRecognizer(target: self, action: #selector(TableDialog.onBackgroundClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClick)
    }
    
     override func viewDidLayoutSubviews() {
        //typesTableView.sizeToFit()
        monthsTableView.frame = CGRect(x: monthsTableView.frame.origin.x, y: monthsTableView.frame.origin.y, width: monthsTableView.frame.size.width, height: monthsTableView.contentSize.height)
        tableViewHeight.constant = monthsTableView.frame.height
        
        if (self.dialogView.frame.size.height > (UIScreen.main.bounds.size.height - 60))
        {
            scrollviewHeight.constant = UIScreen.main.bounds.size.height - 85 - titleLabel.frame.size.height
        }

        //typesTableView.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        UIView.animate(withDuration: 0.3, animations: {
            self.monthTableDialogView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion: nil)
        self.dialogView.isHidden = false
    }
    
    @objc func onBackgroundClick(sender:UITapGestureRecognizer) {
        dismissDialog()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return types.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "support_type_cell") as! SupportTypeViewCell
        let index = indexPath.row
        
        cell.label.text = types[index].textStr
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        
        /*if(APK == APKsEnum.BeautyLine.rawValue)
        {
            cell.label.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
        }*/
        
        let backgroundView = UIView()
        backgroundView.backgroundColor = Colors.dialogSelectionColor
        cell.selectedBackgroundView = backgroundView
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedType = types[indexPath.row].textStr
        selectedTypeInt = indexPath.row
        dismissDialog()
    }
    
    /// Sets the dialog.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - types: The dialog types.
    ///   - selectedType: The selected type.
    func setDialogView(title: String, types: [SingleTextModel], selectedType : String)
    {
        titleText = title
        self.types = types
        self.selectedType = selectedType
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog(){
        UIView.animate(withDuration: 0.3, animations: {
            self.monthTableDialogView.backgroundColor = UIColor.init(red: 1,
                                                                      green: 1,
                                                                      blue: 1,
                                                                      alpha: 0)
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: nil)
        })
        delegate?.dismissed()
    }
}
