//
//  DialogView.swift
//  RichReach2
//
//  Created by Eumbrella on 12/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class DialogView: UIView {

    /*
    init() {
        UIView.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    /// <summary>
    /// Creates the dialog view.
    /// Used for dialogs that display a simple message.
    /// </summary>
    /// <param name="viewController">The view's view controller.</param>
    /// <param name="bottomDrawer">The bottom drawer.</param>
    /// <param name="title">The dialog's title.</param>
    /// <param name="message">The dialog's message to be displayed.</param>
    public void CreateView(UIViewController viewController, BottomDrawer bottomDrawer, string title, string message) { }
    
    /// <summary>
    /// Creates the dialog view.
    /// Used for dialogs that display a simple message and a single button for dismissing the dialog.
    /// </summary>
    /// <param name="viewController">The view's view controller.</param>
    /// <param name="bottomDrawer">The bottom drawer.</param>
    /// <param name="title">The dialog's title.</param>
    /// <param name="message">The dialog's message to be displayed.</param>
    /// <param name="buttonText">The button's text.</param>
    public void CreateView(UIViewController viewController, BottomDrawer bottomDrawer, string title, string message, string buttonText) { }
    
    /// <summary>
    /// Creates the dialog view.
    /// Used for dialogs that display a simple message and two buttons.
    /// </summary>
    /// <param name="viewController">The view's view controller.</param>
    /// <param name="bottomDrawer">The bottom drawer.</param>
    /// <param name="title">The dialog's title.</param>
    /// <param name="message">The dialog's message to be displayed.</param>
    /// <param name="yesButtonText">The yes button text.</param>
    /// <param name="yesButtonText">The no button text.</param>
    public void CreateView(UIViewController viewController, BottomDrawer bottomDrawer, string title, string message, string yesButtonText, string noButtonText) { }
    
    /// <summary>
    /// Creates the dialog view.
    /// Used for dialogs that display a custom view.
    /// </summary>
    /// <param name="viewController">The view's view controller.</param>
    /// <param name="bottomDrawer">The bottom drawer.</param>
    /// <param name="title">The dialog's title.</param>
    /// <param name="customView">The dialog's custom view.</param>
    /// <param name="displayCloseButton">Flag that indicates whether the close button should be displayed or not.</param>
    /// <param name="titleAlignmentType">The title alignment type.</param>
    public void CreateView(UIViewController viewController, BottomDrawer bottomDrawer, string title, UIView customView, bool displayCloseButton = false, TitleAlignmentType titleAlignmentType = TitleAlignmentType.Center) { }
    
    /// <summary>
    /// Calculates and returns the dialog's height.
    /// </summary>
    /// <returns>The dialog's height.</returns>
    public nfloat GetHeight() { return 0; }
 
 */

}
