//
//  SupportTypeDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 20/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// TableDialog is used to display a dialog which has a table with buttons.
class TableDialog: UIViewController , UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var dialogView: UIView!
    @IBOutlet var splitter: UIView!
    @IBOutlet var typesTableView: UITableView!
    @IBOutlet var sypportTypeDialogView: UIView!
    @IBOutlet var backgroundView: UIView!
    
    @IBOutlet var tableViewHeight: NSLayoutConstraint!
    
    var types =  [SingleTextModel]()
    var delegate : ModalViewControllerDelegate?
    var selectedType = ""
    var selectedTypeInt : Int!
    var titleText : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dialogView.sizeToFit()
        titleLabel.sizeToFit()
        titleLabel.numberOfLines = 0
        
        
        titleLabel.textColor = Colors.dialogTextColor
        splitter.backgroundColor = Colors.dialogLineColor
        
        titleLabel.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        typesTableView.delegate = self
        typesTableView.dataSource = self
        
        let onBackgroundClick = UITapGestureRecognizer(target: self, action: #selector(TableDialog.onBackgroundClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClick)
    }
    
     override func viewDidLayoutSubviews() {
        //typesTableView.sizeToFit()
        typesTableView.frame = CGRect(x: typesTableView.frame.origin.x, y: typesTableView.frame.origin.y, width: typesTableView.frame.size.width, height: typesTableView.contentSize.height)
        tableViewHeight.constant = typesTableView.frame.height
        
        if ((typesTableView.frame.height + 25 + titleLabel.frame.size.height) > (UIScreen.main.bounds.size.height - 60))
        {
            tableViewHeight.constant = UIScreen.main.bounds.size.height - 85 - titleLabel.frame.size.height
        }
        //typesTableView.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        titleLabel.text = titleText
        
        self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        UIView.animate(withDuration: 0.3, animations: {
            self.sypportTypeDialogView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion: nil)
        self.dialogView.isHidden = false
    }

    @objc func onBackgroundClick(sender:UITapGestureRecognizer) {
        dismissDialog2()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return types.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "support_type_cell") as! SupportTypeViewCell
        let index = indexPath.row
        
        cell.label.text = types[index].textStr
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero

        if(APK == APKsEnum.BeautyLine.rawValue)
        {
            cell.label.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            cell.label.textColor = Colors.dialogTextColor
        }
        
        let backgroundView = UIView()
        backgroundView.backgroundColor = Colors.dialogSelectionColor
        cell.selectedBackgroundView = backgroundView
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedType = types[indexPath.row].textStr
        selectedTypeInt = indexPath.row
        dismissDialog()
    }
    
    /// Sets the dialog.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - types: The dialog types.
    ///   - selectedType: The selected type.
    func setDialogView(title: String, types: [SingleTextModel], selectedType : String)
    {
        titleText = title
        self.types = types
        self.selectedType = selectedType
    }
    
    /// Sets the dialog.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - types: The dialog types.
    ///   - selectedType: The selected type.
    func setDialogView(title: String, types: [SingleTextModel], selectedType : String, selectedTypeInt : Int)
    {
        titleText = title
        self.types = types
        self.selectedType = selectedType
        self.selectedTypeInt = selectedTypeInt
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog(){
        UIView.animate(withDuration: 0.3, animations: {
            self.sypportTypeDialogView.backgroundColor = UIColor.init(red: 1,
                                                                green: 1,
                                                                blue: 1,
                                                                alpha: 0)
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: nil)
            self.delegate?.dismissed()
        })
    }
    
    func dismissDialog2(){
        UIView.animate(withDuration: 0.3, animations: {
            self.sypportTypeDialogView.backgroundColor = UIColor.init(red: 1,
                                                                      green: 1,
                                                                      blue: 1,
                                                                      alpha: 0)
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: nil)
        })
    }

}
