//
//  BirthDatePickerDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 23/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// DatePickerDialog is the dialog view that allows the user to pick up a certain date.
class DatePickerDialog:  UIViewController, ModalViewControllerDelegate {
    
    @IBOutlet var datePickerDialog: UIView!
    @IBOutlet weak var dialogView: UIView!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var splitter1: UIView!
    @IBOutlet weak var splitter2: UIView!
    @IBOutlet weak var button: UIButton!
    @IBOutlet var closeButton: UIButton!
    @IBOutlet weak var dialogTitle: UILabel!
    
    @IBOutlet var fullDayLabel: UILabel!
    @IBOutlet var dayTextField: UITextField!
    @IBOutlet var monthLabel: UILabel!
    @IBOutlet var yearLabel: UILabel!
    @IBOutlet var errorMessageLabel: UILabel!
    
    @IBOutlet var expandImage1: UIImageView!
    @IBOutlet var expandImage2: UIImageView!
    
    @IBOutlet var monthView: UIView!
    @IBOutlet var yearView: UIView!
    @IBOutlet weak var fullDayView: UIView!
    @IBOutlet weak var dateView: UIView!
    @IBOutlet var titleView: UIView!
    @IBOutlet var buttonView: UIView!
    
    @IBOutlet var errorMessageLabelHeight: NSLayoutConstraint!
    @IBOutlet weak var fullDayTopConstraint: NSLayoutConstraint!
    @IBOutlet var fullDayHeightConstraint: NSLayoutConstraint!
    @IBOutlet var dayTopConstraint: NSLayoutConstraint!
    @IBOutlet var monthTopConstraint: NSLayoutConstraint!
    @IBOutlet var yearTopConstraint: NSLayoutConstraint!
    
    var viewModel : DatePickerDialogViewModel!
    var tableDialog : TableDialog!
    var gridDialog : GridDialog!
    var delegate : ModalViewControllerDelegate?
    var userProfileViewModel : UserProfileViewModel!
    var userProfileViewModel2 : UserProfileViewModel2!
    var viewWillDisapear = false
    var date : String!
    var runnable : Runnable!
    var viewDidAppear = false
    var keyboardHeight : CGFloat!
    var isYearRequired = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let onMonthClick = UITapGestureRecognizer(target: self, action: #selector(DatePickerDialog.onMonthClick(sender:)))
        monthView.isUserInteractionEnabled = true
        monthView.addGestureRecognizer(onMonthClick)
        
        let onYearClick = UITapGestureRecognizer(target: self, action: #selector(DatePickerDialog.onYearClick(sender:)))
        yearView.isUserInteractionEnabled = true
        yearView.addGestureRecognizer(onYearClick)
        
        dialogView.sizeToFit()
        splitter1.backgroundColor = Colors.dialogLineColor
        //splitter2.backgroundColor = Colors.sectionTextUnderlineColor
        button.setTitleColor(Colors.dialogTextColor, for: .normal)
        dialogTitle.textColor = Colors.dialogTextColor
        
        
        dialogTitle.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        let closeImage = UIImage(named: "ic_dialog_close")?.withRenderingMode(.alwaysTemplate)
        closeButton.setImage(closeImage, for: .normal)
        closeButton.tintColor = Colors.dialogTintColor
        
        if(APK == APKsEnum.BeautyLine.rawValue)
        {
            dayTextField.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            dayTextField.textColor = Colors.dialogTextColor
            
            monthLabel.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            monthLabel.textColor = Colors.dialogTextColor
            
            yearLabel.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            yearLabel.textColor = Colors.dialogTextColor
            
            button.titleLabel?.font = UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(FontsAndSizes.dialogTextSize))
            
            //expandImage1.image = UIImage(named: "ic_spinner_expand_gray")?.withRenderingMode(.alwaysTemplate)
            //expandImage1.tintColor = Colors.dialogTintColor
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        dayTextField.attributedPlaceholder = NSAttributedString(string: "Day",attributes: [NSAttributedStringKey.foregroundColor: UIColor.black])
    }
    
    override func viewDidLayoutSubviews() {
        if(!viewDidAppear)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }
        else if (viewWillDisapear)
        {
            
        }
        else if(keyboardHeight != nil)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height - keyboardHeight
        }
        else
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(animated)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
            roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
            
            UIView.animate(withDuration: 0.3, animations: {
                self.datePickerDialog.backgroundColor = Colors.dialogsBackgroundColor
                
                self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
            }, completion: nil)
            viewDidAppear = true
            self.dialogView.isHidden = false
        }
        else
        {
            roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }
    }
    
    @objc func onBackgroundClick(sender:UITapGestureRecognizer) {
        dismissDialog()
    }
    
    @objc func onMonthClick(sender:UITapGestureRecognizer) {
        clearFocusOnTextField()
        let sb = UIStoryboard(name:"TableDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        tableDialog = dialog as? TableDialog
        self.present(dialog,animated:true)
        tableDialog.delegate = self
        tableDialog.setDialogView(title: "Month", types: StaticDataRepository.getMonths(fromMonth: 1, toMonth: 12), selectedType: "" )
    }
    
    @objc func onYearClick(sender:UITapGestureRecognizer) {
        clearFocusOnTextField()
        let sb = UIStoryboard(name:"GridDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        gridDialog = dialog as? GridDialog
        self.present(dialog,animated:true)
        GridDialog.delegate = self
        
        var years : [Int] = []
        let date = Date()
        let calendar = Calendar.current
        let currentYear =  calendar.dateComponents([.year, .month, .day], from: date).year
        years += currentYear! - 91...currentYear! - 7
        gridDialog.setDialogView(title: "Year", years : years)
    }
    
    @IBAction func dayTextChanged(_ sender: UITextField) {
        if(!isNullOrEmpty(string: sender.text))
        {
            var dayString = sender.text
            var dateTimeOperator = DateTimeOperator()
            var dayMaxValue = dateTimeOperator.getMonthNumOfDays(monthName: viewModel.month, year: viewModel.year)
            var day = Int(sender.text!) == nil ? -1 : Int(sender.text!)!
            
            if(dayString![0] == "0" && dayString!.count > 1)
            {
                sender.text?.remove(at: sender.text!.startIndex)
                dayString = sender.text
            }
            
            if(dayString![0] == "0" || day > dayMaxValue)
            {
                sender.text = dayString?.substring(to: (dayString?.index(before: (dayString?.endIndex)!))!)
            }
            
            if(sender.text!.count > 1) 
            {
                 dayString = sender.text
                 dateTimeOperator = DateTimeOperator()
                 dayMaxValue = dateTimeOperator.getMonthNumOfDays(monthName: viewModel.month, year: viewModel.year)
                 day = Int(sender.text!) == nil ? -1 : Int(sender.text!)!
                
                if(dayString![0] == "0" || day > dayMaxValue)
                {
                    sender.text = dayString?.substring(to: (dayString?.index(before: (dayString?.endIndex)!))!)
                }
            }
            
            if(day == -1)
            {
                sender.text = ""
            }
        }
        
        viewModel.Day = sender.text!
        
        //dateView.layoutIfNeeded()
        //dialogView.layoutIfNeeded()
        //datePickerDialog.layoutIfNeeded()
        
        
        //setDayText()
        
        //dayTextField.resignFirstResponder()
        //dateView.layoutIfNeeded()
        //dialogView.layoutIfNeeded()
        //datePickerDialog.layoutIfNeeded()
        
        viewDidLoad()
        viewDidAppear(false)
        
        if(self.keyboardHeight != nil)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height - self.keyboardHeight
        }
        
        //clearFocusOnTextField()
        //viewModel.ShouldDisplayFullDay = true
    }
    
    @IBAction func onClickButton(_ sender: UIButton) {
        if (viewModel.isDateValid(isYearRequired: isYearRequired))
        {
            let dateTimeOperator = DateTimeOperator()
            var date = dateTimeOperator.getDate(day: viewModel.day, monthName: viewModel.month, year: viewModel.year)
            
            if (!isNullOrEmpty(string: date))
            {
                if(viewModel.year ==  NSLocalizedString("yearSpinnerViewDefaultText", comment: ""))
                {
                    date = String((date?.prefix((date?.count)! - (viewModel.year.count + 1)))!)
                }
                
                userProfileViewModel.birthDate = date
                self.date = date
                if(runnable != nil)
                {
                    runnable()
                }
                dismissDialog()
            }
            else
            {
                viewModel.ShouldDisplayErrorMessage = true
                errorMessageLabel.text = viewModel.errorMessage
                dateView.layoutIfNeeded()
                dialogView.layoutIfNeeded()
                datePickerDialog.layoutIfNeeded()
                viewDidAppear(false)
            }
        }
        else
        {
            viewModel.ShouldDisplayErrorMessage = true
            errorMessageLabel.text = viewModel.errorMessage
            dateView.layoutIfNeeded()
            dialogView.layoutIfNeeded()
            datePickerDialog.layoutIfNeeded()
            viewDidAppear(false)
        }
    }
    
    @IBAction func dismissDialog(_ sender: UIButton) {
        dismissDialog()
    }
    
    @objc func keyboardWasShown(notification: NSNotification){
        var info = notification.userInfo!

        if let keyboardFrame: NSValue = notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            keyboardHeight = keyboardRectangle.height
        }
        
        UIView.animate(withDuration: 0.3, animations: {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height - self.keyboardHeight
        }, completion: nil)
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification){
        UIView.animate(withDuration: 0.3, animations: {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion : { (finished : Bool) in
            if(self.viewWillDisapear)
            {
                UIView.animate(withDuration: 0.3, animations: {
                    self.datePickerDialog.backgroundColor = UIColor.init(red: 1,
                                                                         green: 1,
                                                                         blue: 1,
                                                                         alpha: 0)
                    
                    self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
                }, completion: {(finished: Bool) in
                    self.dismiss(animated: true,completion: nil)
                })
                self.delegate?.dismissed()
            }
        })
        
        keyboardHeight = nil
    }
    
    /// Clears focus no day text field.
    func clearFocusOnTextField()
    {
        dayTextField.resignFirstResponder()
        dayTextField.endEditing(true)
        dateView.layoutIfNeeded()
        dialogView.layoutIfNeeded()
        datePickerDialog.layoutIfNeeded()
        viewDidAppear(false)
    }

    /// Called when months dialog or years dialog is been dismissed.
    func dismissed() {
        if (tableDialog != nil && tableDialog.selectedType != "")
        {
            monthLabel.text = tableDialog.selectedType
            viewModel.month = tableDialog.selectedType
            dateView.layoutIfNeeded()
            dialogView.layoutIfNeeded()
            datePickerDialog.layoutIfNeeded()
            viewDidAppear(false)
        }
        
        if(gridDialog != nil && GridDialog.selectedYear != nil)
        {
            yearLabel.text = String(GridDialog.selectedYear)
            viewModel.year = String(GridDialog.selectedYear)
            dateView.layoutIfNeeded()
            dialogView.layoutIfNeeded()
            datePickerDialog.layoutIfNeeded()
            viewDidAppear(false)
        }
        
        viewModel.SetFullDay()
        setDayText()
        
        dayTextField.resignFirstResponder()
        dayTextField.endEditing(true)
        dateView.layoutIfNeeded()
        dialogView.layoutIfNeeded()
        datePickerDialog.layoutIfNeeded()
        viewDidAppear(false)
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog(){
        viewWillDisapear = true

        if(keyboardHeight == nil)
        {
            UIView.animate(withDuration: 0.3, animations: {
                self.datePickerDialog.backgroundColor = UIColor.init(red: 1,
                                                                     green: 1,
                                                                     blue: 1,
                                                                     alpha: 0)
                
                self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
            }, completion: {(finished: Bool) in
                self.dismiss(animated: true,completion: nil)
            })
            delegate?.dismissed()
        }
        
        dayTextField.endEditing(true)
    }
    
    /// Set the dialog fields.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - userProfileViewModel: The user profile model.
    func setDialogView(title : String ,userProfileViewModel : UserProfileViewModel)
    {
        dialogTitle.text = title
        self.userProfileViewModel = userProfileViewModel
        self.viewModel = DatePickerDialogViewModel(viewController: self)
        
        if (!isNullOrEmpty(string : userProfileViewModel.birthDate) && !(userProfileViewModel.birthDate == NSLocalizedString("birthDateDefaultText", comment: "")))
        {
            let dateTimeOperator = DateTimeOperator()
            
            var dateTokens = userProfileViewModel.birthDate.split(separator: "/")
            let day = dateTokens[0]
            let month = dateTokens[1]
            var year = NSLocalizedString("yearSpinnerViewDefaultText", comment: "")
            
            if(dateTokens.count > 2)
            {
                year = String(dateTokens[2])
            }
            
            
            viewModel.month = dateTimeOperator.getMonthNameFromMonthNumber(monthNumber: String(month))
            viewModel.year = String(year)
            
            if(String(day)[0] == "0")
            {
                viewModel.Day = String(String(day)[1])
            }
            else
            {
                viewModel.Day = String(day)
            }
        }
        
        dayTextField.text = viewModel.day
        monthLabel.text = viewModel.month
        yearLabel.text = viewModel.year
        
        fullDayLabel.text = viewModel.fullDay
        
        if (viewModel.shouldDisplayFullDay)
        {
            viewModel.ShouldDisplayFullDay = true
        }
        else
        {
            viewModel.ShouldDisplayFullDay = false
        }
        
        dateView.layoutIfNeeded()
        dialogView.layoutIfNeeded()
        datePickerDialog.layoutIfNeeded()
    }
    
    /// Checks if the day is more than max value.
    func setDayText()
    {
        if(!isNullOrEmpty(string: dayTextField.text))
        {
            let dateTimeOperator = DateTimeOperator()
            let dayMaxValue = dateTimeOperator.getMonthNumOfDays(monthName: viewModel.month, year: viewModel.year)
            
            if let selectedDay = Int(dayTextField.text!)
            {
                if (selectedDay > dayMaxValue)
                {
                    dayTextField.text = nil
                }
            }
        }

    }
}
