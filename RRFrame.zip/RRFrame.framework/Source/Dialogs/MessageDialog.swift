//
//  MessageDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 14/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// MessageDialog is a dialog being displayed when we want to display a short message to the user about something.
class MessageDialog: UIViewController, UITextViewDelegate {
    

    @IBOutlet var descriptionView: UIView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var descriptionTextView: UITextView!
    @IBOutlet var dialogView: UIView!
    @IBOutlet var backgroundView: UIView!
    @IBOutlet var splitter2: UIView!
    @IBOutlet var okButton: CustomButton!
    @IBOutlet var splitter1: UIView!
    
    static var dialogDisappeared = false
    
    var delegate : ModalViewControllerDelegate?
    var okEventHandler : OkEventHandler!
    var dismissWhenClickOutside = true
    var titleText : String!
    var descriptionText : String!
    var buttonText : String!
    var viewIsAppeared = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MessageDialog.dialogDisappeared = false
        
        dialogView.sizeToFit()
        descriptionLabel.sizeToFit()
        
        titleLabel.textColor = Colors.dialogTextColor
        splitter1.backgroundColor = Colors.dialogLineColor
        splitter2.backgroundColor = UIColor.lightGray
        
        
        titleLabel.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        descriptionTextView.delegate = self
        
        if(APK == APKsEnum.BeautyLine.rawValue)
        {
            okButton.titleLabel?.font = UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(FontsAndSizes.dialogTextSize))
            descriptionLabel.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            descriptionLabel.textColor = Colors.dialogTextColor
        }
        
        let onBackgroundClicked = UITapGestureRecognizer(target: self, action: #selector(MessageDialog.onDismissClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClicked)
    }
    
    override func viewDidLayoutSubviews() {
        if(viewIsAppeared)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }
        else
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        titleLabel.text = titleText
        descriptionLabel.text = descriptionText
        okButton.setTitle(buttonText, for: .normal)
        print(descriptionText)
        if(NSLocalizedString("registrationAttemptsMessage", comment: "") == descriptionText ||
            NSLocalizedString("registrationAttemptsMessageBeautyLine", comment: "") == descriptionText)
        {
            descriptionLabel.text = ""
            
            descriptionTextView.isEditable = false
            
            var string = NSLocalizedString("registrationAttemptsMessage", comment: "")
            
            var attributedString  = NSMutableAttributedString(string: string)
            //let font = UIFont(name: "UIFontWeightUltraLight", size: 15) ?? UIFont.systemFont(ofSize: 15)
            //attributedString.addAttribute(NSAttributedStringKey.font, value: font, range: NSMakeRange(0, attributedString.length))
            
            var linkAttributes : [NSAttributedStringKey : Any]
            
            if(APK == APKsEnum.BeautyLine.rawValue || APK == APKsEnum.Test.rawValue)
            {
                descriptionTextView.dataDetectorTypes = .phoneNumber
                string = NSLocalizedString("registrationAttemptsMessageBeautyLine", comment: "")
                attributedString  = NSMutableAttributedString(string: string)
                let range  = (string as NSString).range(of: "customerservice@beautyline.com.cy")
                linkAttributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.link.rawValue): NSURL(string: "https://beautyline.com.cy/contact-us")!] as [NSAttributedStringKey : Any]
                attributedString.setAttributes(linkAttributes, range: range)
                attributedString.addAttribute(NSAttributedStringKey.underlineStyle, value: NSNumber(value: 1), range: range)
                
                /*let range2  = (string as NSString).range(of: "77771701")
                var linkAttributes2 = [NSAttributedStringKey(rawValue: NSAttributedStringKey.link.rawValue): NSURL(string: "https://beautyline.com.cy/contact-us")!] as [NSAttributedStringKey : Any]
                attributedString.setAttributes(linkAttributes2, range: range)
                attributedString.addAttribute(NSAttributedStringKey.underlineStyle, value: NSNumber(value: 1), range: range2)*/
            }
            else
            {
                let range  = (string as NSString).range(of: "Contact Us")
                linkAttributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.link.rawValue): NSURL(string: "http://www.eumbrellacorp.com/Home/Contact-Us")!] as [NSAttributedStringKey : Any]
                attributedString.setAttributes(linkAttributes, range: range)
                attributedString.addAttribute(NSAttributedStringKey.underlineStyle, value: NSNumber(value: 1), range: range)
            }
            
            //attributedString.addAttribute(NSAttributedStringKey.link, value: NSURL(string: "http://www.eumbrellacorp.com/Home/Contact-Us")!, range: range)
            
            //attributedString.addAttribute(NSAttributedStringKey.underlineColor, value: UIColor.blue, range: range)
            //attributedString.addAttribute(NSAttributedStringKey.font, value: font, range: range)
            
            descriptionTextView.attributedText = attributedString
            descriptionTextView.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.light)
            descriptionTextView.textAlignment = .center
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewIsAppeared = true
        MessageDialog.dialogDisappeared = false
            
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.descriptionView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion: nil)
        self.dialogView.isHidden = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        MessageDialog.dialogDisappeared = true
    }
    
    /// Sets the dialog view.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - description: The dialog description.
    ///   - buttonName: The button name.
    ///   - dismissWhenClickOutside: Flag for dissmiss when click outside.
    func setDialogView(title: String, description: String, buttonName: String, dismissWhenClickOutside : Bool)
    {
        titleText = title
        descriptionText = description
        self.dismissWhenClickOutside = dismissWhenClickOutside
        buttonText = buttonName
    }
    
    @available(iOS 10.0, *)
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true
    }
    
    @IBAction func onOkClick(_ sender: UIButton) {
        dismissDialog()
        if(okEventHandler != nil)
        {
            okEventHandler.okClicked()
        }
    }
    

    @objc func onDismissClick(sender:UITapGestureRecognizer) {
        if(dismissWhenClickOutside)
        {
            dismissDialog()
        }
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog(){
        UIView.animate(withDuration: 0.3, animations: {
            if(self.descriptionView != nil && self.dialogView != nil)
            {
                self.descriptionView.backgroundColor = UIColor.init(red: 1,
                                                                    green: 1,
                                                                    blue: 1,
                                                                    alpha: 0)
                
                self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
            }
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion: { () in
                self.delegate?.dismissed()
                MessageDialog.dialogDisappeared = true
            })
        })
    }
}
