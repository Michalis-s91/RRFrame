//
//  YesNoMessageDialog.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// YesNoMessageDialog is a dialog being displayed when user  have two options (eg. when user want to exit from the app).
class YesNoMessageDialog: UIViewController {
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var messageLabel: UILabel!
    @IBOutlet var yesNoMessageDialogView: UIView!
    @IBOutlet var backgroundView: UIView!
    @IBOutlet var dialogView: UIView!
    @IBOutlet var yesButton: UIButton!
    @IBOutlet var noButton: UIButton!
    
    @IBOutlet var splitter1: UIView!
    @IBOutlet var splitter2: UIView!
    @IBOutlet var splitter3: UIView!
    
    var yesRaised : YesEventHandler?
    var noRaised : NoEventHandler?
    
    static var dialogDisappeared = false
    var dialogTitle : String!
    var message  : String!
    var yesButtonName : String!
    var noButtonName : String!
    var viewIsAppeared = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        YesNoMessageDialog.dialogDisappeared = false
        
        titleLabel.textColor = Colors.dialogTextColor
        
        titleLabel.font = UIFont (name: FontsAndSizes.dialogFont, size: CGFloat(FontsAndSizes.dialogTextSize))
        
        yesButton.setTitleColor(Colors.dialogTextColor, for: .normal)
        noButton.setTitleColor(Colors.dialogTextColor, for: .normal)
        
        splitter1.backgroundColor = Colors.dialogLineColor
        splitter2.backgroundColor = UIColor.lightGray
        splitter3.backgroundColor = UIColor.lightGray
        
        if(APK == APKsEnum.BeautyLine.rawValue || APK == APKsEnum.HollandAndBarrett.rawValue)
        {
            messageLabel.font = UIFont (name: "CharpentierSansPro-Leger", size: CGFloat(FontsAndSizes.dialogTextSize))
            messageLabel.textColor = Colors.dialogTextColor
            yesButton.titleLabel?.font = UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(FontsAndSizes.dialogTextSize))
            noButton.titleLabel?.font = UIFont (name: "CharpentierSansPro-Demi", size: CGFloat(FontsAndSizes.dialogTextSize))
        }
        
        dialogView.sizeToFit()
        messageLabel.sizeToFit()
        
        let onBackgroundClicked = UITapGestureRecognizer(target: self, action: #selector(MessageDialog.onDismissClick(sender:)))
        backgroundView.isUserInteractionEnabled = true
        backgroundView.addGestureRecognizer(onBackgroundClicked)
    }
    
    override func viewDidLayoutSubviews() {
        if(viewIsAppeared)
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }
        else
        {
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        titleLabel.text = dialogTitle
        messageLabel.text = message
        yesButton.setTitle(yesButtonName, for: .normal)
        noButton.setTitle(noButtonName, for: .normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewIsAppeared = true
        roundCorners([.topLeft,.topRight], radius: 10, view: dialogView)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.yesNoMessageDialogView.backgroundColor = Colors.dialogsBackgroundColor
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height - self.dialogView.frame.size.height
        }, completion: nil)
        self.dialogView.isHidden = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        YesNoMessageDialog.dialogDisappeared = true
    }

    @IBAction func yesButtonClicked(_ sender: UIButton) {
        dismissDialog(isYesClicked: true)
    }
    
    @IBAction func noButtonClicked(_ sender: UIButton) {
        dismissDialog(isYesClicked: false)
    }
    
    @objc func onDismissClick(sender:UITapGestureRecognizer) {
        dismissDialog(isYesClicked: false)
    }
    
    /// Sets the dialog.
    ///
    /// - Parameters:
    ///   - title: The dialog title.
    ///   - message: The dialog message.
    ///   - yesButtonName: The text of yes button.
    ///   - noButtonName: The text of no button.
    func setDialogView(title: String, message: String, yesButtonName : String, noButtonName : String)
    {
        self.dialogTitle = title
        self.message = message
        self.yesButtonName = yesButtonName
        self.noButtonName = noButtonName
    }
    
    /// Dismiss dialog with animation.
    func dismissDialog( isYesClicked: Bool ){
        UIView.animate(withDuration: 0.3, animations: {
            self.yesNoMessageDialogView.backgroundColor = UIColor.init(red: 1,
                                                                green: 1,
                                                                blue: 1,
                                                                alpha: 0)
            
            self.dialogView.frame.origin.y = UIScreen.main.bounds.size.height
        }, completion: {(finished: Bool) in
            self.dismiss(animated: true,completion:{() in
                if(isYesClicked)
                {
                    self.yesRaised?.yesRaised()
                }
                else
                {
                    self.noRaised?.noRaised()
                }
            })
            
        })
    }

}
