//
//  OverlaySplashViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 14/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class OverlaySplashViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIWebViewDelegate {
    
    @IBOutlet var logoImage: UIImageView!
    @IBOutlet var bannersTableView: UITableView!
    @IBOutlet var continueLabel: UILabel!
    @IBOutlet var dotsLabel: UILabel!
    @IBOutlet var bottomLabel: UILabel!
    @IBOutlet var topPaddingeight: NSLayoutConstraint!
    @IBOutlet var imageHeight: NSLayoutConstraint!
    
    
    var banners : [GeneralInformation2]! = []
    var splashViewParameters : SplashViewParametersModel!
    var duration : Double!
    var duration2 = 0
    var interval : Double = 1
    var timer = Timer()
    var webView : UIWebView!
    var videosPostions : [Int] = []
    var videoLoaded : [Bool] = []
    var videoIsBeenPlaying = false
    var finishedRunnable : Runnable!
    var viewDidAppear = false
    
    override func viewDidLoad() {
        view.backgroundColor = UIColor(splashViewParameters.backgroundColor)
        
        super.viewDidLoad()
        
        self.banners = viewsDB.getGenealInformations(tabID: 0)
        
        if(banners == nil || banners.count == 0)
        {
            imageHeight = self.imageHeight.setMultiplier(multiplier: 0.3)
            topPaddingeight.constant = (self.view.frame.size.height * 0.5) - (self.view.frame.size.height*0.3/2)
        }
        else
        {
            topPaddingeight.constant = self.view.frame.size.height * 0.08
        }
        
        bannersTableView.rowHeight = UITableViewAutomaticDimension
        bannersTableView.tableFooterView = UIView()
        bannersTableView.delegate = self
        bannersTableView.dataSource = self
        
        duration = Double(splashViewParameters.time) + 1
        
        continueLabel.textColor = UIColor(splashViewParameters.textColor)
        continueLabel.font = UIFont (name: (splashViewParameters.font)!, size: CGFloat((17)))
        continueLabel.adjustsFontSizeToFitWidth = true
        continueLabel.minimumScaleFactor = 0.2
        
        dotsLabel.textColor = UIColor(splashViewParameters.textColor)
        dotsLabel.font = UIFont (name: (splashViewParameters.font)!, size: CGFloat((17)))
        
        bottomLabel.textColor = UIColor(splashViewParameters.textColor)
        
        
        logoImage.image = UIImage(named: splashViewParameters.logo)
         
        let nsObject = Bundle.main.infoDictionary?["CFBundleShortVersionString"]
        let version = nsObject as! String
        
        if(APK == APKsEnum.RichReach.rawValue || APK == APKsEnum.Test.rawValue)
        {
            bottomLabel.text = "\(version)"
        }
        else
        {
            if(APK == Bundle.main.bundleIdentifier!)
            {
                bottomLabel.text = "A RichReach App (\(version))"
            }
            else
            {
                bottomLabel.text = "A RichReach App"
            }
        }
        
        continueLabel.text = " "
    }
    
    override func viewDidAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.interval), target: self,   selector: (#selector(OverlaySplashViewController.updateTimer)), userInfo: nil, repeats: true)
        }
        
        bannersTableView.reloadData()
        viewDidAppear = true
        
        let onClick = UITapGestureRecognizer(target: self, action: #selector(OverlaySplashViewController.onContinueClick))
        continueLabel.isUserInteractionEnabled = true
        continueLabel.addGestureRecognizer(onClick)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return banners.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var information : GeneralInformation2!
        
        information = banners[indexPath.row]
        
        switch information.type {
        case SlotType.Photo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_image") as! InformationImageViewCell
            let photo : PhotoModel! = information.photo
            
            cell.link = photo.link
            //let url = URL(string: percentEncode(s: photo.imageUrl))
            
            //cell.cellImage.kf.setImage(with: url)
            
            cell.cellImage.image = viewsDB.getImage(url: photo.imageUrl)
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Text.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
            let text : TextModel! = information.text
            
            //cell.descriptionText.translatesAutoresizingMaskIntoConstraints = true
            //cell.descriptionText.sizeToFit()
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = text?.title
            cell.descriptionText.text = text?.description
            cell.titleLabel.font = UIFont (name: (text?.titleFont)!, size: CGFloat((text?.titleSize)!))
            cell.titleLabel.textColor = UIColor((text?.titleColor)!)
            cell.descriptionText.font = UIFont (name: (text?.descriptionFont)!, size: CGFloat((text?.descriptionSize)!))
            cell.descriptionText.textColor = UIColor((text?.descriptionColor)!)
            cell.splitter.backgroundColor = UIColor((text?.splitterColor)!)
            cell.backgroundColor = UIColor((text?.backgroundColor)!)
            cell.descriptionText.backgroundColor = UIColor((text?.backgroundColor)!)
            
            if(text?.isTitleCentered)!
            {
                cell.titleLabel.textAlignment = .center
            }
            
            switch text?.descriptionAlignmentType.rawValue
            {
            case AlignmentType.Left.rawValue? :
                cell.descriptionText.textAlignment = .left
            case AlignmentType.Center.rawValue? :
                cell.descriptionText.textAlignment = .center
            case AlignmentType.Justified.rawValue? :
                cell.descriptionText.textAlignment = .justified
            default :
                break
            }
            
            
            return cell
        case SlotType.Video.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_video") as! InformationVideoViewCell
            
            if(videoLoaded.count == 0)
            {
                videosPostions.append(indexPath.row)
                
                cell.cellWebView.mediaPlaybackRequiresUserAction = false
                cell.cellWebView.allowsInlineMediaPlayback = true
                cell.cellWebView.delegate = self
                cell.cellWebView.mediaPlaybackAllowsAirPlay = false
                cell.cellWebView.scrollView.isScrollEnabled = false
                cell.cellWebView.scrollView.showsVerticalScrollIndicator = false
                cell.cellWebView.scrollView.showsHorizontalScrollIndicator = false
                //let width = UIScreen.main.bounds.size.width - CGFloat(2 * borderWidth)
                //let height = width/1.77
                
                videoLoaded.append(false)
                webView = cell.cellWebView
                
                
                var cellRect = bannersTableView.rectForRow(at: indexPath)
                cellRect.size.height =  cellRect.size.height
                let completelyVisible = bannersTableView.bounds.contains(cellRect)
                
                if (completelyVisible) {
                    
                    if(!videoLoaded[0])
                    {
                        let width = UIScreen.main.bounds.size.width - CGFloat(2 * borderWidth)
                        let height = width/1.77
                        
                        webView.allowsInlineMediaPlayback = true
                        
                        webView.loadHTMLString("<video controls muted autoplay loop playsinline webkit-playsinline id=\"video1\" width=\"\(width)\" height=\"\(height)\"> <source src=\"\(information.video.videoUrl ?? "")\" type=\"video/mp4\"></video>", baseURL: nil)
                        webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
                        
                        videoIsBeenPlaying = true
                        videoLoaded[0] = true
                    }
                }
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case SlotType.Carousel.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_carousel") as! InformationCarouselViewCell
            
            let carousel : CarouselModel! = information.carousel
            cell.urls = carousel?.urls
            cell.hasTitles = carousel.hasTitles
            cell.titleSize = carousel.titleSize
            cell.isAutomatic = carousel?.isAutomatic
            cell.isManual = carousel?.isManual
            cell.isScrollingEnabled = carousel?.isScrollingEnabled
            cell.interval = (carousel?.interval)!
            
            //if(viewDidAppear)
            //{
            cell.setCarusel(width : bannersTableView.frame.size.width)
            //}
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        default:
            return tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        var i = 0
        for v in videosPostions
        {
            let indexPathTemp = IndexPath(row: v, section: 0)
            
            var cellRect = bannersTableView.rectForRow(at: indexPathTemp)
            cellRect.size.height =  cellRect.size.height
            let completelyVisible = bannersTableView.bounds.contains(cellRect)
            
            if (completelyVisible) {
                
                if(!videoLoaded[i])
                {
                    var information : GeneralInformation2!
                    information =  banners[v]
                    let width = UIScreen.main.bounds.size.width - CGFloat(2 * borderWidth)
                    let height = width/1.77
                    
                    webView.allowsInlineMediaPlayback = true
                    
                    
                    webView.loadHTMLString("<video controls muted autoplay loop playsinline webkit-playsinline id=\"video1\" width=\"\(width)\" height=\"\(height)\"> <source src=\"\(information.video.videoUrl ?? "")\" type=\"video/mp4\"></video>", baseURL: nil)
                    webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
                    
                    videoIsBeenPlaying = true
                    videoLoaded[i] = true
                    i += 1
                }
                else if (!videoIsBeenPlaying)
                {
                    videoIsBeenPlaying = true
                    webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
                }
            }
            
            if( !completelyVisible)
            {
                videoIsBeenPlaying = false
                webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.pause();")
            }
            
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var information : GeneralInformation2!
        
        information = banners[indexPath.row]
        switch information.type {
        case SlotType.Carousel.rawValue:
            let carousel = information.carousel
            var titleHeight : CGFloat! = 0.0
            
            if(carousel?.hasTitles)!
            {
                titleHeight = carousel?.urls[0].title.title?.height(withConstrainedWidth: bannersTableView.frame.size.width, font: UIFont (name: (carousel?.urls[0].title.titleFont)!, size: CGFloat((carousel?.urls[0].title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            let aspcetRatio = carousel?.urls[0].aspectRatio
            if(aspcetRatio != nil)
            {
                cellHeight = bannersTableView.frame.size.width * CGFloat(aspcetRatio!) + titleHeight
            }
            else
            {
                cellHeight = bannersTableView.frame.size.width + titleHeight
            }
            
            return cellHeight
        case SlotType.Video.rawValue:
            return bannersTableView.frame.size.width/1.77 - 2
        case SlotType.Text.rawValue:
            return UITableViewAutomaticDimension
        case SlotType.Photo.rawValue:
            var cellHeight : CGFloat!
            if(information.photo.aspectRatio != nil)
            {
                cellHeight = bannersTableView.frame.size.width * CGFloat(information.photo.aspectRatio)
            }
            else
            {
                cellHeight = bannersTableView.frame.size.width
            }
            
            return cellHeight
        default:
            return 180
        }
        
    }
    
    @objc func onContinueClick(sender:UITapGestureRecognizer) {
        if(duration <= 0.0 && statusModel.isAPKSaved)
        {
            UIView.animate(withDuration: 2, animations: {
                self.dismiss(animated: false, completion: nil)
                
                if (self.finishedRunnable != nil)
                {
                    self.finishedRunnable()
                }
                else if(APKChanger.launchScreenTemp != nil)
                {
                    APKChanger.launchScreenTemp.dismiss(animated: true, completion: nil)
                }
            })
            
            isUpdating = false
            timer.invalidate()
        }
    }
    
    
    @objc func updateTimer(){
        duration = duration - interval
        if(statusModel.isAPKSaved)
        {
            if(banners.count != 0)
            {
                if (duration <= 0)
                {
                    timer.invalidate()
                    continueLabel.text = "Click here to continue"
                    dotsLabel.text = ""
                    //continueButton.isHidden = false
                }
                else
                {
                    continueLabel.text = "Continue at \(Int(duration)) ..."
                    dotsLabel.text = ""
                }
            }
            else if (duration <= 0)
            {
                timer.invalidate()
                
                self.dismiss(animated: true, completion: nil)
                UIView.animate(withDuration: 2, animations: {
                    if (self.finishedRunnable != nil)
                    {
                        self.finishedRunnable()
                    }
                    else if(APKChanger.launchScreenTemp != nil)
                    {
                        APKChanger.launchScreenTemp.dismiss(animated: true, completion: nil)
                    }
                })
                
                isUpdating = false
            }
        }
        else
        {
            let a = duration2 % 3
            let message = isUpdating ? "Updating with the latest information" : "Installing with current information"
           
            continueLabel.text = "\(message)"
            
            if(a == 0)
            {
                dotsLabel.text = "."
            }
            else if(a == 1)
            {
                dotsLabel.text = ".."
            }
            else
            {
                dotsLabel.text = "..."
            }
            
            duration2 += 1
        }
    }
}
