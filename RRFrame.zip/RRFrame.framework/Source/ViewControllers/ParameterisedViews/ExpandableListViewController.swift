//
//  StoresLocatorViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 22/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation
import Kingfisher


// Creates view that user can see the stores for specific business.
class ExpandableListViewController: ViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var expandableListTableView: UITableView!
    @IBOutlet weak var scrollUp: UIImageView!
    
    var viewModel : ExpandableListViewModel!
    var items : [ExpandableListItemModel] = []
    var viewIsNotDisplayed = true
    //var optionsListView : OptionsListViewController!
    var currentUIViewController : UIViewController!
    
    var categories : [CategoryModel] = []
    var brands : [CategoryModel] = []
    
    var areCategoriesLoaded = false
    var areBrandsLoaded = false
    var needToLoadStores = false
    
    var isProductSelected = false
    
    var storeLocatorInfoParameters : StoreLocatorInfoParametersModel!
    var holidays : [YearlyHolidaysModel]!
    var nearHolidays : [YearlyHolidaysModel]! = []
    var shopHolidays : [YearlyShopHolidaysModel]!
    
    var daysInString = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    var status : StatusModel!
    
    var areBrandsLoaded2 = false
    var areCategoriesLoaded2 = false
    var isViewAppeared = false
    
    var images : [ImageCacheModel] = []
    var numberOfCachedImages = 10
    var isToastShowed = false
    
    var lastExpandedTab : ExpandableListItemModel!
    var lastExpandedIndexPath : IndexPath!
    var scrollToIndexPath : IndexPath!
    
    var pageNo : Int! = 0
    var previousPageNo : Int! = 0
    var timer: Timer?
    var lastExpandedCount : Int! = 0
    var tempItems : [ExpandableListItemModel] = []
    var timerReload = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        currentUIViewController = self
        //let MainStoryBoard = UIStoryboard(name: "OptionsListView", bundle: nil)
        //optionsListView = MainStoryBoard.instantiateInitialViewController() as! OptionsListViewController
        
        expandableListTableView.rowHeight = UITableViewAutomaticDimension
        expandableListTableView.tableFooterView = UIView()
        expandableListTableView.delegate = self
        expandableListTableView.dataSource = self
        
        expandableListTableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: -20, right: 0)
        
        viewModel = ExpandableListViewModel()
        
        
        let statusModelTemp = statusDB.getStatus(apk: APK)
        if(!(statusModelTemp?.areExpandableListViewsSaved)!)
        {
            let waitingView =  showWaitingView(view: self, container: self.view, text: "No expandable list.")
            //waitingViewController = waitingView
            DispatchQueue.global(qos: .background).async {
                while(!statusModel.areExpandableListViewsSaved)
                {
                    sleep(2)
                    if(!isActivityActive(viewController: self.currentUIViewController))
                    {
                        return
                    }
                    
                    if(!areParametersDownloading && errorOccured)
                    {
                        /*DispatchQueue.main.async(execute: {() -> Void in
                            waitingView.setText(text: "An error has occured. Please try again later...")
                            waitingView.showInternetIsRequired()
                        })*/
                        return
                    }
                }
                
                if(!areParametersDownloading && errorOccured)
                {
                    return
                }
                
                if(!isActivityActive(viewController: self.currentUIViewController))
                {
                    return
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    waitingView.view.removeFromSuperview()
                    waitingView.removeFromParentViewController()
                    self.viewModel.loadFromLD()
                    
                    for c in self.viewModel.list
                    {
                        var item = ExpandableListItemModel()
                        item.type = ExpandableListItemType.Parent.rawValue
                        item.parentModel = c
                        item.isExpanded = false
                        
                        if(c.type == ExpandableListItemType.Category.rawValue && !self.areCategoriesLoaded)
                        {
                            self.areCategoriesLoaded = true
                            
                            if(!statusModel.areProductsSaved)
                            {
                                self.showToast()
                            }
                            
                            if(statusModel.areProductsSaved &&  brandExpandableListItem != nil &&  brandExpandableListItem.parentModel != nil)
                            {
                                item.parentModel.childs = brandExpandableListItem.parentModel.childs
                                item = brandExpandableListItem
                                item.isExpanded = false
                                //self.areCategoriesLoaded2 = true
                                //addChildStyles(item: item)
                            }
                            
                            DispatchQueue.global(qos: .background).async {
                                self.loadCategories(item : item)
                            }
                        }
                        else if(c.type == ExpandableListItemType.Brand.rawValue && !self.areBrandsLoaded)
                        {
                            self.areBrandsLoaded = true

                            if(!statusModel.areProductsSaved)
                            {
                                self.showToast()
                            }
                            
                            DispatchQueue.global(qos: .background).async {
                                self.loadBrands(item : item)
                            }
                        }
                        else if(c.type == ExpandableListItemType.Store.rawValue)
                        {
                            self.needToLoadStores = true
                        }
                        
                        self.items.append(item)
                    }
                    
                    if(self.needToLoadStores)
                    {
                        self.loadStores()
                    }
                    
                    self.expandableListTableView.reloadData()
                    self.status = statusDB.getStatus(apk: APK)
                })
            }
        }
        else
        {
            viewModel.loadFromLD()
            
            for c in viewModel.list
            {
                var item = ExpandableListItemModel()
                item.type = ExpandableListItemType.Parent.rawValue
                item.parentModel = c
                item.isExpanded = false
                
                if(c.type == ExpandableListItemType.Category.rawValue && !areCategoriesLoaded)
                {
                    areCategoriesLoaded = true
                    
                    if(!statusModel.areProductsSaved)
                    {
                        showToast()
                    }
                    
                    if(statusModel.areProductsSaved && categoryExpandableListItem != nil && categoryExpandableListItem.parentModel != nil )
                    {
                        item.parentModel.childs = categoryExpandableListItem.parentModel.childs
                        item = categoryExpandableListItem
                        item.isExpanded = false
                        
                        //if(item.parentModel.childs != nil && item.parentModel.childs.count > 0)
                        //{
                        //    areCategoriesLoaded2 = true
                        //}
                        
                        //addChildStyles(item: item)
                    }
                    else
                    {
                        DispatchQueue.global(qos: .background).async {
                            self.loadCategories(item : item)
                        }
                    }
                }
                else if(c.type == ExpandableListItemType.Brand.rawValue && !areBrandsLoaded)
                {
                    areBrandsLoaded = true
                    
                    if(!statusModel.areProductsSaved)
                    {
                        showToast()
                    }
                    
                    if(statusModel.areProductsSaved &&  brandExpandableListItem != nil &&  brandExpandableListItem.parentModel != nil)
                    {
                        item.parentModel.childs = brandExpandableListItem.parentModel.childs
                        item = brandExpandableListItem
                        item.isExpanded = false
                        //self.areBrandsLoaded2 = true
                        //addChildStyles(item: item)
                    }
                    else
                    {
                        DispatchQueue.global(qos: .background).async {
                            self.loadBrands(item : item)
                        }
                    }
                }
                else if(c.type == ExpandableListItemType.Store.rawValue)
                {
                    needToLoadStores = true
                }
                
                items.append(item)
            }
            
            if(needToLoadStores)
            {
                loadStores()
            }
            
            expandableListTableView.reloadData()
            status = statusDB.getStatus(apk: APK)
        }
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(tapDetected))
        scrollUp.isUserInteractionEnabled = true
        scrollUp.addGestureRecognizer(singleTap)
    
        startTimer()
        
    }
    
    func startTimer () {
        guard timer == nil else { return }
        
        timer =  Timer.scheduledTimer(
            timeInterval: TimeInterval(5.0),
            target      : self,
            selector    : #selector(checkPage),
            userInfo    : nil,
            repeats     : true)
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    func reload(tableView: UITableView, isFromRefresh : Bool) {
        if(isFromRefresh)
        {
            let contentOffset = tableView.contentOffset
            tableView.reloadData()
            tableView.layoutIfNeeded()
            tableView.setContentOffset(contentOffset, animated: false)
        }
        else
        {
            tableView.reloadData()
            tableView.layoutIfNeeded()
            tableView.setContentOffset(CGPoint(x: CGFloat(0), y: CGFloat(0)), animated: false)
        }
    }
    
    @objc func checkPage()
    {
        DispatchQueue.global(qos: .background).async {
            self.status = statusDB.getStatus(apk: APK)
            
            
            self.previousPageNo = self.pageNo
            self.pageNo = self.status.productsPageNo
            
            if (self.pageNo != nil && self.previousPageNo != nil){
                if (self.pageNo > self.previousPageNo){
                    self.products = productsDB.getProducts()
                    if (self.status.areProductsSaved){
                        self.stopTimer()
                    }
                    
                  
                    self.reloadCategoriesAndBrands()
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                       // self.reload(tableView: self.expandableListTableView, isFromRefresh: true)
                        self.expandableListTableView.reloadData()
                    })
                }
            }
        }
    }
    
    func showToast()
    {
        if(!isToastShowed)
        {
            isToastShowed = true
            
            let toast = CustomToast()
            toast.setToast(viewController : self, message : NSLocalizedString("productLoading", comment: ""), duration: CustomToast.TOAST_LENGTH_LONG)
            toast.show()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(!isViewAppeared)
        {
            super.viewWillAppear(animated)
        }
    }
    
    func addChildStyles(item : ExpandableListItemModel)
    {
        let parent : ExpandableListParentModel! = item.parentModel
        var j = 0
        for ct in item.parentModel.childs
        {
            let c : CategoryModel! = ct.categoryModel
            
            if(item.parentModel.hasAlternatingStyles)
            {
                if(j % 2 == 0)
                {
                    c.textSize = parent.firstStyle.textSize
                    c.textColor = parent.firstStyle.textColor
                    c.font = parent.firstStyle.font
                    c.backgroundColor = parent.firstStyle.backgroundColor
                    c.tintColor = parent.firstStyle.tintColor
                }
                else
                {
                    c.textSize = parent.secondStyle.textSize
                    c.textColor = parent.secondStyle.textColor
                    c.font = parent.secondStyle.font
                    c.backgroundColor = parent.secondStyle.backgroundColor
                    c.tintColor = parent.secondStyle.tintColor
                }
            }
            else if(parent.firstStyle != nil)
            {
                c.textSize = parent.firstStyle.textSize
                c.textColor = parent.firstStyle.textColor
                c.font = parent.firstStyle.font
                c.backgroundColor = parent.firstStyle.backgroundColor
                c.tintColor = parent.firstStyle.tintColor
            }
            else
            {
                c.font = "Roboto-Regular"
                c.textColor = "#456712"
                c.textSize = 16
                c.backgroundColor = "ffffff"
                c.tintColor = "#000000"
            }
            
            j += 1
        }
    }
    
    /*
     self.viewModel.loadFromLD()
     
     for c in self.viewModel.list
     {
     var item = ExpandableListItemModel()
     item.type = ExpandableListItemType.Parent.rawValue
     item.parentModel = c
     item.isExpanded = false
     
     if(c.type == ExpandableListItemType.Category.rawValue && !self.areCategoriesLoaded)
     {
     
     if(brandExpandableListItem != nil &&  brandExpandableListItem.parentModel != nil)
     {
     item.parentModel.childs = brandExpandableListItem.parentModel.childs
     item = brandExpandableListItem
     item.isExpanded = false
     }
     
     DispatchQueue.global(qos: .background).async {
     self.loadCategories(item : item)
     }
     }
     if(c.type == ExpandableListItemType.Brand.rawValue && !self.areBrandsLoaded)
     {
     
     DispatchQueue.global(qos: .background).async {
     self.loadBrands(item : item)
     }
     }
     
     self.items.append(item)
     }
     
     self.expandableListTableView.reloadData()
     self.status = statusDB.getStatus(apk: APK)
 
    */
    
    var threadID = 0
    func reloadCategoriesAndBrands()
    {
      
        for item in items
        {
            
            print("I am here")
            if(item.parentModel != nil && item.parentModel.type == ExpandableListItemType.Brand.rawValue)
            {
                DispatchQueue.global(qos: .background).async {
                    self.loadBrands(item : item)
                   
                }
            }
            else if(item.parentModel != nil && item.parentModel.type == ExpandableListItemType.Category.rawValue)
            {
                DispatchQueue.global(qos: .background).async {
                    self.loadCategories(item : item)
                  
                }
            }
            
        }
    }
    
    func calculateSubCategories()
    {
        parentsProductMenu.removeAll()
        
        for p in productMenu
        {
            p.childCategories = []
            
            if(p.parentID == 0)
            {
                parentsProductMenu.append(p)
           
            }
            
            for p2 in productMenu
            {
                if(p2.parentID != nil && p2.parentID == p.id)
                {
                    p.childCategories.append(p2)
                    p2.parentCategory = p
               
                }
            }
        }
        
        for p in productMenu
        {
            p.level = 0
            
            if(p.parentCategory != nil)
            {
                var parent : ProductMenuModel! = p.parentCategory
                while parent != nil
                {
                    p.level = p.level + 1
                    parent = parent.parentCategory
                }
            }
        }
        
        
        /*for c in categories
         {
         c.childCategories = []
         
         for c2 in categories
         {
         if(c2.parentCategoryID != nil && c2.parentCategoryID == c.id)
         {
         c.childCategories.append(c2)
         c2.parentCategory = c
         }
         }
         }
         
         for c in categories
         {
         c.level = 0
         
         if(c.parentCategory != nil)
         {
         var parent : CategoryModel! = c.parentCategory
         while parent != nil
         {
         c.level = c.level + 1
         parent = parent.parentCategory
         }
         }
         }*/
    }
    
    func calculateSubCategories2()
    {
        for c in brands
        {
            c.childCategories = []
            
            for c2 in brands
            {
                if(c2.parentCategoryID != nil && c2.parentCategoryID == c.id)
                {
                    c.childCategories.append(c2)
                    c2.parentCategory = c
                }
            }
        }
        
        for c in brands
        {
            c.level = 0
            
            if(c.parentCategory != nil)
            {
                var parent : CategoryModel! = c.parentCategory
                while parent != nil
                {
                    c.level = c.level + 1
                    parent = parent.parentCategory
                }
            }
        }
    }
    
    var productMenu : [ProductMenuModel]!
    var parentsProductMenu : [ProductMenuModel]! = []
    var productMenuRelations : [ProductMenuRelationModel]!
    var products : [ProductModel]!
    var areProductsLoading = false
    
    func findSubcategories(category : ProductMenuModel)
    {
        let e = ExpandableListChildModel()
        
        let parent : ExpandableListParentModel! = itemTemp.parentModel
        
        if(itemTemp.parentModel.hasAlternatingStyles)
        {
            if(i % 2 == 0)
            {
                category.textSize = parent.firstStyle.textSize
                category.textColor = parent.firstStyle.textColor
                category.font = parent.firstStyle.font
                category.backgroundColor = parent.firstStyle.backgroundColor
                category.tintColor = parent.firstStyle.tintColor
            }
            else
            {
                category.textSize = parent.secondStyle.textSize
                category.textColor = parent.secondStyle.textColor
                category.font = parent.secondStyle.font
                category.backgroundColor = parent.secondStyle.backgroundColor
                category.tintColor = parent.secondStyle.tintColor
            }
        }
        else if(parent.firstStyle != nil)
        {
            category.textSize = parent.firstStyle.textSize
            category.textColor = parent.firstStyle.textColor
            category.font = parent.firstStyle.font
            category.backgroundColor = parent.firstStyle.backgroundColor
            category.tintColor = parent.firstStyle.tintColor
        }
        else
        {
            category.font = "Roboto-Regular"
            category.textColor = "#000000"
            category.textSize = 16
            category.backgroundColor = "ffffff"
            category.tintColor = "#000000"
        }
        
        if(category.childCategories == nil || category.childCategories.count == 0)
        {
            var productMenuRelationsTemp : [ProductMenuRelationModel] = []
            
            for i in 0..<productMenuRelations.count
            {
                if(productMenuRelations[i].menuStructureID == category.id)
                {
                    productMenuRelationsTemp.append(productMenuRelations[i])
                }
            }
            
            category.products = []
            
            /*if(productMenuRelations != nil)
             {
             for r in productMenuRelations!
             {
             var tempProducts = productsDB.getProductsByCategory(relatedCode: r.relatedCode, typeData: r.typeData)
             
             if(tempProducts != nil)
             {
             for tp in tempProducts!
             {
             category.products.append(tp)
             }
             }
             }
             }*/
            
            
            if(productMenuRelationsTemp != nil)
            {
                var tempProducts : [ProductModel] = []
                for j in 0..<productMenuRelationsTemp.count
                {
                    switch productMenuRelationsTemp[j].typeData {
                    case 0:
                        let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                        for i in 0..<products.count
                        {
                            if(products[i].itemNo == relatedCode)
                            {
                                tempProducts.append(products[i])
                                break
                            }
                        }
                    case 1:
                        let relatedCode =  productMenuRelationsTemp[j].relatedCode
                        for i in 0..<products.count
                        {
                            if(products[i].commonItemNo == relatedCode)
                            {
                                tempProducts.append(products[i])
                            }
                        }
                    case 2:
                        let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                        for i in 0..<products.count
                        {
                            if(products[i].categoryCode == relatedCode)
                            {
                                tempProducts.append(products[i])
                            }
                        }
                    default:
                        break
                    }
                }
                
                category.products = Array(Set(tempProducts))
            }
            
        }
        
        e.type = ExpandableListItemType.Category2.rawValue
        e.categoryModel2 = category
        
        
        let categories = category.childCategories
        if(categories != nil && (categories?.count)! > 0)
        {
            //childs.append(e)
            
            for c in categories!
            {
                findSubcategories(category: c)
            }
            
            var j = 0
            let count : Int! = category.childCategories?.count
            for _ in 0..<count
            {
                if((category.childCategories[j].childCategories == nil || category.childCategories[j].childCategories.count == 0) && (category.childCategories[j].products == nil || category.childCategories[j].products.count == 0))
                {
                    category.childCategories.remove(at: j)
                }
                else
                {
                    j += 1
                }
            }
        }
        
        /*if((category.childCategories == nil || category.childCategories.count == 0) && (category.products == nil || category.products.count == 0))
         {
         
         }*/
    }
    
    
    
    var brandsLock = NSObject()
    
    func loadBrands(item : ExpandableListItemModel, threadID : Int = 0)
    {
        /*if(products == nil || products.count == 0 /*|| self.threadID > 0*/)
         {
         products = productsDB.getProducts()
         }*/
        
        
        //objc_sync_enter(brandsLock)
        
        if((products == nil || products.count == 0) /*!areProductsLoading*/)
        {
            areProductsLoading = true
            products = productsDB.getProducts()
            areProductsLoading = false
        }
        else
        {
            while(areProductsLoading)
            {
                sleep(2)
            }
        }
        
        brands = productsDB.getBrands()
        calculateSubCategories2()
        
        var childs : [ExpandableListChildModel] = []
        let parent : ExpandableListParentModel! = item.parentModel
        var i = 0
        
        for c in brands
        {
            if(!isActivityActive(viewController: self.currentUIViewController) /*|| self.threadID != threadID*/)
            {
                return
            }
            
            let e = ExpandableListChildModel()
            
            if(item.parentModel.hasAlternatingStyles)
            {
                if(i % 2 == 0)
                {
                    c.textSize = parent.firstStyle.textSize
                    c.textColor = parent.firstStyle.textColor
                    c.font = parent.firstStyle.font
                    c.backgroundColor = parent.firstStyle.backgroundColor
                    c.tintColor = parent.firstStyle.tintColor
                }
                else
                {
                    c.textSize = parent.secondStyle.textSize
                    c.textColor = parent.secondStyle.textColor
                    c.font = parent.secondStyle.font
                    c.backgroundColor = parent.secondStyle.backgroundColor
                    c.tintColor = parent.secondStyle.tintColor
                }
            }
            else if(parent.firstStyle != nil)
            {
                c.textSize = parent.firstStyle.textSize
                c.textColor = parent.firstStyle.textColor
                c.font = parent.firstStyle.font
                c.backgroundColor = parent.firstStyle.backgroundColor
                c.tintColor = parent.firstStyle.tintColor
            }
            else
            {
                c.font = "Roboto-Regular"
                c.textColor = "#456712"
                c.textSize = 16
                c.backgroundColor = "ffffff"
                c.tintColor = "#000000"
            }
            
            var tempProducts : [ProductModel] = []
            c.products = []
            
            for i in 0..<products.count
            {
                if(products[i].manufacturerCode == c.code)
                {
                    tempProducts.append(products[i])
                }
            }
            
            c.products = tempProducts
            
            //c.products = productsDB.getProducts(manufacturerName : c.code)
            
            for p in c.products
            {
                p.brand = c
            }
            
            e.type = ExpandableListItemType.Category.rawValue
            e.categoryModel = c
            
            if(c.level == 0 && c.products.count > 0 && !isNullOrEmpty(string: c.name))
            {
                childs.append(e)
                
                i += 1
            }
        }
        
        parent.childs = childs
        
        //objc_sync_exit(brandsLock)
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.expandableListTableView.reloadData()
            self.areBrandsLoaded2 = true
        })
    }
    
    var i = 0
    var itemTemp : ExpandableListItemModel!
    var categoriesLock = NSObject()
    
    func loadCategories(item : ExpandableListItemModel, threadID : Int = 0)
    {
        //objc_sync_enter(categoriesLock)
        var childs : [ExpandableListChildModel] = []
        
        if((products == nil || products.count == 0) /*!areProductsLoading*/)
        {
            areProductsLoading = true
            products = productsDB.getProducts()
            areProductsLoading = false
        }
        else
        {
            while(areProductsLoading)
            {
                sleep(2)
            }
        }
        
        if(productMenu == nil || productMenu.count == 0)
        {
            productMenu = productsDB.getProductMenu()
        }
        
        if(productMenuRelations == nil || productMenuRelations.count == 0)
        {
            productMenuRelations = productsDB.getProductMenuRelations()
        }
        

        
        calculateSubCategories()
        
        self.itemTemp = item
        let parent : ExpandableListParentModel! = item.parentModel
        
        i = 0
        
        if(parentsProductMenu != nil)
        {
            for p in parentsProductMenu!
            {
                if(!isActivityActive(viewController: self.currentUIViewController) /*&& self.threadID != threadID*/)
                {
                    return
                }
                
                let e = ExpandableListChildModel()
                
                if(item.parentModel.hasAlternatingStyles)
                {
                    if(i % 2 == 0)
                    {
                        p.textSize = parent.firstStyle.textSize
                        p.textColor = parent.firstStyle.textColor
                        p.font = parent.firstStyle.font
                        p.backgroundColor = parent.firstStyle.backgroundColor
                        p.tintColor = parent.firstStyle.tintColor
                    }
                    else
                    {
                        p.textSize = parent.secondStyle.textSize
                        p.textColor = parent.secondStyle.textColor
                        p.font = parent.secondStyle.font
                        p.backgroundColor = parent.secondStyle.backgroundColor
                        p.tintColor = parent.secondStyle.tintColor
                    }
                }
                else if(parent.firstStyle != nil)
                {
                    p.textSize = parent.firstStyle.textSize
                    p.textColor = parent.firstStyle.textColor
                    p.font = parent.firstStyle.font
                    p.backgroundColor = parent.firstStyle.backgroundColor
                    p.tintColor = parent.firstStyle.tintColor
                }
                else
                {
                    p.font = "Roboto-Regular"
                    p.textColor = "#456712"
                    p.textSize = 16
                    p.backgroundColor = "ffffff"
                    p.tintColor = "#000000"
                }
                
                i += 1
                
                
                
                if(p.childCategories == nil || p.childCategories.count == 0)
                {
                    var productMenuRelationsTemp : [ProductMenuRelationModel] = []
                    
                    for j in 0..<productMenuRelations.count
                    {
                        if(productMenuRelations[j].menuStructureID == p.id)
                        {
                            productMenuRelationsTemp.append(productMenuRelations[j])
                        }
                    }
                    
                    p.products = []
                    
                    
                    if(productMenuRelationsTemp != nil)
                    {
                        var tempProducts : [ProductModel] = []
                        for j in 0..<productMenuRelationsTemp.count
                        {
                            switch productMenuRelationsTemp[j].typeData {
                            case 0:
                                let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                                for i in 0..<products.count
                                {
                                    if(products[i].itemNo == relatedCode)
                                    {
                                        tempProducts.append(products[i])
                                        break
                                    }
                                }
                                
                                
                            case 1:
                                let relatedCode =  productMenuRelationsTemp[j].relatedCode
                                for i in 0..<products.count
                                {
                                    if(products[i].commonItemNo == relatedCode)
                                    {
                                        tempProducts.append(products[i])
                                    }
                                }
                            case 2:
                                let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
                                for i in 0..<products.count
                                {
                                    if(products[i].categoryCode == relatedCode)
                                    {
                                        tempProducts.append(products[i])
                                    }
                                }
                            default:
                                break
                            }
                        }
                        
                        p.products = Array(Set(tempProducts))
                    }
                    
                }
                
                //uniq(source: p.products)
                
                /*for product in p.products
                 {
                 product.category2 = p
                 }*/
                
                e.type = ExpandableListItemType.Category2.rawValue
                e.categoryModel2 = p
                
                
                //if(p.products.count > 0)
                //{
                
                //}
                
                
                if(p.childCategories != nil && p.childCategories.count > 0)
                {
                    print(p.childCategories.count)
                    for c in p.childCategories
                    {
                        findSubcategories(category: c)
                    }
                    
                    var j = 0
                    for _ in 0..<p.childCategories.count
                    {
                        if((p.childCategories[j].childCategories == nil || p.childCategories[j].childCategories.count == 0) && (p.childCategories[j].products == nil || p.childCategories[j].products.count == 0))
                        {
                            p.childCategories.remove(at: j)
                        }
                        else
                        {
                            j += 1
                        }
                    }
                }
                

                if((p.childCategories != nil && p.childCategories.count > 0) || (p.products != nil && p.products.count > 0))
                {
                    childs.append(e)
                }
            }
        }
        
        parent.childs = childs
        
       // objc_sync_exit(categoriesLock)
        
        DispatchQueue.main.async(execute: {() -> Void in
            if(!self.timerReload){
            self.expandableListTableView.reloadData()
            self.areCategoriesLoaded2 = true
            }
        })
    }
    
    /*func loadCategories(item : ExpandableListItemModel)
     {
     productMenu = productsDB.getProductMenu()
     productMenuRelations = productsDB.getProductMenuRelations()
     products = productsDB.getProducts()
     
     calculateSubCategories()
     
     self.itemTemp = item
     let parent : ExpandableListParentModel! = item.parentModel
     
     i = 0
     
     if(parentsProductMenu != nil)
     {
     for p in parentsProductMenu!
     {
     let e = ExpandableListChildModel()
     
     if(item.parentModel.hasAlternatingStyles)
     {
     if(i % 2 == 0)
     {
     p.textSize = parent.firstStyle.textSize
     p.textColor = parent.firstStyle.textColor
     p.font = parent.firstStyle.font
     p.backgroundColor = parent.firstStyle.backgroundColor
     p.tintColor = parent.firstStyle.tintColor
     }
     else
     {
     p.textSize = parent.secondStyle.textSize
     p.textColor = parent.secondStyle.textColor
     p.font = parent.secondStyle.font
     p.backgroundColor = parent.secondStyle.backgroundColor
     p.tintColor = parent.secondStyle.tintColor
     }
     }
     else if(parent.firstStyle != nil)
     {
     p.textSize = parent.firstStyle.textSize
     p.textColor = parent.firstStyle.textColor
     p.font = parent.firstStyle.font
     p.backgroundColor = parent.firstStyle.backgroundColor
     p.tintColor = parent.firstStyle.tintColor
     }
     else
     {
     p.font = "Roboto-Regular"
     p.textColor = "#456712"
     p.textSize = 16
     p.backgroundColor = "ffffff"
     p.tintColor = "#000000"
     }
     
     i += 1
     
     var productMenuRelationsTemp : [ProductMenuRelationModel] = []
     
     for j in 0..<productMenuRelations.count
     {
     if(productMenuRelations[j].menuStructureID == p.id)
     {
     productMenuRelationsTemp.append(productMenuRelations[j])
     }
     }
     
     
     p.products = []
     
     /*if(productMenuRelations != nil)
     {
     for r in productMenuRelations!
     {
     var tempProducts = productsDB.getProductsByCategory(relatedCode: r.relatedCode, typeData: r.typeData)
     
     if(tempProducts != nil)
     {
     for tp in tempProducts!
     {
     if(!p.products.contains(tp))
     {
     p.products.append(tp)
     }
     }
     }
     }
     }*/
     
     if(productMenuRelationsTemp != nil)
     {
     for j in 0..<productMenuRelationsTemp.count
     {
     switch productMenuRelationsTemp[j].typeData {
     case 0:
     let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
     for i in 0..<products.count
     {
     if(products[i].itemNo == relatedCode)
     {
     p.products.append(products[i])
     break
     }
     }
     
     
     case 1:
     let relatedCode =  productMenuRelationsTemp[j].relatedCode
     for i in 0..<products.count
     {
     if(products[i].commonItemNo == relatedCode)
     {
     p.products.append(products[i])
     }
     }
     case 2:
     let relatedCode =  Int64(productMenuRelationsTemp[j].relatedCode)
     for i in 0..<products.count
     {
     if(products[i].categoryCode == relatedCode)
     {
     p.products.append(products[i])
     }
     }
     default:
     break
     }
     }
     
     p.products = Array(Set(p.products))
     }
     
     
     
     //uniq(source: p.products)
     
     /*for product in p.products
     {
     product.category2 = p
     }*/
     
     e.type = ExpandableListItemType.Category2.rawValue
     e.categoryModel2 = p
     
     
     if(p.products.count > 0)
     {
     childs.append(e)
     }
     
     if(p.childCategories != nil)
     {
     print(p.childCategories.count)
     for c in p.childCategories
     {
     findSubcategories(category: c)
     }
     }
     }
     }
     
     parent.childs = childs
     
     DispatchQueue.main.async(execute: {() -> Void in
     self.expandableListTableView.reloadData()
     })
     }*/
    
    
    func loadStores()
    {
        let stores : [StoreModel] = storesDB.getStores()
        
        for s in stores
        {
            s.dayGroups = []
            let hours = s.hours
            
            for d in 0...6
            {
                var foundSame = false
                
                //Check if group already exists
                if(s.dayGroups.count != 0)
                {
                    for g in s.dayGroups
                    {
                        if(g.startTime1 == hours?.startTime1[d] && g.startTime2 == hours?.startTime2[d] && g.endTime1 == hours?.endTime1[d] && g.endTime2 == hours?.endTime2[d])
                        {
                            g.daysInInt.append(d)
                            //g.days.append(daysInString[d])
                            foundSame = true
                            break
                        }
                    }
                }
                else
                {
                    let dayGroup = DayGroupModel()
                    
                    //dayGroup.days.append(daysInString[d])
                    dayGroup.daysInInt.append(d)
                    dayGroup.startTime1 = hours?.startTime1[d]
                    dayGroup.startTime2 = hours?.startTime2[d]
                    dayGroup.endTime1 = hours?.endTime1[d]
                    dayGroup.endTime2 = hours?.endTime2[d]
                    s.dayGroups.append(dayGroup)
                    
                    foundSame = true
                }
                
                if(!foundSame)
                {
                    let dayGroup = DayGroupModel()
                    
                    dayGroup.daysInInt.append(d)
                    //dayGroup.days.append(daysInString[d])
                    dayGroup.startTime1 = hours?.startTime1[d]
                    dayGroup.startTime2 = hours?.startTime2[d]
                    dayGroup.endTime1 = hours?.endTime1[d]
                    dayGroup.endTime2 = hours?.endTime2[d]
                    s.dayGroups.append(dayGroup)
                }
                
                /*if(!foundSame)
                 {
                 for i in 0...6
                 {
                 if(d != i)
                 {
                 if(hours?.startTime1[d] == hours?.startTime1[i] && hours?.startTime2[d] == hours?.startTime2[i] && hours?.endTime1[d] == hours?.endTime1[i] && hours?.endTime2[d] == hours?.endTime2[i])
                 {
                 let dayGroup = DayGroupModel()
                 
                 dayGroup.days.append("A")
                 dayGroup.startTime1 = hours?.startTime1[d]
                 dayGroup.startTime2 = hours?.startTime2[d]
                 dayGroup.endTime1 = hours?.endTime1[d]
                 dayGroup.endTime2 = hours?.endTime2[d]
                 s.dayGroups.append(dayGroup)
                 
                 break
                 }
                 }
                 }
                 }*/
            }
            
            for g in s.dayGroups
            {
                var daysCalculated = 0
                var i = 0
                
                for d in g.daysInInt
                {
                    if(i >= daysCalculated)
                    {
                        daysCalculated += 1
                        
                        var j = 1
                        var tempDay = d
                        while(true)
                        {
                            if(i + j == g.daysInInt.count)
                            {
                                break
                            }
                            else if(tempDay - g.daysInInt[i + j] == -1)
                            {
                                tempDay += 1
                                j += 1
                                daysCalculated += 1
                            }
                            else
                            {
                                break
                            }
                        }
                        
                        if(j < 3)
                        {
                            g.days.append(daysInString[d])
                            daysCalculated -= j - 1
                        }
                        else
                        {
                            g.days.append(daysInString[d] + " - " + daysInString[g.daysInInt[i + j - 1]])
                        }
                        
                        
                    }
                    
                    i += 1
                }
            }
            
            
        }
        
        for i in items
        {
            for s in stores
            {
                if(i.parentModel.name.lowercased() == s.city.lowercased())
                {
                    let child = ExpandableListChildModel()
                    child.storeModel = s
                    child.type = ExpandableListItemType.Store.rawValue
                    i.parentModel.childs.append(child)
                }
            }
        }
        
        expandableListTableView.reloadData()
    }
    
    override func viewDidLayoutSubviews() {
        if(!viewIsNotDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        navigation = self.navigationController
        
        isProductSelected = false
        isViewAppeared = true
        super.viewDidAppear(animated)
        
        if(!viewIsNotDisplayed)
        {
            for c in self.viewModel.list
            {
                var item = ExpandableListItemModel()
                item.type = ExpandableListItemType.Parent.rawValue
                item.parentModel = c
                item.isExpanded = false
                
                if(c.type == ExpandableListItemType.Category.rawValue && self.areCategoriesLoaded && !self.areCategoriesLoaded2 && (categoryExpandableListItem == nil || categoryExpandableListItem.parentModel == nil))
                {
                    DispatchQueue.global(qos: .background).async {
                        self.loadCategories(item : item)
                    }
                }
                else if(c.type == ExpandableListItemType.Brand.rawValue && self.areBrandsLoaded && !self.areBrandsLoaded2 && (categoryExpandableListItem == nil || categoryExpandableListItem.parentModel == nil))
                {
                    DispatchQueue.global(qos: .background).async {
                        self.loadBrands(item : item)
                    }
                }
            }
        }
        else
        {
            viewIsNotDisplayed = false
        }
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        if(separatorColor != nil)
        {
            headerView.backgroundColor = UIColor((separatorColor)!)
        }
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        let item = items[section]
        
        switch item.type {
        case ExpandableListItemType.Parent.rawValue:
            if(section == 0 || separatorHeight == 0)
            {
                return CGFloat.leastNormalMagnitude
            }
            else
            {
                if(self.items[section - 1].type == ExpandableListItemType.Parent.rawValue && separatorHeight != nil)
                {
                    return CGFloat(separatorHeight)
                }
                else
                {
                    return CGFloat.leastNormalMagnitude
                }
            }
        case ExpandableListItemType.Store.rawValue:
            return CGFloat.leastNormalMagnitude
        default:
            return CGFloat.leastNormalMagnitude
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        KingfisherManager.shared.cache.clearMemoryCache()
        KingfisherManager.shared.cache.clearDiskCache()
        KingfisherManager.shared.cache.cleanExpiredDiskCache()
    }
    
    func calculateHolidaysPerShop()
    {
        holidays = storesDB.getHolidays()
        
        for i in items
        {
            if(i.parentModel != nil)
            {
                for child in i.parentModel.childs
                {
                    if child.type == ExpandableListItemType.Store.rawValue
                    {
                        //child.storeModel.closedHolidays = holidays
                        
                        let sh = storesDB.getShopHolidays(addressID: child.storeModel.addressID)
                        if(sh != nil && sh?.count != 0)
                        {
                            child.storeModel.opendHolidays = sh
                        }
                    }
                }
            }
        }
        
        for h in holidays
        {
            let dateFormatter = DateFormatter()
            dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
            dateFormatter.dateFormat = "dd/MM/yyyy"
            let holidayDate = dateFormatter.date(from: h.holidayDate)
            
            let currentDate = dateFormatter.date(from: dateFormatter.string(from: Date()))
            
            //let calendar = NSCalendar.current
            //let components = calendar.dateComponents([.day], from: currentDate!, to: holidayDate!)
            

            let difference = holidayDate?.timeIntervalSince(currentDate!)
            let differenceInDays = Int(difference!/(60 * 60 * 24 ))
            
            if(differenceInDays >= 0 && differenceInDays <= 30)
            {
                nearHolidays.append(h)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*let cell = tableView.dequeueReusableCell(withIdentifier: "town_cell") as! TownViewCell
         cell.selectionStyle = .none
         
         if(indexPath.row == 1)
         {
         let cell = tableView.dequeueReusableCell(withIdentifier: "header_cell") as! HeaderViewCell
         cell.selectionStyle = .none
         
         return cell
         }
         else if(indexPath.row >= 2)
         {
         let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_cell") as! StoreInfoViewCell
         cell.selectionStyle = .none
         
         return cell
         }
         
         return cell*/
        let item = items[indexPath.section]
        
        switch item.type {
        case ExpandableListItemType.Parent.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "expandable_cell_parent") as! ExpandableParentViewCell
            let parent : ExpandableListParentModel! = item.parentModel
            
            cell.labelWidth.constant = CGFloat(parent.labelWidth)
            cell.labelHeight.constant = CGFloat(parent.labelHeight)
            
            if(parent.labelBackgroundColor != nil)
            {
                cell.parentLabel.backgroundColor = UIColor(parent.labelBackgroundColor)
            }
            
            if(parent.childs != nil && parent.childs.count > 0)
            {
                cell.parentLabel.text = parent.name //+ " (" + String(parent.childs.count) + ")"
                cell.expandImageHeight.constant = 15
                
                if(item.isExpanded)
                {
                    cell.expandImage.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                    cell.expandImage.tintColor = UIColor(parent.tintColor)
                }
                else
                {
                    cell.expandImage.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                    cell.expandImage.tintColor = UIColor(parent.tintColor)
                    //item.isExpanded = false
                }
                
               cell.indicator.stopAnimating()
            }
            else
            {
                cell.parentLabel.text = parent.name
                cell.expandImageHeight.constant = 0
                parent.childs = []
                
                if(item.parentModel.type == ExpandableListItemType.Category.rawValue)
                {
                    if(/*statusModel.areProductsSaved &&*/ areCategoriesLoaded2)
                    {
                        cell.indicator.stopAnimating()
                    }
                    else
                    {
                        cell.indicator.startAnimating()
                    }
                }
                else if(item.parentModel.type == ExpandableListItemType.Brand.rawValue)
                {
                    if(/*statusModel.areProductsSaved &&*/ areBrandsLoaded2)
                    {
                        cell.indicator.stopAnimating()
                    }
                    else
                        
                    {
                        cell.indicator.startAnimating()
                    }
                }
                else
                {
                    cell.indicator.stopAnimating()
                }
            }
            
            
            if(parent.image == nil)
            {
                cell.parentImageHeight.constant = 0
            }
            else
            {
                cell.parentImageHeight.constant = 30
                
                var image = viewsDB.getImage(url: parent.image)
                
                if(image != nil)
                {
                    cell.parentImage.image = viewsDB.getImage(url: parent.image)
                }
                else
                {
                    let url = URL(string: percentEncode(s: parent.image))
                    cell.parentImage.kf.setImage(with: url)
                }
            }
            
            if(!isNullOrEmpty(string: parent.backgroundImage))
            {
                //let url = URL(string: percentEncode(s: parent.backgroundImage))
                //cell.backgroundImage.image = viewsDB.getImage(url: parent.backgroundImage)
                
                if(!parent.isBackgroundImageLoaded)
                {
                    var image = viewsDB.getImage(url: parent.backgroundImage)
                    
                    if(image != nil)
                    {
                        images.append(ImageCacheModel(image: image!, url: parent.backgroundImage, parentModel : parent))
                        cell.backgroundImage.image = (images.last)?.image
                        parent.isBackgroundImageLoaded = true
                        
                        if(images.count > numberOfCachedImages)
                        {
                            images[0].parentModel.isBackgroundImageLoaded = false
                            images.remove(at: 0)
                        }
                    }
                    else
                    {
                        let url = URL(string: percentEncode(s:parent.backgroundImage))
                        cell.backgroundImage.kf.setImage(with: url, completionHandler: {
                            (image, error, cacheType, imageUrl) in
                            // image: Image? `nil` means failed
                            // error: NSError? non-`nil` means failed
                            // cacheType: CacheType
                            //                  .none - Just downloaded
                            //                  .memory - Got from memory cache
                            //                  .disk - Got from disk cache
                            // imageUrl: URL of the image
                            
                            if(image != nil)
                            {
                                var aspectRatio = Double((image?.size.height)! / (image?.size.width)!)
                                parent.aspectRatio = aspectRatio
                                self.images.append(ImageCacheModel(image: image!, url: parent.backgroundImage, parentModel : parent))
                                
                                
                                if(self.images.count > self.numberOfCachedImages)
                                {
                                    self.images[0].parentModel.isBackgroundImageLoaded = false
                                    self.images.remove(at: 0)
                                }
                                
                                if(!parent.isBackgroundImageLoaded)
                                {
                                    self.expandableListTableView.reloadData()
                                    parent.isBackgroundImageLoaded = true
                                    //viewsDB.insertImage(url: photo.imageUrl, str: UIImagePNGRepresentation(image!)!)
                                }
                                
                            }
                        })
                    }
                }
                else
                {
                    for i in 0..<images.count
                    {
                        if(images[i].url == parent.backgroundImage)
                        {
                            cell.backgroundImage.image = images[i].image
                            break
                        }
                    }
                }
            }
            
            var cellHeight : CGFloat!
            
            if #available(iOS 11.0, *) {
                if(isNullOrEmpty(string: parent.backgroundImage))
                {
                    cellHeight = (self.view.safeAreaLayoutGuide.layoutFrame.size.height - (CGFloat(separatorHeight) * (CGFloat(viewModel.list.count) - 1))) / CGFloat(viewModel.list.count)
                }
                else
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(item.parentModel.aspectRatio)
                }
            }
            else
            {
                if(isNullOrEmpty(string: parent.backgroundImage))
                {
                    cellHeight = (self.view.frame.height  - (CGFloat(separatorHeight) * (CGFloat(viewModel.list.count) - 1))) / CGFloat(viewModel.list.count)
                }
                else
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(item.parentModel.aspectRatio)
                }
            }
            
            switch parent.labelPosition
            {
            case 1:
                cell.parentImageBottom.constant = cellHeight - cell.labelHeight.constant - cell.parentImageHeight.constant - 5
            case 2:
                cell.parentImageBottom.constant = cellHeight/2 - cell.parentImageHeight.constant/2 + 8
            case 3:
                cell.expandImageHeight.constant = 0
                cell.indicator.stopAnimating()
            default:
                cell.parentImageBottom.constant = cellHeight/2 - cell.parentImageHeight.constant/2
            }
            
            cell.parentLabel.font = UIFont (name: parent.font, size: CGFloat(parent.textSize))
            cell.parentLabel.textColor = UIColor(parent.textColor)
            cell.backgroundColor = UIColor(parent.backgroundColor)
            
            cell.selectionStyle = .none
            return cell
        case ExpandableListItemType.Store.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "expandable_cell_store") as! ExpandableStoreViewCell
            if(storeLocatorInfoParameters == nil)
            {
                storeLocatorInfoParameters = viewsDB.getStoreLocatorInfoParameters()
                calculateHolidaysPerShop()
            }
            
            let store : StoreModel! = item.storeModel
            
            cell.infoImage.image = UIImage(named: "ic_left_drawer_about")?.withRenderingMode(.alwaysTemplate)
            cell.infoImage.tintColor = UIColor(storeLocatorInfoParameters.tintColor)
            
            cell.store = store
            cell.storeInfoParameters = storeLocatorInfoParameters
            cell.table = expandableListTableView
            cell.indexPath = indexPath
            
            cell.addressLabel.text = store.description //store.address1
            cell.addressLabel.font = UIFont (name: (storeLocatorInfoParameters.textFont)!, size: CGFloat(storeLocatorInfoParameters.sizeOfText))
            cell.addressLabel.textColor = UIColor(storeLocatorInfoParameters.textColor)
            
            cell.navigationController = self.navigationController
            
            if(isShopOpen(store : store, holidays : nearHolidays))
            {
                cell.statusLabel.textColor = UIColor("#249DD9") //UIColor.green
                cell.statusLabel.text = "OPEN"
            }
            else
            {
                cell.statusLabel.textColor = UIColor.red
                cell.statusLabel.text = "CLOSED"
            }
            
             cell.selectionStyle = .none
            return cell
        case ExpandableListItemType.Search.rawValue :
            let cell = tableView.dequeueReusableCell(withIdentifier: "expandable_cell_search") as! ExpandableSearchViewCell
            return cell
        case ExpandableListItemType.Category.rawValue , ExpandableListItemType.Brand.rawValue :
            let cell = tableView.dequeueReusableCell(withIdentifier: "expandable_cell_categories") as! ExpandableCategoryViewCell
            let category : CategoryModel! = item.categoryModel
            
            
            cell.backgroundColor = UIColor(category.backgroundColor)
            cell.categoryLabel.font = UIFont (name: category.font, size: CGFloat(category.textSize))
            cell.categoryLabel.textColor = UIColor(category.textColor)
            
            if(category.childCategories == nil || category.childCategories.count == 0)
            {
                cell.categoryLabel.text = "\(category.name ?? "")" //(\(category.products.count))"
            }
            else
            {
                cell.categoryLabel.text = "\(category.name ?? "")"//" (\(category.childCategories.count))"
            }
            
            if((category.childCategories == nil || category.childCategories.count == 0) && (category.products == nil || category.products.count == 0))
            {
                cell.expandImage.image = UIImage(named: "")
            }
            else
            {
                if(!item.isExpanded)
                {
                    cell.expandImage.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                    cell.expandImage.tintColor = UIColor(category.tintColor)
                }
                else
                {
                    cell.expandImage.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                    cell.expandImage.tintColor = UIColor(category.tintColor)
                }
            }
            
            if(category.image == nil)
            {
                cell.categoryImageWidth.constant = 0
            }
            else
            {
                cell.categoryImageWidth.constant = 30
                let url = URL(string: percentEncode(s: category.image))
                cell.categoryImage.kf.setImage(with: url )
            }
            
            cell.leftPadding.constant = CGFloat(category.level * 15)
            
            cell.selectionStyle = .none
            return cell
        case ExpandableListItemType.Category2.rawValue :
            let cell = tableView.dequeueReusableCell(withIdentifier: "expandable_cell_categories") as! ExpandableCategoryViewCell
            let category : ProductMenuModel! = item.categoryModel2
            
            
            cell.backgroundColor = UIColor(category.backgroundColor)
            cell.categoryLabel.font = UIFont (name: category.font, size: CGFloat(category.textSize))
            cell.categoryLabel.textColor = UIColor(category.textColor)
            
            if(category.childCategories != nil && category.childCategories.count > 0)
            {
                cell.categoryLabel.text = "\(category.name ?? "")"//" (\(category.childCategories.count))"
            }
            else if(category.products != nil && category.products.count > 0)
            {
                cell.categoryLabel.text = "\(category.name ?? "") (\(category.products.count))"
            }
            else
            {
                cell.categoryLabel.text = "\(category.name ?? "")"
            }
            
            if((category.childCategories == nil || category.childCategories.count == 0) && (category.products == nil || category.products.count == 0))
            {
                cell.expandImage.image = UIImage(named: "")
            }
            else
            {
                if(!item.isExpanded)
                {
                    cell.expandImage.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                    cell.expandImage.tintColor = UIColor(category.tintColor)
                }
                else
                {
                    cell.expandImage.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                    cell.expandImage.tintColor = UIColor(category.tintColor)
                }
            }
            
            if(category.image == nil)
            {
                cell.categoryImageWidth.constant = 0
            }
            else
            {
                cell.categoryImageWidth.constant = 30
                let url = URL(string: percentEncode(s: category.image))
                cell.categoryImage.kf.setImage(with: url )
            }
            
            cell.leftPadding.constant = CGFloat(category.level * 15)
            
            cell.selectionStyle = .none
            return cell
        case ExpandableListItemType.Product.rawValue :
            let cell = tableView.dequeueReusableCell(withIdentifier: "expandable_cell_product") as! ExpandableProductViewCell
            let product : ProductModel! = item.productModel
            
            cell.productLabel.text = product.webDescription
            
            cell.backgroundColor = UIColor(product.backgroundColor)
            cell.productLabel.font = UIFont (name: product.font, size: CGFloat(product.textSize))
            cell.productLabel.textColor = UIColor(product.textColor)
            
            if(product.imageA == nil && product.imageB == nil)
            {
                cell.productImageHeight.constant = 0
            }
            else
            {
                cell.productImageHeight.constant = 30
                if(!isNullOrEmpty(string : product.imageA))
                {
                    let url = URL(string: percentEncode(s: product.imageA))
                    cell.productImage.kf.setImage(with: url )
                }
                else if(!isNullOrEmpty(string : product.imageB))
                {
                    let url = URL(string: percentEncode(s: product.imageB))
                    cell.productImage.kf.setImage(with: url )
                }
            }
            
            if(product.category != nil)
            {
                cell.leftPadding.constant = CGFloat((product.category.level) * 15)
            }
            else if(product.category2 != nil)
            {
                cell.leftPadding.constant = CGFloat((product.category2.level) * 15)
            }
            else if(product.brand != nil)
            {
                cell.leftPadding.constant = 15
            }
            
            
            cell.selectionStyle = .none
            return cell
            
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "town_cell") as! ExpandableParentViewCell
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let item = items[indexPath.section]
        
        switch item.type {
        case ExpandableListItemType.Parent.rawValue:
            if #available(iOS 11.0, *) {
                if(isNullOrEmpty(string: item.parentModel.backgroundImage))
                {
                    return (self.view.safeAreaLayoutGuide.layoutFrame.size.height - (CGFloat(separatorHeight) * (CGFloat(viewModel.list.count) - 1))) / CGFloat(viewModel.list.count)
                }
                else
                {
                    return UIScreen.main.bounds.size.width * CGFloat(item.parentModel.aspectRatio)
                }
            } else {
                // Fallback on earlier versions
            }
            
            if(isNullOrEmpty(string: item.parentModel.backgroundImage))
            {
                return (self.view.frame.height  - (CGFloat(separatorHeight) * (CGFloat(viewModel.list.count) - 1))) / CGFloat(viewModel.list.count)
            }
            else
            {
                return UIScreen.main.bounds.size.width * CGFloat(item.parentModel.aspectRatio)
            }
        default:
            return UITableViewAutomaticDimension
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var item = items[indexPath.section]
      
        switch item.type {
        case ExpandableListItemType.Parent.rawValue:
            let  parent : ExpandableListParentModel = item.parentModel
            
            if(parent.childs != nil && parent.childs.count > 0)
            {
                if(!item.isExpanded)
                {
                    lastExpandedTab = nil
                    lastExpandedIndexPath = nil
                    item.isExpanded = true
                    
                    //let header = StoreLocatorItem()
                    //items.append(header)
                    //parent = l
                    var i = 1
                    for c in parent.childs
                    {
                        let child = ExpandableListItemModel()
                        child.type = c.type
                        child.isExpanded = false
                        
                        switch c.type
                        {
                        case ExpandableListItemType.Store.rawValue:
                            child.storeModel = c.storeModel
                        case ExpandableListItemType.Category.rawValue, ExpandableListItemType.Brand.rawValue:
                            
                            child.categoryModel = c.categoryModel
                        case ExpandableListItemType.Category2.rawValue, ExpandableListItemType.Brand.rawValue:
                            child.categoryModel2 = c.categoryModel2
                        default :
                            break
                        }
                        
                        items.insert(child, at: indexPath.section + i)
                        i += 1
                    }
                    
                    expandableListTableView.reloadData()
                    
                    /*if (storesLocatorTableView.cellForRow(at: IndexPath(row: 0, section: indexPath.section + city.stores.count)) == nil) {
                     DispatchQueue.main.async(execute: {
                     self.storesLocatorTableView.scrollToRow( at: IndexPath(row: 0, section: indexPath.section + city.stores.count), at: .bottom , animated: true)
                     })
                     }*/
                    
                    DispatchQueue.main.async(execute: {
                        let indexPathTemp = IndexPath(row: 0, section: indexPath.section + 1)
                        
                        let cellRect = self.expandableListTableView.rectForRow(at: indexPathTemp)
                        let completelyVisible = self.expandableListTableView.bounds.contains(cellRect)
                        if (!completelyVisible) {
                            //
                            //                            if((parent.childs?.count)! > 10)
                            //                            {
                            //                                self.expandableListTableView.scrollToRow( at: indexPathTemp, at: .top , animated: true)
                            //                            }
                            //                            else
                            //                            {
                            self.expandableListTableView.scrollToRow( at: indexPathTemp, at: .middle , animated: true)
                            //                            }
                        }
                    })
                    
                    
                }
                else
                {
                    lastExpandedTab = nil
                    lastExpandedIndexPath = nil
                    
                    item.isExpanded = false
                    
                    //items.remove(at: indexPath.row + 1)
                    
                    while(true)
                    {
                        let index = indexPath.section + 1
                        if(index < items.count)
                        {
                            let item2 = items[indexPath.section + 1]
                            if(item2.type == ExpandableListItemType.Parent.rawValue)
                            {
                                break
                            }
                            
                            items.remove(at: indexPath.section + 1)
                        }
                        else
                        {
                            break
                        }
                    }
                    
                    expandableListTableView.reloadData()
                    
                    /*if (storesLocatorTableView.cellForRow(at: IndexPath(row: 0, section: indexPath.section)) == nil) {
                     DispatchQueue.main.async(execute: {
                     self.storesLocatorTableView.scrollToRow( at: IndexPath(row: 0, section: indexPath.section), at: .middle, animated: true)
                     })
                     }*/
                    
                    DispatchQueue.main.async(execute: {
                        //self.expandableListTableView.scrollToRow( at: indexPath, at: .middle , animated: true)
                    })
                }
            }
            else
            {
                switch parent.type
                {
                case ExpandableListItemType.BarcodeScan.rawValue:
                    if AVCaptureDevice.authorizationStatus(for: .video) ==  .authorized {
                        isViewPushed = true
                        let BarcodeScannerStoryBoard: UIStoryboard = UIStoryboard(name: "BarcodeScannerView" , bundle: nil)
                        let barcodeScannernViewController = BarcodeScannerStoryBoard.instantiateInitialViewController() as! BarcodeScannerViewController
                        barcodeScannernViewController.isEmbeded = true
                        self.navigationController?.pushViewController(barcodeScannernViewController, animated: true)
                    } else {
                        AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                            if granted {
                                DispatchQueue.main.async(execute: {() -> Void in
                                    isViewPushed = true
                                    let BarcodeScannerStoryBoard: UIStoryboard = UIStoryboard(name: "BarcodeScannerView" , bundle: nil)
                                    let barcodeScannernViewController = BarcodeScannerStoryBoard.instantiateInitialViewController() as! BarcodeScannerViewController
                                    barcodeScannernViewController.isEmbeded = true
                                    self.navigationController?.pushViewController(barcodeScannernViewController, animated: true)
                                })
                            } else {
                                let alertController = UIAlertController(title: "Camera permission", message: "You need to enabled camera permission from settings in order to access this feature.", preferredStyle: .alert)
                                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
                                self.present(alertController, animated: true, completion: nil)
                                return
                            }
                        })
                    }
                case ExpandableListItemType.Search.rawValue:
                    isViewPushed = true
                    let SearchStoryBoard : UIStoryboard = UIStoryboard(name: "SearchView", bundle: nil)
                    let searchView =  SearchStoryBoard.instantiateInitialViewController() as! SearchViewController
                    searchView.isEmbeded = true
                    self.navigationController?.pushViewController(searchView, animated: true)
                default :
                    break
                }
            }
        case ExpandableListItemType.Store.rawValue:
            isViewPushed = true
            let StoreInfoStoryBoard : UIStoryboard = UIStoryboard(name: "StoreInformationView", bundle: nil)
            let storeInfoView =  StoreInfoStoryBoard.instantiateInitialViewController() as! StoreInformationViewController
            storeInfoView.store = items[indexPath.section].storeModel
            storeInfoView.storeInfoParameters = storeLocatorInfoParameters
            storeInfoView.holidays = nearHolidays
            self.navigationController?.pushViewController(storeInfoView, animated: true)
        case ExpandableListItemType.Search.rawValue:
            isViewPushed = true
            let SearchStoryBoard : UIStoryboard = UIStoryboard(name: "SearchView", bundle: nil)
            let searchView =  SearchStoryBoard.instantiateInitialViewController() as! SearchViewController
            searchView.isEmbeded = true
            self.navigationController?.pushViewController(searchView, animated: true)
        case ExpandableListItemType.Category.rawValue , ExpandableListItemType.Brand.rawValue:
            let category : CategoryModel! = item.categoryModel
            var childsCount = 0
            
            if(!item.isExpanded)
            {
                if(category.childCategories != nil && category.childCategories.count > 0)
                {
                    let childs = category.childCategories
                    
                    var i = 1
                    
                    if(childs != nil)
                    {
                        childsCount = (childs?.count)!
                        
                        for c in childs!
                        {
                            let child = ExpandableListItemModel()
                            child.type = ExpandableListItemType.Category.rawValue
                            
                            child.categoryModel = c
                            child.isExpanded = false
                            
                            items.insert(child, at: indexPath.section + i)
                            i += 1
                        }
                        
                    }
                }
                else if (category.products != nil && category.products.count > 0)
                {
                    let childs = category.products
                    
                    var i = 1
                    
                    if(childs != nil)
                    {
                        childsCount = (childs?.count)!
                        
                        for c in childs!
                        {
                            let child = ExpandableListItemModel()
                            child.type = ExpandableListItemType.Product.rawValue
                            
                            child.productModel = c
                            
                            items.insert(child, at: indexPath.section + i)
                            i += 1
                        }
                    }
                }
                else
                {
                    return
                }
                
                item.isExpanded = true
                lastExpandedTab = item
                lastExpandedIndexPath = indexPath
            
                scrollToIndexPath = IndexPath(row: 0 , section: lastExpandedIndexPath.section-1)
            
                expandableListTableView.reloadData()
                
                
                /*DispatchQueue.main.async(execute: {
                 let indexPathTemp = IndexPath(row: 0, section: indexPath.section + 1)
                 self.expandableListTableView.scrollToRow( at: indexPathTemp, at: .middle , animated: false)
                 })*/
                
                /*if(childsCount > 10)
                 {
                 DispatchQueue.main.async(execute: {
                 let indexPathTemp = IndexPath(row: 0, section: indexPath.section + 1)
                 self.expandableListTableView.scrollToRow( at: indexPathTemp, at: .middle , animated: true)
                 })
                 }*/
                
                DispatchQueue.main.async(execute: {
                    let indexPathTemp = IndexPath(row: 0, section: indexPath.section + 1)
                    
                    let cellRect = self.expandableListTableView.rectForRow(at: indexPathTemp)
                    let completelyVisible = self.expandableListTableView.bounds.contains(cellRect)
                    if (!completelyVisible) {
                        self.expandableListTableView.scrollToRow( at: indexPathTemp, at: .middle , animated: true)
                    }
                })
            }
            else
            {
                lastExpandedTab = nil
                lastExpandedIndexPath = nil
                item.isExpanded = false
                
                if(category.childCategories != nil && category.childCategories.count > 0)
                {
                    let childs = category.childCategories
                    
                    if(childs != nil)
                    {
                        /*for c in childs!
                         {
                         if(items[indexPath.section + 1].isExpanded)
                         {
                         var childs2 = items[indexPath.section + 1].categoryModel.childCategories
                         
                         while(childs2 != nil)
                         {
                         for c in childs2!
                         {
                         items.remove(at: indexPath.section + 2)
                         }
                         
                         }
                         }
                         items.remove(at: indexPath.section + 1)
                         }*/
                        while(true)
                        {
                            let index = indexPath.section + 1
                            if(index < items.count)
                            {
                                let item2 = items[indexPath.section + 1]
                                if((item2.type == ExpandableListItemType.Category.rawValue && item2.categoryModel2.level <= item.categoryModel2.level) || item2.type == ExpandableListItemType.Parent.rawValue)
                                {
                                    break
                                }
                                
                                items.remove(at: indexPath.section + 1)
                            }
                            else
                            {
                                break
                            }
                        }
                    }
                }
                else
                {
                    let childs = category.products
                    
                    if(childs != nil)
                    {
                        for _ in childs!
                        {
                            items.remove(at: indexPath.section + 1)
                        }
                    }
                    
                    
                }
                
                expandableListTableView.reloadData()
                
                /*if (storesLocatorTableView.cellForRow(at: IndexPath(row: 0, section: indexPath.section)) == nil) {
                 DispatchQueue.main.async(execute: {
                 self.storesLocatorTableView.scrollToRow( at: IndexPath(row: 0, section: indexPath.section), at: .middle, animated: true)
                 })
                 }*/
                
                DispatchQueue.main.async(execute: {
                    //self.expandableListTableView.scrollToRow( at: indexPath, at: .middle , animated: false)
                })
                
                if(indexPath.section == items.count - 1)
                {
                    DispatchQueue.main.async(execute: {
                        self.expandableListTableView.scrollToRow( at: indexPath, at: .middle , animated: true)
                    })
                }
                
            }
        case ExpandableListItemType.Category2.rawValue:
            let category : ProductMenuModel! = item.categoryModel2
            var childsCount = 0
            
            if(!item.isExpanded)
            {
                if (category.products != nil && category.products.count > 0)
                {
                    let childs = category.products
                    lastExpandedCount = childs?.count
                    var i = 1
                    
                    if(childs != nil)
                    {
                        childsCount = (childs?.count)!
                        
                        for c in childs!
                        {
                            let child = ExpandableListItemModel()
                            child.type = ExpandableListItemType.Product.rawValue
                            
                            child.productModel = c
                            child.productModel.category2 = category
                            
                            items.insert(child, at: indexPath.section + i)
                            i += 1
                        }
                    }
                }
                else if (category.childCategories != nil && category.childCategories.count > 0)
                {
                    let childs = category.childCategories
                    
                    var i = 1
                    
                    if(childs != nil)
                    {
                        childsCount = (childs?.count)!
                        
                        for c in childs!
                        {
                            let child = ExpandableListItemModel()
                            child.type = ExpandableListItemType.Category2.rawValue
                            
                            child.categoryModel2 = c
                            
                            items.insert(child, at: indexPath.section + i)
                            i += 1
                        }
                    }
                }
                else
                {
                    return
                }
                
                lastExpandedTab = item
                lastExpandedIndexPath = indexPath
                scrollToIndexPath = IndexPath(row: 0 , section: lastExpandedIndexPath.section-1)
                item.isExpanded = true
                category.isExpanded = true
                
                expandableListTableView.reloadData()
                
                DispatchQueue.main.async(execute: {
                    let indexPathTemp = IndexPath(row: 0, section: indexPath.section + 1)
                    
                    let cellRect = self.expandableListTableView.rectForRow(at: indexPathTemp)
                    let completelyVisible = self.expandableListTableView.bounds.contains(cellRect)
                    if (!completelyVisible) {
                        self.expandableListTableView.scrollToRow( at: indexPathTemp, at: .middle , animated: true)
                    }
                })
                
                /*
                 DispatchQueue.main.async(execute: {
                 let indexPathTemp = IndexPath(row: 0, section: indexPath.section + 1)
                 self.expandableListTableView.scrollToRow( at: indexPathTemp, at: .middle , animated: false)
                 })*/
                
            }
            else
            {
                lastExpandedTab = nil
                lastExpandedIndexPath = nil
                item.isExpanded = false
                category.isExpanded = false
               
                if(category.products != nil && category.products.count > 0)
                {
                    let childs = category.products
                    
                    if(childs != nil)
                    {
                        var c = 0
                        
                       Loop: for _ in childs!
                        {
                            
                            if(c<lastExpandedCount && lastExpandedCount != nil){
                            items.remove(at: indexPath.section + 1)
                                c+=1
                            }
                            else{
                               break Loop
                            }
                        }
                    }
                }
                else if (category.childCategories != nil && category.childCategories.count > 0)
                {
                    
                    while(true)
                    {
                        let index = indexPath.section + 1
                        if(index < items.count)
                        {
                            let item2 = items[indexPath.section + 1]
                            if((item2.type == ExpandableListItemType.Category2.rawValue && item2.categoryModel2.level <= item.categoryModel2.level) || (item2.parentModel != nil))
                            {
                                break
                            }
                            
                            items.remove(at: indexPath.section + 1)
                            
                        }
                        else
                        {
                            break
                        }
                    }
                    
                    //var childs = category.childCategories
                    
                    
                    
                    //removeCategories(categories: category.childCategories,index: indexPath.section + 1)
                    /*if(childs != nil)
                     {
                     for c in childs!
                     {
                     var childs2 = c.childCategories
                     while(childs2 != nil)
                     {
                     for c in childs2!
                     {
                     
                     items.remove(at: indexPath.section + 1)
                     }
                     
                     }
                     }
                     }*/
                }
                
                expandableListTableView.reloadData()
                
                /*DispatchQueue.main.async(execute: {
                 self.expandableListTableView.scrollToRow( at: indexPath, at: .middle , animated: false)
                 })*/
                
                if(indexPath.section == items.count - 1)
                {
                    DispatchQueue.main.async(execute: {
                        self.expandableListTableView.scrollToRow( at: indexPath, at: .middle , animated: true)
                    })
                }
            }
        case ExpandableListItemType.Product.rawValue:
            if(!isProductSelected)
            {
                isProductSelected = true
                var product = item.productModel
                //removeSpecialcharacters(product : &product!)
                let productView = showProductView(productModel:product, viewController : self)
                self.navigationController?.pushViewController(productView, animated: true)
            }
        default:
            break
        }
    }
    
    func removeCategories(categories : [ProductMenuModel]!, index : Int)
    {
        if(categories != nil && categories.count > 0)
        {
            for c in categories!
            {
                items.remove(at: index)
                if(c.isExpanded)
                {
                    if(c.products != nil && c.products.count > 0)
                    {
                        for _ in c.products!
                        {
                            items.remove(at: index)
                        }
                    }
                    
                    if(c.childCategories != nil && c.childCategories.count > 0)
                    {
                        removeCategories(categories: c.childCategories, index: index)
                    }
                }
            }
        }
        
    }
    
    private var cellHeights: [IndexPath: CGFloat?] = [:]
    var expandedIndexPaths: [IndexPath] = []
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cellHeights[indexPath] = cell.frame.height
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        if let height = cellHeights[indexPath] {
            return height ?? UITableViewAutomaticDimension
        }
        return UITableViewAutomaticDimension
    }
    
    
    func expandCell(cell: UITableViewCell) {
        if let indexPath = expandableListTableView.indexPath(for: cell) {
            if !expandedIndexPaths.contains(indexPath) {
                expandedIndexPaths.append(indexPath)
                cellHeights[indexPath] = nil
                expandableListTableView.reloadRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
                //tableView.scrollToRow(at: indexPath, at: .top, animated: true)
            }
        }
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {

        if (lastExpandedTab != nil){
            let currentIndexPath = getIndexPath()
            if ((currentIndexPath?.compare(lastExpandedIndexPath))!.rawValue == ComparisonResult.orderedDescending.rawValue){
                if !((self.expandableListTableView.indexPathsForVisibleRows?.contains(lastExpandedIndexPath))!) {
                    scrollUp.isHidden = false
                }
                else{
                    scrollUp.isHidden = true
                }
            }
            else{
                scrollUp.isHidden = true
            }
        }
    }
    @objc func tapDetected() {
        if (lastExpandedTab != nil){
            self.expandableListTableView.scrollToRow(at: scrollToIndexPath as IndexPath, at: .top, animated: true)
        }
    }
    
    func getIndexPath() -> IndexPath? {
        let cell2 = self.expandableListTableView.indexPathsForVisibleRows
        var cindexPath : IndexPath!
        for c in cell2!{
            cindexPath = c
        }
        
        return cindexPath
    }
    
}
