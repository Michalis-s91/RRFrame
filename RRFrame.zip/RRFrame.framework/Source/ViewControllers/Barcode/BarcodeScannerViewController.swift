//
//  BarcodeScannerViewController4.swift
//  RichReach2
//
//  Created by Eumbrella on 18/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation

class BarcodeScannerViewController: ViewController , AVCaptureMetadataOutputObjectsDelegate
{
    
    /*var captureSession = AVCaptureSession()
    var previewLayer = AVCaptureVideoPreviewLayer()
    var sessionOutput = AVCaptureStillImageOutput()
    
    override func viewWillAppear(_ animated: Bool) {
        
        let devices = AVCaptureDevice.devices(for: .video)
        for device in devices
        {
            do
            {
                let input = try AVCaptureDeviceInput(device: device as! AVCaptureDevice)
                
                if captureSession.canAddInput(input)
                {
                    captureSession.addInput(input)
                    sessionOutput.outputSettings = [AVVideoCodecKey : AVVideoCodecJPEG]
                    
                    if(captureSession.canAddOutput(sessionOutput))
                    {
                        captureSession.addOutput(sessionOutput)
                        
                        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
                        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
                        previewLayer.connection?.videoOrientation = AVCaptureVideoOrientation.portrait
                        cameraUIView.layer.addSublayer(previewLayer)
                    }
                }
            }
            catch
            {
                
            }
        }
    }*/
    
    @IBOutlet var label: UILabel!
    @IBOutlet var previewView: UIView!
    @IBOutlet var titleTopPaddingView: NSLayoutConstraint!
    @IBOutlet var titleLine: UIView!
    
   
    //var previewView : UIView!
    var boxView:UIView!
    var lineView : UIView = UIView()
    var scanLineView : UIView = UIView()
    
    //Camera Capture requiered properties
    var videoDataOutput: AVCaptureVideoDataOutput!
    var videoDataOutputQueue: DispatchQueue!
    var previewLayer:AVCaptureVideoPreviewLayer!
    var captureDevice : AVCaptureDevice!
    
    let session = AVCaptureSession()
    let sessionQueue = DispatchQueue(label: AVCaptureSession.self.description(), attributes: [], target: nil)
    var timer = Timer()
    var duration = 0
    var productScanned = false
    var isEmbeded = false
    
    override func viewDidLoad() {
        if(!isEmbeded)
        {
            super.viewDidLoad()
        }
        
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
        label.font = font
        label.textColor = Colors.titleTextColor
        label.backgroundColor = Colors.titleBackround
        titleTopPaddingView.constant = titleTopPadding
        
        titleLine.backgroundColor = Colors.titleSplitterColor
        
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(0.8), target: self,   selector: (#selector(BarcodeScannerViewController.updateTimer)), userInfo: nil, repeats: true)
        
        //previewView.contentMode = UIViewContentMode.scaleToFill
        
        //previewView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        //previewView.frame.size.height = UIScreen.main.bounds.size.height
        //view.addSubview(previewView)
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        isViewPushed = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        productScanned = false
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.setupAVCapture()
        super.viewDidAppear(animated)
        sessionQueue.async {
            //self.cameraView.bringSubview(toFront: self.lineImage)
            self.session.startRunning()
            
            DispatchQueue.main.async(execute: {() -> Void in
                //informationTableView.frame = CGRect(x: informationTableView.frame.origin.x, y: informationTableView.frame.origin.y + 15.0, width: informationTableView.frame.size.width, height: informationTableView.frame.size.height - 15.0)
                
                self.lineView.frame.size.height =  230
                self.lineView.frame.size.width = 230
                self.lineView.layer.borderWidth = 1.5
                self.lineView.layer.borderColor = UIColor.red.cgColor
                print(self.previewView.frame.origin.y)
                self.lineView.center = CGPoint(x: UIScreen.main.bounds.size.width/2, y: self.previewView.frame.size.height/2 + self.previewView.frame.origin.y )
                self.lineView.backgroundColor = UIColor.clear
                
                self.scanLineView.frame.size.height = 0.5
                self.scanLineView.frame.size.width = 230
                self.scanLineView.backgroundColor = UIColor.red
                //self.lineView.layer.borderWidth = 1
                //self.lineView.layer.borderColor = UIColor.red.cgColor
                //print(self.previewView.frame.origin.y)
                self.scanLineView.center = self.lineView.center
                //self.lineView.backgroundColor = UIColor.clear
                
                self.view.addSubview(self.lineView)
                self.view.addSubview(self.scanLineView)
            })
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    /*override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        // Update camera orientation
        let videoOrientation: AVCaptureVideoOrientation
        switch UIDevice.current.orientation {
        case .portrait:
            videoOrientation = .portrait
            
        case .portraitUpsideDown:
            videoOrientation = .portraitUpsideDown
            
        case .landscapeLeft:
            videoOrientation = .landscapeRight
            
        case .landscapeRight:
            videoOrientation = .landscapeLeft
            
        default:
            videoOrientation = .portrait
        }
        
        previewLayer.connection?.videoOrientation = .landscapeLeft
    }*/
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if (metadataObjects.count > 0 && metadataObjects.first is AVMetadataMachineReadableCodeObject) {
            if(!productScanned)
            {
                productScanned = true
                let scan = metadataObjects.first as! AVMetadataMachineReadableCodeObject
                
                var product  = productsDB.getProduct(barcode: scan.stringValue!)
                
                if(product != nil)
                {
                    //removeSpecialcharacters(product : &product!)
                    let productView = showProductView(productModel: product, viewController : self)
                    self.navigationController?.pushViewController(productView, animated: true)
                }
                else
                {
                    let alertController = UIAlertController(title: "Scan Result", message: "No information is available for this product.", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
                    present(alertController, animated: true, completion: nil)
                    productScanned = false
                }
            }

        }
    }
    
    @objc func updateTimer(){
        if(duration % 2 == 0)
        {
            UIView.animate(withDuration: 0.8, delay: 0, options: UIViewAnimationOptions.allowUserInteraction, animations: { () -> Void in
                self.scanLineView.backgroundColor = UIColor.clear
            }) {(Bool) -> Void in
            }
        }
        else
        {
            UIView.animate(withDuration: 0.8, delay: 0, options: UIViewAnimationOptions.allowUserInteraction, animations: { () -> Void in
                self.scanLineView.backgroundColor = UIColor.red
            }) {(Bool) -> Void in
            }
            
        }
        
        duration += 1
    }
    
}


// AVCaptureVideoDataOutputSampleBufferDelegate protocol and related methods
extension BarcodeScannerViewController:  AVCaptureVideoDataOutputSampleBufferDelegate{
    func setupAVCapture(){
        session.sessionPreset = AVCaptureSession.Preset.vga640x480
        /*if #available(iOS 10.0, *) {
            guard let device = AVCaptureDevice
                .default(AVCaptureDevice.DeviceType.builtInWideAngleCamera,
                         for: .video,
                         position: AVCaptureDevice.Position.back) else {
                            return
            }
        } else {
            // Fallback on earlier versions
        }*/
        
        session.beginConfiguration()
        captureDevice = AVCaptureDevice.default(for: .video)
        beginSession()
    }
    
    func beginSession(){
        var deviceInput: AVCaptureDeviceInput!
        
        do {
            deviceInput = try? AVCaptureDeviceInput(device: captureDevice)
            guard deviceInput != nil else {
                print("error: cant get deviceInput")
                return
            }
            
            if self.session.canAddInput(deviceInput){
                self.session.addInput(deviceInput)
            }
            
            videoDataOutput = AVCaptureVideoDataOutput()
            videoDataOutput.alwaysDiscardsLateVideoFrames=true
            videoDataOutputQueue = DispatchQueue(label: "VideoDataOutputQueue")
            videoDataOutput.setSampleBufferDelegate(self, queue:self.videoDataOutputQueue)
            
            if session.canAddOutput(self.videoDataOutput){
                session.addOutput(self.videoDataOutput)
            }
            
            videoDataOutput.connection(with: .video)?.isEnabled = true
            
            previewLayer = AVCaptureVideoPreviewLayer(session: self.session)
            previewLayer.videoGravity = AVLayerVideoGravity.resizeAspect
            
            let rootLayer : CALayer = self.previewView.layer
            rootLayer.masksToBounds = true
            rootLayer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: previewView.frame.size.height)
            previewLayer.frame = rootLayer.bounds
            //previewLayer.frame = CGRect(x: 0, y: 0, width: self.previewView.frame.size.width, height: self.previewView.frame.size.height)
            rootLayer.addSublayer(self.previewLayer)
            
            
            if (captureDevice != nil) {
                if (deviceInput != nil) {
                    if (session.canAddInput(deviceInput!)) {
                        session.addInput(deviceInput!)
                    }
                }
                
                let metadataOutput = AVCaptureMetadataOutput()
                
                if (session.canAddOutput(metadataOutput)) {
                    session.addOutput(metadataOutput)
                    
                    metadataOutput.metadataObjectTypes = [
                        .ean13,
                        .ean8,
                        .code39,
                        .code128,
                        .code93,
                        .qr
                    ]
                    
                    metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                }
            }
            
            session.commitConfiguration()
            
            //previewView.layer.session = session
            //previewView.layer.videoGravity = .resizeAspectFill
            
        }
        catch let error as NSError
        {
            deviceInput = nil
            print("error: \(error.localizedDescription)")
        }
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // do stuff here
    }
    
    // clean up AVCapture
    func stopCamera(){
        session.stopRunning()
    }
    
}

class CameraView: UIView {
    override class var layerClass: AnyClass {
        get {
            return AVCaptureVideoPreviewLayer.self
        }
    }
    
    override var layer: AVCaptureVideoPreviewLayer {
        get {
            return super.layer as! AVCaptureVideoPreviewLayer
        }
    }
}

