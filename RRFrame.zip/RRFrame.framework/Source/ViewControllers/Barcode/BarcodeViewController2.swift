//
//  BarcodeViewController2.swift
//  RichReach2
//
//  Created by Eumbrella on 10/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation
import RSBarcodes

class BarcodeViewController2: ViewController {
    
    var viewModel : BarcodeViewModel!
    
    @IBOutlet weak var barcodeImageView: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var pointsLabel: LabelWithPadding!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var backgroundImage: UIImageView!
    @IBOutlet var descriptionLabel: UILabel!
    
    @IBOutlet var descriptionTop: NSLayoutConstraint!
    
    @IBOutlet var titleHeight: NSLayoutConstraint!
    @IBOutlet var barcodeImageTop: NSLayoutConstraint!
    
    @IBOutlet var viewTop: NSLayoutConstraint!
    @IBOutlet var titleTop: NSLayoutConstraint!
    @IBOutlet var viewLeading: NSLayoutConstraint!
    @IBOutlet var viewTrailing: NSLayoutConstraint!
    @IBOutlet var viewBottom: NSLayoutConstraint!
    @IBOutlet var pointsSplitter: UIView!
    
    var arePointsShowing = true
    var pointsBalance : PointsBalanceModel!
    var barcodeView : BarcodeModel2!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        if (viewModel == nil) {
            viewModel = BarcodeViewModel()
        }
        
        let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
        
        var titleHeightSize : CGFloat = 40
        
        if(font != nil)
        {
            titleHeightSize = selectedTab.name.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 20
        }
        
        if(selectedTab.hasBackgroundImage)
        {
            let data = parameterizationDatabase.getBackgroundImage(apk: APK)
            
            if(data != nil)
            {
                backgroundImage.image = UIImage(data: data!)
            }
        }
        
        titleHeight.constant = titleHeightSize
        
        descriptionTop.constant = titleHeightSize + titleTopPadding + 15
        
        /*if(titleHeightSize > 40)
        {
            barcodeImageTop.constant = barcodeImageTop.constant + titleHeightSize - 40
        }*/
        
        let task = WebApiTask(viewController : self, action : syncPoints, displayToast : false)
        task.start()
        
        titleLabel.text = selectedTab.name
        titleLabel.backgroundColor = Colors.titleBackround
        titleLabel.textColor = Colors.titleTextColor
        titleLabel.font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
        
        pointsLabel.layer.cornerRadius = pointsLabel.frame.size.width/2
        pointsLabel.clipsToBounds = true
        
        pointsLabel.layer.borderColor = UIColor.clear.cgColor
        pointsLabel.layer.borderWidth = 5.0
        
        //let onPointsClick = UITapGestureRecognizer(target: self, action: #selector(BarcodeViewController2.onPointsClick))
        //pointsLabel.isUserInteractionEnabled = true
        //pointsLabel.addGestureRecognizer(onPointsClick)
        
        pointsBalance = loyaltyDB.getPointsBalance()
        
        titleTop.constant = titleTopPadding
        
        if(selectedTab.borderSize != nil && selectedTab.borderSize > 0)
        {
            viewTop.constant = CGFloat(selectedTab.borderSize)
            viewBottom.constant = CGFloat(selectedTab.borderSize)
            viewLeading.constant = CGFloat(selectedTab.borderSize)
            viewTrailing.constant = CGFloat(selectedTab.borderSize)
            
            self.view.backgroundColor  = UIColor(selectedTab.borderColor)
        }
        
        let appUser = localDatabase.getAppUser()
        if(appUser?.name != nil)
        {
            nameLabel.text = (localDatabase.getAppUser()?.name)!
            
            if(appUser?.surname != nil)
            {
                nameLabel.text = nameLabel.text! + "\n" + (localDatabase.getAppUser()?.surname)!
            }
        }
        
        barcodeView = viewModel.barcodeView
        
        setPointsLabelText()
        
        pointsLabel.backgroundColor = UIColor( barcodeView.backgroundColor)
        pointsLabel.textColor = UIColor( barcodeView.pointsTextColor)
        pointsLabel.font = UIFont(name: barcodeView.pointsFont, size: CGFloat((barcodeView?.pointsTextSize)!))
        
        nameLabel.textColor = UIColor( barcodeView.infoTextColor)
        nameLabel.font = UIFont(name: barcodeView.infoFont, size: CGFloat((barcodeView?.infoTextSize)!))
        
        descriptionLabel.backgroundColor = .clear
        descriptionLabel.text = "To get points, scan the barcode below at the till when making a purchase."
        descriptionLabel.textColor = UIColor( barcodeView.infoTextColor)
        descriptionLabel.font = UIFont(name: "CharpentierSansPro-Normal" , size: CGFloat((barcodeView?.infoTextSize)!))
        
        createBarcodeImage()
    }
    
    var viewIsDisplayed = false
    
    override func viewDidLayoutSubviews() {
        if(viewIsDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewIsDisplayed = true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    
    /*@IBAction func onPointsClick(_ sender: UIButton) {
        if(arePointsShowing)
        {
            if(pointsBalance != nil)
            {
                pointsLabel.text = "\(String(format: "%.2f", pointsBalance.amount) ?? "")\nEuro"
            }
            else
            {
                pointsLabel.text = "0\nEuro"
            }
            
            arePointsShowing = false
        }
        else
        {
            if(pointsBalance != nil)
            {
                pointsLabel.text = "\(String(format: "%.0f", pointsBalance.points))\nPoints"
            }
            else
            {
                pointsLabel.text = "0\nPoints"
            }
            
            arePointsShowing = true
        }
    }*/
    
    @IBAction func displayHelp(_ sender: UIBarButtonItem) {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()! as! MessageDialog
        self.present(dialog,animated:true)
        dialog.setDialogView(title: NSLocalizedString("barcodeHelpDialogTitle", comment: ""), description: NSLocalizedString("barcodeHelpDialogMessage", comment: ""), buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
    }
    
    
    @IBAction func syncClick(_ sender: UIBarButtonItem) {
        let task = WebApiTask(viewController : self, action : syncPoints, displayToast : true)
        task.successMessage = NSLocalizedString("synchronizationCompleted", comment: "")
        task.errorMessage = NSLocalizedString("somethingWentWrong", comment: "")
        task.start()
    }
    
    func syncPoints()
    {
        let pointsBalance = UserProfileWebApi.getUserPointsBalance(clientID: clientID, phoneNumber: localDatabase.getAppUser()?.phoneNumber)
        
        if(pointsBalance != nil)
        {
            loyaltyDB.insertPoitsBalance(pointsBalance: pointsBalance)
            self.pointsBalance = pointsBalance
            setPointsLabelText()
            
            /*DispatchQueue.main.async(execute: {() -> Void in
                if(self.arePointsShowing)
                {
                    self.pointsLabel.text = "\(String(format: "%.0f", self.pointsBalance.points))\nPoints"
                }
                else
                {
                    self.pointsLabel.text = "\(String(format: "%.2f", self.pointsBalance.amount) ?? "")\nEuro"
                }
            })*/
        }
    }
    
    func setPointsLabelText()
    {
        
        DispatchQueue.main.async(execute: {() -> Void in
            if(self.pointsBalance != nil )
            {
                if(self.barcodeView != nil)
                {
                    self.pointsSplitter.backgroundColor = UIColor.clear
                    switch self.barcodeView.pointsType
                    {
                    case PointsType.PointsOnly.rawValue:
                        self.pointsLabel.text = "\(String(format: "%.0f", self.pointsBalance.points))\nPoints"
                    case PointsType.AmountOnly.rawValue:
                        self.pointsLabel.text = "\(String(format: "%.2f", self.pointsBalance.amount) ?? "")\nEuro"
                    case PointsType.PointsAndAmount.rawValue:
                        self.pointsSplitter.backgroundColor = UIColor(self.barcodeView.pointsTextColor)
                        var euroSymbol = "€"
                        self.pointsLabel.text = "\(String(format: "%.0f", self.pointsBalance.points)) Points\n\n\(euroSymbol)\(String(format: "%.2f", self.pointsBalance.amount) ?? "")"
                    default :
                        self.pointsSplitter.backgroundColor = UIColor(self.barcodeView.pointsTextColor)
                        var euroSymbol = "€"
                        self.pointsLabel.text = "\(String(format: "%.0f", self.pointsBalance.points)) Points\n\n\(euroSymbol)\(String(format: "%.2f", self.pointsBalance.amount) ?? "")"
                    }
                }
                else
                {
                    self.pointsSplitter.backgroundColor = UIColor.clear
                    self.pointsLabel.text = "\(String(format: "%.0f", self.pointsBalance.points))\nPoints"
                }
            }
            else
            {
                self.pointsSplitter.backgroundColor = UIColor.clear
                self.pointsLabel.text = "0\nPoints"
            }
        })
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    
    /// Create barcode image.
    func createBarcodeImage(){
        //let height = UIScreen.main.bounds.size.height * 0.2
        //let width = UIScreen.main.bounds.size.width * 0.6
        
        let barcodeHelper = BarcodeHelper()
        //barcodeImageView.translatesAutoresizingMaskIntoConstraints = true
        //barcodeImageView.frame = CGRect(x:(UIScreen.main.bounds.size.width - width)/2, y: 0, width: width, height: height ) //CGSize(width: width, height: height)// = CGRect(x:(UIScreen.main.bounds.size.width - width)/2, y: 0, width: width, height: height )
        
        let appUser = localDatabase.getAppUser()
        if(appUser != nil && appUser?.phoneNumber != nil)
        {
            barcodeImageView.image =   barcodeHelper.getImageFromString(barcodeID: (appUser?.phoneNumber)!, type : AVMetadataObject.ObjectType.code128.rawValue)
        }
        
        //barcodeLabel.translatesAutoresizingMaskIntoConstraints = true
        //barcodeLabel.frame = CGRect(x:0, y: barcodeImageView.frame.height + 8, width: UIScreen.main.bounds.size.width, height: barcodeLabel.frame.height)
        
        
        
        //barcodeView.translatesAutoresizingMaskIntoConstraints = true
        //barcodeView.frame = CGRect(x:0, y: self.view.frame.height/2 - barcodeImageView.frame.height , width: barcodeView.frame.width, height: barcodeView.frame.height )
        
    }
}
