//
//  BarcodeViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 14/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation
import RSBarcodes

/// Create view which user can see his unique barcode.
class BarcodeViewController: ViewController {

    var viewModel : BarcodeViewModel!

    @IBOutlet weak var barcodeImageView: UIImageView!
    @IBOutlet weak var barcodeLabel: UILabel!
    @IBOutlet var barcodeView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        if (viewModel == nil) {
            viewModel = BarcodeViewModel()
        }
        
        barcodeLabel.text = viewModel.barcodeID
        createBarcodeImage()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func displayHelp(_ sender: UIBarButtonItem) {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()! as! MessageDialog
        self.present(dialog,animated:true)
        dialog.setDialogView(title: NSLocalizedString("barcodeHelpDialogTitle", comment: ""), description: NSLocalizedString("barcodeHelpDialogMessage", comment: ""), buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    
    /// Create barcode image.
    func createBarcodeImage(){
        let height = UIScreen.main.bounds.size.height * 0.2
        let width = UIScreen.main.bounds.size.width * 0.6

        let barcodeHelper = BarcodeHelper()
        barcodeImageView.translatesAutoresizingMaskIntoConstraints = true
        barcodeImageView.frame = CGRect(x:(UIScreen.main.bounds.size.width - width)/2, y: 0, width: width, height: height ) //CGSize(width: width, height: height)// = CGRect(x:(UIScreen.main.bounds.size.width - width)/2, y: 0, width: width, height: height )
        barcodeImageView.image =   barcodeHelper.getImageFromString(barcodeID: self.viewModel.barcodeID , type : AVMetadataObject.ObjectType.code93.rawValue)
        
        barcodeLabel.translatesAutoresizingMaskIntoConstraints = true
        barcodeLabel.frame = CGRect(x:0, y: barcodeImageView.frame.height + 8, width: UIScreen.main.bounds.size.width, height: barcodeLabel.frame.height)
        //CGSize(width: UIScreen.main.bounds.size.width, height: barcodeLabel.frame.height)
        // CGRect(x:0, y: barcodeImageView.frame.height + 8, width: UIScreen.main.bounds.size.width, height: barcodeLabel.frame.height)
        
        barcodeView.translatesAutoresizingMaskIntoConstraints = true
        barcodeView.frame = CGRect(x:0, y: self.view.frame.height/2 - barcodeImageView.frame.height , width: barcodeView.frame.width, height: barcodeView.frame.height )
    }
}
