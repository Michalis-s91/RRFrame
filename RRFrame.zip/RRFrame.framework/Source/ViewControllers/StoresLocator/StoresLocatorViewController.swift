//  StoresLocatorViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 22/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

// Creates view that user can see the stores for specific business.
class StoresLocatorViewController: ViewController /*, UITableViewDelegate, UITableViewDataSource*/ {
    
    @IBOutlet var storesLocatorTableView: UITableView!
    
    var viewModel : StoresLocatorViewModel!
    var items : [StoreLocatorItem] = []
    var viewIsNotDisplayed = true
    //var optionsListView : OptionsListViewController!
    
    /*override func viewDidLoad() {
        super.viewDidLoad()
        
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        //let MainStoryBoard = UIStoryboard(name: "OptionsListView", bundle: nil)
        //optionsListView = MainStoryBoard.instantiateInitialViewController() as! OptionsListViewController
        
        storesLocatorTableView.rowHeight = UITableViewAutomaticDimension
        storesLocatorTableView.tableFooterView = UIView()
        storesLocatorTableView.delegate = self
        storesLocatorTableView.dataSource = self
        
        storesLocatorTableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: -20, right: 0)
        
        viewModel = StoresLocatorViewModel()
        for var c in viewModel.cities
        {
            let item = StoreLocatorItem(cityName: c.cityName)
            item.numOfStores = c.stores.count
            items.append(item)
        }
        
        storesLocatorTableView.reloadData()
    }
    
    override func viewDidLayoutSubviews() {
        if(!viewIsNotDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        viewIsNotDisplayed = false
        super.viewDidAppear(animated)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        if(separatorColor != nil)
        {
            headerView.backgroundColor = UIColor((separatorColor)!)
        }
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        let item = items[section]
        
        switch item.type {
        case StoresLocatorItemType.City.rawValue:
            if(section == 0)
            {
                return CGFloat.leastNormalMagnitude
            }
            else
            {
                if(items[section - 1].type == StoresLocatorItemType.City.rawValue)
                {
                    return CGFloat(separatorHeight)
                }
                else
                {
                    return CGFloat.leastNormalMagnitude
                }
            }
        case StoresLocatorItemType.Store.rawValue:
            return CGFloat.leastNormalMagnitude
        default:
            return CGFloat.leastNormalMagnitude
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*let cell = tableView.dequeueReusableCell(withIdentifier: "town_cell") as! TownViewCell
         cell.selectionStyle = .none
         
         if(indexPath.row == 1)
         {
         let cell = tableView.dequeueReusableCell(withIdentifier: "header_cell") as! HeaderViewCell
         cell.selectionStyle = .none
         
         return cell
         }
         else if(indexPath.row >= 2)
         {
         let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_cell") as! StoreInfoViewCell
         cell.selectionStyle = .none
         
         return cell
         }
         
         return cell*/
        let item = items[indexPath.section]
        
        switch item.type {
        case StoresLocatorItemType.City.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "town_cell") as! TownViewCell
            cell.cityLabel.text = items[indexPath.section].cityName + " (" + String(item.numOfStores) + ")"
            
            cell.cityLabel.font = UIFont (name: viewModel.cityTextFont, size: CGFloat(viewModel.cityTextSize))
            cell.cityLabel.textColor = UIColor(viewModel.cityTextColor)
            
            if(item.isExpaned)
            {
                cell.expandImage.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                cell.expandImage.tintColor = UIColor("#2BA9DE")
            }
            else
            {
                cell.expandImage.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                cell.expandImage.tintColor = UIColor("#2BA9DE")
                item.isExpaned = false
            }
            
            cell.selectionStyle = .none
            return cell
        case StoresLocatorItemType.Store.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "store_info_cell2") as! StoreInfoViewCell2
            let store = item.storeInfo
            
            cell.infoImage.image = UIImage(named: "ic_left_drawer_about")?.withRenderingMode(.alwaysTemplate)
            cell.infoImage.tintColor = Colors.colorPrimary
            
            cell.store = store
            cell.table = storesLocatorTableView
            //cell.optionsListView = optionsListView
            cell.indexPath = indexPath
            
            cell.addressLabel.font = UIFont (name: (viewModel.addressTextFont)!, size: CGFloat((viewModel.addressTextSize)!))
            cell.addressLabel.textColor = UIColor(viewModel.addressTextColor)

            cell.navigationController = self.navigationController
            
            let date = Date()
            let calendar = Calendar(identifier: .gregorian)
            //let day = calendar.component(.weekday, from: date)
            let hour = calendar.component(.hour, from: date)
            let minutes = calendar.component(.minute, from: date)
            
            var currentTime : Double!
            let openTime : Double!
            let closeTime : Double!
            
            /*if(day == WeekDay.Sunday.rawValue)
            {
                openTime = store?.openHours[6]
                closeTime = store?.closeHours[6]
            }
            else
            {
                openTime = store?.openHours[day - 2]
                closeTime = store?.closeHours[day - 2]
            }*/
            
            
            
            if(minutes < 10)
            {
                currentTime = Double(String(hour) + ".0" + String(minutes))
            }
            else
            {
                currentTime = Double(String(hour) + "." + String(minutes))
            }
            
            cell.statusLabel.font = UIFont (name: (viewModel.addressTextFont)!, size: CGFloat((viewModel.addressTextSize)!))
            
            if(openTime < 0 || closeTime < 0)
            {
                cell.statusLabel.textColor = UIColor.red
                cell.statusLabel.text = "CLOSED"
            }
            else if((currentTime?.isLess(than: (openTime)!))! || (closeTime.isLess(than: currentTime)))
            {
                cell.statusLabel.textColor = UIColor.red
                cell.statusLabel.text = "CLOSED"
            }
            else
            {
                cell.statusLabel.textColor = UIColor("#249DD9") //UIColor.green
                cell.statusLabel.text = "OPEN"
            }
            
            cell.selectionStyle = .none
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "town_cell") as! TownViewCell
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let item = items[indexPath.section]
        
        switch item.type {
        case StoresLocatorItemType.City.rawValue:
            return (self.view.frame.height - (CGFloat(separatorHeight) * (CGFloat(viewModel.cities.count) - 1))) / CGFloat(viewModel.cities.count)
        case StoresLocatorItemType.Store.rawValue:
            return UITableViewAutomaticDimension
        default:
            return UITableViewAutomaticDimension
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = items[indexPath.section]
        var city : CityModel!
        
        switch item.type {
        case StoresLocatorItemType.City.rawValue:
            if(!item.isExpaned)
            {
                item.isExpaned = true
                
                //let header = StoreLocatorItem()
                //items.append(header)
                
                for c in viewModel.cities
                {
                    if (c.cityName == item.cityName)
                    {
                        city = c
                        var i = 1
                        for s in c.stores
                        {
                            let store = StoreLocatorItem(storeInfo : s)
                            items.insert(store, at: indexPath.section + i)
                            i += 1
                        }
                        break
                    }
                }
                
                storesLocatorTableView.reloadData()
                
                /*if (storesLocatorTableView.cellForRow(at: IndexPath(row: 0, section: indexPath.section + city.stores.count)) == nil) {
                 DispatchQueue.main.async(execute: {
                 self.storesLocatorTableView.scrollToRow( at: IndexPath(row: 0, section: indexPath.section + city.stores.count), at: .bottom , animated: true)
                 })
                 }*/
                
                DispatchQueue.main.async(execute: {
                    let indexPathTemp = IndexPath(row: 0, section: indexPath.section + city.stores.count)
                    
                    let cellRect = self.storesLocatorTableView.rectForRow(at: indexPathTemp)
                    let completelyVisible = self.storesLocatorTableView.bounds.contains(cellRect)
                    if (!completelyVisible) {
                        self.storesLocatorTableView.scrollToRow( at: indexPathTemp, at: .middle , animated: true)
                    }
                })
                
                
            }
            else
            {
                item.isExpaned = false
                
                //items.remove(at: indexPath.row + 1)
                
                for c in viewModel.cities
                {
                    if (c.cityName == item.cityName)
                    {
                        for _ in c.stores
                        {
                            items.remove(at: indexPath.section + 1)
                        }
                        break
                    }
                }
                
                storesLocatorTableView.reloadData()
                
                /*if (storesLocatorTableView.cellForRow(at: IndexPath(row: 0, section: indexPath.section)) == nil) {
                 DispatchQueue.main.async(execute: {
                 self.storesLocatorTableView.scrollToRow( at: IndexPath(row: 0, section: indexPath.section), at: .middle, animated: true)
                 })
                 }*/
                
                DispatchQueue.main.async(execute: {
                    let cellRect = self.storesLocatorTableView.rectForRow(at: indexPath)
                    let completelyVisible = self.storesLocatorTableView.bounds.contains(cellRect)
                    if (!completelyVisible) {
                        
                        self.storesLocatorTableView.scrollToRow( at: indexPath, at: .middle , animated: true)
                    }
                })
                
                if(indexPath.section == items.count - 1)
                {
                    DispatchQueue.main.async(execute: {
                        self.storesLocatorTableView.scrollToRow( at: indexPath, at: .middle , animated: true)
                    })
                }
                
            }
        case StoresLocatorItemType.Store.rawValue:
            let StoreInfoStoryBoard : UIStoryboard = UIStoryboard(name: "StoreInformationView", bundle: nil)
            let storeInfoView =  StoreInfoStoryBoard.instantiateInitialViewController() as! StoreInformationViewController
            storeInfoView.store = items[indexPath.section].storeInfo
            self.navigationController?.pushViewController(storeInfoView, animated: true)
        default:
            break
        }
    }*/
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    
}
