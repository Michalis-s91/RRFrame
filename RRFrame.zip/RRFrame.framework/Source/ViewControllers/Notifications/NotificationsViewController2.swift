//
//  NotificationsViewController2.swift
//  RichReach
//
//  Created by Eumbrella on 23/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import UIKit


/// Creates view for pushed offers.
class NotificationsViewController2: ViewController {
    
    @IBOutlet var pushedOffersContainer: UIView!
    
    var offersView : OffersView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //super.viewWillAppear(animated)
        navigation = self.navigationController
    }
    
    override func viewDidAppear(_ animated: Bool) {        
        if(leftDrawer != nil && leftDrawer.highlightedTabString != nil)
        {
            leftDrawer.selectTab(tabString: leftDrawer.highlightedTabString)
        }
        else
        {
            let MainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
            leftDrawer = MainStoryBoard.instantiateViewController(withIdentifier: "LeftDrawerViewController") as? LeftDrawerViewController
            leftDrawer.highlightedTabString = ""
            
            if #available(iOS 11.0, *) {
                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
            } else {
                leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.size.height)
            }
        }
        
        if(self.pushedOffersContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"OffersView",bundle:nil)
            offersView = storyBoard.instantiateViewController(withIdentifier: "offers_view") as? OffersView
            offersView.isPushedOffers2 = true
            //offersView.campaingID = campaingID
            pushedOffersContainer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((pushedOffersContainer?.frame.height)!))
            offersView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (pushedOffersContainer?.frame.height)!)
            offersView.willMove(toParentViewController: self)
            self.pushedOffersContainer?.addSubview((offersView.view)!)
            self.addChildViewController(offersView)
            offersView.didMove(toParentViewController: self)
            offersView.parentNavigationController = self.navigationController
            offersView.offersContainer = pushedOffersContainer
            offersView.container = pushedOffersContainer
        }
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
}
