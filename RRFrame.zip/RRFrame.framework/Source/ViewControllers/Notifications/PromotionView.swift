//
//  PromotionView.swift
//  RichReach2
//
//  Created by Eumbrella on 06/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import AVFoundation
import RSBarcodes

class PromotionView: UIViewController {

    @IBOutlet var image: UIImageView!
    @IBOutlet var barcodeImage: UIImageView!
    @IBOutlet var barcodeText: UILabel!
    @IBOutlet var barcodeTitle: UILabel!
    @IBOutlet var descriptionText: UILabel!
    @IBOutlet var termsAndCondtitionsText: UILabel!

    @IBOutlet var descriptionTitle: UILabel!
    @IBOutlet var termsAndConditionsTitle: UILabel!
    
    
    var promotionModel : PromotionModel!
    
    var countdownTimer: Timer!
    var totalTime = 300
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let barcodeHelper = BarcodeHelper()
        
        let url = URL(string: promotionModel.imageUrl)!
        image.kf.setImage(with: url)

        barcodeImage.image = barcodeHelper.getImageFromString(barcodeID: (promotionModel.barcode), type : AVMetadataObject.ObjectType.code128.rawValue)
        barcodeText.text = promotionModel.barcode
        descriptionText.text = promotionModel.extendedDescription
        termsAndCondtitionsText.text = promotionModel.termsAndConditions
        
        barcodeTitle.font = UIFont (name: "CharpentierSansPro-Gros", size: CGFloat(15))
        barcodeTitle.textColor = UIColor("#1D2D51")
        
        descriptionTitle.font = UIFont (name: "CharpentierSansPro-Gros", size: CGFloat(15))
        descriptionTitle.textColor = UIColor("#1D2D51")
        
        termsAndConditionsTitle.font = UIFont (name: "CharpentierSansPro-Gros", size: CGFloat(15))
        termsAndConditionsTitle.textColor = UIColor("#1D2D51")
        
        countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        
         NotificationCenter.default.addObserver(self, selector:#selector(viewCameActive), name: NSNotification.Name.UIApplicationWillEnterForeground, object: nil)
    }
    
    @objc func viewCameActive(){
        DispatchQueue.global(qos: .background).async {
            if(isActivityActive(viewController: self))
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.endTimer()
                })
            }
        }
        
    }

    @objc func updateTime() {
        if totalTime != 0 {
            totalTime -= 1
        } else {
            endTimer()
        }
    }
    
    func endTimer() {
        countdownTimer.invalidate()
        self.navigationController?.popViewController(animated: true)
    }
    
    func timeFormatted(_ totalSeconds: Int) -> String {
        let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        //     let hours: Int = totalSeconds / 3600
        return String(format: "%02d:%02d", minutes, seconds)
    }
}
