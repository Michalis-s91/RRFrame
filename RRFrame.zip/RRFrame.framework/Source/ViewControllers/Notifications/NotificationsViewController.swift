//
//  NotificationsViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 26/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Creates a view with container and is been used for showing the notifications view.
class NotificationsViewController: ViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var notificationsContainer: UIView!
    @IBOutlet var notificationsTable: UITableView!
    
    var viewModel : NotificationsViewModel!
    var task : WebApiTask!
    var lock = NSObject()
    var ignoreLoadingMoreData = false
    var previousNotificationsListSize = 0
    //var notAvailableView : NotAvailableViewController!
    var synchronized : Synchronized = Synchronized()
    var viewDidAppeared = false
    
    /*override func viewDidLoad() {
        super.viewDidLoad()
        print()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(self.notificationsContainer.subviews.count == 0)
        {
            let storyBoard = UIStoryboard(name:"NotificationsView",bundle:nil)
            notificationsView = storyBoard.instantiateViewController(withIdentifier: "NotificationsView") as! NotificationsView
            notificationsView.notificationsContainer = notificationsContainer
            notificationsView.container = notificationsContainer
            notificationsView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (notificationsContainer?.frame.height)!)
            notificationsView.willMove(toParentViewController: self)
            self.notificationsContainer?.addSubview((notificationsView.view)!)
            //self.addChildViewController(wishListView)
            notificationsView.didMove(toParentViewController: self)
            notificationsView.parentNavigationController = self.navigationController
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {        
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.container = notificationsContainer
        
        notificationsTable.tableFooterView = UIView()
        notificationsTable.delegate = self
        notificationsTable.dataSource = self
        
        if(viewModel == nil)
        {
            viewModel = NotificationsViewModel()
            viewModel.pageToLoad = 1
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(!viewDidAppeared)
        {
            viewModel.pageToLoad = 1
            task = WebApiTask(viewController: self, action: loadNotifications)
            task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
            task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: self.notificationsContainer)
            task.start()
            viewDidAppeared = true
        }
        
        super.viewWillAppear(animated)
        navigation = self.navigationController
    }
    
    override func viewDidAppear(_ animated: Bool) {

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 0
        }
        else
        {
            return viewModel.notificationsList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notification_cell") as! NotificationViewCell
        let notification = viewModel.notificationsList[indexPath.row]
        
        let url = URL(string: percentEncode(s: notification.partnerImageUri))
        cell.partnerImage.kf.setImage(with: url)
        
        cell.partnerNameLabel.text = notification.partnerName
        
        if(APK == APKsEnum.RichReach.rawValue)
        {
            cell.timeStampLabel.text = notification.TimeStampString + ","
            cell.messageLabel.text = notification.message
        }
        else
        {
            cell.isSeenImage.removeFromSuperview()
            cell.timeStampLabel.text = notification.TimeStampString
            cell.productsImage.removeFromSuperview()
        }
        
        if(notification.IsSeen != nil && notification.IsSeen)
        {
            cell.isSeenLabel.text = "Seen"
        }
        else
        {
            cell.isNotSeenView.removeFromSuperview()
        }
        
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let notification = viewModel.notificationsList[indexPath.row]
        hasActivityBeenCreatedFromNotificationsView = false
        
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            if(notification.isNotSeen)
            {
                numberOfGeneralNotifications -= 1
                numberOfNotifications -= 1
                UIApplication.shared.applicationIconBadgeNumber -= 1
                
                DispatchQueue.main.async(execute: {() -> Void in
                    leftDrawer.tableView.reloadData()
                    leftDrawer.selectTab(tabString: leftDrawer.highlightedTabString)
                })
            }
            
            isViewPushed = true
            let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
            let viewController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "PushedOffersView") as! PushedOffersViewController
            
            //let PushedOffersStoryBoard = UIStoryboard(name: "NotificationView2", bundle: nil)
            //let viewController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "NotificationView") as! NotificationsViewController2
            
            viewController.partnerName = notification.partnerName
            self.navigationController?.pushViewController(viewController, animated: true)
            campaingID = notification.campaignID
            
            //viewController.partnerTemp.name = notification.partnerName
        }
        else
        {
            let toast = CustomToast()
            toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height {
            synchronized.synchronize(obj: lock)
            {
                if (viewModel != nil && viewModel.notificationsList != nil)
                {
                    if (!ignoreLoadingMoreData)
                    {
                        ignoreLoadingMoreData = true
                        loadMoreNotifications()
                    }
                }
            }
        }
    }
    
    /// Load notifications from internet
    func loadNotifications()
    {
        viewModel.loadNotificationsList()
        
        if (!isActivityActive(viewController: self))
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            if(self.viewModel.notificationsList == nil || self.viewModel.notificationsList.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.notificationsContainer!, text: NSLocalizedString("noAvailableNotifications", comment: ""))
            }
            else
            {
                if(self.notAvailableView != nil)
                {
                    self.notAvailableView.view.removeFromSuperview()
                }
            }
        })
        
        previousNotificationsListSize = viewModel.notificationsList.count
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.notificationsTable.reloadData()
        })
        
        DispatchQueue.global(qos: .background).async {
            var numberOfGeneralNotificationsTemp = 0
            
            var generalNotifications : [NotificationModel]! = []
            let appUser = localDatabase.getAppUser()
            let phoneNumber = appUser?.phoneNumber
            var pageToLoad = 1
            
            var generalNotificationsTemp = NotificationsWebApi.getNotifications(userPhoneNumber: phoneNumber ?? "" , pageToLoad: pageToLoad)
            while(generalNotificationsTemp != nil && (generalNotificationsTemp?.count)! > 0)
            {
                if(generalNotificationsTemp != nil)
                {
                    for n in generalNotificationsTemp!
                    {
                        generalNotifications.append(n)
                    }
                }
                
                pageToLoad += 1
                generalNotificationsTemp = NotificationsWebApi.getNotifications(userPhoneNumber: phoneNumber ?? "" , pageToLoad: pageToLoad)
            }
            
            if(generalNotifications != nil)
            {
                for n in generalNotifications
                {
                    if(n.isNotSeen)
                    {
                        numberOfGeneralNotificationsTemp += 1
                    }
                }
            }
            
            if(!loadingNotificationsFromProfile)
            {
                numberOfNotifications -= numberOfGeneralNotifications
                numberOfGeneralNotifications = numberOfGeneralNotificationsTemp
                numberOfNotifications += numberOfGeneralNotifications
                
                DispatchQueue.main.async(execute: {() -> Void in
                    if(APK == Bundle.main.bundleIdentifier!)
                    {
                        UIApplication.shared.applicationIconBadgeNumber = numberOfNotifications
                    }
                })
            }
            
            DispatchQueue.main.async(execute: {() -> Void in
                leftDrawer.tableView.reloadData()
                leftDrawer.selectTab(tabString: leftDrawer.highlightedTabString)
            })
        }

    }
    
    /// Loads more notifications from internet
    func loadMoreNotificationsAsync()
    {
        viewModel.loadNotificationsList()
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.notificationsTable.reloadData()
        })
        
        if(!(previousNotificationsListSize == viewModel.notificationsList.count))
        {
            ignoreLoadingMoreData = false
        }
    }
    
    /// This function is been called when failure occured.
    func failureAction()
    {
        ignoreLoadingMoreData = false
    }
    
    /// Loads more notifications when user reaches the bottom of table view.
    func loadMoreNotifications()
    {
        task = WebApiTask(viewController: self, action: loadMoreNotificationsAsync, displayToast: false, isSynchronizationTimerEnabled: false)
        task.setFailureAction(action: failureAction)
        task.start()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func onSyncClick(_ sender: UIBarButtonItem) {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            if(viewModel.notificationsList.count == 0)
            {
                viewModel.notificationsList.removeAll()
                viewModel.pageToLoad = 1
                
                if(notAvailableView != nil)
                {
                    notAvailableView.view.removeFromSuperview()
                }
            }
            
            task = WebApiTask(viewController: self, action: loadNotifications, displayToast: true)
            task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
            task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: notificationsContainer)
            task.start()
        }
        else
        {
            let toast = CustomToast()
            toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
    }
}
