//
//  NotificationOffers.swift
//  RichReach2
//
//  Created by Eumbrella on 16/10/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class PromotionsNotificationViewController : ViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var promotionsTableView: UITableView!
    @IBOutlet var promotionsContainer: UIView!
    
    //var notAvailableView : NotAvailableViewController!
    var task : WebApiTask!
    var promotionsList : [PromotionModel] = []
    var viewModel : PromotionNotificationsViewModel!
    var lock = NSObject()
    var synchronized : Synchronized = Synchronized()
    var ignoreLoadingMoreData = false
    var startLoading = false
    var ingoreLoading = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        self.container = promotionsContainer
        
        promotionsTableView.tableFooterView = UIView()
        promotionsTableView.delegate = self
        promotionsTableView.dataSource = self
        
        if(viewModel == nil)
        {
            viewModel = PromotionNotificationsViewModel()
            viewModel.pageToLoad = 1
        }
        
        NotificationCenter.default.addObserver(self, selector:#selector(viewCameActive), name: NSNotification.Name.UIApplicationWillEnterForeground, object: nil)
    }
    
    @objc func viewCameActive(){
        DispatchQueue.global(qos: .background).async {
            if(isActivityActive(viewController: self))
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    objc_sync_enter(self.lock)
                    if(!self.startLoading)
                    {
                        self.startLoading = true
                        self.viewModel.notificationsList.removeAll()
                        self.promotionsTableView.reloadData()
                        
                        if(self.notAvailableView != nil)
                        {
                            self.notAvailableView.view.removeFromSuperview()
                        }
                        
                        self.viewModel.pageToLoad = 1
                        self.task = WebApiTask(viewController: self, action: self.loadNotifications)
                        self.task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
                        self.task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: self.promotionsContainer)
                        self.task.start()
                    }
                    else
                    {
                        self.startLoading = false
                    }
                    objc_sync_exit(self.lock)
                })
            }
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        objc_sync_enter(lock)
        if(!startLoading)
        {
            startLoading = true
            
            if(viewModel != nil && viewModel.notificationsList != nil)
            {
                viewModel.notificationsList.removeAll()
            }
            
            self.promotionsTableView.reloadData()
            
            if(self.notAvailableView != nil)
            {
                self.notAvailableView.view.removeFromSuperview()
            }
            
            viewModel.pageToLoad = 1
            task = WebApiTask(viewController: self, action: loadNotifications)
            task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
            task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: self.promotionsContainer)
            task.start()
        }
        else
        {
            startLoading = false
        }
        objc_sync_exit(lock)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 0
        }
        else
        {
            return viewModel.notificationsList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "promotion_cell") as! PromotionViewCell
        
        if(viewModel != nil && viewModel.notificationsList != nil && indexPath.row < viewModel.notificationsList.count )
        {
            let promotion : PromotionModel! = viewModel.notificationsList[indexPath.row]
            
            let url = URL(string: promotion.imageUrl)!
            cell.promotionImage.kf.setImage(with: url)
            
            cell.promotionShortDescription.text = promotion.shortDescription
            
            
            if (promotion.firstValidDate == promotion.lastValidDate){
            cell.promotionDate.text = "\(promotion.firstValidDate ?? "")"
            }
            else{
            cell.promotionDate.text = "\(promotion.firstValidDate ?? "") - \(promotion.lastValidDate ?? "")"
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            if(promotion.isSeen != nil && promotion.isSeen)
            {
                cell.isSeenLabel.text = "Seen"
            }
            else
            {
                cell.isSeenLabel.text = ""
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let notification = viewModel.notificationsList[indexPath.row]
        hasActivityBeenCreatedFromNotificationsView = false
        
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            let appUser = localDatabase.getAppUser()
            let phoneNumber = appUser?.phoneNumber
            
            do
            {
                let pushNotifications = try NotificationsWebApi.getPromotionNotificationOffers(userPhone: phoneNumber!)
                if(pushNotifications == nil || pushNotifications!.count == 0)
                {
                    if(viewModel.notificationsList.count != 0)
                    {
                        viewModel.notificationsList.removeAll()
                        self.promotionsTableView.reloadData()
                        
                        viewModel.pageToLoad = 1
                    }
                    
                    if(notAvailableView != nil)
                    {
                        self.notAvailableView.view.removeFromSuperview()
                    }
                    
                    task = WebApiTask(viewController: self, action: loadNotifications, displayToast: true)
                    task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
                    task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: promotionsContainer)
                    task.start()
                }
                else
                {
                    for p in pushNotifications!
                    {
                        if(indexPath.row < viewModel.notificationsList.count && p.couponCode == viewModel.notificationsList[indexPath.row].couponCode && p.barcode == viewModel.notificationsList[indexPath.row].barcode)
                        {
                            try NotificationsWebApi.updateUserCouponStatus(userPhone: phoneNumber!,couponCode: viewModel.notificationsList[indexPath.row].couponCode, barcode: viewModel.notificationsList[indexPath.row].barcode)
                            
                            if(indexPath.row < viewModel.notificationsList.count && viewModel.notificationsList[indexPath.row].isSeen != nil && !viewModel.notificationsList[indexPath.row].isSeen)
                            {
                                numberOfPromotionNotifications -= 1
                                numberOfNotifications -= 1
                                UIApplication.shared.applicationIconBadgeNumber -= 1
                                
                                DispatchQueue.main.async(execute: {() -> Void in
                                    leftDrawer.tableView.reloadData()
                                    leftDrawer.selectTab(tabString: leftDrawer.highlightedTabString)
                                })
                            }
                            
                            if(indexPath.row < viewModel.notificationsList.count)
                            {
                                let PromotionStoryBoard = UIStoryboard(name: "PromotionsNotificationView", bundle: nil)
                                let viewController = PromotionStoryBoard.instantiateViewController(withIdentifier: "PromotionView") as! PromotionView
                                viewController.promotionModel = viewModel.notificationsList[indexPath.row]
                                self.navigationController?.pushViewController(viewController, animated: true)
                            }
                        }
                    }
                }
            }
            catch
            {
                
            }
        }
        else
        {
            let toast = CustomToast()
            toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height {
            synchronized.synchronize(obj: lock)
            {
                if (viewModel != nil && viewModel.notificationsList != nil)
                {
                    if (!ignoreLoadingMoreData)
                    {
                        ignoreLoadingMoreData = true
                        loadMoreNotifications()
                    }
                }
            }
        }
    }
    
    /// Load notifications from internet
    func loadNotifications()
    {
        var numberOfPromotionNotificationsTemp = 0
        
        viewModel.loadNotificationsList()
        
        if (!isActivityActive(viewController: self))
        {
            return
        }
        
        ingoreLoading = false
        
        DispatchQueue.main.async(execute: {() -> Void in
            if(self.viewModel.notificationsList == nil || self.viewModel.notificationsList.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.promotionsContainer!, text: NSLocalizedString("noAvailableNotifications", comment: ""))
            }
            else
            {
                for n in self.viewModel.notificationsList
                {
                    if(n.isSeen != nil && !n.isSeen)
                    {
                        numberOfPromotionNotificationsTemp += 1
                    }
                }
                
                //numberOfPromotionNotificationsTemp = self.viewModel.notificationsList.count
                if(self.notAvailableView != nil)
                {
                    self.notAvailableView.view.removeFromSuperview()
                }
            }
            
            if(!loadingNotificationsFromProfile)
            {
                numberOfNotifications -= numberOfPromotionNotifications
                numberOfPromotionNotifications = numberOfPromotionNotificationsTemp
                numberOfNotifications += numberOfPromotionNotifications
                
                if(APK == Bundle.main.bundleIdentifier!)
                {
                    UIApplication.shared.applicationIconBadgeNumber = numberOfNotifications
                }
            }
            
            leftDrawer.tableView.reloadData()
            leftDrawer.selectTab(tabString: leftDrawer.currentTab)
        })
        
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.promotionsTableView.reloadData()
            self.startLoading = false
        })
    }
    
    /// Loads more notifications from internet
    func loadMoreNotificationsAsync()
    {
        viewModel.loadNotificationsList()
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.promotionsTableView.reloadData()
        })

    }
    
    /// This function is been called when failure occured.
    func failureAction()
    {
    
    }
    
    /// Loads more notifications when user reaches the bottom of table view.
    func loadMoreNotifications()
    {
        task = WebApiTask(viewController: self, action: loadMoreNotificationsAsync, displayToast: false, isSynchronizationTimerEnabled: false)
        task.setFailureAction(action: failureAction)
        task.start()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    func setIngoreLoading()
    {
        ingoreLoading = false
    }
    
    @IBAction func onSyncClick(_ sender: UIBarButtonItem) {
        if(!ingoreLoading)
        {
            ingoreLoading = true
            
            if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
            {
                if(viewModel.notificationsList.count != 0)
                {
                    viewModel.notificationsList.removeAll()
                    self.promotionsTableView.reloadData()
                    
                    viewModel.pageToLoad = 1
                }
                
                if(self.notAvailableView != nil)
                {
                    self.notAvailableView.view.removeFromSuperview()
                }
                
                task = WebApiTask(viewController: self, action: loadNotifications, displayToast: true)
                task.successMessage = NSLocalizedString("synchronizationCompleted", comment: "")
                task.setFailureAction(action: setIngoreLoading)
                task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
                task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: promotionsContainer)
                task.start()
            }
            else
            {
                ingoreLoading = false
                let toast = CustomToast()
                toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
                toast.show()
            }
        }
    }
}
