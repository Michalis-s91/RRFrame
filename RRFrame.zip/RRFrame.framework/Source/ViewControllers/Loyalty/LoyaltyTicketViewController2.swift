//
//  LoyaltyTicketViewController2.swift
//  RichReach2
//
//  Created by Eumbrella on 01/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class LoyaltyTicketViewController2: ViewController, UITableViewDelegate, UITableViewDataSource{
    @IBOutlet var containerView: UIView!
    @IBOutlet var ticketTableView: UITableView!
    @IBOutlet var refreshItem: UIBarButtonItem!
    
    @IBOutlet var containerTop: NSLayoutConstraint!
    
    var loyaltyTicketView : LoyaltyTicketView!
    
    var headerView : UIView!
    
    var partner : PartnerModel!
    var ticket : LoyaltyStatementModel!
    var viewModel : LoyaltyTicketViewModel!
    var task : WebApiTask!
    //var notAvailableView : NotAvailableViewController!
    var displaySyncItem = false
    
    var ticketView : TicketView!
    
    var itemStyle : TicketStyle!
    var itemStyle2 : TicketStyle!
    var amountStyle : TicketStyle!
    var hasAlternatingStyles = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ticketView = loyaltyDB.getTicketView()
        
        itemStyle = ticketView.ticketStyleModel
        
        if(ticketView.ticketStyleModel2 == nil)
        {
            itemStyle2 = ticketView.ticketStyleModel
        }
        else
        {
            itemStyle2 = ticketView.ticketStyleModel2
            hasAlternatingStyles = true
        }
        
        amountStyle = ticketView.ticketStyleModel
        
        ticketTableView.rowHeight = UITableViewAutomaticDimension
        ticketTableView.tableFooterView = UIView()
        ticketTableView.delegate = self
        ticketTableView.dataSource = self
        
        self.navigationItem.leftBarButtonItem?.image = UIImage(named: "ic_back")//?.resizeImage2(30 , 20, opaque: false)
        
        /*detailsHeaderStyle.backgroundColor = "#21639C"
         detailsHeaderStyle.textColor = "#ffffff"
         detailsHeaderStyle.font = "Roboto-Light"
         detailsHeaderStyle.textSize = 16
         
         headerStyle.backgroundColor = "#1393CD"
         headerStyle.textColor = "#ffffff"
         headerStyle.font = "Roboto-Light"
         headerStyle.textSize = 16
         
         itemStyle.backgroundColor = "#ffffff"
         itemStyle.textColor = "#002559"
         itemStyle.font = "Roboto-Light"
         itemStyle.textSize = 14
         
         amountStyle.backgroundColor = "#ffffff"
         amountStyle.textColor = "#002559"
         amountStyle.font = "Roboto-Light"
         amountStyle.textSize = 14*/
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //self.tabBarController?.tabBar.isHidden = true
        
        //self.title = ""
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        containerTop.constant = ticketTableView.rectForRow(at: IndexPath(row: 0, section: 0)).size.height + ticketTableView.rectForRow(at: IndexPath(row: 1, section: 0)).size.height
        self.container = self.containerView
        
        if(headerView != nil)
        {
            //headerView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.height, height: headerView.frame.height)
            roundCorners([.bottomLeft,.bottomRight], radius: 10, view: headerView)
        }
        
        viewModel = LoyaltyTicketViewModel(partner: partner)
        LoyaltyTicketViewModel.ticket = ticket
        self.container = containerView
        
        loadTicketInformation()
        /*task = WebApiTask(viewController: self, action: loadTicketInformation)
         task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
         task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: containerView)
         task.setFailureAction(action: failureTask)
         task.start()*/
        
        //let titleFont = UIFont(name: "UIFontWeightRegular", size: 16) ?? UIFont.systemFont(ofSize: 16)
        //self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
        //self.title = viewModel.title
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 2
        }
        else
        {
            return viewModel.LoyaltyTicketList.count + 3
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_details_cell") as! TicketDetailsViewCell
            
            if(viewModel != nil)
            {
                cell.ticketNoLabel.text = viewModel.ticketNo
                cell.ticketDateLabel.text = viewModel.ticketDate
                cell.rewardPointsLabel.text = viewModel.rewardPoints
                cell.redemptionPointsLabel.text = viewModel.redemptionPoints
                cell.ticketTitle.text = viewModel.title
            }
            
            cell.backgroundColor = UIColor(ticketView.detailsBackgroundColor)
            
            
            cell.ticketNoHeaderLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.ticketDateHeaderLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.rewardPointsHeaderLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.redemptionPointsHeaderLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.ticketTitle.textColor = UIColor(ticketView.headerTextColor)
            
            cell.ticketNoHeaderLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.ticketDateHeaderLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.rewardPointsHeaderLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.redemptionPointsHeaderLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.ticketTitle.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            
            
            cell.ticketNoLabel.textColor = UIColor(ticketView.detailsTextColor)
            cell.ticketDateLabel.textColor = UIColor(ticketView.detailsTextColor)
            cell.rewardPointsLabel.textColor = UIColor(ticketView.detailsTextColor)
            cell.redemptionPointsLabel.textColor = UIColor(ticketView.detailsTextColor)
            
            cell.ticketNoLabel.font = UIFont (name: (ticketView.detailsFont)!, size: CGFloat((ticketView.detailsTextSize)!))
            cell.ticketDateLabel.font = UIFont (name: (ticketView.detailsFont)!, size: CGFloat((ticketView.detailsTextSize)!))
            cell.rewardPointsLabel.font = UIFont (name: (ticketView.detailsFont)!, size: CGFloat((ticketView.detailsTextSize)!))
            cell.redemptionPointsLabel.font = UIFont (name: (ticketView.detailsFont)!, size: CGFloat((ticketView.detailsTextSize)!))
            
            cell.line.backgroundColor = UIColor(ticketView.detailsTextColor)
            
            cell.separatorInset = UIEdgeInsetsMake(0.0, cell.bounds.size.width, 0.0, 0.0)
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_header_cell") as! TicketHeaderViewCell
            headerView = cell
            
            cell.backgroundColor = UIColor(ticketView.headerBackgroundColor)
            
            cell.itemLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.quantityLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.priceLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.vatLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.amountLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.discountLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.discountPercLabel.textColor = UIColor(ticketView.headerTextColor)
            cell.grossLabel.textColor = UIColor(ticketView.headerTextColor)
            
            cell.itemLabel.font = UIFont (name: (ticketView.headerFont)! , size: CGFloat((ticketView.headerTextSize)!))
            cell.quantityLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.priceLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.vatLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.amountLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.discountLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.discountPercLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            cell.grossLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
            
            cell.separatorInset = UIEdgeInsetsMake(0.0, cell.frame.size.width, 0.0, 0.0)
            //roundCorners([.bottomLeft,.bottomRight], radius: 10, view: cell)
            cell.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.height, height: cell.frame.height)
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case viewModel.LoyaltyTicketList.count + 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_total_cell") as! TicketTotalViewCell
            if(viewModel != nil)
            {
                //cell.backgroundColor = UIColor(amountStyle.backgroundColor)
                
                cell.totalHeaderLabel.textColor = UIColor(amountStyle.textColor)
                cell.totalLabel.textColor = UIColor(amountStyle.textColor)
                cell.totalDiscountLabel.textColor = UIColor(amountStyle.textColor)
                cell.totalGrossLabel.textColor = UIColor(amountStyle.textColor)
                
                cell.totalHeaderLabel.font = UIFont (name: (ticketView.headerFont)!, size: CGFloat((ticketView.headerTextSize)!))
                
                cell.totalLabel.font = UIFont (name: (ticketView.detailsFont)!, size: CGFloat((ticketView.detailsTextSize)!))
                cell.totalDiscountLabel.font = UIFont (name: (ticketView.detailsFont)!, size: CGFloat((ticketView.detailsTextSize)!))
                cell.totalGrossLabel.font = UIFont (name: (ticketView.detailsFont)!, size: CGFloat((ticketView.detailsTextSize)!))
                
                cell.totalLabel.text = viewModel.totalAmount
                cell.totalGrossLabel.text =  String(format: "%.2f" , viewModel.totalGross)
                cell.totalDiscountLabel.text = String(format: "%.2f" , viewModel.discountAmount)
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_item_cell") as! TicketItemViewCell
            let ticket = viewModel.LoyaltyTicketList[indexPath.row - 2]
            
            if(hasAlternatingStyles && indexPath.row != viewModel.LoyaltyTicketList.count + 1)
            {
                cell.lineHeight.constant = 0
            }
            else
            {
                cell.lineHeight.constant = 0.5
            }
            
            if(indexPath.row % 2 == 0)
            {
                cell.backgroundColor = UIColor(itemStyle.backgroundColor)
                
                cell.descriptionLabel.textColor = UIColor(itemStyle.textColor)
                cell.erpReferenceLabel.textColor = UIColor(itemStyle.textColor)
                cell.barcodeLabel.textColor = UIColor(itemStyle.textColor)
                cell.quantityLabel.textColor = UIColor(itemStyle.textColor)
                cell.priceLabel.textColor = UIColor(itemStyle.textColor)
                cell.vatLabel.textColor = UIColor(itemStyle.textColor)
                cell.amountLabel.textColor = UIColor(itemStyle.textColor)
                cell.discountLabel.textColor = UIColor(itemStyle.textColor)
                cell.discountPercLabel.textColor = UIColor(itemStyle.textColor)
                cell.grossLabel.textColor = UIColor(itemStyle.textColor)
                
                cell.descriptionLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.erpReferenceLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.barcodeLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.quantityLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.priceLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.vatLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.amountLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.discountLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.discountPercLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
                cell.grossLabel.font = UIFont (name: (itemStyle.font)!, size: CGFloat((itemStyle.textSize)!))
            }
            else
            {
                cell.backgroundColor = UIColor(itemStyle2.backgroundColor)
                
                cell.descriptionLabel.textColor = UIColor(itemStyle2.textColor)
                cell.erpReferenceLabel.textColor = UIColor(itemStyle2.textColor)
                cell.barcodeLabel.textColor = UIColor(itemStyle2.textColor)
                cell.quantityLabel.textColor = UIColor(itemStyle2.textColor)
                cell.priceLabel.textColor = UIColor(itemStyle2.textColor)
                cell.vatLabel.textColor = UIColor(itemStyle2.textColor)
                cell.amountLabel.textColor = UIColor(itemStyle2.textColor)
                cell.discountLabel.textColor = UIColor(itemStyle2.textColor)
                cell.discountPercLabel.textColor = UIColor(itemStyle2.textColor)
                cell.grossLabel.textColor = UIColor(itemStyle2.textColor)
                
                cell.descriptionLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.erpReferenceLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.barcodeLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.quantityLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.priceLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.vatLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.amountLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.discountLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.discountPercLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
                cell.grossLabel.font = UIFont (name: (itemStyle2.font)!, size: CGFloat((itemStyle2.textSize)!))
            }
            
            cell.descriptionLabel.text = ticket.description
            cell.erpReferenceLabel.text = ticket.ERPReference == -1 ? "" : String(ticket.ERPReference)
            cell.barcodeLabel.text = ticket.barcode
            cell.quantityLabel.text = ticket.Quantity
            cell.priceLabel.text = ticket.price
            cell.vatLabel.text = ticket.LineVATPurcentage
            cell.amountLabel.text = ticket.lineAmountWithVAT
            
            if(Double(ticket.Quantity) == 0.0 || Double(ticket.price) == 0.0)
            {
                cell.discountPercLabel.text = "0"
            }
            else
            {
                let discountPercentage = 100 - ((Double(ticket.lineAmountWithVAT)! / (Double(ticket.Quantity)! * Double(ticket.price)!)) * 100)
                cell.discountPercLabel.text = "\(Int(round(discountPercentage)))"
                // discountPercentage == 0.0 ? "0" : (Int(round(discountPercentage)) == 100.0 ? "100" : "\(Int(round(discountPercentage)))")
            }
            
            //var discount = Double(ticket.price)! * Double(ticket.Quantity)! - Double(ticket.amountWithVAT)!
            cell.discountLabel.text = ticket.lineDiscountAmount //String(format: "%.2f" , discount)
            
            let gross = Double(ticket.price)! * Double(ticket.Quantity)!
            cell.grossLabel.text = String(format: "%.2f" , gross)
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        }
    }
    
    @IBAction func backPressed(_ sender: UIBarButtonItem) {
        isViewPushed = false
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    /// Loads the ticket information from internet
    func loadTicketInformation()
    {
        viewModel.ticketNo = ticket.ticketNo
        viewModel.ticketDate = ticket.transDate
        viewModel.previousPoints = String(Int(ticket.balance)! + Int(ticket.redemptionPoints)! - Int(ticket.rewardPoints)!)
        viewModel.redemptionPoints = ticket.redemptionPoints != nil ? ticket.redemptionPoints : "0"
        viewModel.rewardPoints = ticket.rewardPoints
        viewModel.totalAmount = ticket.amount
        viewModel.LoyaltyTicketList = loyaltyDB.getTickets(ticketNo : ticket.ticketNo)
        
        for listItem in viewModel.LoyaltyTicketList
        {
            if(!isNullOrEmpty(string: listItem.lineDiscountAmount) && !(listItem.lineDiscountAmount == "0,00") && !(listItem.lineDiscountAmount == "0.00") && !(listItem.lineDiscountAmount == "0"))
            {
                
                //totalDiscountAmount = totalDiscountAmount + Double(listItem.lineDiscountAmount)!
                
                viewModel.hasDiscountAmount = true
                if(viewModel.discountAmount != nil)
                {
                    viewModel.discountAmount = viewModel.discountAmount + Double(listItem.lineDiscountAmount)!
                }
                else
                {
                    viewModel.discountAmount =   Double(listItem.lineDiscountAmount)!
                }
            }
            
            viewModel.totalGross = viewModel.totalGross + (Double(listItem.price)! * Double(listItem.Quantity)!)
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            if (self.viewModel.LoyaltyTicketList == nil || self.viewModel.LoyaltyTicketList.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.container!, text: NSLocalizedString("noAvailableTicketInformation", comment: ""))
                self.notAvailableView.image.removeFromSuperview()
            }
            else
            {
                if(self.notAvailableView != nil)
                {
                    self.notAvailableView.view.removeFromSuperview()
                }
                
                //self.hideSyncItem()
                
                self.ticketTableView.reloadData()
            }
        })
        
    }
    
    /// This function is been called when failure occured.
    func failureTask()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            self.displaySyncItem = true
            //self.showSyncItem()
        })
    }
}
