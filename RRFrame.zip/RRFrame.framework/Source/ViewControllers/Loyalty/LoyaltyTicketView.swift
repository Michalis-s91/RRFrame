//
//  LoyaltyTicketView.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// /// Creates view that displays loyalty tickets information.
class LoyaltyTicketView: LoyaltyTicketViewController, UITableViewDelegate, UITableViewDataSource{

    @IBOutlet var ticketTableView: UITableView!
    
    var headerView : UIView!
    
    var partner : PartnerModel!
    var ticket : LoyaltyStatementModel!
    var viewModel : LoyaltyTicketViewModel!
    var task : WebApiTask!
    //var notAvailableView : NotAvailableViewController!
    var displaySyncItem = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        ticketTableView.rowHeight = UITableViewAutomaticDimension
        ticketTableView.tableFooterView = UIView()
        ticketTableView.delegate = self
        ticketTableView.dataSource = self
    }

    override func viewWillAppear(_ animated: Bool) {
        UIApplication.shared.statusBarOrientation = .landscapeRight
        AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.container = self.loyaltyTicketContainer
        
        if(headerView != nil)
        {
            //headerView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.height, height: headerView.frame.height)
            roundCorners([.bottomLeft,.bottomRight], radius: 10, view: headerView)
        }
        
        viewModel = LoyaltyTicketViewModel(partner: partner)
        LoyaltyTicketViewModel.ticket = ticket
        
        task = WebApiTask(viewController: self, action: loadTicketInformation)
        task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
        task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: loyaltyTicketContainer)
        task.setFailureAction(action: failureTask)
        task.start()
        
        let titleFont = UIFont(name: "UIFontWeightRegular", size: 16) ?? UIFont.systemFont(ofSize: 16)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
        self.title = viewModel.title
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 2
        }
        else
        {
            return viewModel.LoyaltyTicketList.count + 3
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_details_cell") as! TicketDetailsViewCell
            
            if(viewModel != nil)
            {
                cell.ticketNoLabel.text = viewModel.ticketNo
                cell.ticketDateLabel.text = viewModel.ticketDate
                cell.rewardPointsLabel.text = viewModel.rewardPoints
                cell.redemptionPointsLabel.text = viewModel.redemptionPoints
            }
            
            cell.backgroundColor = Colors.bckg_drawer_item
            cell.separatorInset = UIEdgeInsetsMake(0.0, cell.bounds.size.width, 0.0, 0.0)
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_header_cell") as! TicketHeaderViewCell
            headerView = cell
            
            cell.separatorInset = UIEdgeInsetsMake(0.0, cell.frame.size.width, 0.0, 0.0)
            //roundCorners([.bottomLeft,.bottomRight], radius: 10, view: cell)
            cell.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.height, height: cell.frame.height)
            cell.backgroundColor = Colors.bckg_drawer
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case viewModel.LoyaltyTicketList.count + 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_total_cell") as! TicketTotalViewCell
            if(viewModel != nil)
            {
                cell.totalLabel.text = viewModel.totalAmount
                
                /*if( self.viewModel.hasDiscountAmount == nil || !self.viewModel.hasDiscountAmount )
                {
                    cell.discountViewHeight.constant = 0
                    cell.totalTopContraint1.constant = 0
                    cell.totalTopContraint2.constant = 0
                }
                else
                {
                    cell.discountLabel.text = String(viewModel.discountAmount)
                }*/
            }
            
            
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ticket_item_cell") as! TicketItemViewCell
            let ticket = viewModel.LoyaltyTicketList[indexPath.row - 2]
            
            cell.descriptionLabel.text = ticket.description
            cell.barcodeLabel.text = ticket.barcode
            cell.quantityLabel.text = ticket.Quantity
            cell.priceLabel.text = ticket.price
            cell.vatLabel.text = ticket.LineVATPurcentage
            cell.amountLabel.text = ticket.lineAmountWithVAT
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        }
    }
    
    
    /// Loads the ticket information from internet
    func loadTicketInformation()
    {
        viewModel.loadFromInternet()
        
        if (!isActivityActive(viewController: self))
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            if (self.viewModel.LoyaltyTicketList == nil || self.viewModel.LoyaltyTicketList.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.container!, text: NSLocalizedString("noAvailableTicketInformation", comment: ""))
                self.notAvailableView.image.removeFromSuperview()
            }
            else
            {
                if(self.notAvailableView != nil)
                {
                    self.notAvailableView.view.removeFromSuperview()
                }
                
                self.hideSyncItem()
                
                self.ticketTableView.reloadData()
            }
        })

    }
    
    /// This function is been called when failure occured.
    func failureTask()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            self.displaySyncItem = true
            self.showSyncItem()
        })
    }
    
    
    /// Hide sync bar button item from navigation bar.
    func hideSyncItem()
    {
        refreshItem.image = imageWithColor(color: Colors.trasnparent)
        refreshItem.isEnabled = false
    }
    
    /// Show sync bar button item to navigation bar.
    func showSyncItem()
    {
        refreshItem.image = UIImage(named: "ic_sync")
        refreshItem.isEnabled = true
    }
    
    /// This function is been call when user clicks a bar button item from navigation.
    func onOptionsItemSelected()
    {
        task = WebApiTask(viewController: self, action: loadTicketInformation, displayToast: false)
        //task.errorMessage = NSLocalizedString("noDataLoaded", comment: "")
        task.start()
    }
}
