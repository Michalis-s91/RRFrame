//
//  LoyaltyTicketViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Creates a view with container and is been used for showing the loyalty ticket view.
class LoyaltyTicketViewController: ViewController {

    @IBOutlet var loyaltyTicketContainer: UIView!
    @IBOutlet var refreshItem: UIBarButtonItem!
    
    var loyaltyTicketView : LoyaltyTicketView!
    
    var tempTicket : LoyaltyStatementModel!
    var tempPartner : PartnerModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //self.tabBarController?.tabBar.isHidden = true
        
        self.title = "" 
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        loyaltyTicketView = self.storyboard?.instantiateViewController(withIdentifier: "LoyaltyTicketView") as? LoyaltyTicketView
        loyaltyTicketView.partner = tempPartner
        loyaltyTicketView.ticket = tempTicket
        loyaltyTicketView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (loyaltyTicketContainer?.frame.height)!)
        loyaltyTicketView.willMove(toParentViewController: self)
        self.loyaltyTicketContainer?.addSubview((loyaltyTicketView.view)!)
        //self.addChildViewController(wishListView)
        loyaltyTicketView.didMove(toParentViewController: self)
        loyaltyTicketView.loyaltyTicketContainer = loyaltyTicketContainer
        loyaltyTicketView.refreshItem = self.refreshItem
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }

    @IBAction func refreshItemClicked(_ sender: UIBarButtonItem) {
        loyaltyTicketView.onOptionsItemSelected()
    }
}
