//
//  LoyaltyStatementView.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates view that displays loyalty statement for app user.
class LoyaltyStatementView: LoyaltyStatementViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var loyaltyStatementTable: UITableView!
    
    var viewModel : LoyaltyStatementViewModel!
    var partner : PartnerModel!
    //var notAvailableView : NotAvailableViewController!
    var task : WebApiTask!
    var loyaltyStatementListCount = 0
    var loadMoreDataLock = NSObject()
    var ignoreLoadingMoreData = false
    var previousOffersListSize = 0
    var synchronized : Synchronized = Synchronized()
    var parentNavigationController : UINavigationController!
    var ticketSelected = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loyaltyStatementTable.tableFooterView = UIView()
        loyaltyStatementTable.delegate = self
        loyaltyStatementTable.dataSource = self
        
        viewModel = LoyaltyStatementViewModel(partner: partner, tableView: loyaltyStatementTable)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        switch UIDevice.current.orientation{
        case .portrait:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
        case .portraitUpsideDown:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeLeft)
        case .landscapeLeft:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeLeft)
            break
        case .landscapeRight:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
        default:
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
        }
        
        AppDelegate.isPotraitOrientation = false
        UIApplication.shared.isStatusBarHidden = false

        let titleFont = UIFont(name: "UIFontWeightRegular", size: 16) ?? UIFont.systemFont(ofSize: 16)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.view.frame = CGRect(x: 0, y: 0, width: (loyaltyStatementContainer?.frame.width)!, height: (loyaltyStatementContainer?.frame.height)!)
        //loyaltyStatementTable.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (loyaltyStatementContainer?.frame.height)!)
        
        self.container = self.loyaltyStatementContainer
        
        task = WebApiTask( viewController: self, action: loadLoyaltyStatement)
        task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
        task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: self.loyaltyStatementContainer)
        task.start()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        
        /*if(task != nil)
        {
            task.stop()
        }
        
        if(!ticketSelected)
        {
            UIApplication.shared.statusBarOrientation = .portrait
            //AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.landscapeRight, andRotateTo: UIInterfaceOrientation.landscapeRight)
            AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)
            AppDelegate.isPotraitOrientation = true
        }
        else
        {
            ticketSelected = false
        }*/
        
    }
    


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 0
        }
        else
        {
            return viewModel.LoyaltyStatementList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "loyalty_statement_cell") as! LoyaltyStatementViewCell
        let ticket = viewModel.LoyaltyStatementList[indexPath.row]
        
        cell.transactionDateLabel.text = ticket.transDate
        cell.ticketNoLabel.attributedText =  NSAttributedString(string: ticket.ticketNo, attributes:[.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
        cell.amountLabel.text = ticket.amount
        cell.rewardPointsLabel.text = ticket.rewardPoints
        cell.redemptionPointsLabel.text = ticket.redemptionPoints
        cell.balanceLabel.text = ticket.balance
        
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            ticketSelected = true
            let LoyaltyTicketStoryBoard : UIStoryboard = UIStoryboard(name: "LoyaltyTicketView", bundle: nil)
            let loyaltyTicketView =  LoyaltyTicketStoryBoard.instantiateViewController(withIdentifier: "LoyaltyTicketViewController") as! LoyaltyTicketViewController
            loyaltyTicketView.tempTicket = viewModel.LoyaltyStatementList[indexPath.row]
            loyaltyTicketView.tempPartner = partner
            parentNavigationController.pushViewController(loyaltyTicketView, animated: true)
        }
        else
        {
            let toast =  CustomToast()
            toast.setToast(viewController: self,message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if (distanceFromBottom < height) {
            synchronized.synchronize(obj: loadMoreDataLock)
            {
                if (viewModel != nil && viewModel.LoyaltyStatementList != nil)
                {
                    if (!ignoreLoadingMoreData)
                    {
                        ignoreLoadingMoreData = true
                        loadMoreStatementEntries()
                    }
                }
            }
        }
    }
    
    /// Loads statement data from internet
    func loadLoyaltyStatement()
    {
        let loyaltyStatementList = viewModel.loadFromInternet(partnerID: partner.partnerID)
        
        if (!isActivityActive(viewController: self))
        {
            return
        }
        
        viewModel.loadAvailableLoyaltyStatement(list: loyaltyStatementList)
        previousOffersListSize = (loyaltyStatementList.count)
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.loyaltyStatementTable.reloadData()
            if (self.viewModel.LoyaltyStatementList == nil || self.viewModel.LoyaltyStatementList.count == 0)
            {
                self.notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.container!, text: NSLocalizedString("noAvailableStatement", comment: ""))
                self.notAvailableView.image.removeFromSuperview()
            }
            else
            {
                if(self.notAvailableView != nil)
                {
                    self.notAvailableView.view.removeFromSuperview()
                }
            }
        })
    }
    
    ///  Loads more statement entries.
    func loadMoreStatementEntriesAsync()
    {
        viewModel.loadMoreFromInternet(partnerID: partner.partnerID)
        if(!(previousOffersListSize == viewModel.LoyaltyStatementList.count))
        {
            ignoreLoadingMoreData = false
        }
        
        previousOffersListSize = viewModel.LoyaltyStatementList.count
    }
    
    
    /// This function is been called when failure occured.
    func failureAction()
    {
        ignoreLoadingMoreData = false
    }
    
    /// Loads more statment data after user reaches the bottom of table view.
    func loadMoreStatementEntries()
    {
        task = WebApiTask(viewController: self, action: loadMoreStatementEntriesAsync, displayToast: false, isSynchronizationTimerEnabled: false)
        task.failureAction = failureAction
        task.start()
    }
    
    
    /// This function is been call when user clicks a bar button item from navigation.
    func onOptionsItemSelected()
    {
        //ignoreLoadingMoreData = false
        //viewModel.LoyaltyStatementList.removeAll()
        //loyaltyStatementTable.reloadData()
        
        task = WebApiTask(viewController: self, action: loadLoyaltyStatement, displayToast: true)
        task.successMessage = NSLocalizedString("synchronizationCompleted", comment: "")
        task.errorMessage = NSLocalizedString("noDataLoaded", comment: "")
        task.start()
        
        if(viewModel != nil && viewModel.LoyaltyStatementList != nil && viewModel.LoyaltyStatementList.count > 0)
        {
            loyaltyStatementTable.scrollToRow( at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        }
    }
}
