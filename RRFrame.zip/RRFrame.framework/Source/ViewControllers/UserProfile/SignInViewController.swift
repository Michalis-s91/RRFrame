//
//  SignInViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 11/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class SignInViewController: ViewController {

    @IBOutlet var phoneLabel: UILabel!
    @IBOutlet var phoneText: UITextField!
    @IBOutlet var registerButton: UIButton!
    @IBOutlet var termsLabel1: UILabel!
    @IBOutlet var termsLabel2: UILabel!
    @IBOutlet var alreadyRegisteredLabel: UILabel!
    
    var appUser: AppUser!
    var tableDialog : TableDialog!
    var birthDatePickerDialog : DatePickerDialog!
    var viewModel : UserProfileViewModel!
    var dialogType = 0
    var activeView : UIView!
    
    var statusDialogView : DescriptionDialog!
    var statusTextDialog : DescriptionTextFieldDialog!
    var verificationCode : String!
    var message : String!
    var verificationMessage : String!
    var registrationVisibility : Int!
    var verificationVisibility : Int!
    var isLoadingParameters = false
    var isStatusTextDialogDisplayed = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        appUser = localDatabase.getAppUser()
        
        if(viewModel == nil)
        {
            viewModel = UserProfileViewModel()
        }
        
        let onTermsAndPolicyClick = UITapGestureRecognizer(target: self, action: #selector(SignInViewController.onTermsAndPolicyClick))
        termsLabel1.isUserInteractionEnabled = true
        termsLabel1.addGestureRecognizer(onTermsAndPolicyClick)
        
        let onTermsAndPolicyClick2 = UITapGestureRecognizer(target: self, action: #selector(SignInViewController.onTermsAndPolicyClick))
        termsLabel2.isUserInteractionEnabled = true
        termsLabel2.addGestureRecognizer(onTermsAndPolicyClick2)
        
        phoneLabel.text = "Please enter your mobile number so that RichReach will verify that is actually YOU"
        termsLabel1.text = "By submiting your registration you accept our"
        termsLabel2.text = "Terms and Policies"
        
        termsLabel2.attributedText = NSAttributedString(string: termsLabel2.text!, attributes: [.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
        
        registerButton.layer.cornerRadius = 10
        registerButton.backgroundColor = Colors.buttonGray
        registerButton.setBackgroundImage(imageWithColor(color: Colors.buttonGraySelected), for: .highlighted)
        
        if(!isNullOrEmpty(string: appUser.phoneNumber))
        {
            phoneText.text = appUser.phoneNumber
        }
        
        if(appUser.isPending)
        {
            showAlreadyRegistered()
        }

        setSimData()
        
        let sb = UIStoryboard(name:"StatusDialog",bundle:nil)
        self.statusDialogView = sb.instantiateInitialViewController()! as? DescriptionDialog
        self.statusDialogView.dismissWhenClickOutside = false
        
        let sb2 = UIStoryboard(name:"DescriptionTextFieldDialog",bundle:nil)
        self.statusTextDialog = sb2.instantiateInitialViewController()! as? DescriptionTextFieldDialog
        self.statusTextDialog.dismissWhenClickOutside = false
        
        registerForKeyboardNotifications()
        hideKeyboardWhenTappedAround()
    }

    /// Register view for keyboard notifications.
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func showAlreadyRegistered()
    {
        alreadyRegisteredLabel.text = "If you have already received a verification code please click here!"
        let onClickAlreadyRegistered = UITapGestureRecognizer(target: self, action: #selector(SignInViewController.onClickAlreadyRegistered))
        alreadyRegisteredLabel.isUserInteractionEnabled = true
        alreadyRegisteredLabel.addGestureRecognizer(onClickAlreadyRegistered)
    }
    
    /// Set SIM data.
    func setSimData()
    {
        viewModel.networkName = ""
        viewModel.networkISO = "en"
        viewModel.deviceID = UIDevice.current.identifierForVendor!.uuidString
    }
    
    /// Verifies whether the verification code is valid or not.
    ///
    /// - Parameter verificationCodeTemp: The verification code.
    func verifyUser()
    {
        let verificationCodeTemp = statusTextDialog.inputText
        if (!isNullOrEmpty(string: verificationCodeTemp))
        {
            if (verificationCodeTemp?.count == 4)
            {
                
                //let sb = UIStoryboard(name:"DescriptionDialog",bundle:nil)
                //statusDialogView = sb.instantiateInitialViewController() as! DescriptionDialog
                //let dialog = statusDialogView
                statusTextDialog.present(statusDialogView,animated:true)
                statusDialogView?.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("yourVerificationCodeIs", comment: "") + " " + verificationCodeTemp! + ".\n" + NSLocalizedString("pleaseWaitWhileVerifying", comment: ""))
                
                
                if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
                {
                    verificationCode = verificationCodeTemp
                    
                    DispatchQueue.global(qos: .background).async {
                        self.verifyVerificationCode(verificationCode: self.verificationCode)
                    }
                }
                else
                {
                    DispatchQueue.global(qos: .background).async {
                        self.dismissStatusDialogView()
                        
                        while(!DescriptionDialog.dialogDisappeared)
                        {
                            
                        }
                        
                        sleep(1)
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetConnectionIsRequiredDuringRegistration", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                        })
                    }
                }
            }
            else
            {
                displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: NSLocalizedString("invalidVerificationCode", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
            }
        }
        else
        {
            displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: NSLocalizedString("verificationCodeCannotBeEmpty", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
        }
    }
    
    
    @IBAction func onRegistrationClick(_ sender: UIButton) {
        phoneText.endEditing(true)
        
        DispatchQueue.main.async(execute: {() -> Void in
            
            let telephoneNumber = self.phoneText.text
            self.viewModel.phoneNumber = telephoneNumber
            self.phoneText.endEditing(true)
            
            if(!isNullOrEmpty(string: telephoneNumber))
            {
                if(telephoneNumber?.count == 8)
                {
                    if(telephoneNumber?.starts(with: "9"))!
                    {
                        self.displayConfirmTelephoneNumberDialog(telephoneNumber: telephoneNumber!)
                    }
                    else
                    {
                        self.displayMessageDialogView(title: NSLocalizedString("invalidTelephoneNumber", comment: ""), message: NSLocalizedString("telephoneFormatNotValidCY", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    }
                }
                else
                {
                    self.displayMessageDialogView(title: NSLocalizedString("invalidTelephoneNumber", comment: ""), message: NSLocalizedString("telephoneLengthNotValidCY", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                }
            }
            else
            {
                self.displayMessageDialogView(title: NSLocalizedString("invalidTelephoneNumber", comment: ""), message: NSLocalizedString("pleaseEnterTelephoneNumber", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
            }
        })
    }
    
    /// Displays a dialog that asks user to confirm his/her telephone number.
    ///
    /// - Parameter telephoneNumber: The user's telephone number.
    func displayConfirmTelephoneNumberDialog(telephoneNumber : String)
    {
        let sb = UIStoryboard(name:"YesNoMessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController() as! YesNoMessageDialog
        self.present(dialog,animated:true)
        dialog.setDialogView(title: NSLocalizedString("buttonVerify", comment: ""), message: ParameterizedStrings.confirmPhoneNumber(prefix: "CY", phoneText: telephoneNumber), yesButtonName: NSLocalizedString("Yes", comment: ""), noButtonName: NSLocalizedString("No", comment: ""))
        var appUser : AppUser!
        
        func yesRaised()
        {
            if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
            {
                if(telephoneNumber == "99367677")
                {
                    viewModel.phoneNumber = "99367677"
                    viewModel.registerUser()
                    let appUser = AppUser()
                    appUser.phoneNumber = telephoneNumber
                    
                    localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked: false)
                    localDatabase.insertRegisteredAPK(bussinessID: clientID)
                    
                    appUser.isPending = false
                    appUser.hasVerifiedPhoneNumber = true
                    localDatabase.updateAppUser(appUser: appUser)
                    
                    
                    DispatchQueue.global(qos: .background).async {
                        self.loadUserOptins()
                        self.loadUserProfileInformation()
                        self.loadUserDefaultOptions()
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            let UserProfileStoryBoard: UIStoryboard = UIStoryboard(name: "UserProfileView", bundle: nil)
                            let userProfileView =  UserProfileStoryBoard.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
                            self.previousViewController = userProfileView
                            self.navigationController?.pushViewController(userProfileView, animated: true)
                            
                            AppDelegate.registerForPushNotifications(application: appApplication)
                            
                        })
                    }
                }
                else if(localDatabase.isPhoneNumberVerified(phoneNumber: telephoneNumber))
                {
                    viewModel.phoneNumber = telephoneNumber
                    
                    while(!YesNoMessageDialog.dialogDisappeared)
                    {
                        /* wait for dialog to disappeared */
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        if(!self.statusDialogView.isBeingPresented)
                        {
                            self.present(self.statusDialogView,animated:true)
                            self.statusDialogView.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("submittingDetailsPleaseWait", comment: ""))
                        }
                        
                        DispatchQueue.global(qos: .background).async {
                            self.viewModel.registerUser()
                            self.loadUserOptins()
                            self.loadUserProfileInformation()
                            self.loadUserDefaultOptions()
                            
                            localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked: false)
                            localDatabase.insertRegisteredAPK(bussinessID: clientID)
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.dismissStatusDialogView()
                                self.dismissStatusTextDialogView()
                            })
                            
                            while(!DescriptionTextFieldDialog.dialogDisappeared || !DescriptionDialog.dialogDisappeared)
                            {
                                
                            }
                            
                            DispatchQueue.main.async(execute: {() -> Void in
                                let UserProfileStoryBoard: UIStoryboard = UIStoryboard(name: "UserProfileView", bundle: nil)
                                let userProfileView =  UserProfileStoryBoard.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
                                userProfileView.showSucceedDialog = true
                                self.navigationController?.pushViewController(userProfileView, animated: true)
                            })
                        }
                    })
                }
                else
                {
                    registerUser()
                    showAlreadyRegistered()
                }
            }
            else
            {
                DispatchQueue.global(qos: .background).async {
                    
                    while(!YesNoMessageDialog.dialogDisappeared)
                    {
                        /* wait for dialog to disappeared */
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.displayMessageDialogView(title: NSLocalizedString("noInternetConnection", comment: ""), message: NSLocalizedString("internetConnectionIsRequiredDuringRegistration", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    })
                }
            }
        }
        
        func noRaised()
        {
        }
        
        yesAction = yesRaised
        noAction = noRaised
        
        dialog.yesRaised = self
        dialog.noRaised = self
    }
    
    /// Registers the user.
    func registerUser()
    {
        DispatchQueue.global(qos: .background).async {
            
            while(!YesNoMessageDialog.dialogDisappeared)
            {
                /* wait for dialog to disappeared */
            }
            
            DispatchQueue.main.async(execute: {() -> Void in
                if(!self.statusDialogView.isBeingPresented)
                {
                    self.present(self.statusDialogView,animated:true)
                    self.statusDialogView.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("submittingDetailsPleaseWait", comment: ""))
                }
            })
            
            do
            {
                self.viewModel.registerUser()
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.proceedToVerificationProcess()
                })
            }
            catch
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.dismissStatusDialogView()
                    self.displayMessageDialogView(title: NSLocalizedString("registrationFailedTitle", comment: ""), message: NSLocalizedString("registrationFailed", comment: ""), closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                })
            }
        }
    }
    
    /// Proceeds to the verification process.
    func proceedToVerificationProcess()
    {
        if(!viewModel.hasUserReceivedRegistrationVerificationCode())
        {
            DispatchQueue.global(qos: .background).async {
                sleep(2)

                self.dismissStatusDialogView()
                
                while(!DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                self.getVerificationCode()
            }
        }
    }
    
    func getVerificationCodeViaSMS()
    {
        DispatchQueue.main.asyncAfter(deadline: .now() + 60) {
            DispatchQueue.global(qos: .background).async {
                if(!isActivityActive(viewController: self))
                {
                    return
                }
                
                let appUser = localDatabase.getAppUser()
                do
                {
                    if(appUser?.hasVerifiedPhoneNumber == nil || !(appUser?.hasVerifiedPhoneNumber)!)
                    {
                        var mServerResponse : String! = ""
                        
                        mServerResponse = try RegistrationWebApi.getVerificationCodeViaSMS(phoneNumber: (appUser?.phoneNumber)!, prefix: "357", carrier: (appUser?.networkOperator)!, deviceID: (appUser?.deviceID)!, applicationLanguage: "en")
                        
                        if(!isActivityActive(viewController: self))
                        {
                            return
                        }
                        
                        let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
                        
                        let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: mServerResponse)) && (mServerResponse?.contains(registrationMaxAttemptsReachedStr))!
                        
                        if(shouldDisplayMaxAttemptsDialogView)
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                self.displayRegistrationMaxAttemptsDialog()
                            })
                        }
                        else
                        {
                            DispatchQueue.main.async(execute: {() -> Void in
                                if(self.statusTextDialog != nil && !DescriptionTextFieldDialog.dialogDisappeared)
                                {
                                    self.statusTextDialog.updateDescription(newDescription : NSLocalizedString("callVerificationFailed", comment: "") )
                                }
                                else
                                {
                                    self.present(self.statusTextDialog,animated:true)
                                    self.statusTextDialog.buttonRunnable = self.verifyUser
                                    self.statusTextDialog.dismissWhenClickOutside = false
                                    self.statusTextDialog.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("callVerificationFailed", comment: ""))
                                    self.isStatusTextDialogDisplayed = true
                                }
                            })
                        }
                    }
                    
                    //}
                    
                    appUser?.hasUserReceivedRegistrationVerificationCode = true
                    localDatabase.updateAppUser(appUser: appUser!)
                    
                }
                catch
                {
                    self.displayFailureDialog()
                }
            }
        }
        
    }
    
    /// Contacts the server to make a request to get an SMS that contains the 4-digit verification code.
    func getVerificationCode()
    {
        do
        {
            try viewModel.getVerificationCodePost()
            getVerificationCodeViaSMS()
            
            let mServerResponse = viewModel.serverResponse
            let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
            
            let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: mServerResponse)) && (mServerResponse?.contains(registrationMaxAttemptsReachedStr))!
            
            if(shouldDisplayMaxAttemptsDialogView)
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.displayRegistrationMaxAttemptsDialog()
                })
            }
            else
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    if(!self.statusTextDialog.isBeingPresented && !self.statusTextDialog.isMovingToParentViewController)
                    {
                        self.present(self.statusTextDialog,animated:true)
                        self.statusTextDialog.buttonRunnable = self.verifyUser
                        self.statusTextDialog.dismissWhenClickOutside = false
                        self.statusTextDialog.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("makingIncomingCallRichReach", comment: ""))
                        self.isStatusTextDialogDisplayed = true
                    }
                })
            }
        }
        catch
        {
            displayFailureDialog()
        }
    }
    
    func displayFailureDialog()
    {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        let dialogViewController = dialog as! MessageDialog
        self.present(dialog,animated:true)
        dialogViewController.setDialogView(title:"Status" , description: NSLocalizedString("somethingWentWrong", comment: "") , buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside: false)
    }
    
    /// Updates the status dialog view message.
    ///
    /// - Parameter messageTemp: The updated message.
    func updateStatusDialogViewMessage(messageTemp : String)
    {
        message = messageTemp
        DispatchQueue.main.async(execute: {() -> Void in
            if (self.statusDialogView != nil)
            {
                self.statusDialogView.updateDescription(newDescription: self.message)
            }
        })
    }
    
    /// Updates the status dialog view message.
    ///
    /// - Parameter messageTemp: The updated message.
    func updateStatusTextDialogViewMessage(messageTemp : String)
    {
        message = messageTemp
        DispatchQueue.main.async(execute: {() -> Void in
            if (self.statusTextDialog != nil)
            {
                self.statusTextDialog.updateDescription(newDescription: self.message)
            }
        })
    }
    
    /// Dismisses the registration status dialog view.
    func dismissStatusDialogView()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            do
            {
                self.statusDialogView.dismissDialog()
            }
            catch
            {
                
            }
        })
    }
    
    /// Dismisses the registration status dialog view.
    func dismissStatusTextDialogView()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            do
            {
                self.isStatusTextDialogDisplayed = false
                self.statusTextDialog.dismissDialog()
            }
            catch
            {
                
            }
        })
    }
    
    /// Resends the verification code to the user.
    /*func resendVerificationCode()
    {
        do
        {
            let mServerResponse = viewModel.resendVerificationCode()
            let registrationMaxAttemptsReachedStr = NSLocalizedString("registrationMaxAttemptsReached", comment: "")
            
            let shouldDisplayMaxAttemptsDialogView = (!isNullOrEmpty(string: mServerResponse)) && mServerResponse.contains(registrationMaxAttemptsReachedStr)
            
            if(shouldDisplayMaxAttemptsDialogView)
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.dismissStatusDialogView()
                })
                
                while(!DescriptionDialog.dialogDisappeared)
                {
                    
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    self.displayRegistrationMaxAttemptsDialog()
                })
                
            }
        }
        catch
        {
            
        }
    }*/
    
    /// Indicates if status dialog is vissible or not.
    ///
    /// - Returns: True in case the status dialog is visible, otherwise false.
    func isStatusDialogVisible() -> Bool
    {
        return statusDialogView != nil && statusDialogView.view != nil && !statusDialogView.isBeingDismissed
    }
    
    /// Displays the RegistrationMaxAttemptsDialogView.
    func displayRegistrationMaxAttemptsDialog()
    {
        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        let dialogViewController = dialog as! MessageDialog
        self.present(dialog,animated:true)
        dialogViewController.setDialogView(title:NSLocalizedString("registrationAttemptsTitle", comment: "") , description: NSLocalizedString("registrationAttemptsMessage", comment: "") , buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside: false)
        
    }
    
    
    /// Verifies the verification code that was sent to the user (or the one specified by the user).
    ///
    /// - Parameter verificationCode: The verification code.
    func verifyVerificationCode(verificationCode : String)
    {
        viewModel.verificationCode = verificationCode
        viewModel.registrationSourceType = RegistrationSourceTypeEnum.RichReachIphone.rawValue
        
        do
        {
            DispatchQueue.global(qos: .background).async {
                self.viewModel.verifyVerificationCode()
                self.verificationMessage = self.viewModel.verificationMessage
                
                if(self.viewModel.isVerified)
                {
                    self.loadUserOptins()
                    self.loadUserProfileInformation()
                    self.loadUserDefaultOptions()
                    
                    //localDatabase.insertVerifiedAPK(bussinessID: clientID, isBlocked: false)
                    //localDatabase.insertRegisteredAPK(bussinessID: clientID)
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.dismissStatusDialogView()
                        self.dismissStatusTextDialogView()
                    })
                    
                    while(!DescriptionTextFieldDialog.dialogDisappeared || !DescriptionDialog.dialogDisappeared)
                    {
                        
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        let UserProfileStoryBoard: UIStoryboard = UIStoryboard(name: "UserProfileView", bundle: nil)
                        let userProfileView =  UserProfileStoryBoard.instantiateViewController(withIdentifier: "UserProfileViewController") as! UserProfileViewController
                        userProfileView.showSucceedDialog = true
                        self.navigationController?.pushViewController(userProfileView, animated: true)
                    })
                }
                else if(self.verificationMessage != nil)
                {
                    self.dismissStatusDialogView()
                    
                    while(!DescriptionDialog.dialogDisappeared)
                    {
                        
                    }
                    
                    sleep(1)
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.displayMessageDialogView(title: NSLocalizedString("verificationFailedTitle", comment: ""), message: self.verificationMessage, closeDialogButtonText: NSLocalizedString("Ok", comment: ""))
                    })
                }
                
            }
        }
        catch
        {
            updateStatusDialogViewMessage(messageTemp: NSLocalizedString("verificationFailed", comment: ""))
        }
        
    }
    
    /// Loads the user's optins.
    func loadUserOptins()
    {
        do
        {
            viewModel.loadUserOptins()
        }
        catch
        {
            
        }
    }
    
    
    /// Loads the user's profile information from our server.
    func loadUserProfileInformation()
    {
        do
        {
            let userProfileViewModel = UserProfileViewModel(viewController: nil)
            userProfileViewModel.getUserProfileInformationFromServer()
        }
        catch
        {
            
        }
    }
    
    
    /// Loads the user's default options.
    func loadUserDefaultOptions()
    {
        do
        {
            viewModel.loadUserDefaultOptions()
        }
        catch
        {
            
        }
    }
    
    /// Displays a message to the user using our message dialog view design.
    ///
    /// - Parameters:
    ///   - title: The dialog's title.
    ///   - message: The message to be displayed.
    ///   - closeDialogButtonText: The close dialog button text.
    func displayMessageDialogView(title : String,message : String, closeDialogButtonText : String)
    {
        if(!DescriptionTextFieldDialog.dialogDisappeared)
        {
            let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()! as! MessageDialog
            statusTextDialog.present(dialog,animated:true)
            dialog.setDialogView(title: title, description:message, buttonName: closeDialogButtonText, dismissWhenClickOutside: true)
        }
        else
        {
            let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()! as! MessageDialog
            self.present(dialog,animated:true)
            dialog.setDialogView(title: title, description:message, buttonName: closeDialogButtonText, dismissWhenClickOutside: true)
        }
    }
    
    @objc func onTermsAndPolicyClick (sender:UITapGestureRecognizer) {
        restartApp = false
        UIApplication.shared.openURL(NSURL(string: NSLocalizedString("termsAndPoliciesLink", comment: ""))! as URL)
    }
    
    @objc func onClickAlreadyRegistered(sender : UITapGestureRecognizer) {
        DispatchQueue.main.async(execute: {() -> Void in
            //let sb = UIStoryboard(name:"StatusDialog",bundle:nil)
            //self.statusDialogView = sb.instantiateInitialViewController()! as! DescriptionDialog
            //statusDialogView = dialog as! DescriptionDialog
            if(!self.statusTextDialog.isBeingPresented && !self.statusTextDialog.isMovingToParentViewController)
            {
                let sb = UIStoryboard(name:"DescriptionTextFieldDialog",bundle:nil)
                self.statusTextDialog = sb.instantiateInitialViewController()! as? DescriptionTextFieldDialog
                self.statusTextDialog.dismissWhenClickOutside = false
                self.present(self.statusTextDialog,animated:true)
                self.statusTextDialog.buttonRunnable = self.verifyUser
                self.statusTextDialog.setDialogView(title: NSLocalizedString("registrationStatus", comment: ""), description: NSLocalizedString("enterCode", comment: ""))
                self.isStatusTextDialogDisplayed = true
            }
        })
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        super.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    
    @objc func keyboardWasShown(notification: NSNotification){
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        
        if(statusTextDialog.isViewLoaded)
        {
            UIView.animate(withDuration: 0.3, animations: {
                self.statusTextDialog.dialogView.frame.origin.y =  UIScreen.main.bounds.size.height - self.statusTextDialog.dialogView.frame.size.height - (keyboardSize?.height)!
            }, completion: nil)
            return
        }
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification){
        if(statusTextDialog.isViewLoaded)
        {
            UIView.animate(withDuration: 0.3, animations: {
                self.statusTextDialog.dialogView.frame.origin.y =  UIScreen.main.bounds.size.height - self.statusTextDialog.dialogView.frame.size.height
            }, completion: nil)
            return
        }
    }

}
