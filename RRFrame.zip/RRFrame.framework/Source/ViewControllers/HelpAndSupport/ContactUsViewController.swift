//
//  ContactUsViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 23/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class ContactUsViewController: ViewController, ModalViewControllerDelegate, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var splitter: UIView!
    @IBOutlet var typesLabel: UILabel!
    @IBOutlet var expandImage: UIImageView!
    @IBOutlet var line: UIView!
    @IBOutlet var messageLabel: UILabel!
    @IBOutlet var messageTextView: UITextView!
    @IBOutlet var sendButton: UIButton!
    @IBOutlet var infoTable: UITableView!
    @IBOutlet var sendButtonWidth: NSLayoutConstraint!
    @IBOutlet var innerView: UIView!
    @IBOutlet var backgroundImage: UIImageView!
    @IBOutlet var typesView: UIView!
    
    @IBOutlet var innerViewTrailing: NSLayoutConstraint!
    @IBOutlet var innerViewBottom: NSLayoutConstraint!
    @IBOutlet var innerViewLeading: NSLayoutConstraint!
    @IBOutlet var innerViewTop: NSLayoutConstraint!
    
    @IBOutlet var titleTop: NSLayoutConstraint!
    @IBOutlet var titleHeight: NSLayoutConstraint!
    @IBOutlet var typesLabelTop: NSLayoutConstraint!
    
    
    var viewModel : ContactUsViewModel!
    var typesDialog : TableDialog!
    var model : ContactUsModel!
    var isFeedback = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if (viewModel == nil)
        {
            viewModel = ContactUsViewModel()
            viewModel.loadFromDB()
            model = viewModel.model
        }
        
        if(isFeedback)
        {
            typesLabel.textAlignment = .center
            line.backgroundColor = UIColor.clear
            expandImage.image = UIImage(named: "")
        }
        else
        {
            let onClick = UITapGestureRecognizer(target: self, action: #selector(ContactUsViewController.onClickTypeLabel))
            typesView.isUserInteractionEnabled = true
            typesView.addGestureRecognizer(onClick)
            
            if(self.model != nil && self.model.types.count > 0)
            {
                viewModel.selectedType = self.model.types[0]
            }
            
            expandImage.image = UIImage(named: "ic_spinner_expand_gray")?.withRenderingMode(.alwaysTemplate)
            expandImage.tintColor = UIColor(model.tintColor)
            
            line.backgroundColor = UIColor.clear //UIColor(model.tintColor)
        }
        
        if(selectedTab.hasBackgroundImage)
        {
            let data = parameterizationDatabase.getBackgroundImage(apk: APK)
            
            if(data != nil)
            {
                backgroundImage.image = UIImage(data: data!)
            }
        }
        
        let onSendClick = UITapGestureRecognizer(target: self, action: #selector(ContactUsViewController.onSendClick))
        sendButton.isUserInteractionEnabled = true
        sendButton.addGestureRecognizer(onSendClick)
        
        infoTable.rowHeight = UITableViewAutomaticDimension
        infoTable.tableFooterView = UIView()
        infoTable.delegate = self
        infoTable.dataSource = self
        
        let font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
        
        var titleHeightSize : CGFloat = 40
        
        if(font != nil)
        {
            titleHeightSize = selectedTab.name.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 20
        }
        
        titleHeight.constant = titleHeightSize
        if(titleHeightSize > 40)
        {
            typesLabelTop.constant = typesLabelTop.constant + titleHeightSize - 40
        }
        
        titleLabel.text = selectedTab.name
        titleLabel.backgroundColor = Colors.titleBackround
        titleLabel.textColor = Colors.titleTextColor
        titleLabel.font = font
        
        
        splitter.backgroundColor = Colors.titleSplitterColor
        
        typesLabel.text = viewModel.model.typeTitle
        typesLabel.textColor = UIColor(model.typeTextColor)
        typesLabel.font = UIFont (name: (model.typeFont)!, size: CGFloat((model.typeTextSize)!))

        messageLabel.text = model.messageTitle
        messageLabel.textColor = UIColor(model.messageTextColor)
        messageLabel.font = UIFont (name: (model.messageFont)!, size: CGFloat((model.messageTextSize)!))
        
        messageTextView.textColor = UIColor(model.messageTextColor)
        messageTextView.font = UIFont (name: (model.messageFont)!, size: CGFloat((model.messageTextSize)!))
        messageTextView.layer.borderColor = UIColor(model.tintColor).cgColor
        messageTextView.layer.borderWidth = 1.0
        messageTextView.layer.cornerRadius = 5.0
        messageTextView.delegate = self
        
        sendButton.setTitle(model.buttonText, for: .normal)
        sendButton.backgroundColor = UIColor(model.buttonBackgroundColor)
        sendButton.setTitleColor(UIColor(model.buttonTextColor), for: .normal)
        let buttonFont = UIFont(name: model.buttonFont, size: CGFloat( model.buttonTextSize))
        sendButton.titleLabel?.font = buttonFont
        sendButtonWidth.constant = (model.buttonText as NSString).size(withAttributes: [NSAttributedStringKey.font: buttonFont]).width + 30
        sendButton.center.x = infoTable.center.x
        
        sendButton.layer.borderWidth = CGFloat(model.buttonBorderWidth)
        sendButton.layer.borderColor = UIColor(model.buttonBorderColor).cgColor
        
        infoTable.frame.size.height = CGFloat(40 * model.info.count)
        self.hideKeyboardWhenTappedAround()
        
        if(borderWidth != nil && borderWidth > 0)
        {
            innerViewTop.constant = CGFloat(borderWidth)
            innerViewBottom.constant = CGFloat(borderWidth)
            innerViewLeading.constant = CGFloat(borderWidth)
            innerViewTrailing.constant = CGFloat(borderWidth)
            
            if(titleTopPadding != nil)
            {
                titleTop.constant = titleTopPadding
            }
            
            
            self.view.backgroundColor = UIColor(borderColor)
        }

        // Do any additional setup after loading the view.
    }
    
    var viewIsDisplayed = false
    
    override func viewDidLayoutSubviews() {
        if(viewIsDisplayed)
        {
            super.viewDidAppear(true)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewIsDisplayed = true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.info.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contact_us_info_cell") as! ContactUsViewCell
        
        switch model.info[indexPath.row].type {
        case 1:
            cell.infoImage.image = UIImage(named: "ic_email")?.withRenderingMode(.alwaysTemplate)
            cell.infoImage.tintColor = UIColor(model.infoTextColor)
        case 2:
            cell.infoImage.image = UIImage(named: "ic_phone")?.withRenderingMode(.alwaysTemplate)
            cell.infoImage.tintColor = UIColor(model.infoTextColor)
        default:
            break
        }
        
        cell.label.text = model.info[indexPath.row].info
        cell.label.font = UIFont (name: (model.infoFont)!, size: CGFloat((model.infoTextSize)!))
        cell.label.textColor = UIColor(model.infoTextColor)
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch model.info[indexPath.row].type {
        case 1:
            break
        case 2:
            if(model.info[indexPath.row].info != nil)
            {
                UIApplication.shared.openURL(URL(string: "tel://" + model.info[indexPath.row].info!)!)
            }
        default:
            break
        }
    }
    
    @objc func onClickTypeLabel(sender:UITapGestureRecognizer) {
        let sb = UIStoryboard(name:"TableDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        typesDialog = dialog as? TableDialog
        self.present(dialog,animated:true)
        typesDialog.delegate = self
        typesDialog.setDialogView(title: "SUBJECTS", types: StaticDataRepository.getSupportTypesStrings(types: self.model.types ), selectedType: viewModel.selectedType )
    }
    
    
    @objc func onSendClick(sender:UITapGestureRecognizer) {
        if(!localDatabase.isAPKVerified(clientID: clientID))
        {
            let s = ShowRegistrationDialog()
            s.viewController = leftDrawer
            s.showRegistrationDialog()
        }
        else if(viewModel.selectedType == "")
        {
            let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()! as! MessageDialog
            self.present(dialog,animated:true)
            dialog.setDialogView(title: "Incomplete data", description: "Please choose subject." , buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
        }
        else if (isNullOrEmpty(string: messageTextView.text.replacingOccurrences(of: " ", with: "").replacingOccurrences(of: "\n", with: "")))
        {
            let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()! as! MessageDialog
            self.present(dialog,animated:true)
            dialog.setDialogView(title: "Incomplete data", description: "Please enter a message." , buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
        }
        else
        {
            let task = WebApiTask(viewController : self, action : submitMessage, displayToast : true)
            task.setFailureAction(action: showStatusMessage)
            task.start()
        }
    }
    
    /// Show custom toast with message.
    private func showStatusMessage ()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
            let dialog = sb.instantiateInitialViewController()! as! MessageDialog
            self.present(dialog,animated:true)
            dialog.setDialogView(title: "Result", description: self.viewModel.verificationMessage , buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: false)
        })
    }
    
    func submitMessage()
    {
        DispatchQueue.main.async(execute: {() -> Void in
            let message : String! = self.messageTextView.text!
            var type : String!
            
            if(self.isFeedback)
            {
                type = "FEEDBACK"
            }
            else
            {
                type = self.typesLabel.text!
            }
            
            DispatchQueue.global(qos: .background).async {
                self.viewModel.submitMessage(type: type, message: message )
                self.showStatusMessage()
            }
        })
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    /// Dismiss dialog.
    func dismissed() {
        viewModel.selectedType = typesDialog.selectedType
        if(viewModel.selectedType != "")
        {
            typesLabel.text = viewModel.selectedType
        }
    }
    

}
