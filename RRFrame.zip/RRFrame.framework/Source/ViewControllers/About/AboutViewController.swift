//
//  AboutViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 08/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates view where user can read information's about app.
class AboutViewController: ViewController  {

    @IBOutlet weak var offersLabel: UILabel!
    @IBOutlet weak var loyaltyLabel: UILabel!
    @IBOutlet weak var notesLabel: UILabel!
    @IBOutlet weak var websiteLabel: UILabel!
    @IBOutlet weak var privacyPolicyLabel: UILabel!
    @IBOutlet weak var appVersionNameLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        //Customize labels
        offersLabel.layer.borderColor = UIColor.lightGray.cgColor
        offersLabel.layer.borderWidth = 0.8
        //offersLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        loyaltyLabel.layer.borderColor = UIColor.lightGray.cgColor
        loyaltyLabel.layer.borderWidth = 0.8
        //loyaltyLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        notesLabel.layer.borderColor = UIColor.lightGray.cgColor
        notesLabel.layer.borderWidth = 0.8
        //notesLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        websiteLabel.layer.borderColor = UIColor.lightGray.cgColor
        websiteLabel.layer.borderWidth = 0.8
        //websiteLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        privacyPolicyLabel.layer.borderColor = UIColor.lightGray.cgColor
        privacyPolicyLabel.layer.borderWidth = 0.8
        //privacyPolicyLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        
        appVersionNameLabel.font = UIFont.boldSystemFont(ofSize: 14.0)
        
        //Sets click listeners on labels
        var onClick = UITapGestureRecognizer(target: self, action: #selector(AboutViewController.onClickOffersLabel))
        offersLabel.isUserInteractionEnabled = true
        offersLabel.addGestureRecognizer(onClick)
        
        onClick = UITapGestureRecognizer(target: self, action: #selector(AboutViewController.onClickLoyaltyLabel))
        loyaltyLabel.isUserInteractionEnabled = true
        loyaltyLabel.addGestureRecognizer(onClick)
        
        onClick = UITapGestureRecognizer(target: self, action: #selector(AboutViewController.onClickNotesLabel))
        notesLabel.isUserInteractionEnabled = true
        notesLabel.addGestureRecognizer(onClick)
        
        onClick = UITapGestureRecognizer(target: self, action: #selector(AboutViewController.onClickWebsiteLabel))
        websiteLabel.isUserInteractionEnabled = true
        websiteLabel.addGestureRecognizer(onClick)
        
        onClick = UITapGestureRecognizer(target: self, action: #selector(AboutViewController.onClickPrivacyPlicyLabel))
        privacyPolicyLabel.isUserInteractionEnabled = true
        privacyPolicyLabel.addGestureRecognizer(onClick)
        
        //Set the version label
        let nsObject = Bundle.main.infoDictionary?["CFBundleShortVersionString"]
        let version = nsObject as! String
        appVersionNameLabel.text = appVersionNameLabel.text! + " " + version
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @objc func onClickOffersLabel(sender:UITapGestureRecognizer) {
        showDialog(title: offersLabel.text!,description: NSLocalizedString("offersDescription", comment: ""))
    }
    
    @objc func onClickLoyaltyLabel(sender:UITapGestureRecognizer) {
        showDialog(title: loyaltyLabel.text!,description: NSLocalizedString("loyaltyDescription", comment: ""))
    }
    
    @objc func onClickNotesLabel(sender:UITapGestureRecognizer) {
        showDialog(title: notesLabel.text!,description: NSLocalizedString("notesDescription", comment: ""))
    }
    
    @objc func onClickWebsiteLabel(sender:UITapGestureRecognizer) {
        if let checkURL = NSURL(string: NSLocalizedString("websiteLink", comment: "")) {
            //restartApp = false
           UIApplication.shared.openURL(checkURL as URL)
        }
    }
    
    @objc func onClickPrivacyPlicyLabel(sender:UITapGestureRecognizer) {
        if let checkURL = NSURL(string: NSLocalizedString("privacyPolicyLink", comment: "")) {
            //restartApp = false
            UIApplication.shared.openURL(checkURL as URL)
        }
    }
    
    func showDialog(title: String, description: String ){
        let sb = UIStoryboard(name:"DescriptionDialog",bundle:nil)
        let dialog = sb.instantiateInitialViewController()!
        let dialogViewController = dialog as! DescriptionDialog
        self.present(dialog,animated:true)
        dialogViewController.setDialogView(title: title, description: description)
    }
}
