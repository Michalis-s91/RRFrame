//
//  OfferInformationViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher
import MapKit

class InformationsViewController: ViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var offerInfoTableView: UITableView!
    @IBOutlet var map: MKMapView!
    
    var viewModel : OfferInformationViewModel!
    var partnerInfoViewModel : PartnerInfoViewModel!
    
    var isOfferImageStoredInStorage = false
    var task : WebApiTask!
    var offer = OfferModel()
    var currentImagePos = 0
    var previousX = 0
    //var ScrollView partnerInformationScrollView
    var imagesUrls : [String]!
    var offersList : [OfferItemModel]!
    
    var storesTableView : UITableView!
    
    var isPartnerInformationView = false
    var navController : UINavigationController!
    var isFirstTime = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepare(for:  UIStoryboardSegue(identifier: "a",source: UIViewController() ,destination: UIViewController()), sender: nil)
        
        //offerInfoTableView.rowHeight = UITableViewAutomaticDimension
        offerInfoTableView.tableFooterView = UIView()
        offerInfoTableView.delegate = self
        offerInfoTableView.dataSource = self
        

        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        

        
        if(isFirstTime)
        {
            if(!isPartnerInformationView)
            {
                viewModel = OfferInformationViewModel(offer: &offer, viewController: self)
                self.title = viewModel.title
            }
            else
            {
                self.title = partnerInfoViewModel.title
            }
            let titleFont = UIFont(name: "UIFontWeightRegular", size: 15) ?? UIFont.systemFont(ofSize: 15)
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
            
            
            if(!isPartnerInformationView)
            {
                task = WebApiTask(viewController: self, action: loadOfferInformation, displayToast: true)
                task.errorMessage = NSLocalizedString("offerInformationSyncError", comment: "")
                task.start()
            }
        }
        else
        {
            if(!isPartnerInformationView)
            {
                self.title = viewModel.title
            }
            else
            {
                self.title = partnerInfoViewModel.title
            }
        }
        
        isFirstTime = false
    }
    
    func loadOfferInformation()
    {
        viewModel.loadFromInternet()
        
        if (!isActivityActive(viewController: self))
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.offerInfoTableView.reloadData()
        })
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(!isPartnerInformationView)
        {
            return viewModel.informationsList.count
        }
        else
        {
            return partnerInfoViewModel.informationsList.count
        }
    }
    
    var image : UIImageView!
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var information : GeneralInformation!
        
        if(!isPartnerInformationView)
        {
            information = viewModel.informationsList[indexPath.row]
        }
        else
        {
            information = partnerInfoViewModel.informationsList[indexPath.row]
        }
        
        switch information.type {
        case InformationType.Title.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_title") as! OfferInfoTitleViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = information.title
            return cell
        case InformationType.Image.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_image") as! OfferInfoImageViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            let url = URL(string: percentEncode(s: information.imageUrl))
            cell.offerImage.kf.setImage(with: url)
            image = cell.offerImage
            imageCell = cell
            return cell
        case InformationType.Description.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_description") as! OfferInfoDescriptionViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            //cell.titleLabel.text = "ERP Reference Code"
            //cell.descriptionLabel.text = viewModel.erpReferenceCode
            cell.titleLabel.text = information.title
            cell.descriptionLabel.text = information.description
            return cell
        case InformationType.Discount.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_discount") as! OfferInfoDiscountViewCell
            
            cell.titleLabel.text = information.title
            cell.originalPriceTitleLabel.text = information.originalPriceTitle
            cell.originalPriceTextLabel.text = information.originalPriceText
            cell.offerDescriptionTextLabel.text = information.offerDescriptionText
            cell.offerNewPriceLabel.text = information.offerNewPrice
            cell.strike.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi/8))
            
            if(!viewModel.isStrikeThrough && !viewModel.isSetOffer)
            {
                cell.strike.removeFromSuperview()
            }
            
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case InformationType.Stores.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_table") as! OfferInfoStoresViewCell
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = information.title
            if(information.stores != nil)
            {
                cell.stores = information.stores
                cell.storesTableView.reloadData()
                cell.navigationController = self.navigationController
            }
            else
            {
                cell.stores = []
                cell.notAvailableStoresLabel.text = NSLocalizedString("noAvailablePointsOfSales", comment: "")
            }
            
            storesTableView = cell.storesTableView
            //tableCell.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
            return cell
        case InformationType.Facebook.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_facebook") as! OfferInfoFacebookViewCell
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = information.title
            //cell.websiteLabel.text = information.website
            
            if(information.website != NSLocalizedString("noAvailableWebsite", comment: ""))
            {
                cell.websiteLabel.attributedText =  NSAttributedString(string: information.website, attributes:[.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
                cell.websiteLabel.textColor = Colors.blue
            }
            else
            {
                cell.websiteLabel.text = information.website
            }
            
            if(!information.isHasFacebookPage)
            {
                cell.facebookImage.removeFromSuperview()
            }
            
            cell.facebookPage = information.facebookPage
            cell.facebookPageID = information.facebookPageID
            
            return cell
        case InformationType.Combo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_info_combo") as! OfferInfoComboViewCell
            
            cell.appOfferID = information.appOfferID
            cell.setImages()
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        default:
            return tableView.dequeueReusableCell(withIdentifier: "offer_info_title") as! OfferInfoTitleViewCell
        }
        
    }
    
    var imageCell : OfferInfoImageViewCell!
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var information : GeneralInformation!
        
        if(!isPartnerInformationView)
        {
            information = viewModel.informationsList[indexPath.row]
        }
        else
        {
            information = partnerInfoViewModel.informationsList[indexPath.row]
        }
        
        if (information.type == InformationType.Stores.rawValue)
        {
            storesTableView.layoutIfNeeded()
            let heightOfTableView: CGFloat = storesTableView.contentSize.height
            
            
            //self.storesTableView.layoutIfNeeded()
            
            // Get visible cells and sum up their heights
            /*let cells = self.storesTableView.visibleCells
             for i in 0..<2 {
             print(i)
             heightOfTableView += (storesTableView.cellForRow(at: IndexPath(row: i, section: i))?.frame.height)!
             }*/
            
            print(heightOfTableView)
            if(information.stores.count > 0)
            {
                return 32 + (CGFloat(information.stores.count) * 73)
            }
            else
            {
                return 51
            }
        }
        else if (information.type == InformationType.Combo.rawValue)
        {
            return 160
        }
        else if (information.type == InformationType.Image.rawValue)
        {
            //image.image = scaleUIImageToSize(image: image.image!, size: CGSize(width: 200, height: 200))
            
            image.layoutIfNeeded()
            print(image.frame.height)
            imageCell.layoutIfNeeded()
            return UITableViewAutomaticDimension
        }
        else
        {
            return UITableViewAutomaticDimension
        }
    }
    
    func scaleUIImageToSize( image: UIImage, size: CGSize) -> UIImage {
        let hasAlpha = false
        let scale: CGFloat = 0.0 // Automatically use scale factor of main screen
        
        UIGraphicsBeginImageContextWithOptions(size, !hasAlpha, scale)
        image.draw(in: CGRect(origin: CGPoint.zero, size: size))
        
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return scaledImage!
    }
    
    
    func setOffer(offer : OfferModel)
    {
        self.offer = offer
    }
    
}
