//
//  InformationsViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 25/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class InformationsViewController: ViewController {
    
    @IBOutlet var informationContainer: UIView!
    
    var informationsView : InformationsView!
    var offer = OfferModel()
    var isPartnerInformationView = false
    var partnerInfoViewModel : PartnerInfoViewModel!
    var navController : UINavigationController!
    var parentNavigationController : UINavigationController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        isViewPushed = false
    }
    
    override func viewDidAppear(_ animated: Bool) {        
        informationsView = self.storyboard?.instantiateViewController(withIdentifier: "InformationView") as? InformationsView
        informationsView.container = self.informationContainer
        informationsView.parentController = self
        
        informationsView.offer = self.offer
        informationsView.isPartnerInformationView = isPartnerInformationView
        informationsView.partnerInfoViewModel = partnerInfoViewModel
        informationsView.navController = navController
        
        if(parentNavigationController == nil)
        {
            informationsView.parentNavigationController = self.navigationController
        }
        else
        {
            informationsView.parentNavigationController = parentNavigationController
        }
        
        if(self.informationContainer.subviews.count == 1)
        {
            informationsView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (informationContainer?.frame.height)!)
            informationsView.willMove(toParentViewController: self)
            self.informationContainer?.addSubview((informationsView.view)!)
            //self.addChildViewController(wishListView)
            informationsView.didMove(toParentViewController: self)
            //loyaltyStatementView.loyaltyStatementContainer = loyaltyStatementContainer
            //loyaltyStatementView.parentNavigationController = self.navigationController
        }
    }
    
    func setOffer(offer : OfferModel)
    {
        self.offer = offer
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
}
