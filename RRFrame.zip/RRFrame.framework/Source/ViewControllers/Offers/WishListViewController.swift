//
//  WishListViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Creates a view with container and is been used for showing the wish list view.
class WishListViewController: ViewController {
    @IBOutlet var wishListContainer: UIView!
    
    var wishListView : WishListView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(self.wishListContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"WishListView",bundle:nil)
            wishListView = storyBoard.instantiateInitialViewController() as? WishListView
            wishListView.parentNavigationController = self.navigationController
            wishListContainer.frame = CGRect(x: 0, y: UIApplication.shared.statusBarFrame.height + (self.navigationController?.navigationBar.frame.size.height)!, width: UIScreen.main.bounds.size.width, height: ((wishListContainer?.frame.height)! - 50))
            wishListView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (wishListContainer?.frame.height)!)
            wishListView.willMove(toParentViewController: self)
            self.wishListContainer?.addSubview((wishListView.view)!)
            //self.addChildViewController(wishListView)
            wishListView.didMove(toParentViewController: self)
            wishListView.wishListContainer = wishListContainer
        }
        
        navigation = self.navigationController
        //CustomTabbarViewController2.navigationControllers[1] = navigationController!
        
        if(selectedTab != nil && tabIndex != nil && tabIndex != -1)
        {
            checkForTabBar(tab : selectedTab, index: tabIndex)
        }
        
        if(CustomTabbarViewController.navigationControllers != nil && CustomTabbarViewController.navigationControllers.count > tabIndex)
        {
            //CustomTabbarViewController2.navigationControllers[tabIndex] = self.navigationController!
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        showHideLeftDrawer()
    }
}
