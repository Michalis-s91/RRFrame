//
//  OptInHistoryView.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates opt in history view. Here, user can see what partners set as favourite or un-favourite and when he did that.
class OptInHistoryView: OptInHistoryViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var optInHistoryTable: UITableView!
    
    //var notAvailableView : NotAvailableViewController!
    var viewModel : OptInHistoryViewModel!
    var task : WebApiTask!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        optInHistoryTable.tableFooterView = UIView()
        optInHistoryTable.delegate = self
        optInHistoryTable.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if (viewModel == nil)
        {
            viewModel = OptInHistoryViewModel()
            
            self.container = self.optInHistoryContainer
            task = WebApiTask(viewController: self, action: loadOptInHistory)
            task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
            task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: self.optInHistoryContainer)
            task.start()
        }
        else
        {
            setNotAvailableView()
        }
        

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 0
        }
        else
        {
            return viewModel.optInHistoryList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "optin_cell") as! OptInHistoryViewCell
        
        let optInModel = viewModel.optInHistoryList[indexPath.row]
        
        cell.nameLabel.text = optInModel.name
        cell.timeStampLabel.text = optInModel.timeStamp
        
        if(optInModel.isFavourite)
        {
            cell.isFavouriteImage.image = UIImage(named: "ic_favourite_filled")
        }
        else
        {
            cell.isFavouriteImage.image = UIImage(named: "ic_favourite")
        }
        
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    /// Loads optin history information from internet and displays them
    func loadOptInHistory()
    {
        viewModel.loadFromInternet()
        
        if(!isActivityActive(viewController: self) && CustomTabbarViewController.navigationControllers.count == 0)
        {
            return
        }
        
        if(viewModel.optInHistoryList != nil && viewModel.optInHistoryList.count > 0)
        {
            DispatchQueue.main.async(execute: {() -> Void in
                self.optInHistoryTable.reloadData()
                self.optInHistoryTable.scrollToRow( at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                self.setNotAvailableView()
            })
        }
        else
        {
            DispatchQueue.main.async(execute: {() -> Void in
                self.setNotAvailableView()
            })
        }
    }
    
    
    /// Checks opt in history list and sets the not available view.
    private func setNotAvailableView()
    {
        if (viewModel.optInHistoryList == nil || viewModel.optInHistoryList.count == 0)
        {
            notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: container!, text: NSLocalizedString("noAvailableOptInHistory", comment: ""))
        }
        else
        {
            if(notAvailableView != nil)
            {
                notAvailableView.view.removeFromSuperview()
            }
        }
    }
    
    /// This function is been call when user clicks a bar button item from navigation.
    func onOptionsItemSelected()
    {
        task = WebApiTask(viewController: self, action: loadOptInHistory, displayToast: true)
        task.successMessage = NSLocalizedString("synchronizationCompleted", comment: "")
        task.errorMessage = NSLocalizedString("noDataLoaded", comment: "")
        task.start()
    }
}
