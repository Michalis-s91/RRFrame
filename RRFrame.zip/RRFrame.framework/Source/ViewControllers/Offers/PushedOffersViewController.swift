//
//  PushedOffersViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 27/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates view for pushed offers.
class PushedOffersViewController: ViewController {

    @IBOutlet var leftDrawerItem: UIBarButtonItem!
    @IBOutlet var pushedOffersContainer: UIView!
    
    @IBOutlet var barItem: UIBarButtonItem!
    
    
    var offersView : OffersView!
    var partnerTemp : PartnerModel!
    var partnerName : String!
    //var campaingID : Int64!
    //var partnerName : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let titleFont = UIFont(name: "UIFontWeightRegular", size: 16) ?? UIFont.systemFont(ofSize: 16)
        
        if(self.navigationController != nil && self.navigationController?.navigationBar != nil)
        {
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
        }
        
        navigation = self.navigationController
        
        if(!wasAppClosed)
        {
            leftDrawerItem.image = UIImage(named : "ic_back" )
        }
        else
        {
            //currentViewController = nil
            //currentViewController2 = nil
            navigation = nil
        }
        
        if(APK == APKsEnum.RichReach.rawValue)
        {
            if(partnerName != nil)
            {
                self.title = partnerName
            }
            else if(header != nil)
            {
                self.title = header
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(self.pushedOffersContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"OffersView",bundle:nil)
            offersView = storyBoard.instantiateViewController(withIdentifier: "offers_view") as? OffersView
            offersView.isPushedOffers = true
            offersView.campaingID = campaingID
            pushedOffersContainer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((pushedOffersContainer?.frame.height)!))
            offersView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (pushedOffersContainer?.frame.height)!)
            offersView.willMove(toParentViewController: self)
            self.pushedOffersContainer?.addSubview((offersView.view)!)
            self.addChildViewController(offersView)
            offersView.didMove(toParentViewController: self)
            offersView.parentNavigationController = self.navigationController
            offersView.isPushedOffers = true
            offersView.offersContainer = pushedOffersContainer
            offersView.container = pushedOffersContainer
        }
        
        if(wasAppClosed)
        {
            for t in leftDrawer.leftDrawerTabsList
            {
                if(t.type == LeftDrawerTabsType.Notifications.rawValue)
                {
                    leftDrawer.selectTab(tabString: t.name)
                    selectedTab = t
                    break
                }
            }
            
        }
    }

    @IBAction func onBackClick(_ sender: UIBarButtonItem) {
        isViewPushed = false
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        if(!wasAppClosed)
        {
            isViewPushed = false
            if(!hasActivityBeenCreatedFromNotificationsView)
            {
                navigationController?.popViewController(animated: true)
            }
            else
            {
                var leftDrawerTabsList : [Tab]! = []
                leftDrawerTabsList = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
                
                if(leftDrawerTabsList != nil)
                {
                    var firstTab : Tab!
                    
                    for t in leftDrawerTabsList
                    {
                        if(t.isVissible)
                        {
                            firstTab = t
                            break
                        }
                    }
                    
                    if(!firstTab.isParent)
                    {
                        /*//self.window = UIWindow(frame: UIScreen.main.bounds)
                        separatorHeight = firstTab.separatorHeight
                        separatorColor = firstTab.separatorColor
                        let storyboard = UIStoryboard(name: firstTab.storyboardName , bundle: nil)
                        let viewController = storyboard.instantiateViewController(withIdentifier: firstTab.viewID) as! UINavigationController
                        
                        //viewController.campaingID = notification.campaignID
                        //viewController.partnerName = notification.header
                        
                        //currentController.navigationController?.pushViewController(viewController, animated: true)
                        
                        UIApplication.shared.keyWindow?.rootViewController = viewController
                        UIApplication.shared.keyWindow?.makeKeyAndVisible()*/
                        
                        separatorHeight = firstTab.separatorHeight
                        separatorColor = firstTab.separatorColor
                       
                        
                        leftDrawer.selectTab(tabString: firstTab.name)
                        leftDrawer.currentTab = firstTab.name
                        selectedTab = firstTab
                    }
                    else
                    {
                        var relations : [PCRelation]!
                        relations = parameterizationDatabase.getPCRelations(apk: APK)
                        
                        for r in relations!
                        {
                            if (r.parentID == firstTab.id)
                            {
                                for t in leftDrawerTabsList
                                {
                                    if(t.id == r.childID && t.isVissible)
                                    {
                                        /*separatorHeight = t.separatorHeight
                                        separatorColor = t.separatorColor
                                        //self.window = UIWindow(frame: UIScreen.main.bounds)
                                        let storyboard = UIStoryboard(name: t.storyboardName , bundle: nil)
                                        let viewController = storyboard.instantiateViewController(withIdentifier: t.viewID) as! UINavigationController
                                        
                                        //viewController.campaingID = notification.campaignID
                                        //viewController.partnerName = notification.header
                                        
                                        //currentController.navigationController?.pushViewController(viewController, animated: true)
                                        
                                        UIApplication.shared.keyWindow?.rootViewController = viewController
                                        UIApplication.shared.keyWindow?.makeKeyAndVisible()
                                        
                                        //self.window?.rootViewController = viewController
                                        //self.window?.makeKeyAndVisible()*/
                                        
                                        separatorHeight = t.separatorHeight
                                        separatorColor = t.separatorColor
                                        
                                        leftDrawer.selectTab(tabString: t.name)
                                        leftDrawer.currentTab = t.name
                                        selectedTab = t
                                        
                                        return
                                    }
                                }
                            }
                        }
                    }
                }
                
                navigationController?.popToRootViewController(animated: true)
            }
        }
        else
        {
            showHideLeftDrawer()
             isViewPushed = false
        }
        
    }
}
