//
//  AllPartnersViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Creates a view with container and is been used for showing the all partners view.
class AllPartnersViewController: ViewController {
    
    @IBOutlet var allPartnersContainer: UIView!
    @IBOutlet var refreshItem: UIBarButtonItem!
    @IBOutlet var leftDrawerButton: UIBarButtonItem!
    
    @IBOutlet var containerBottom: NSLayoutConstraint!
    
    var allPartnersView : AllPartnersView!
    var containerHeight : CGFloat!
    var changed = false
    
    var synchronized2 = Synchronized()
    var lock2 = NSObject()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(self.allPartnersContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"AllPartnersView",bundle:nil)
            allPartnersView = storyBoard.instantiateInitialViewController() as? AllPartnersView
            allPartnersView.parentView = self
            //print(allPartnersContainer.frame.height)
            if(!AllPartnersView.displayLoyaltyPartnersOnly)
            {
                //allPartnersContainer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((allPartnersContainer?.frame.height)! - 50))
                
                containerBottom.constant = 50
                allPartnersView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((allPartnersContainer?.frame.height)!))
                containerHeight = allPartnersContainer.frame.height
            }
            else
            {
                //allPartnersContainer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((allPartnersContainer?.frame.height)! + 50))
                //allPartnersView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((allPartnersContainer?.frame.height)!))
                containerBottom.constant = 0
                allPartnersView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((allPartnersContainer?.frame.height)!))
                containerHeight = allPartnersContainer.frame.height
            }
            //print(allPartnersContainer.frame.height)
            allPartnersView.willMove(toParentViewController: self)
            self.allPartnersContainer?.addSubview((allPartnersView.view)!)
            //self.addChildViewController(allPartnersView)
            allPartnersView.didMove(toParentViewController: self)
            allPartnersView.allPartnersContainer = self.allPartnersContainer
            allPartnersView.container = allPartnersContainer
            allPartnersView.refreshItem = refreshItem
        }
        else
        {
            self.addChildViewController(self.allPartnersView)
        }
        
        navigation = self.navigationController
        
        if(!AllPartnersView.displayLoyaltyPartnersOnly)
        {            
            if(CustomTabbarViewController.navigationControllers.count > 0)
            {
                //CustomTabbarViewController2.navigationControllers[0] = navigationController!
            }
        }

        
        if(!AllPartnersView.displayLoyaltyPartnersOnly)
        {
            if(selectedTab != nil && tabIndex != nil && tabIndex != -1)
            {
                checkForTabBar(tab : selectedTab, index: tabIndex)
                
                if(CustomTabbarViewController.navigationControllers != nil && CustomTabbarViewController.navigationControllers.count > tabIndex )
                {
                    CustomTabbarViewController.navigationControllers[tabIndex] = self.navigationController!
                }
            }
            //self.showTabbar(index : 0 )
        }
    }
    
    func loop()
    {
        DispatchQueue.global(qos: .background).async {
            for _ in 0...1000000
            {
                //sleep(10)
                //taskTemp.stop()
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        /*let backItem = UIBarButtonItem()
        backItem.title = ""
        backItem.image = UIImage(named : "ic_back")
        navigationItem.backBarButtonItem = backItem*/
        
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        UIView.setAnimationsEnabled(false)
        coordinator.notifyWhenInteractionEnds {_ in
            UIView.setAnimationsEnabled(true)
        }
        
        coordinator.animate(alongsideTransition: nil, completion: {
            _ in
            usleep(50000)
            UIView.setAnimationsEnabled(true)
            if(!AllPartnersView.displayLoyaltyPartnersOnly)
            {
                if(selectedTab != nil && tabIndex != nil)
                {
                    self.checkForTabBar(tab : selectedTab, index: tabIndex)
                }
                //self.showTabbar(index: 0)
            }
        })
        
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
        taskTemp = nil
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func refreshClicked(_ sender: UIBarButtonItem) {
        allPartnersView.onOptionsItemSelected()
    }
}
