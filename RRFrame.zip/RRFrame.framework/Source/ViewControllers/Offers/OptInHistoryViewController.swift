//
//  OptInHistoryViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Creates a view with container and is been used for showing the opt in history view.
class OptInHistoryViewController: ViewController {

    @IBOutlet var optInHistoryContainer: UIView!
    
    var optInHistoryView : OptInHistoryView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //self.showTabbar(index : 2)
        navigation = self.navigationController
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(self.optInHistoryContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"OptInHistoryView",bundle:nil)
            optInHistoryView = storyBoard.instantiateInitialViewController() as? OptInHistoryView
            optInHistoryContainer.frame = CGRect(x: 0, y: UIApplication.shared.statusBarFrame.height + (self.navigationController?.navigationBar.frame.size.height)!, width: UIScreen.main.bounds.size.width, height: ((optInHistoryContainer?.frame.height)! - 50))
            optInHistoryView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (optInHistoryContainer?.frame.height)!)
            optInHistoryView.willMove(toParentViewController: self)
            self.optInHistoryContainer?.addSubview((optInHistoryView.view)!)
            //self.addChildViewController(wishListView)
            optInHistoryView.didMove(toParentViewController: self)
            optInHistoryView.optInHistoryContainer = optInHistoryContainer
        }
        
        navigation = navigationController
        //CustomTabbarViewController2.navigationControllers[2] = navigationController!
        
        if(selectedTab != nil && tabIndex != nil)
        {
            checkForTabBar(tab : selectedTab, index: tabIndex)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func syncCliked(_ sender: UIBarButtonItem) {
        optInHistoryView.onOptionsItemSelected()
    }
}
