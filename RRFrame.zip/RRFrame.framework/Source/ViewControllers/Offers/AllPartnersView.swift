//
//  AllPartnersView.swift
//  RichReach2
//
//  Created by Eumbrella on 06/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher


/// Creates view that displays all partners.
class AllPartnersView: AllPartnersViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet var partnersTableView: UITableView!
    
    var viewModel : AllPartnersViewModel!
    var lock = NSObject()
    var ignorePartnersListViewClicks = false
    var ignoreLoadingMoreData = false
    var partnersListCount = 0
    var partnersFragment : ViewController!
    var task : WebApiTask!
    var previousPartnersListSize = 0
    var partnersView : AllPartnersView!
    static var displayLoyaltyPartnersOnly = false
    
    //var notAvailableView : NotAvailableViewController!
    
    var refreshCtrl: UIRefreshControl!
    var tableData:[AnyObject]!
    var task2: URLSessionDownloadTask!
    var session: URLSession!
    var cache:NSCache<AnyObject, AnyObject>!
    var synchronized : Synchronized = Synchronized()
    var parentView : AllPartnersViewController!
    
    var selectedPartner : PartnerModel = PartnerModel()
    var isFirstTime = true
    var isExit = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addToParentView()
        partnersTableView.rowHeight = UITableViewAutomaticDimension
        partnersTableView.tableFooterView = UIView()
        partnersTableView.delegate = self
        partnersTableView.dataSource = self
        
        
        partnersView = self
        if (viewModel == nil)
        {
            viewModel = AllPartnersViewModel(viewController: self)
        }
        
        session = URLSession.shared
        task2 = URLSessionDownloadTask()
        
        self.cache = NSCache()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        isExit = true
        partnersTableView.reloadData()
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(isFirstTime)
        {
            isFirstTime = !isFirstTime
            
            task = WebApiTask(viewController: self, action: loadPartners)
            task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
            task.shouldDisplayNotAvailableView (shouldDisplayNotAvailableView : true, container : allPartnersContainer!)
            task.start()
        }
        else
        {
            //addToParentView()
        }
        
        //setNotAvailableView()
        setCurrentAppVersion()
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        setNeedsStatusBarAppearanceUpdate()
        if(isExit)
        {
            removeFromParentView()
            
            if (task != nil)
            {
                task.stop()
            }
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        UIView.setAnimationsEnabled(false)
        coordinator.notifyWhenInteractionEnds {_ in UIView.setAnimationsEnabled(true)}
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel.partnersList == nil)
        {
            return 0
        }
        else
        {
            return viewModel.partnersList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "partner_cell2") as! PartnerViewCell
        let index = indexPath.row
        let partner = viewModel.partnersList[index]
        
        if((index == 0 || partner.industryID != viewModel.partnersList[index - 1].industryID) && viewModel.partnersList[index].industryName != "")
        {
            cell.categoryViewheight.constant = 20
            cell.categoryView.backgroundColor = Colors.categoryColor
            cell.categoryLabel.text = partner.industryName
        }
        else
        {
            cell.categoryViewheight.constant = 0
        }
        
        cell.partner = viewModel.partnersList[index]
        cell.viewController = self
        cell.viewModel = viewModel
        
        let url = URL(string: percentEncode(s: partner.imageUri))
        cell.partnerImage.kf.setImage(with: url)
        //cell.partnerImage.downloadImageFromUrl(partner.imageUri)
        
        cell.nameLabel.text = partner.name
        cell.loyaltyPointsLabel.text = partner.loyaltyPoints
        cell.optInTypeLabel.text = partner.optInType
        
        if(partner.optInDate != nil)
        {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
            cell.optinDateLabel.text = formatter.string(from: partner.optInDate)
        }
        
        if(!partner.IsOptInVisible)
        {
            cell.optInViewHeight.constant = 0
            cell.optInViewTop.constant = 10
        }
        else
        {
            cell.optInViewHeight.constant = 11
            cell.optInViewTop.constant = 5
        }
        
        if(!partner.isLoyalty)
        {
            cell.loyaltyView.isHidden = true
        }
        else
        {
            cell.loyaltyView.isHidden = false
        }
        
        
        let loyaltyImage = UIImage(named: "ic_loyalty")?.withRenderingMode(.alwaysTemplate)
        cell.loyaltyImage.tintColor = Colors.bckg_main_color_new
        cell.loyaltyImage.image = loyaltyImage
        
        let offerImage = UIImage(named: "ic_products")?.withRenderingMode(.alwaysTemplate)
        cell.offersImage.tintColor = Colors.bckg_main_color_new
        cell.offersImage.image = offerImage
        
        if (partner.IsFavourite)
        {
            let favouriteImage = UIImage(named: "ic_favourite_filled")?.withRenderingMode(.alwaysTemplate)
            cell.isFavouriteImage.tintColor = Colors.bckg_main_color_new
            cell.isFavouriteImage.image = favouriteImage
        }
        else
        {
            let favouriteImage = UIImage(named: "ic_favourite")?.withRenderingMode(.alwaysTemplate)
            cell.isFavouriteImage.tintColor = Colors.bckg_main_color_new
            cell.isFavouriteImage.image = favouriteImage
        }
        
        if(partner.isEmbeded)
        {
            cell.loyaltyViewWidth.constant = 0
            cell.offersViewWidth.constant = 0
            cell.loyaltyImageWidth.constant = 0
            cell.offersImageWidth.constant = 0
        }
        else
        {
            cell.loyaltyViewWidth.constant = 70
            cell.offersViewWidth.constant = 40
            cell.loyaltyImageWidth.constant = 25
            cell.offersImageWidth.constant = 25
        }
        
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if(!ignorePartnersListViewClicks)
        {
            selectedPartner = viewModel.partnersList[indexPath.row]
            
            if(selectedPartner.isEmbeded)
            {
                /*campaingID = 20651
                let PushedOffersStoryBoard = UIStoryboard(name: "PushedOffersView", bundle: nil)
                let viewController = PushedOffersStoryBoard.instantiateViewController(withIdentifier: "PushedOffersView") as! PushedOffersViewController
                navigation.pushViewController(viewController, animated: true)
                return*/
                
                if(true /*selectedPartner.isUserEmbededAppTester*/)
                {                    
                    //selectedPartner.apkCode = "test"
                    
                    var statusModelTemp : StatusModel! = statusDB.getStatus(apk : selectedPartner.apkCode)
                    
                    let theme  = parameterizationDatabase.getTheme(apk: selectedPartner.apkCode)
                    
                    if(theme != nil && theme?.defaultTabID == nil)
                    {
                        statusModel = nil
                        isUpdating = true
                    }
                    else
                    {
                        if(theme != nil)
                        {
                            defaultTabID = theme?.defaultTabID
                        }
                        else
                        {
                            defaultTabID = 1
                        }
                    }
                    
                    if(statusModelTemp == nil )
                    {
                        statusModelTemp = StatusModel()
                        statusModel = statusModelTemp
                        
                        parameterizationDatabase.deleteEntries(apk : selectedPartner.apkCode)
                        viewsDB.deleteEntries(apk : selectedPartner.apkCode)
                        viewsDB.deleteAllGeneralViews(apk : APK)
                        //loyaltyDB.deleteEntries(apk : selectedPartner.apkCode)
                        storesDB.deleteEntries(apk : selectedPartner.apkCode)
                        userProfileDB.deleteEntries(apk : selectedPartner.apkCode)
                        productsDB.deleteEntries(apk: selectedPartner.apkCode)
                        
                        statusDB.insertStatus(status : statusModelTemp, apk : selectedPartner.apkCode)
                        statusDB.needUpdate2(apk : selectedPartner.apkCode)
                    }
                    else if ((NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable()))
                    {
                        /*isUpdating = true
                        statusModelTemp = StatusModel()
                        statusDB.insertStatus(status : statusModelTemp, apk : selectedPartner.apkCode)
                        
                        statusModel = statusModelTemp
                        
                        parameterizationDatabase.deleteEntries(apk : selectedPartner.apkCode)
                        viewsDB.deleteEntries(apk : selectedPartner.apkCode)
                        //loyaltyDB.deleteEntries(apk : selectedPartner.apkCode)
                        storesDB.deleteEntries(apk : selectedPartner.apkCode)
                        userProfileDB.deleteEntries(apk : selectedPartner.apkCode)
                        productsDB.deleteEntries(apk: selectedPartner.apkCode)
                        
                        
                        /*statusModelTemp.areLeftDrawerTabsSaved = false
                         statusModelTemp.areStoresSaved = false
                         statusModelTemp.isAPKSaved = false
                         statusDB.insertStatus(status : statusModelTemp, apk : selectedPartner.apkCode)*/*/
                        
                        statusModel = statusModelTemp
                        checkForSync(APK : selectedPartner.apkCode)
                    }
                    
                    
                    /*let theme  = parameterizationDatabase.getTheme(apk: selectedPartner.apkCode)

                    if(theme != nil && theme?.defaultTabID == nil)
                    {
                        statusModelTemp = StatusModel()
                        statusModel = statusModelTemp
                        
                        parameterizationDatabase.deleteEntries(apk : selectedPartner.apkCode)
                        viewsDB.deleteEntries(apk : selectedPartner.apkCode)
                        //loyaltyDB.deleteEntries(apk : selectedPartner.apkCode)
                        storesDB.deleteEntries(apk : selectedPartner.apkCode)
                        userProfileDB.deleteEntries(apk : selectedPartner.apkCode)
                        productsDB.deleteEntries(apk: selectedPartner.apkCode)
                        
                        statusDB.insertStatus(status : statusModelTemp, apk : selectedPartner.apkCode)
                        statusDB.needUpdate2(apk : selectedPartner.apkCode)
                    }
                    else
                    {
                        if(theme != nil)
                        {
                            defaultTabID = theme?.defaultTabID
                        }
                        else
                        {
                            defaultTabID = 1
                        }
                    }*/
                    
                    if((statusModelTemp.isAPKSaved) || (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable()))
                    {
                        isExit = false
                        //ignorePartnersListViewClicks = true
                        APK = selectedPartner.apkCode
                        clientID = selectedPartner.administratorID
                        businessID = selectedPartner.partnerID
                        statusModel = statusDB.getStatus(apk : APK)
                        //numberOfEmbededViews = 0
                        
                        var launchScreen : UIViewController!
                        let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
                        
                        switch APK {
                        case APKsEnum.RichReach.rawValue:
                            let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                        case APKsEnum.BeautyLine.rawValue :
                            let LaunchScreenStoryBoard2 = UIStoryboard(name: "BeautyLineLaunchScreen", bundle: nil)
                            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                        case APKsEnum.HollandAndBarrett.rawValue :
                            let LaunchScreenStoryBoard2 = UIStoryboard(name: "HollandAndBarrettLaunchScreen", bundle: nil)
                            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                        default:
                            let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                            launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                        }
                        
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.present(launchScreen, animated: true, completion: { () in
                                
                                func failureAction()
                                {
                                    navigation = self.navigationController
                                    
                                    let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                                    let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                                    dialog.dismissWhenClickOutside = false
                                    dialog.titleText = "Initialisation failed"
                                    dialog.descriptionText = "Internet connection was interupted during initialisation. Please ensure your internet connection is active and try again."
                                    dialog.buttonText = NSLocalizedString("ok", comment: "")
                                    self.present(dialog,animated:true)
                                }
                                
                                do
                                {
                                    try APKChanger.downloadParameters(viewController: self, launchScreen: launchScreen, failureAction: failureAction)
                                }
                                catch
                                {
                                    
                                }
                                
                            })
                            
                        })
                    }
                    else
                    {
                        let toast = CustomToast()
                        toast.setToast(viewController: self, message: NSLocalizedString("internetRequired", comment: ""), duration: CustomToast.TOAST_LENGTH_LONG)
                        toast.show()
                    }
                }
                else
                {
                    let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                    let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                    self.present(dialog,animated:true)
                    dialog.setDialogView(title: selectedPartner.name, description: selectedPartner.name +  " app under construction.", buttonName: NSLocalizedString("ok", comment: ""), dismissWhenClickOutside: true)
                    
                    //let toast = CustomToast(viewController: self, message: selectedPartner.shortName +  " app under construction.", duration: CustomToast.TOAST_LENGTH_LONG)
                    //toast.show()
                }
            }
            else
            {
                isExit = false
                ignorePartnersListViewClicks = true
                
                let task = WebApiTask(viewController: self, action: loadPartnerShopsInformation, displayToast: true)
                task.errorMessage = NSLocalizedString("partnerInformationSyncError", comment: "")
                task.setFailureAction(action: failureAction)
                task.start()
            }
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height {
            synchronized.synchronize(obj: lock)
            {
                if (viewModel != nil && viewModel.partnersList != nil)
                {
                    if (!ignoreLoadingMoreData)
                    {
                        ignoreLoadingMoreData = true
                        loadMorePartners()
                    }
                }
            }
        }
    }
    
    
    /// Add current view to parent view.
    func addToParentView()
    {
        parentView.addChildViewController(self)
    }
    
    
    /// Remove current view from parent view controller.
    func removeFromParentView()
    {
        self.removeFromParentViewController()
    }
    
    
    /// Loads partner stores information.
    func loadPartnerShopsInformation()
    {
        viewModel.getShopsInformation(partner: &selectedPartner)
        
        if (!isActivityActive(viewController: self) && CustomTabbarViewController.navigationControllers.count == 0 )
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.ignorePartnersListViewClicks = false
            let PartnerInformationStoryBoard : UIStoryboard = UIStoryboard(name: "PartnerInformationView", bundle: nil)
            let partnerInformationView =  PartnerInformationStoryBoard.instantiateViewController(withIdentifier: "PartnerInformationViewController") as! PartnerInformationViewController
            partnerInformationView.partner = self.selectedPartner
            self.navigationController?.pushViewController(partnerInformationView, animated: true)
        })
    }
    
    /// This function is been called when failure occured.
    func failureAction() {
        ignorePartnersListViewClicks = false
    }
    
    
    /// Loads partners from internet and displays them.
    func loadPartners()
    {
        viewModel.partnersList = viewModel.loadFromInternet(loadLoyaltyPartnersOnly: AllPartnersView.displayLoyaltyPartnersOnly)
        
        if (!isActivityActive(viewController: self) && CustomTabbarViewController.navigationControllers.count == 0)
        {
            return
        }
        
        previousPartnersListSize = viewModel.partnersList != nil ? viewModel.partnersList.count : 0
        
        //adapter = new PartnersAdapter(getContext(), R.layout.fragment_tab2_available_partners, viewModel.getPartnersList(),getActivity(),viewModel, partnersFragment)
        //viewModel.setAdapter(adapter)
        
        DispatchQueue.main.async(execute: {() -> Void in
            //partnersListView.setAdapter(adapter)
            self.setNotAvailableView()
            self.partnersTableView.reloadData()
            
            if(self.previousPartnersListSize > 0)
            {
                self.container?.addSubview(self.partnersView.view)
            }
            //getActivity().invalidateOptionsMenu()
        })
    }
    
    
    /// Loads more partners.
    func loadMorePartnersRunnable()
    {
        viewModel.loadPartners(loadLoyaltyPartnersOnly: AllPartnersView.displayLoyaltyPartnersOnly)
        
        if(previousPartnersListSize == viewModel.partnersList.count)
        {
            return
        }
        
        if (!isActivityActive(viewController: self) && CustomTabbarViewController.navigationControllers.count == 0)
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.partnersTableView.reloadData()
        })
        
        previousPartnersListSize = viewModel.partnersList.count
        ignoreLoadingMoreData = false
    }
    
    
    /// Sets ignoreLoadingMoreData flag to false.
    func setIgnoreLoadingMoreDataFlag()
    {
        ignoreLoadingMoreData = false
    }
    
    
    /// Loads more partners after user reaches the bottom of table view.
    func loadMorePartners()
    {
        task = WebApiTask(viewController: self, action: loadMorePartnersRunnable, displayToast: false, isSynchronizationTimerEnabled: false)
        task.isFailureActionToast = false
        task.failureAction = setIgnoreLoadingMoreDataFlag
        task.start()
    }
    
    
    /// Checks the partners list and sets the not available view.
    func setNotAvailableView()
    {
        if (viewModel.partnersList == nil || viewModel.partnersList.count == 0)
        {
            notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: container!, text: NSLocalizedString("noAvailableBusinesses", comment: ""))
        }
        else
        {
            if(notAvailableView != nil)
            {
                notAvailableView.view.removeFromSuperview()
            }
            
            refreshItem.image = imageWithColor(color: Colors.trasnparent)
            refreshItem.isEnabled = false
            
            if(localDatabase.isAPKRegistered(bussinessID: clientID) && APK == APKsEnum.BeautyLine.rawValue)
            {
                let bell = UIBarButtonItem(badge: "\(numberOfNotifications)", title: "", target: self, action: #selector(ViewController.onNotificationsClick))
                bell.badgedButton?.setImage(UIImage(named: "ic_left_drawer_notifications"), for: .normal)
                parentView.navigationItem.rightBarButtonItems = [bell]
            }
        }
    }
    
    
    /// Sets the current app version on the view model.
    func setCurrentAppVersion()
    {
        do
        {
            viewModel.currentAppVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
            viewModel.currentAppBuildVersion = Bundle.main.infoDictionary?["CFBundleVersion"]  as! String
        }
        catch
        {
            viewModel.currentAppVersion = ""
            viewModel.currentAppBuildVersion = ""
        }
    }
    
    /// This function is been call when user clicks a bar button item from navigation.
    func onOptionsItemSelected()
    {
        task = WebApiTask(viewController: self, action: loadPartners, displayToast: true)
        task.successMessage = NSLocalizedString("synchronizationCompleted", comment: "")
        task.errorMessage = NSLocalizedString("noDataLoaded", comment: "")
        task.start()
    }
    
}
