//
//  PreferredOffersViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 20/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates offers view for preferred partner only.
class PreferredOffersViewController: ViewController {
    
    @IBOutlet var refreshItem: UIBarButtonItem!
    @IBOutlet var preferredOffersContainer: UIView!
    
    var offersView : OffersView!
    var partnerTemp = PartnerModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if(localDatabase.getAppUser()?.partnerID == 0)
        {
            
            /*if(selectedTab != nil && tabIndex != nil)
            {
                checkForTabBar(tab : selectedTab, index: tabIndex)
            }*/
            
            let MainStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            currentViewController = MainStoryBoard.instantiateViewController(withIdentifier: "AllPartnersViewController") as! AllPartnersViewController
            AllPartnersView.displayLoyaltyPartnersOnly = false
            //leftDrawer.selectTab(tabString: LeftDrawerTabsString.Offers.rawValue)
            self.navigationController?.pushViewController(currentViewController, animated: true)
            ViewController.previousTab = LeftDrawerTabsType.Offers.rawValue
        }
        else
        {
            if(selectedTab != nil && tabIndex != nil)
            {
                checkForTabBar(tab : selectedTab, index: tabIndex)
            }
            //self.showTabbar(index : 0)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let appUser = localDatabase.getAppUser()
        
        partnerTemp.id = appUser?.partnerID
        partnerTemp.partnerID = appUser?.partnerID
        partnerTemp.name = appUser?.partnerName
        partnerTemp.shortName = appUser?.partnerShortName
        
        if(self.preferredOffersContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"OffersView",bundle:nil)
            offersView = storyBoard.instantiateViewController(withIdentifier: "offers_view") as? OffersView
            offersView.setProperties(partner : partnerTemp, container: preferredOffersContainer)
            preferredOffersContainer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: ((preferredOffersContainer?.frame.height)! - 50))
            offersView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (preferredOffersContainer?.frame.height)!)
            offersView.willMove(toParentViewController: self)
            self.preferredOffersContainer?.addSubview((offersView.view)!)
            self.addChildViewController(offersView)
            offersView.didMove(toParentViewController: self)
            offersView.parentNavigationController = self.navigationController
            offersView.isPreferredPartner = true
            offersView.refreshItem = self.refreshItem
            offersView.offersContainer = preferredOffersContainer
        }
        
        navigation = self.navigationController
        //CustomTabbarViewController2.navigationControllers[0] = navigationController!
        
        if(localDatabase.getAppUser()?.partnerID != 0)
        {
            if(selectedTab != nil && tabIndex != nil && tabIndex != -1)
            {
                checkForTabBar(tab : selectedTab, index: tabIndex)
                
                if(CustomTabbarViewController.navigationControllers != nil && CustomTabbarViewController.navigationControllers.count > tabIndex)
                {
                    CustomTabbarViewController.navigationControllers[tabIndex] = self.navigationController!
                }
            }
            //self.showTabbar(index : 0)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        /*let backItem = UIBarButtonItem()
         backItem.title = ""
         backItem.image = UIImage(named : "ic_back")
         navigationItem.backBarButtonItem = backItem*/
        
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }
    
    
    @IBAction func showHideLeftDrawer(_ sender: UIBarButtonItem) {
        self.showHideLeftDrawer()
    }
    
    @IBAction func panGesture(_ sender: UIPanGestureRecognizer) {
        panGestureRecognitier(sender)
    }
    
    @IBAction func refreshClicked(_ sender: UIBarButtonItem) {
        offersView.refreshClicked()
    }
}
