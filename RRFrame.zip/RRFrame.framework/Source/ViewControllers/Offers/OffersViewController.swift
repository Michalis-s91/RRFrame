//
//  OffersViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 08/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Creates a view with container and is been used for showing the offers view.
class OffersViewController: ViewController {

    @IBOutlet var offersContainer: UIView!
    
    var partnerTemp : PartnerModel!
    var offersView : OffersView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //self.tabBarController?.tabBar.isHidden = true
        let titleFont = UIFont(name: "UIFontWeightRegular", size: 16) ?? UIFont.systemFont(ofSize: 16)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
        self.title = partnerTemp.name
        
        super.viewWillAppear(animated)
        navigation = self.navigationController
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(self.offersContainer.subviews.count == 1)
        {
            let storyBoard = UIStoryboard(name:"OffersView",bundle:nil)
            offersView = storyBoard.instantiateViewController(withIdentifier: "offers_view") as? OffersView
            offersView.setProperties(partner : partnerTemp, container: offersContainer)
            offersView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: (offersContainer?.frame.height)!)
            offersView.willMove(toParentViewController: self)
            self.offersContainer?.addSubview((offersView.view)!)
            //self.addChildViewController(offersView)
            offersView.didMove(toParentViewController: self)
            offersView.parentNavigationController = self.navigationController
            
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {        
        self.navigationController?.navigationBar.backIndicatorImage = UIImage(named : "ic_back")
        self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named : "ic_back")
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
    }

    func setOffersView(partner : PartnerModel)
    {
        self.partnerTemp = partner
    }
}
