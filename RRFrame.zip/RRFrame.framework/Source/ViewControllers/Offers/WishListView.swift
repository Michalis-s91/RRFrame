//
//  WishListView.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Creates wish list view. Here, user can see what offers he added to his wish list.
class WishListView: WishListViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var wishListTableView: UITableView!
    
    var viewModel : WishListViewModel!
    //var notAvailableView : NotAvailableViewController!
    var parentNavigationController : UINavigationController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        wishListTableView.tableFooterView = UIView()
        wishListTableView.delegate = self
        wishListTableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if (viewModel == nil)
        {
            viewModel = WishListViewModel(notAvailableView: notAvailableView, wishListTableView: wishListTableView, container : self.wishListContainer, view : self)
            viewModel.loadWishList()
            
            if(viewModel.isWishListEmpty)
            {
                notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.wishListContainer!, text: NSLocalizedString("noProductsInWishList", comment: ""))
            }
            else
            {
                if(notAvailableView != nil)
                {
                    notAvailableView.view.removeFromSuperview()
                }
            }
            
            wishListTableView.reloadData()
        }
        else
        {
            viewModel.loadWishList()
            
            if(viewModel.isWishListEmpty)
            {
                notAvailableView =  ShowNotAvailableView.showNotAvailableView(view: self, container: self.wishListContainer!, text: NSLocalizedString("noProductsInWishList", comment: ""))
            }
            else
            {
                if(notAvailableView != nil)
                {
                    notAvailableView.view.removeFromSuperview()
                }
            }
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel == nil)
        {
            return 0
        }
        else
        {
            return viewModel.favouriteOffersList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "wishlist_cell") as! WishListViewCell
        
        let offer = viewModel.favouriteOffersList[indexPath.row]
        cell.offer = offer
        cell.viewModel = viewModel
        
        cell.strikeView.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi/8))
        cell.validLabel.font = UIFont.boldSystemFont(ofSize: 8.0)
        cell.partnerNameLabel.font = UIFont.boldSystemFont(ofSize: 10.0)
        cell.generalOfferTitleLabel.font = UIFont.boldSystemFont(ofSize: 10.0)
        
        
        let url = URL(string: percentEncode(s: offer.imageUrl))
        cell.offerImage.kf.setImage(with: url)
        
        cell.partnerNameLabel.text = offer.partnerName
        cell.offerNewValueLabel.text = offer.getOfferNewValue()
        cell.offerNewValueLabel2.text = offer.getOfferNewValue()
        cell.priceLabel.text = "Price: "
        cell.originalPriceLabel.text = offer.originalPrice
        cell.offerDescriptionLabel.text = offer.offerDescription
        cell.durationTextLabel.text = offer.duration
        cell.descriptionLabel.text = offer.Description
        cell.generalOfferTitleLabel.text = offer.getGeneralOfferTitle()
        
        cell.offerDescriptionView.layer.cornerRadius = 5
        cell.offerDescriptionView.layer.masksToBounds = true
        
        if(offer.IsToAvoidOfferDetails)
        {
            //cell.avoidOfferDetailView.sizeToFit()
            cell.avoidOfferViewWidth.constant = cell.infoView.frame.size.width - 60
        }
        else
        {
            cell.avoidOfferViewWidth.constant = 0
        }
        
        if(offer.isNotGeneralOffer())
        {
            //cell.isNotGeneralOfferView.sizeToFit()
            cell.isNotGeneralOfferViewWidth.constant = cell.infoView.frame.size.width - 60
        }
        else
        {
            cell.isNotGeneralOfferViewWidth.constant = 0
            cell.priceLabel.text = ""
            cell.offerNewValueLabel2.text = ""
            cell.originalPriceLabel.text = ""
            cell.offerDescriptionLabel.text = ""
        }
        
        cell.infoView.layoutIfNeeded()
        if(offer.isItemWatched)
        {
            cell.wishListButton.setImage(UIImage(named: "ic_shopping_bag_filled"), for: .normal)
        }
        else
        {
            cell.wishListButton.setImage(UIImage(named: "ic_wish_list_empty_bag"), for: .normal)
        }
        
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
        {
            let OfferInformationStoryBoard : UIStoryboard = UIStoryboard(name: "InformationView", bundle: nil)
            let offerInformationView =  OfferInformationStoryBoard.instantiateInitialViewController() as! InformationsViewController
            offerInformationView.setOffer(offer: viewModel.favouriteOffersList[indexPath.row])
            self.parentNavigationController.pushViewController(offerInformationView, animated: true)

        }
        else
        {
            let toast = CustomToast()
            toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
            toast.show()
        }
    }

}
