//
//  OffersView.swift
//  RichReach2
//
//  Created by Eumbrella on 07/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher


class OffersView: OffersViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var offersTableView: UITableView!
    
    var partner : PartnerModel!
    var viewModel : PartnersOffersViewModel!
    var pushedViewModel : PushedOffersViewModel!
    var pushedViewModel2 : PushedOffersViewModel2!
    var lock = NSObject()
    var ignoreLoadingMoreData = false
    //var notAvailableView : NotAvailableViewController!
    var task : WebApiTask!
    var offersViewController : UIViewController!
    var previousOffersListSize = 0
    var isPartnerInfoClicked = false
    var synchronized : Synchronized = Synchronized()
    var parentNavigationController : UINavigationController!
    var isPreferredPartner = false
    var isPushedOffers = false
    var isPushedOffers2 = false
    var partnerID : Int64 = 0
    var campaingID : Int64!
    var refreshItem : UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        offersTableView.tableFooterView = UIView()
        offersTableView.delegate = self
        offersTableView.dataSource = self
        
        if(isPushedOffers)
        {
            pushedViewModel = PushedOffersViewModel()
            pushedViewModel.campaingID = campaingID
            pushedViewModel.pushedOfferTable = offersTableView
            
            viewModel = PartnersOffersViewModel(partner: partner, viewController: self)
        }
        else if(isPushedOffers2)
        {
            pushedViewModel2 = PushedOffersViewModel2()
            pushedViewModel2.campaingID = campaingID
            pushedViewModel2.pushedOfferTable = offersTableView
            
            viewModel = PartnersOffersViewModel(partner: partner, viewController: self)
        }
        else
        {
            viewModel = PartnersOffersViewModel(partner: partner, viewController: self)
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        let titleFont = UIFont(name: "UIFontWeightRegular", size: 16) ?? UIFont.systemFont(ofSize: 16)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: titleFont, NSAttributedStringKey.foregroundColor:UIColor.white]
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        offersViewController = self
        
        task = WebApiTask( viewController: self, action: loadOffers)
        task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
        task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: offersContainer)
        task.start()
        
        DispatchQueue.global(qos: .background).async {
            if(!loadingNotificationsFromProfile)
            {
                
                let appUser = localDatabase.getAppUser()
                
                let phoneNumber = appUser?.phoneNumber
                var notificationsCountersInfo = NotificationsWebApi.getNotificationsCountersInfo(userPhone: phoneNumber)
                
                if(notificationsCountersInfo != nil)
                {
                    numberOfGeneralNotifications = notificationsCountersInfo!.unseenCampaigns
                    numberOfPromotionNotifications = notificationsCountersInfo!.unseenCoupons
                    numberOfNotifications = notificationsCountersInfo!.allUnseen
                }
                
                DispatchQueue.main.async(execute: {() -> Void in
                    if(APK == Bundle.main.bundleIdentifier!)
                    {
                        UIApplication.shared.applicationIconBadgeNumber = numberOfNotifications
                    }
                    
                    if(leftDrawer == nil)
                    {
                        let MainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
                        leftDrawer = MainStoryBoard.instantiateViewController(withIdentifier: "LeftDrawerViewController") as? LeftDrawerViewController
                        leftDrawer.highlightedTabString = ""
                        
                        if #available(iOS 11.0, *) {
                            leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.safeAreaLayoutGuide.layoutFrame.size.height)
                        } else {
                            leftDrawer.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.size.height)
                        }
                    }
                    
                    leftDrawer.tableView.reloadData()
                    leftDrawer.selectTab(tabString: leftDrawer.highlightedTabString)
                })
            }
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        if (task != nil)
        {
            task.stop()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(viewModel.OffersList == nil)
        {
            return 0
        }
        else
        {
            return viewModel.OffersList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let offer = viewModel.OffersList[indexPath.row]
        
        if(offer.isSms != nil && offer.isSms)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_sms") as! SmsViewCell
            
            cell.offer = offer
            
            cell.tableView = offersTableView
            cell.headerLabel.text = offer.smsHeader
            cell.bodyLabel.text = offer.smsBody
            
            cell.seenLabel.textColor = Colors.holo_red_dark
            
            if(offer.isSeen != nil && offer.isSeen)
            {
                cell.seenLabel.text = "(Seen)"
            }
            else
            {
                cell.seenLabel.text = ""
            }
            
            cell.separatorInset = UIEdgeInsets.zero
            cell.layoutMargins = UIEdgeInsets.zero
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            return cell
        }
        else if (isPushedOffers2 && APK != APKsEnum.RichReach.rawValue)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_cell2") as! OfferViewCell
            
            cell.offer = offer
            cell.viewModel = viewModel
            
           
            cell.validLabel.font = UIFont.boldSystemFont(ofSize: 8.0)
            cell.generalOfferTitleLabel.font = UIFont.boldSystemFont(ofSize: 10.0)
            
            let url = URL(string: percentEncode(s: offer.imageUrl))
            //cell.offerImage.kf.setImage(with: url)
            //cell.offerImage.kf.indicatorType = .activity
            cell.offerImage.kf.setImage(with: url, options: [.forceRefresh])
            
            if(offer.isSeen != nil && offer.isSeen)
            {
                cell.isSeenLabel.text = "(Seen)"
            }
            else
            {
                cell.isSeenLabel.text = ""
            }
    
            cell.durationTextLabel.text = offer.duration
            cell.offerNewValueLabel.text = offer.getGeneralOfferTitle()
            cell.generalOfferTitleLabel.text = offer.extendedDescription
            cell.descriptionLabel.text = offer.Description
            
            if(APK == APKsEnum.BeautyLine.rawValue)
            {
                cell.descriptionLabel.textColor = UIColor("#002856")
                cell.descriptionLabel.font = UIFont(name: "CharpentierSansPro-Normal", size: CGFloat(19))
                
                cell.offerNewValueLabel.textColor = UIColor("#249dd9")
                cell.offerNewValueLabel.font = UIFont(name: "CharpentierSansPro-Normal", size: CGFloat(17))
                
                cell.generalOfferTitleLabel.textColor = UIColor("#002856")
                cell.generalOfferTitleLabel.font = UIFont(name: "CharpentierSansPro-Normal", size: CGFloat(16))
                
                cell.validLabel.textColor = UIColor("#8f8f8f")
                
                cell.validLabel.textColor = UIColor("#8f8f8f")
                cell.validLabel.font = UIFont(name: "CharpentierSansPro-Normal", size: CGFloat(13))
                
                cell.durationTextLabel.textColor = UIColor("#8f8f8f")
                cell.durationTextLabel.font = UIFont(name: "CharpentierSansPro-Normal", size: CGFloat(13))
            }
            
            cell.infoView.layoutIfNeeded()
            
            cell.separatorInset = UIEdgeInsets.zero
            cell.layoutMargins = UIEdgeInsets.zero
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "offer_cell") as! OfferViewCell
            
            cell.offer = offer
            cell.viewModel = viewModel
            
            cell.strikeView.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi/8))
            cell.validLabel.font = UIFont.boldSystemFont(ofSize: 8.0)
            cell.generalOfferTitleLabel.font = UIFont.boldSystemFont(ofSize: 10.0)
            
            let url = URL(string: percentEncode(s: offer.imageUrl))
            //cell.offerImage.kf.setImage(with: url)
            //cell.offerImage.kf.indicatorType = .activity
            cell.offerImage.kf.setImage(with: url, options: [.forceRefresh])

            if(offer.isSeen != nil && offer.isSeen)
            {
                cell.isSeenLabel.text = "(Seen)"
            }
            else
            {
                cell.isSeenLabel.text = ""
            }
            
            cell.offerNewValueLabel.text = offer.getOfferNewValue()
            cell.offerNewValueLabel2.text = offer.getOfferNewValue()
            cell.priceLabel.text = "Price: "
            cell.originalPriceLabel.text = offer.originalPrice
            cell.offerDescriptionLabel.text = offer.offerDescription
            cell.durationTextLabel.text = offer.duration
            
            
            cell.generalOfferTitleLabel.text = offer.getGeneralOfferTitle()
            
            cell.descriptionLabel.text = offer.Description
            
            if(APK == APKsEnum.BeautyLine.rawValue)
            {
                cell.infoView.removeFromSuperview()
                cell.durationTextLabel.font = cell.durationTextLabel.font.withSize(11)
                cell.validLabel.font = cell.validLabel.font.withSize(11)
                cell.durationView.removeConstraint(cell.validDateViewBottom)
                //cell. validDateViewBottom.remove
            }
            
            //roundCorners([.allCorners], radius: 5, view: cell.offerDescriptionView)
            cell.offerDescriptionView.layer.cornerRadius = 5
            cell.offerDescriptionView.layer.masksToBounds = true
            //cell.offerDescriptionLabel.frame = CGRect(x: cell.offerDescriptionLabel.frame.origin.x , y: cell.offerDescriptionLabel.frame.origin.y, width: 0, height: 0)
            //  = CGSize(width: 0, height: cell.offerDescriptionLabel.frame.size.height)
            
            if(offer.IsToAvoidOfferDetails)
            {
                //cell.avoidOfferDetailView.sizeToFit()
                cell.avoidOfferViewWidth.constant = cell.infoView.frame.width - 60
            }
            else
            {
                cell.avoidOfferViewWidth.constant = 0
            }
            
            if(offer.isNotGeneralOffer())
            {
                //cell.isNotGeneralOfferView.sizeToFit()
                cell.isNotGeneralOfferViewWidth.constant = cell.infoView.frame.width - 60
            }
            else
            {
                cell.isNotGeneralOfferViewWidth.constant = 0
                cell.priceLabel.text = ""
                cell.offerNewValueLabel2.text = ""
                cell.originalPriceLabel.text = ""
                cell.offerDescriptionLabel.text = ""
            }
            
            cell.infoView.layoutIfNeeded()
            
            if(APK == APKsEnum.RichReach.rawValue)
            {
                if(offer.isItemWatched)
                {
                    cell.wihshListButton.setImage(UIImage(named: "ic_shopping_bag_filled"), for: .normal)
                }
                else
                {
                    cell.wihshListButton.setImage(UIImage(named: "ic_wish_list_empty_bag"), for: .normal)
                }
            }
            
            if(!offer.isStrikethrough)
            {
                cell.strikeView.removeFromSuperview()
            }
            
            cell.separatorInset = UIEdgeInsets.zero
            cell.layoutMargins = UIEdgeInsets.zero
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            //roundCorners([.allCorners], radius: 5, view: cell.offerDescriptionView)
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(viewModel.OffersList[indexPath.row].isSms == nil || !viewModel.OffersList[indexPath.row].isSms)
        {
            if (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable())
            {
                isViewPushed = true
                let OfferInformationStoryBoard : UIStoryboard = UIStoryboard(name: "InformationView", bundle: nil)
                let offerInformationView =  OfferInformationStoryBoard.instantiateInitialViewController() as! InformationsViewController
                offerInformationView.setOffer(offer: viewModel.OffersList[indexPath.row])
                parentNavigationController.pushViewController(offerInformationView, animated: true)
                isPartnerInfoClicked = true
                
            }
            else
            {
                let toast = CustomToast()
                toast.setToast(viewController: self, message: NSLocalizedString("internetIsRequired", comment: ""))
                toast.show()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height {
            synchronized.synchronize(obj: lock)
            {
                if (viewModel != nil && viewModel.OffersList != nil)
                {
                    if (!ignoreLoadingMoreData)
                    {
                        ignoreLoadingMoreData = true
                        loadMoreOffers()
                    }
                }
            }
        }
    }
    

    
    /// Loads offers from internet
    func loadOffers()
    {
        if(isPushedOffers)
        {
            viewModel.OffersList = pushedViewModel.loadFromInternet()
            pushedViewModel.offersList = viewModel.OffersList
        }
        else if(isPushedOffers2)
        {
            viewModel.OffersList = pushedViewModel2.loadFromInternet()
            pushedViewModel2.offersList = viewModel.OffersList
        }
        else
        {
            viewModel.OffersList = viewModel.loadFromInternet()
        }
        
        previousOffersListSize = viewModel.OffersList.count
        
        if (!isActivityActive(viewController: self) && CustomTabbarViewController.navigationControllers.count == 0)
        {
            return
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.offersTableView.reloadData()
            
            if(self.viewModel.OffersList == nil || self.viewModel.OffersList.count == 0)
            {
                if(self.isPushedOffers2 || self.isPushedOffers)
                {
                    self.notAvailableView = ShowNotAvailableView.showNotAvailableView(view: self.offersViewController, container: self.container!, text: NSLocalizedString("noAvailableNotifications", comment: ""))
                }
                else
                {
                    self.notAvailableView = ShowNotAvailableView.showNotAvailableView(view: self.offersViewController, container: self.container!, text: NSLocalizedString("noAvailableProducts", comment: ""))
                }
            }
            else
            {
                if(self.notAvailableView != nil)
                {
                    self.notAvailableView.view.removeFromSuperview()
                }
                
                if(self.isPreferredPartner)
                {
                    //self.refreshItem.image = ImageWithColor.imageWithColor(color: Colors.trasnparent)
                    //self.refreshItem.isEnabled = false
                }
            }
        })
    }
    
    func loadMoreOffersAsync()
    {
        if(isPushedOffers)
        {
            pushedViewModel.loadMoreFromInternet()
            viewModel.OffersList = pushedViewModel.offersList
        }
        else if(isPushedOffers2)
        {
            pushedViewModel2.loadMoreFromInternet()
            viewModel.OffersList = pushedViewModel2.offersList
        }
        else
        {
            viewModel.loadMoreFromInternet()
        }
        
        if(!(previousOffersListSize == viewModel.OffersList.count))
        {
            ignoreLoadingMoreData = false
        }
    }
    
    /// Loads more offers when user reaches the bottom of table view.
    func loadMoreOffers()
    {
        task = WebApiTask(viewController: self, action: loadMoreOffersAsync, displayToast: false, isSynchronizationTimerEnabled: false)
        task.failureAction = failureAction
        task.start()
    }
    
    /// This function is been called when failure occured.
    func failureAction()
    {
        ignoreLoadingMoreData = false
    }
    
    
    /// Set partner and container.
    ///
    /// - Parameters:
    ///   - partner: The partner.
    ///   - container: The container of parent view.
    func setProperties(partner : PartnerModel, container : UIView)
    {
        self.partner = partner
        self.offersContainer = container
        self.container = container
    }
    
    
    /// This function is been called when user click on refresh bar button item at navigation bar.
    func refreshClicked()
    {
        //task.stop()
        task = WebApiTask(viewController: self, action: loadOffers, displayToast: true)
        task.shouldDisplayNotAvailableView(shouldDisplayNotAvailableView: true, container: offersContainer)
        task.shouldDisplayActivityIndicator(shouldDisplayActivityIndicator: true)
        task.successMessage = NSLocalizedString("synchronizationCompleted", comment: "")
        task.errorMessage = NSLocalizedString("noDataLoaded", comment: "")
        task.start()
    }
    
    /*func test()
    {
        var i = 0
        while(i < 10000000)
        {
            sleep(5)
            i += 1
        }
    }*/
}
