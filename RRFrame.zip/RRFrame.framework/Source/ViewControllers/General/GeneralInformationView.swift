//
//  GeneralInformationView.swift
//  RichReach2
//
//  Created by Eumbrella on 16/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import Kingfisher
import ImageIO

/// Creates general information view. This view is reusable and it has table for showing images, texts, videos and carousels etc.
class GeneralInformationView: ViewController {

    @IBOutlet var informationTableView: UITableView!

    var informationsList : [GeneralInformation2]! = []
    static var sectionLoaded : [Bool] = []
    var videosPostions : [Int] = []
    var videoLoaded : [Bool] = []
    var videoIsBeenPlaying = false
    var headersView : [UIView] = []
    var viewController : ViewController!
    var titleLabel : UILabel!
    var titleBackground : UIView!
    var webView : UIWebView!
    var isEmbeded = false
    
    /*override func viewDidLoad() {
        super.viewDidLoad()

        informationTableView.rowHeight = UITableViewAutomaticDimension
        informationTableView.tableFooterView = UIView()
        informationTableView.delegate = self
        informationTableView.dataSource = self
        
        informationTableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: -20, right: 0)
        //informationTableView.reloadData()
        
        GeneralInformationView.sectionLoaded.removeAll()
        for _ in 0..<informationsList.count
        {
            GeneralInformationView.sectionLoaded.append(false)
            headersView.append(UIView())
        }
        
        //tableViewHeight.constant = viewHeight - 2*CGFloat(borderWidth)
    }
    
    /*func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(informationsList != nil)
        {
            return informationsList.count
        }
        else
        {
            return 0
        }
    }*/
    
    override func viewDidAppear(_ animated: Bool) {
        informationTableView.reloadData()
        
        if(isEmbeded)
        {
            self.view.window?.backgroundColor = UIColor.white
            
            var topPadding : Int!  = parameterizationDatabase.getTheme(apk: APK).topPadding == nil ? 0 : parameterizationDatabase.getTheme(apk: APK).topPadding
            
            self.view.frame.origin.y =  offset + CGFloat(topPadding)
            self.view.frame.size.height = self.view.frame.size.height - CGFloat(topPadding)

        }

//        DispatchQueue.main.async(execute: {() -> Void in
//            print(self.informationTableView.frame.size.height)
//            if(self.informationTableView.frame.size.height < (viewHeight - 2*CGFloat(borderWidth)))
//            {
//                print(viewHeight - (2*CGFloat(borderWidth)) - self.informationTableView.frame.size.height)
//                let insets = UIEdgeInsets(top: 0, left: 0, bottom: viewHeight - (2*CGFloat(borderWidth)) - self.informationTableView.frame.size.height, right: 0)
//                self.informationTableView.contentInset = insets
//            }
//        })
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        let url = NSURL(string : "")
        let request  = URLRequest(url : url as! URL)
        if(webView != nil)
        {
            webView.loadRequest(request)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if(informationsList != nil)
        {
            return informationsList.count
        }
        else
        {
            return 0
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        GeneralInformationView.sectionLoaded.removeAll()
        super.viewWillDisappear(animated)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if(section == 0)
        {
            return 0
        }
        
        return CGFloat(separatorHeight)
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        if(separatorHeight != nil && separatorHeight > 0)
        {
            headerView.backgroundColor = UIColor((separatorColor)!)
        }
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var information : GeneralInformation2!

        information = informationsList[indexPath.section]

        switch information.type {
        case InformationType2.Title.rawValue:
            /*let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_title") as! InformationTitleViewCell
            var title : TitleModel! = information.title
            cell.titleLabel.text = title.title
            cell.titleLabel.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
            cell.titleLabel.textColor = UIColor((title.titleColor)!)
            cell.titleLabel.backgroundColor = UIColor((title.titleBackgroundColor)!)
            
            //cell.titleLabel.bringSubview(toFront: self.view)
            self.view.bringSubview(toFront: cell.titleLabel)
            self.view.bringSubview(toFront: cell)
            cell.frame = CGRect(x: 0, y: 0, width: 10000, height: 50)
            if(title.isTitleCentered != nil && !title.isTitleCentered)
            {
                cell.titleLabel.textAlignment = .left
            }
            cell.selectionStyle = .none
 
            return cell*/
            if(titleLabel == nil)
            {
                let title : TitleModel! = information.title
                let label = LabelWithPadding()
                
                //informationTableView.frame = CGRect(x: informationTableView.frame.origin.x, y: informationTableView.frame.origin.y + 15.0, width: informationTableView.frame.size.width, height: informationTableView.frame.size.height - 15.0)
                
                var font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
                
                if(isEmbeded)
                {
                    label.text = title.title
                }
                else
                {
                    label.text = selectedTab.name
                }
                
                label.font = font
                label.textColor = Colors.titleTextColor
                label.backgroundColor = Colors.titleBackround
                label.numberOfLines = 0
                
                let line = UIView()
                line.backgroundColor = Colors.titleSplitterColor
                
                if(!FontsAndSizes.isTitleCentered)
                {
                    label.leftPadding = borderWidth + 10
                    label.textAlignment = .left
                }
                else
                {
                    label.textAlignment = .center
                }
                
                var titleHeightSize : CGFloat = 40
                
                if(font != nil)
                {
                    titleHeightSize = title.title.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 20
                }
                
                let blankView = UIView()
                blankView.backgroundColor = UIColor.white

                label.frame = CGRect(x: 0, y: titleTopPadding, width: UIScreen.main.bounds.size.width, height: titleHeightSize)
                line.frame = CGRect(x: 0, y: titleTopPadding + titleHeightSize, width: UIScreen.main.bounds.size.width * 0.8, height: 1)
                line.center.x = UIScreen.main.bounds.size.width / 2
                
                blankView.frame = CGRect(x: tableView.frame.origin.x, y: tableView.frame.origin.y, width: tableView.frame.size.width, height: (titleTopPadding + titleHeightSize) - tableView.frame.origin.y)
                self.view.addSubview(blankView)
                //titleBackground = blankView
                
                titleLabel = label
                self.view.addSubview(label)
                self.view.addSubview(line)
            }
            

            
            let cell = UITableViewCell()
            cell.selectionStyle = .none
            
            return cell
        case InformationType2.Photo.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_image") as! InformationImageViewCell
            let photo : PhotoModel! = information.photo
            
            if(photo.title != nil)
            {
                let title : TitleModel! = photo.title
                
                cell.cellTitle.text = title.title
                cell.cellTitle.font = UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))
                cell.cellTitle.textColor = UIColor((title.titleColor)!)
                cell.cellTitle.backgroundColor = UIColor((title.titleBackgroundColor)!)
                cell.titleHeightConstraint.constant = (title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (title.titleFont)!, size: CGFloat((title.titleSize)!))!))!
            }
            else
            {
                cell.titleHeightConstraint.constant = 0
            }
            
            cell.link = photo.link
            cell.awakeFromNib()
            
            let url = URL(string: percentEncode(s: photo.imageUrl))
            
            cell.cellImage.kf.setImage(with: url)
            
            /*cell.cellImage.kf.setImage(with: url, completionHandler: {
             (image, error, cacheType, imageUrl) in
             // image: Image? `nil` means failed
             // error: NSError? non-`nil` means failed
             // cacheType: CacheType
             //                  .none - Just downloaded
             //                  .memory - Got from memory cache
             //                  .disk - Got from disk cache
             // imageUrl: URL of the image
             })*/
            
            
            if(!photo.takeFullWidth)
            {
                cell.imageWidth = cell.imageWidth.setMultiplier(multiplier: 0.5)
            }
            
            //cell.imageWidth.multiplier = 0.5
            
            if(photo.button != nil)
            {
                let button : ButtonModel! = photo.button
                
                cell.viewController = self.viewController
                cell.tabID = button.tabID
                
                cell.buttonWidth.constant = CGFloat(button.width)
                cell.buttonHeight.constant = CGFloat(button.height)
                cell.cellButton.center = cell.cellImage.center
                cell.cellButton.setTitle(button.name, for: .normal)
                cell.cellButton.titleLabel?.font = UIFont (name: (button?.font)!, size: CGFloat(button.textSize))
                cell.cellButton.setTitleColor(UIColor(button.textColor), for: .normal)
                //cell.cellButton.titleLabel?.textColor = UIColor(button.textColor)
                cell.cellButton.backgroundColor = UIColor(correctHexString(string: button.backgroundColor))
                
                cell.borderWidth.constant =  CGFloat(button.width + button.borderWidth * 2)
                cell.borderHeight.constant = CGFloat(button.height + button.borderWidth * 2)
                cell.buttonBorder.backgroundColor = button.borderWidth != 0 ? UIColor(correctHexString(string: button.borderColor)) : UIColor.clear
                
                
                var titleHeight : CGFloat! = 0.0
                
                if(information.photo.title != nil)
                {
                    titleHeight = photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (photo.title.titleFont)!, size: CGFloat((photo.title.titleSize)!))!)
                }
                
                var cellHeight : CGFloat!
                if(photo.aspectRatio != nil)
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(photo.aspectRatio) + titleHeight
                }
                else
                {
                    cellHeight = UIScreen.main.bounds.size.width + titleHeight
                }
            
                switch button.buttonPosition
                {
                case 1:
                    break
                case 2:
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 3:
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 4:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    break
                case 5:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 6:
                    cell.borderY.constant = cellHeight/2 - CGFloat(button.height + button.borderWidth * 2)/2
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                case 7:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    break
                case 8:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width/2 - CGFloat(button.width + button.borderWidth * 2)/2
                    break
                case 9:
                    cell.borderY.constant = cellHeight - CGFloat(button.height) - CGFloat(button.borderWidth * 2)
                    cell.borderX.constant = UIScreen.main.bounds.size.width - CGFloat(button.width) - CGFloat(button.borderWidth * 2)
                    break
                default :
                    break
                }
                
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case InformationType2.Text.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
            let text : TextModel! = information.text
            
            //cell.descriptionText.translatesAutoresizingMaskIntoConstraints = true
            //cell.descriptionText.sizeToFit()
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            cell.titleLabel.text = text?.title
            cell.descriptionText.text = text?.description
            cell.titleLabel.font = UIFont (name: (text?.titleFont)!, size: CGFloat((text?.titleSize)!))
            cell.titleLabel.textColor = UIColor((text?.titleColor)!)
            cell.descriptionText.font = UIFont (name: (text?.descriptionFont)!, size: CGFloat((text?.descriptionSize)!))
            cell.descriptionText.textColor = UIColor((text?.descriptionColor)!)
            cell.splitter.backgroundColor = UIColor((text?.splitterColor)!)
            cell.backgroundColor = UIColor((text?.backgroundColor)!)
            cell.descriptionText.backgroundColor = UIColor((text?.backgroundColor)!)
            
            if(text?.isTitleCentered)!
            {
                cell.titleLabel.textAlignment = .center
            }
            
            switch text?.descriptionAlignmentType.rawValue
            {
            case AlignmentType.Left.rawValue? :
                cell.descriptionText.textAlignment = .left
            case AlignmentType.Center.rawValue? :
                cell.descriptionText.textAlignment = .center
            case AlignmentType.Justified.rawValue? :
                cell.descriptionText.textAlignment = .justified
            default :
                break
            }
            
            //cell.descriptionText.text = cell.descriptionText.text.trimmingCharacters(in: .whitespacesAndNewlines)
        
            /*var maxSize = CGSize(cell.descriptionText.frame.size.width, 20);
            
            // Determine the size needed to display the text - we just need the new height.
            var textSize = CGSize(sizewi) cell.descriptionText.text  sizeWithFont:myTextView.font constrainedToSize:maxSize lineBreakMode:UILineBreakModeWordWrap];
            
            // Set the UITextView's frame to the new height.
            CGRect textViewRect = myTextView.frame;
            textViewRect.size.height = textSize.height+13;
            myTextView.frame = textViewRect;*/
            
            return cell
        case InformationType2.Video.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_video") as! InformationVideoViewCell
            
            if(GeneralInformationView.sectionLoaded.count >= (indexPath.section + 1) && !GeneralInformationView.sectionLoaded[indexPath.section])
            {
                videosPostions.append(indexPath.section)
                
                cell.cellWebView.mediaPlaybackRequiresUserAction = false
                cell.cellWebView.allowsInlineMediaPlayback = true
                cell.cellWebView.delegate = self
                cell.cellWebView.mediaPlaybackAllowsAirPlay = false
                cell.cellWebView.scrollView.isScrollEnabled = false
                cell.cellWebView.scrollView.showsVerticalScrollIndicator = false
                cell.cellWebView.scrollView.showsHorizontalScrollIndicator = false
                
                
                webView = cell.cellWebView
                GeneralInformationView.sectionLoaded[indexPath.section] = true
                
                videoLoaded.append(false)
                var cellRect = informationTableView.rectForRow(at: indexPath)
                cellRect.size.height =  cellRect.size.height
                let completelyVisible = informationTableView.bounds.contains(cellRect)
                
                if (completelyVisible) {
                    
                    if(!videoLoaded[0])
                    {
                        let width = UIScreen.main.bounds.size.width - CGFloat(2 * borderWidth)
                        let height = width/1.77
                       
                        webView.allowsInlineMediaPlayback = true
                        
                        webView.loadHTMLString("<video controls muted autoplay loop playsinline webkit-playsinline id=\"video1\" width=\"\(width)\" height=\"\(height)\"> <source src=\"\(information.video.videoUrl ?? "")\" type=\"video/mp4\"></video>", baseURL: nil)
                        webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
                        
                        videoIsBeenPlaying = true
                        videoLoaded[0] = true
                    }
                }
                /*if #available(iOS 10.0, *) {
                    if (completelyVisible)
                    {
                        cell.cellWebView.loadHTMLString("<iframe id=\"video1\" width=\"\(width)\" height=\"\(height)\" src=\(information.video.videoUrl ?? "")?playsinline=1\" frameborder=\"0\" allowfullscreen></iframe>", baseURL: nil)
                        videoLoaded.append(true)
                    }
                    else
                    {
                        cell.cellWebView.loadHTMLString("<iframe id=\"video1\" width=\"\(width)\" height=\"\(height)\" src=\("" ?? "")?playsinline=1\" frameborder=\"0\" allowfullscreen></iframe>", baseURL: nil)
                        videoLoaded.append(false)
                    }
                } else {
                    if (completelyVisible)
                    {
                        cell.cellWebView.loadHTMLString("<iframe id=\"video1\" width=\"\(width)\" height=\"\(height)\" src=\(information.video.videoUrl ?? "")?webkit-playsinline=1\" frameborder=\"0\" allowfullscreen></iframe>", baseURL: nil)
                        videoLoaded.append(true)
                    }
                    else
                    {
                        cell.cellWebView.loadHTMLString("<iframe id=\"video1\" width=\"\(width)\" height=\"\(height)\" src=\("" ?? "")?webkit-playsinline=1\" frameborder=\"0\" allowfullscreen></iframe>", baseURL: nil)
                 
                    }
                }*/
                
                
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case InformationType2.Carousel.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_carousel") as! InformationCarouselViewCell
            
                let carousel : CarouselModel! = information.carousel
                cell.urls = carousel?.urls
                cell.hasTitles = carousel.hasTitles
                cell.titleSize = carousel.titleSize
                cell.isAutomatic = carousel?.isAutomatic
                cell.isManual = carousel?.isManual
                cell.isScrollingEnabled = carousel?.isScrollingEnabled
                cell.interval = (carousel?.interval)!
                
                cell.setCarusel()
                
                /*if(cell.titles != nil && cell.titles.count > 0)
                {
                    cell.titleLabel.font = UIFont (name: (carousel.titleFont)!, size: CGFloat((carousel.titleSize)!))
                    cell.titleLabel.textColor = UIColor((carousel.titleColor)!)
                    cell.titleLabel.backgroundColor =  UIColor((carousel.titleBackgroundColor)!)
                }*/
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        case InformationType2.PDF.rawValue:
            let cell = tableView.dequeueReusableCell(withIdentifier: "general_info_pdf") as! InformationPDFViewCell

            cell.cellWebView.isUserInteractionEnabled = false
            //cell.cellWebView.scrollView.isUserInteractionEnabled = false
            //cell.cellWebView.scrollView.isScrollEnabled = false
            //cell.cellWebView.scrollView.bounces = false
            let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
            let nsUserDomainMask = FileManager.SearchPathDomainMask.userDomainMask
            let paths = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory, nsUserDomainMask, true)
            if let dirPath = paths.first
            {
                let url = URL(fileURLWithPath: dirPath).appendingPathComponent("\(APK.replacingOccurrences(of: ".", with: ""))\(indexPath.section)\(selectedTab.id!).pdf")
                let request  = URLRequest(url : url)
                cell.cellWebView.loadRequest(request)
            }
            
            /*var pdfDocumentRef = CGPDFDocument(createWithURl : 1 ) //CGPDFDocumentCreateWithURL((CFURLRef)url);
            CGPDFPageRef pdfPageRef = CGPDFDocumentGetPage(pdfDocumentRef, 1);
            
            CGRect pdfPageRect = CGPDFPageGetBoxRect(pdfPageRef, kCGPDFMediaBox);
            
            var height = pdfPageRect.size.height;*/
            
            //cell.cellWebView.backgroundColor = UIColor.clear
            //cell.cellWebView.scrollView.backgroundColor = UIColor.clear
            cell.cellWebView.delegate = self
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        default:
            return tableView.dequeueReusableCell(withIdentifier: "general_info_text") as! InformationTextViewCell
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let contentYoffset = scrollView.contentOffset.y
        //print(contentYoffset)
        
        /*if(titleBackground != nil )
        {
            if((contentYoffset - 35) < 0)
            {
                titleBackground.frame.size.height = 50 - contentYoffset + 35
            }
            else
            {
                titleBackground.frame.size.height = 50
            }
        }*/
        
        var i = 0
        for v in videosPostions
        {
            let indexPathTemp = IndexPath(row:  0, section: v)
            
            var cellRect = informationTableView.rectForRow(at: indexPathTemp)
            cellRect.size.height =  cellRect.size.height
            let completelyVisible = informationTableView.bounds.contains(cellRect)
            
            if (completelyVisible) {
                
                if(!videoLoaded[i])
                {
                    var information : GeneralInformation2!
                    information = informationsList[v]
                    let width = UIScreen.main.bounds.size.width - CGFloat(2 * borderWidth)
                    let height = width/1.77
                    
                    //webView.mediaPlaybackRequiresUserAction = false
                    
                    //var script = "<script> var symbol = $(\"#video1\")[0].src.indexOf(\"?\") > -1 ? \"&\" : \"?\"; $(\"#video1\")[0].src += symbol + \"autoplay=1\"; </script>"
                    //webView.loadHTMLString("<head>  <meta charset=\"UTF-8\"> <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"> <title></title> <script> $('a.pause-video').click(function(){$('.youtube-video')[0].contentWindow.postMessage('{\"event\":\"command\",\"func\":\"' + 'pauseVideo' + '\",\"args\":\"\"}', '*');});    </script> </head>  <body> <div><a href=\"#\" class=\"pause-video\">Pause Video</a></div> <iframe class=\"youtube-video\"  width=\"\(width)\" height=\"\(height)\" src=\(information.video.videoUrl ?? "")?playsinline=1\" frameborder=\"0\" allowfullscreen></iframe> </body>", baseURL: nil)

                    webView.allowsInlineMediaPlayback = true
                    

                    webView.loadHTMLString("<video controls muted autoplay loop playsinline webkit-playsinline id=\"video1\" width=\"\(width)\" height=\"\(height)\"> <source src=\"\(information.video.videoUrl ?? "")\" type=\"video/mp4\"></video>", baseURL: nil)
                    webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
                    
                    //var script2 = "$('a.pause-video').click(function(){$('.youtube-video')[0].contentWindow.postMessage('{\"event\":\"command\",\"func\":\"' + 'pauseVideo' + '\",\"args\":\"\"}', '*');});"
                    
                    //print(webView.stringByEvaluatingJavaScript(from: script2))
                    
                    videoIsBeenPlaying = true
                    videoLoaded[i] = true
                    i += 1
                }
                else if (!videoIsBeenPlaying)
                {
                    videoIsBeenPlaying = true
                    webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.play();")
                }
            }
            
            if( !completelyVisible)
            {
                videoIsBeenPlaying = false
                webView.stringByEvaluatingJavaScript(from: "var vid = document.getElementById(\"video1\"); vid.pause();")
            }
        }
        
    }
    static var a = true
    
    /*func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        var information : GeneralInformation2!
        information = informationsList[indexPath.section]

        if (information.type == InformationType2.Video.rawValue)
        {
            var script = "<script language=\"javascript\" type=\"text/javascript\" src=\"jquery-1.8.2.js\"></script><script language=\"javascript\" type=\"text/javascript\"> var src= $(this).attr('src');$(this).attr('src',src);</script>"
            webView.stringByEvaluatingJavaScript(from: script)
            
            webView.mediaPlaybackRequiresUserAction = true
        }
    }*/
    
    /*func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        var information : GeneralInformation2!
        information = informationsList[indexPath.section]
        
        if(information.video != nil && information.video.autoPlay && webView != nil)
        {
            webView.mediaPlaybackRequiresUserAction = false
        }
    }*/
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // note that indexPath.section is used rather than indexPath.row
        //print("You tapped cell number \(indexPath.section).")
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var information : GeneralInformation2!
        
        information = informationsList[indexPath.section]
        switch information.type {
        case InformationType2.Carousel.rawValue:
            var carousel = information.carousel
            var titleHeight : CGFloat! = 0.0
            
            if(carousel?.hasTitles)!
            {
                titleHeight = carousel?.urls[0].title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (carousel?.urls[0].title.titleFont)!, size: CGFloat((carousel?.urls[0].title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            var aspcetRatio = carousel?.urls[0].aspectRatio
            if(aspcetRatio != nil)
            {
                cellHeight = UIScreen.main.bounds.size.width * CGFloat(aspcetRatio!) + titleHeight
            }
            else
            {
                cellHeight = UIScreen.main.bounds.size.width + titleHeight
            }
            
            return cellHeight
        case InformationType2.Video.rawValue:
            return UIScreen.main.bounds.size.width/1.77 - 2
        case InformationType2.Text.rawValue:
            return UITableViewAutomaticDimension
        case InformationType2.Photo.rawValue:
            var titleHeight : CGFloat! = 0.0
            
            if(information.photo.title != nil)
            {
                titleHeight = information.photo.title.title?.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: UIFont (name: (information.photo.title.titleFont)!, size: CGFloat((information.photo.title.titleSize)!))!)
            }
            
            var cellHeight : CGFloat!
            if(information.photo.aspectRatio != nil)
            {
                if(information.photo.takeFullWidth)
                {
                    cellHeight = UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
                }
                else
                {
                    cellHeight = 0.5 * UIScreen.main.bounds.size.width * CGFloat(information.photo.aspectRatio) + titleHeight
                }
            }
            else
            {
                cellHeight = UIScreen.main.bounds.size.width + titleHeight
            }
            
            return cellHeight
        case InformationType2.Title.rawValue:
            var font = UIFont (name: (FontsAndSizes.titleFont), size: CGFloat((FontsAndSizes.titleTextSize)))
            return (information.title.title.height(withConstrainedWidth: UIScreen.main.bounds.size.width, font: font!) + 30)
        case InformationType2.PDF.rawValue:
            var screenAspectRatio = (UIScreen.main.bounds.size.height / (UIScreen.main.bounds.size.width - CGFloat(borderWidth * 2)))
            return (UIScreen.main.bounds.size.width - CGFloat(borderWidth * 2)) * 1.417 * CGFloat(information.pdf.numOfPages)
        default:
            return 180
        }
        
    }

    func webViewDidFinishLoad(_ webView: UIWebView) {
        for subview:UIView in webView.scrollView.subviews {
            if (subview is UIScrollView) {
                for shadowView: UIView in subview.subviews {
                    if (shadowView is UIImageView) {
                        shadowView.isHidden = true
                    }
                }
            }
            
            subview.layer.shadowOpacity = 0
            for subsubview in subview.subviews {
                subsubview.layer.shadowOpacity = 0
            }
        }
    }
    
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool
    {
        switch navigationType {
        case .linkClicked:
            // Open links in Safari
            guard let url = request.url else { return true }
            
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                // openURL(_:) is deprecated in iOS 10+.
                UIApplication.shared.openURL(url)
            }
            return false
        default:
            // Handle other navigation types...
            return true
        }
    }*/

}
