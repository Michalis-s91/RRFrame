//
//  MapViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 26/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class customPin :NSObject, MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    
    
    init(pinTitle:String, location: CLLocationCoordinate2D) {
        self.title = pinTitle
        self.coordinate = location
        
    }
}

/// Creates view with map inidcating a specific point of map.
class MapViewController: UIViewController, MKMapViewDelegate  {
    
    @IBOutlet var map: MKMapView!
    @IBOutlet var routeDescriptionLabel: UILabel!
    @IBOutlet var indicator: UIActivityIndicatorView!
    @IBOutlet weak var mapBottom: NSLayoutConstraint!
    
    var latitude : String!
    var longitude : String!
    var name : String!
    var address : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // For use in foreground
        //locationManager.requestWhenInUseAuthorization()
        var sourceCoordinates = CLLocationCoordinate2D()
        
        if (CLLocationManager.locationServicesEnabled() && (NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable()) && currentLocation != nil) {
            
            switch CLLocationManager.authorizationStatus() {
            case .notDetermined, .restricted, .denied:
                print("No access")
                DispatchQueue.main.async(execute: {() -> Void in
                    self.indicator.stopAnimating()
                    self.mapBottom.constant = 0.0
                })
            case .authorizedAlways, .authorizedWhenInUse:
                print("Access")
                sourceCoordinates = CLLocationCoordinate2DMake(currentLocation.coordinate.latitude, currentLocation.coordinate.longitude)
                
                let lat: CLLocationDegrees = Double(latitude.replacingOccurrences(of: " ", with: ""))!
                let lon: CLLocationDegrees = Double(longitude.replacingOccurrences(of: " ", with: ""))!
                
                let location = CLLocation(latitude: lat, longitude: lon)
                let destinationCoordinates = CLLocationCoordinate2DMake(lat, lon)
                
                map.delegate = self
                map.showsUserLocation = true
                map.mapType = MKMapType(rawValue: 0)!
                map.userTrackingMode = MKUserTrackingMode(rawValue: 2)!
                
                DispatchQueue.global(qos: .background).async {
                    self.showRouteOnMap(sourceCoordinate: sourceCoordinates, destinationCoordinate: destinationCoordinates)
                }
                
            }
        } else {
            print("Location services are not enabled")
            self.indicator.stopAnimating()
            self.mapBottom.constant = 0.0
        }
        
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        isViewPushed = false
    }
    
    func showRouteOnMap(sourceCoordinate: CLLocationCoordinate2D, destinationCoordinate: CLLocationCoordinate2D) {
        let sourcePin = customPin(pinTitle : "Your Location" , location: sourceCoordinate)
        let destinationPin = customPin(pinTitle : name , location: destinationCoordinate)
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.map.addAnnotation(sourcePin)
            self.map.addAnnotation(destinationPin)
        })
        
        let sourcePlacemark = MKPlacemark(coordinate: sourceCoordinate, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate, addressDictionary: nil)
        
        let directionRequest = MKDirectionsRequest()
        directionRequest.source = MKMapItem(placemark: sourcePlacemark)
        directionRequest.destination = MKMapItem(placemark: destinationPlacemark)
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = true
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            DispatchQueue.main.async(execute: {() -> Void in
                guard let directionsResponse = response else{
                    if let error = error {
                        print ("We have error getting directions")
                    }
                    return
                }
                
                var route = directionsResponse.routes[0]
                var shortestTime = directionsResponse.routes[0].expectedTravelTime
                var shortestDistance = directionsResponse.routes[0].distance
                
                for r in directionsResponse.routes
                {
                    if(r.expectedTravelTime < shortestTime)
                    {
                        route = r
                        shortestTime = r.expectedTravelTime
                        shortestDistance = r.distance
                    }
                }
                
                self.routeDescriptionLabel.text = "\(Int(round(shortestTime/60))) min (\(String(format: "%.1f", shortestDistance/1000)) km)"
                self.map.add(route.polyline, level: .aboveRoads)
                
                self.indicator.stopAnimating()
                
                let rect = route.polyline.boundingMapRect
                self.map.setRegion(MKCoordinateRegionForMapRect(rect), animated: true)
            })
        }
        
        self.map.delegate = self
        
    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 4.0
        
        return renderer
    }
    
    func addAnnotationsOnMap(locationToPoint : CLLocation){
        
        var annotation = MKPointAnnotation()
        annotation.coordinate = locationToPoint.coordinate
        var geoCoder = CLGeocoder ()
        geoCoder.reverseGeocodeLocation(locationToPoint, completionHandler: { (placemarks, error) -> Void in
            if let placemarks = placemarks as? [CLPlacemark], placemarks.count > 0 {
                var placemark = placemarks[0]
                var addressDictionary = placemark.addressDictionary;
                annotation.title = addressDictionary!["Name"] as? String
                self.map.addAnnotation(annotation)
            }
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = address
        
        let lat: CLLocationDegrees = Double(latitude.replacingOccurrences(of: " ", with: ""))!
        let lon: CLLocationDegrees = Double(longitude.replacingOccurrences(of: " ", with: ""))!
        
        let location = CLLocation(latitude: lat, longitude: lon)
        let coordinates = CLLocationCoordinate2DMake(lat, lon)
        map.centerCoordinate = coordinates
        let regionRadius: CLLocationDistance = 1000
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,regionRadius, regionRadius)
        map.setRegion(coordinateRegion, animated: true)
        let marker = MapMarker(title: name, locationName: name, discipline: "", coordinate: coordinates)
        map.addAnnotation(marker)
    }
    
    
    
}


/// Helper class for making map.
class MapMarker : NSObject, MKAnnotation
{
    let title: String?
    let locationName: String
    let discipline: String
    let coordinate: CLLocationCoordinate2D
    
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameters:
    ///   - title: The title.
    ///   - locationName: The location name.
    ///   - discipline: The discipline.
    ///   - coordinate: The coordinate.
    init(title: String, locationName: String, discipline: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.locationName = locationName
        self.discipline = discipline
        self.coordinate = coordinate
        
        super.init()
    }
}

