//
//  RightDrawerViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 30/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates right drawer view.
class RightDrawerViewController: ViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var rightDrawerTableView: UITableView!
    
    var items : [RightDrawerItem] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        rightDrawerTableView.delegate = self
        rightDrawerTableView.dataSource = self
        
        rightDrawerTableView.frame = CGRect(x: rightDrawerTableView.frame.origin.x, y: rightDrawerTableView.frame.origin.y, width: rightDrawerTableView.frame.size.width, height: UIScreen.main.bounds.size.height - offset)
        roundCorners([.topLeft,.bottomLeft],radius:10, view: rightDrawerTableView )
        
        rightDrawerTableView.separatorStyle = .none
        rightDrawerTableView.backgroundColor = Colors.leftDrawerBackground
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "right_drawer_cell") as! RightDrawerViewCell
        
        let item = items[indexPath.row]
        
        switch item.type {
        case RightDrawerType.Switch.rawValue:
            cell = cell as! RightDrawerSwitchViewCell
        default:
            break
        }
        
        cell.backgroundColor = Colors.leftDrawerBackground
        roundCorners([.topRight,.bottomRight], radius: 10, view: cell)
        
        let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.clear
        cell.selectedBackgroundView = backgroundView
        
        return cell
    }

}
