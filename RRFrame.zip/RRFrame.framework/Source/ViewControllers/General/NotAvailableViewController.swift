//
//  NotAvailableViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 16/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates a view that is been showed when there is nothing available to show.
class NotAvailableViewController: UIViewController {
    
    @IBOutlet var image: UIImageView!
    @IBOutlet var label: UILabel!

    //@IBOutlet var imageTop: NSLayoutConstraint!
    @IBOutlet var imageHeight: NSLayoutConstraint!
    @IBOutlet var imageWidth: NSLayoutConstraint!
    @IBOutlet var labelTop: NSLayoutConstraint!
    
    var notAvailableView : NotAvailableModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notAvailableView = viewsDB.getNotAvailableView()
        
        if(notAvailableView != nil)
        {
            self.view.backgroundColor = UIColor(notAvailableView.backgroundColor)
            
            label.textColor = UIColor(notAvailableView.messageTextColor)
            label.font = UIFont (name: (notAvailableView.messageFont)!, size: CGFloat((notAvailableView.messageTextSize)!))
            
            if(!isNullOrEmpty(string: notAvailableView.image))
            {
                var uiImage = viewsDB.getNotAvailableImage()
                
                if((uiImage?.size.width)! > (UIScreen.main.bounds.width - 40))
                {
                    imageWidth.constant = UIScreen.main.bounds.width - 40
                }
                else
                {
                    imageWidth.constant = (uiImage?.size.width)!
                }
                
                var aspectRatio = (uiImage?.size.height)!/(uiImage?.size.width)!
                imageHeight.constant = imageWidth.constant * aspectRatio
                image.image = uiImage
                
                //imageTop.constant = ((view.frame.size.height  - offset) / CGFloat(2)) -  (image.frame.size.height / CGFloat(2))
            }
            else
            {
                imageHeight.constant = 0
                labelTop.constant = 0
                
                //imageTop.constant = ((view.frame.size.height  - offset) / CGFloat(2))
            }
            
            //let url = URL(string: percentEncode(s: notAvailableView.image))
            //image.kf.setImage(with: url)
        }
    }
    
    class ScaledHeightImageView: UIImageView {
        
        override var intrinsicContentSize: CGSize {
            
            if let myImage = self.image {
                let myImageWidth = myImage.size.width
                let myImageHeight = myImage.size.height
                let myViewWidth = self.frame.size.width
                
                let ratio = myViewWidth/myImageWidth
                let scaledHeight = myImageHeight * ratio
                
                return CGSize(width: myViewWidth, height: scaledHeight)
            }
            
            return CGSize(width: -1.0, height: -1.0)
        }
        
    }
    
    func setLabel(labelText : String)
    {
        label.text = labelText
    }
}
