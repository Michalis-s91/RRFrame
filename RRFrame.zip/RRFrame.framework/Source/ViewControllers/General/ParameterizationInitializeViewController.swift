//
//  ParameterizationInitializeViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 03/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Creates view that is been shown when paramerization is needed and there is no access to internet.
class ParameterizationInitializeViewController: ViewController {
    
    
    @IBOutlet var installButton: UIButton!
    @IBOutlet var upgradeNowButton: UIButton!
    @IBOutlet var upgradeLaterButton: UIButton!
    @IBOutlet var messageLabel: UILabel!
    
    @IBOutlet var installButtonWidth: NSLayoutConstraint!
    @IBOutlet var upgradeNowButtonWidth: NSLayoutConstraint!
    @IBOutlet var upgradeLaterButtonWidth: NSLayoutConstraint!
    
    
    var isLoadingParameters = false
    var statusDialogView : DescriptionDialog!
    
    override func viewDidLoad() {
        isViewPushed = true
        
        super.viewDidLoad()
        
        if(syncModel.hasUpdateOnStore)
        {
            installButtonWidth.constant = 0
            
            if(true)
            {
                upgradeLaterButtonWidth.constant = 0
            }
        }
        else
        {
            upgradeNowButtonWidth.constant = 0
            upgradeLaterButtonWidth.constant = 0
        }
        
        if(syncModel.hasUpdateOnStore)
        {
            messageLabel.text = syncModel.whatIsNew //"Threre is an upgrade to version \(syncModel.updateVersion!)."
        }
        else if((localDatabase.getAppUser() == nil || !(localDatabase.isAPKRegistered(bussinessID: clientID))!))
        {
            messageLabel.text = "Please active your internet connection and click \"INSTALL\" in order to install the basic app components."
        }
        
        roundCorners(.allCorners, radius: 10, view: installButton)
        roundCorners(.allCorners, radius: 10, view: upgradeNowButton)
        roundCorners(.allCorners, radius: 10, view: upgradeLaterButton)
        
        navigationController?.navigationBar.tintColor = Colors.navigationBarTintColor
        navigationController?.navigationBar.barTintColor = Colors.colorPrimary
        navigationController?.navigationBar.isTranslucent = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        /*statusModel = StatusModel()
        statusDB.insertStatus(status : statusModel, apk : APK)
        
        parameterizationDatabase.deleteEntries(apk : APK)
        viewsDB.deleteEntries(apk : APK)
        //loyaltyDB.deleteEntries(apk : APK)
        storesDB.deleteEntries(apk : APK)
        userProfileDB.deleteEntries(apk : APK)
        productsDB.deleteEntries(apk: APK)*/
        
        navigation = self.navigationController
        
        let sb = UIStoryboard(name:"StatusDialog",bundle:nil)
        self.statusDialogView = sb.instantiateInitialViewController()! as? DescriptionDialog
        self.statusDialogView.dismissWhenClickOutside = false
    }
    
    @IBAction func installButtonClicked(_ sender: UIButton) {
        if(!areParametersDownloading)
        {
            areParametersDownloading = true
            
            if ((NetworkHelper.isReachable() && NetworkHelper.isNetworkAvailable()) || syncModel.hasUpdateOnStore)
            {
                DispatchQueue.global(qos: .background).async {
                    isViewPushed = false
                    
                    var launchScreen : UIViewController!
                    
                    let LaunchScreenStoryBoard = UIStoryboard(name: "OverlaySplashScreen", bundle: nil)
                    
                    switch APK {
                    case APKsEnum.RichReach.rawValue:
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    case APKsEnum.BeautyLine.rawValue :
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "BeautyLineLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    case APKsEnum.HollandAndBarrett.rawValue :
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "HollandAndBarrettLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    default:
                        let LaunchScreenStoryBoard2 = UIStoryboard(name: "RichReachLaunchScreen", bundle: nil)
                        launchScreen =  LaunchScreenStoryBoard2.instantiateInitialViewController()
                    }
                    
                    DispatchQueue.main.async(execute: {() -> Void in
                        self.present(launchScreen, animated: true, completion: nil)
                    })
                    
                    func failureAction()
                    {
                        /*statusModel = StatusModel()
                        statusDB.insertStatus(status : statusModel, apk : APK)
                        
                        parameterizationDatabase.deleteEntries(apk : APK)
                        viewsDB.deleteEntries(apk : APK)
                        //loyaltyDB.deleteEntries(apk : APK)
                        storesDB.deleteEntries(apk : APK)
                        userProfileDB.deleteEntries(apk : APK)
                        productsDB.deleteEntries(apk: APK)*/
                    }
                    
                    do
                    {
                        checkForSync(APK : APK)
                        try APKChanger.downloadParameters(viewController : self, launchScreen : launchScreen, failureAction: failureAction)
                    }
                    catch
                    {
                        self.isLoadingParameters = false
                    }
                }
            }
            else
            {
                self.present(self.statusDialogView,animated:true)
                self.statusDialogView.setDialogView(title: NSLocalizedString("syncSatus", comment: ""), description: NSLocalizedString("instalationFailed", comment: ""))
                areParametersDownloading = false
                
                /*DispatchQueue.main.async(execute: {() -> Void in
                 self.present(self.statusDialogView,animated:true)
                 self.statusDialogView.setDialogView(title: NSLocalizedString("syncSatus", comment: ""), description: NSLocalizedString("upgradeFailed", comment: ""))
                 self.isLoadingParameters = false
                 })*/
            }
        }
    }
    
    @IBAction func upgradeNowButtonClicked(_ sender: UIButton) {
        /*if let bundleIdentifier = Bundle.main.bundleIdentifier {
            //appSupportURL.appendingPathComponent(".appendingPathComponent("Documents")
            if let url = URL(string: "itms-apps://itunes.apple.com/app/\(bundleIdentifier)"),
                UIApplication.shared.canOpenURL(url){
                UIApplication.shared.openURL(url)
            }
        }*/
        
        /*if let bundleIdentifier = Bundle.main.bundleIdentifier {
            //appSupportURL.appendingPathComponent(".appendingPathComponent("Documents")
            if let url = URL(string: "https://itunes.apple.com/cy/app/beauty-line/id1440122167?mt=8"),
                UIApplication.shared.canOpenURL(url){
                UIApplication.shared.openURL(url)
            }
        }*/
        
        
        var bundleIdentifier: String {
            return Bundle.main.infoDictionary?["CFBundleIdentifier"] as! String
        }
        let baseURL: String = "http://itunes.apple.com/lookup?bundleId=\(bundleIdentifier)"
        let encodedURL = baseURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        
        // Creating URL Object
        let url = URL(string:encodedURL!)
        
        // Creating a Mutable Request
        var request = URLRequest.init(url: url!)
        
        //Setting HTTP values
        request.httpMethod = "GET"
        request.timeoutInterval = 120
        
        let configuration = URLSessionConfiguration.default
        
        let session = URLSession(configuration: configuration)
        
        let downloadTask = session.dataTask(with: request, completionHandler: { (data, response, error) -> Void in
            
            //API Call over,getting Main queue
            DispatchQueue.main.async(execute: { () -> Void in
                
                if error == nil
                {
                    
                    if data != nil {
                        
                        do {
                            
                            let resultDictionary:NSDictionary! = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! NSDictionary
                            
                            if resultDictionary != nil && resultDictionary.count > 0 {
                                if (resultDictionary.object(forKey: "results") as! NSArray).count != 0 {
                                    let AppName = "\(((resultDictionary.object(forKey: "results") as! NSArray).object(at: 0) as! NSDictionary).object(forKey: "trackCensoredName")!)"
                                    let AppId = "\(((resultDictionary.object(forKey: "results") as! NSArray).object(at: 0) as! NSDictionary).object(forKey: "trackId")!)"
                                    print("AppName : \(AppName) \nAppId: \(AppId)")
                                    
                                    if let bundleIdentifier = Bundle.main.bundleIdentifier {
                                        //appSupportURL.appendingPathComponent(".appendingPathComponent("Documents")
                                        if let url = URL(string: "itms-apps://itunes.apple.com/app/\(AppId)"),
                                            UIApplication.shared.canOpenURL(url){
                                            UIApplication.shared.openURL(url)
                                        }
                                    }
                                }
                            } else {
                                print("Unable to proceed your request,Please try again")
                            }
                        } catch {
                            print("Unable to proceed your request,Please try again")
                            
                        }
                    } else {
                        print("Unable to proceed your request,Please try again")
                    }
                } else {
                    print("Unable to proceed your request,Please try again")
                }
            })
            
        })
        downloadTask.resume()
    }
    
    
    func showFirstView()
    {
        var leftDrawerTabsList : [Tab]! = []
        leftDrawerTabsList = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
        
        if(defaultTabID == nil)
        {
            let theme  = parameterizationDatabase.getTheme(apk: APK)
            
            if(theme != nil)
            {
                defaultTabID = theme?.defaultTabID
            }
        }
        
        if(defaultTabID != nil)
        {
            for t in leftDrawerTabsList
            {
                if(t.id == defaultTabID)
                {
                    if(t.isVissible)
                    {
                        let storyboard = UIStoryboard(name: t.storyboardName , bundle: nil)
                        let viewController = storyboard.instantiateViewController(withIdentifier: t.viewID) as! UINavigationController
                        separatorHeight = t.separatorHeight
                        separatorColor = t.separatorColor
                        self.present(viewController, animated: true, completion: nil)
                    }
                    else
                    {
                        findFirstTab()
                    }
                }
            }
        }
        else
        {
            findFirstTab()
        }
    }
    
    func findFirstTab()
    {
        var leftDrawerTabsList : [Tab]! = []
        leftDrawerTabsList = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
        
        var firstTab : Tab!
        
        for t in leftDrawerTabsList
        {
            if(t.isVissible)
            {
                firstTab = t
                break
            }
        }
        
        if(!firstTab.isParent)
        {
            if(firstTab.type == LeftDrawerTabsType.Businesses.rawValue)
            {
                AllPartnersView.displayLoyaltyPartnersOnly = false
            }
            
            let storyboard = UIStoryboard(name: firstTab.storyboardName , bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: firstTab.viewID) as! UINavigationController
            self.present(viewController, animated: true, completion: nil)
            separatorHeight = firstTab.separatorHeight
            separatorColor = firstTab.separatorColor
        }
        else
        {
            var relations : [PCRelation]!
            relations = parameterizationDatabase.getPCRelations(apk: APK)
            
            for r in relations!
            {
                if (r.parentID == firstTab.id)
                {
                    for t in leftDrawerTabsList
                    {
                        if(t.id == r.childID && t.isVissible)
                        {
                            if(t.type == LeftDrawerTabsType.Businesses.rawValue)
                            {
                                AllPartnersView.displayLoyaltyPartnersOnly = false
                            }
                            
                            let storyboard = UIStoryboard(name: t.storyboardName , bundle: nil)
                            let viewController = storyboard.instantiateViewController(withIdentifier: t.viewID) as! UINavigationController
                            separatorHeight = t.separatorHeight
                            separatorColor = t.separatorColor
                            self.present(viewController, animated: true, completion: nil)
                        }
                    }
                    
                }
            }
        }
    }
}
