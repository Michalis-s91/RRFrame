//
//  LeftDrawerViewController.swift
//  RichReach2
//
//  Created by Eumbrella on 08/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

var expandedTable : [Int] = []
var leftDrawerTopPadding : Int!

/// Creates the left drawer view.
class LeftDrawerViewController: ViewController, UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate {
    
    @IBOutlet weak var leftDrawerBlankView: UIView!
    @IBOutlet var leftDrawerView: UIView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var leftDrawerView2: UIView!
    @IBOutlet var leftDtawerView3: UIView!
    @IBOutlet var scrollView: UIScrollView!
    
    @IBOutlet var leftDrawerTop1: NSLayoutConstraint!
    @IBOutlet var leftDrawerTop2: NSLayoutConstraint!
    
    var spaceBetweenTableScreen : CGFloat = 0
    static var leftDrawerGroupTabs : [String] = []
    static var leftDrawerGroupTabsID : [Int] = []
    var leftDrawerGroupsChildTabs : [[String]] = [[]]
    
    var leftDrawerTabsList : [Tab]! = []
    var relations : [PCRelation]!
    static var bold = false
    static var italic = false
    static var showImages = false
    static var showLine = false
    static var parentFont : String!
    static var parentTextSize : CGFloat!
    static var childFont : String!
    static var childTextSize : CGFloat!
    
    var currentTab : String!
    var previousTab : String!
    var initialContainerHeight : CGFloat!
    var socialMediaIndex = -1
    var isSocialMediaTabExpanded = false
    var highlightedTabString : String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        spaceBetweenTableScreen = UIScreen.main.bounds.size.width - tableView.frame.size.width
        numberOfNotifications = 0
        numberOfGeneralNotifications = 0
        numberOfPromotionNotifications = 0
        
        DispatchQueue.global(qos: .background).async {
            /*if(localDatabase.isAPKRegistered(bussinessID: clientID))
            {
                
            }
            else
            {
                numberOfGeneralNotifications = 0
                numberOfPromotionNotifications = 0
                numberOfNotifications = 0
                
                DispatchQueue.main.async(execute: {() -> Void in
                    if(APK == Bundle.main.bundleIdentifier!)
                    {
                        UIApplication.shared.applicationIconBadgeNumber = 0
                    }
                })
            }*/
        }
        
        /*leftDtawerView3.backgroundColor = Colors.leftDrawerBackground
        leftDtawerView3.layer.shadowColor = UIColor.darkGray.cgColor
        //leftDtawerView3.frame = CGRect(x: 0, y: 0, width: leftDrawerView2.frame.size.width, height: leftDrawerView2.frame.size.height)
        leftDtawerView3.layer.shadowOffset = CGSize(width: 5.0, height: 5.0)
        leftDtawerView3.layer.shadowOpacity = 0.7
        leftDtawerView3.layer.shadowRadius = 20
        
        
        roundCorners([.topRight,.bottomRight],radius:10, view: leftDrawerView2 )
        leftDrawerView2.backgroundColor = Colors.leftDrawerBackground*/
        

        //roundCorners([.topRight,.bottomRight],radius:10, view: leftDtawerView3 )
        

        socialMediaIndex = -1
        leftDtawerView3.backgroundColor = Colors.leftDrawerBackground
        
        leftDtawerView3.layer.shadowColor = Colors.leftDrawerShadowColor.cgColor // UIColor.darkGray.cgColor
        leftDtawerView3.backgroundColor = Colors.leftDrawerBackground
        leftDtawerView3.layer.shadowOffset = CGSize(width: 5.0, height: 5.0)
        leftDtawerView3.layer.shadowOpacity = 0.7
        leftDtawerView3.layer.shadowRadius = 20
        
        //roundCorners([.topRight,.bottomRight],radius:10, view: leftDrawerView2 )
        leftDrawerView2.frame = CGRect(x: 0, y: 0, width: leftDrawerView2.frame.size.width, height: leftDrawerView2.frame.size.height)
        leftDrawerView2.backgroundColor = Colors.leftDrawerBackground

        if(leftDrawerTopPadding != nil)
        {
            leftDrawerTop1.constant = CGFloat(leftDrawerTopPadding)
            leftDrawerTop2.constant = CGFloat(leftDrawerTopPadding)
        }
        
        tableView.delegate = self
        tableView.dataSource = self
        
        if(viewHeight <= 0.0)
        {
            viewHeight = self.view.frame.size.height - offset
        }
        
        //tableView.frame = CGRect(x: tableView.frame.origin.x, y: tableView.frame.origin.y, width: tableView.frame.size.width, height: 5000 )
        //roundCorners([.topRight,.bottomRight],radius:10, view: tableView )
        
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.clear
        
        var frm = leftDrawerView.frame
        frm.size.width = tableView.layer.frame.width
        leftDrawerView.frame = frm
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(LeftDrawerViewController.onBlankSpaceClick))
        leftDrawerBlankView.isUserInteractionEnabled = true
        leftDrawerBlankView.addGestureRecognizer(tap)
        
        leftDrawerTabsList = parameterizationDatabase.getLeftDrawerTabs(apk: APK)
        relations = parameterizationDatabase.getPCRelations(apk: APK)
        
        var tabIndex = 0
        
        if(selectedTab == nil)
        {
            currentTab = leftDrawerTabsList[0].name
            selectedTab = leftDrawerTabsList[0]
        }
        
        previousTab = currentTab
        highlightedTabString = selectedTab.name
        
        for tab in self.leftDrawerTabsList!
        {
            if(tab.id == defaultTabID)
            {
                currentTab = tab.name
                previousTab = currentTab
                //selectedTab = tab
                highlightedTabString = selectedTab.name
            }
            
            if(relations != nil)
            {
                for r in relations!
                {
                    if(r.childID == tab.id)
                    {
                        r.child = tab
                        break
                    }
                    else if (r.parentID == tab.id)
                    {
                        r.parent = tab
                    }
                }
            }
            tabIndex += 1
        }
        
        for r in relations
        {
            if(r.childID == defaultTabID && r.child.isVissible)
            {
                currentTab = r.child.name
                previousTab = currentTab
                selectedTab = r.child
                tabIndex = 0
                highlightedTabString =  r.parent.name
                break
            }
        }
        
        setBorder(tab: selectedTab)
        
        //tableView.selectRow(at: IndexPath(row: 0, section : 0) , animated: false, scrollPosition: .none)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        /* Don't call super.viewWillAppear() */
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let path = UIBezierPath(roundedRect:leftDrawerView2.bounds, byRoundingCorners:[.bottomRight, .topRight],  cornerRadii: CGSize(width: 10, height:  10))
        
        let maskLayer = CAShapeLayer()
        
        maskLayer.path = path.cgPath
        leftDrawerView2.layer.mask = maskLayer
    }
    
    override func viewDidAppear(_ animated: Bool) {
        /*
         Override viewDidAppear so the super.viewDidAppear don't get called
         */
        if #available(iOS 11.0, *) {
            //let window = UIApplication.shared.keyWindow
            //let bottomPadding = window?.safeAreaInsets.bottom
            //let bottomPadding = view.safeAreaInsets.bottom

            self.view.frame.size.height = self.view.safeAreaLayoutGuide.layoutFrame.size.height
            leftDrawerView2.frame.size.height = self.view.safeAreaLayoutGuide.layoutFrame.size.height
        }
        else
        {
            //self.view.frame.size.height = viewHeight
            //leftDrawerView2.frame.size.height = viewHeight
        }
        
        //initialContainerHeight = containerView.frame.size.height
    }
    
    
    @objc func onBlankSpaceClick(sender:UITapGestureRecognizer) {
        self.showHideLeftDrawer()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "left_drawer_cell") as! LeftDrawerViewCell
        var tab : Tab!
        
        cell.backgroundColor = UIColor.clear
        cell.leftDrawerLabel.textColor = Colors.leftDrawerItemTextColor
        cell.leftDrawerLabel.font = UIFont (name: FontsAndSizes.leftDrawerFont, size: CGFloat(FontsAndSizes.leftDrawerSize))
        //cell.line.backgroundColor = Colors.leftDrawerSelectedItemBackground
        
        var parentCount = 0
        
        if(cell.leftDrawerExpand != nil)
        {
            cell.leftDrawerExpand.isHidden = true
        }
        
        if (!LeftDrawerViewController.showImages)
        {
            cell.leftDrawerImageWidth.constant = 0
            cell.lableLeadingSpace.constant = 15
            cell.lineLeading.constant  = 23
        }
        else
        {
            cell.leftDrawerImageWidth.constant = 30
            cell.lableLeadingSpace.constant = 20
            cell.lineLeading.constant = 8
        }
        
        for t in self.leftDrawerTabsList
        {
            if(LeftDrawerViewController.leftDrawerGroupTabsID[indexPath.row] == t.id)
            {
                tab = t
                if(t.type == LeftDrawerTabsType.SocialMedia.rawValue)
                {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "left_drawer_social_media_child_cell") as! LeftDrawerSocialViewCell
                    
                    cell.line.backgroundColor = Colors.leftDrawerLineColor
                    
                    if(socialMedia == nil)
                    {
                        socialMedia = parameterizationDatabase.getSocialMedia()
                        t.isParent = true
                    }
                    
                    if(socialMediaIndex == indexPath.row)
                    {
                        if(t.isExpanded)
                        {
                            if(cell.leftDrawerExpand != nil)
                            {
                                cell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                                cell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                            }
                            
                            cell.line.backgroundColor = UIColor.clear
                        }
                        else
                        {
                            if(socialMedia.count > 4)
                            {
                                cell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                                cell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                            }
                            else
                            {
                                cell.secondImageLeading.constant = 30
                                cell.thirdImageLeading.constant = 30
                                cell.fourthImageLeading.constant = 30

                            }
                        }
                    }
                    else if(socialMediaIndex == -1)
                    {
                        if(socialMedia.count > 4)
                        {
                            if(cell.leftDrawerExpand != nil)
                            {
                                cell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                                cell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                            }
                        }
                        else
                        {
                            cell.secondImageLeading.constant = 30
                            cell.thirdImageLeading.constant = 30
                            cell.fourthImageLeading.constant = 30
                            
                            if(cell.leftDrawerExpand != nil)
                            {
                                cell.leftDrawerExpand.removeFromSuperview()
                            }
                        }
                        socialMediaIndex = indexPath.row
                    }
                    else
                    {
                        if(cell.leftDrawerExpand != nil)
                        {
                            cell.leftDrawerExpand.frame.size.width = 0
                        }
                        
                        if((indexPath.row - socialMediaIndex) != Int(socialMedia.count/4))
                        {
                            cell.line.backgroundColor = UIColor.clear
                        }
                    }

                    
                    if (!LeftDrawerViewController.showImages)
                    {
                        cell.firstimageLeading.constant = 23
                    }
                    else
                    {
                        cell.firstimageLeading.constant = 8
                    }
                    
                    
                    cell.firstImageWidth.constant = 22
                    cell.secondImageWidth.constant = 22
                    cell.thirdImageWidth.constant = 22
                    cell.fourthImageWidth.constant = 22
                    
                    var tabSocialMedia : [SocialMediaModel] = []
                    let startIndex = indexPath.row - socialMediaIndex
                    for i in startIndex*4..<(startIndex*4 + 4)
                    {
                        
                        var type = 0
                        if(i >= 0 && i < socialMedia.count)
                        {
                            type = socialMedia[i].type
                            tabSocialMedia.append(socialMedia[i])
                        }
                        else
                        {
                            type = -1
                        }
                        switch type
                        {
                        case SocialMediaTypes.Facebook.rawValue:
                            let pos = i % 4
                            if(pos == 0)
                            {
                                cell.firstImage.image = UIImage(named: "ic_facebook")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if (pos == 1)
                            {
                                cell.secondmage.image = UIImage(named: "ic_facebook")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if(pos == 2)
                            {
                                cell.thirdmage.image = UIImage(named: "ic_facebook")?.withRenderingMode(.alwaysTemplate)
                            }
                            else
                            {
                                cell.fourthmage.image = UIImage(named: "ic_facebook")?.withRenderingMode(.alwaysTemplate)
                            }
                        case SocialMediaTypes.Instangram.rawValue:
                            let pos = i % 4
                            if(pos == 0)
                            {
                                cell.firstImage.image = UIImage(named: "ic_instangram")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if (pos == 1)
                            {
                                cell.secondmage.image = UIImage(named: "ic_instangram")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if(pos == 2)
                            {
                                cell.thirdmage.image = UIImage(named: "ic_instangram")?.withRenderingMode(.alwaysTemplate)
                            }
                            else
                            {
                                cell.fourthmage.image = UIImage(named: "ic_instangram")?.withRenderingMode(.alwaysTemplate)
                            }
                        case SocialMediaTypes.Twitter.rawValue:
                            let pos = i % 4
                            if(pos == 0)
                            {
                                cell.firstImage.image = UIImage(named: "ic_twitter")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if (pos == 1)
                            {
                                cell.secondmage.image = UIImage(named: "ic_twitter")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if(pos == 2)
                            {
                                cell.thirdmage.image = UIImage(named: "ic_twitter")?.withRenderingMode(.alwaysTemplate)
                            }
                            else
                            {
                                cell.fourthmage.image = UIImage(named: "ic_twitter")?.withRenderingMode(.alwaysTemplate)
                            }
                        case SocialMediaTypes.Internet.rawValue:
                            let pos = i % 4
                            if(pos == 0)
                            {
                                cell.firstImage.image = UIImage(named: "ic_internet")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if (pos == 1)
                            {
                                cell.secondmage.image = UIImage(named: "ic_internet")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if(pos == 2)
                            {
                                cell.thirdmage.image = UIImage(named: "ic_internet")?.withRenderingMode(.alwaysTemplate)
                            }
                            else
                            {
                                cell.fourthmage.image = UIImage(named: "ic_internet")?.withRenderingMode(.alwaysTemplate)
                            }
                        case SocialMediaTypes.Pinterest.rawValue:
                            let pos = i % 4
                            if(pos == 0)
                            {
                                cell.firstImage.image = UIImage(named: "ic_pinterest")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if (pos == 1)
                            {
                                cell.secondmage.image = UIImage(named: "ic_pinterest")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if(pos == 2)
                            {
                                cell.thirdmage.image = UIImage(named: "ic_pinterest")?.withRenderingMode(.alwaysTemplate)
                            }
                            else
                            {
                                cell.fourthmage.image = UIImage(named: "ic_pinterest")?.withRenderingMode(.alwaysTemplate)
                            }
                        case SocialMediaTypes.Youtube.rawValue:
                            let pos = i % 4
                            if(pos == 0)
                            {
                                cell.firstImage.image = UIImage(named: "ic_youtube")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if (pos == 1)
                            {
                                cell.secondmage.image = UIImage(named: "ic_youtube")?.withRenderingMode(.alwaysTemplate)
                            }
                            else if(pos == 2)
                            {
                                cell.thirdmage.image = UIImage(named: "ic_youtube")?.withRenderingMode(.alwaysTemplate)
                            }
                            else
                            {
                                cell.fourthmage.image = UIImage(named: "ic_youtube")?.withRenderingMode(.alwaysTemplate)
                            }
                        default:
                            let pos = i % 4
                            if(pos == 0)
                            {
                                cell.firstImageWidth.constant = 0
                            }
                            else if (pos == 1)
                            {
                                cell.secondImageWidth.constant = 0 //frame.size.width = 0
                            }
                            else if(pos == 2)
                            {
                                cell.thirdImageWidth.constant = 0 //frame.size.width = 0
                            }
                            else
                            {
                                cell.fourthImageWidth.constant = 0 //frame.size.width = 0
                            }
                        }

                    }
                    
                    cell.socialMedia = tabSocialMedia
                    cell.firstImage.tintColor = Colors.leftDrawerTintColor
                    cell.secondmage.tintColor = Colors.leftDrawerTintColor
                    cell.thirdmage.tintColor = Colors.leftDrawerTintColor
                    cell.fourthmage.tintColor = Colors.leftDrawerTintColor
                    
                    cell.backgroundColor = UIColor.clear
                    cell.selectionStyle = .none
                    return cell
                }
                
                if(t.isChild)
                {
                    cell = tableView.dequeueReusableCell(withIdentifier: "left_drawer_child_cell") as! LeftDrawerChildViewCell
                    cell.backgroundColor = Colors.leftDrawerChildBackground
                    cell.leftDrawerLabel.textColor = Colors.leftDrawerChildItemTextColor
                    cell.leftDrawerLabel.font = UIFont (name: FontsAndSizes.leftDrawerChildFont, size: CGFloat(FontsAndSizes.leftDrawerChildSize))
                    
                    if(LeftDrawerViewController.italic == true)
                    {
                        cell.leftDrawerLabel.font = cell.leftDrawerLabel.font.withTraits(traits: .traitItalic)
                    }
                    
                    if (!LeftDrawerViewController.showImages)
                    {
                        //cell.lableLeadingSpace.constant = -30
                    }
                    
                    if (!LeftDrawerViewController.showImages)
                    {
                        cell.leftDrawerImageWidth.constant = 0
                        cell.lableLeadingSpace.constant = 0
                    }
                    else
                    {
                        cell.leftDrawerImageWidth.constant = 30
                        cell.lableLeadingSpace.constant = 20
                    }
                }
                else if(t.isParent)
                {
                    cell.leftDrawerExpand.isHidden = false
                    
                    if(t.isExpanded)
                    {
                        cell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                        cell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                    }
                    else
                    {
                        cell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                        cell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                    }
                    
                    if(LeftDrawerViewController.bold)
                    {
                        cell.leftDrawerLabel.font = cell.leftDrawerLabel.font.withTraits(traits: .traitBold) //= cell.leftDrawerLabel.font.withTraits(traits: .traitBold)
                    }
                    
                    parentCount += 1
                }
                else
                {
                    if(LeftDrawerViewController.bold)
                    {
                        cell.leftDrawerLabel.font = cell.leftDrawerLabel.font.withTraits(traits: .traitBold) //= cell.leftDrawerLabel.font.withTraits(traits: .traitBold)
                    }
                    
                    cell.leftDrawerExpand.isHidden = true
                }
                
                
                if(t.image != nil)
                {
                    cell.leftDrawerImage.image = UIImage(named: t.image )?.withRenderingMode(.alwaysTemplate)
                    cell.leftDrawerImage.tintColor = Colors.leftDrawerTintColor
                }
                else
                {
                    cell.leftDrawerImage.image = UIImage(named: "" )
                }
                
                break
            }
        }
        
        if(!LeftDrawerViewController.showLine)
        {
            cell.line.backgroundColor = UIColor.clear
        }
        else
        {
            cell.line.backgroundColor = Colors.leftDrawerLineColor
        }
        
        
        if(tab != nil && tab.type == LeftDrawerTabsType.Notifications.rawValue)
        {
            if(localDatabase.isAPKRegistered(bussinessID: clientID))
            {
                if(tab.isParent)
                {
                    cell.leftDrawerLabel.text = "\(LeftDrawerViewController.leftDrawerGroupTabs[indexPath.row]) (\(numberOfNotifications))"
                }
                else
                {
                    cell.leftDrawerLabel.text = "\(LeftDrawerViewController.leftDrawerGroupTabs[indexPath.row]) (\(numberOfGeneralNotifications))"
                }
            }
            else
            {
                cell.leftDrawerLabel.text = LeftDrawerViewController.leftDrawerGroupTabs[indexPath.row]
            }
        }
        else if(tab != nil && tab.type == LeftDrawerTabsType.PromotionNotifications.rawValue)
        {
            if(localDatabase.isAPKRegistered(bussinessID: clientID))
            {
                cell.leftDrawerLabel.text = "\(LeftDrawerViewController.leftDrawerGroupTabs[indexPath.row]) (\(numberOfPromotionNotifications))"
            }
            else
            {
                cell.leftDrawerLabel.text = LeftDrawerViewController.leftDrawerGroupTabs[indexPath.row]
            }
        }
        else
        {
            cell.leftDrawerLabel.text = LeftDrawerViewController.leftDrawerGroupTabs[indexPath.row]
        }
        
        roundCorners([.topRight,.bottomRight], radius: 10, view: cell)
        cell.leftDrawerImage.tintColor = Colors.leftDrawerTintColor
        
        
        cell.selectionStyle = .none
        
        if(LeftDrawerViewController.leftDrawerGroupTabs[indexPath.row] == highlightedTabString)
        {
            cell.backgroundColor = Colors.leftDrawerSelectedItemBackground
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.view.frame.size.height = viewHeight
        return LeftDrawerViewController.leftDrawerGroupTabs.count
    }
    
    var scrollIndex = 0
    var expandedTabIndex = 0
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var index : Int
        index = indexPath.row
        expandedTabIndex = index
        
        if(LeftDrawerViewController.leftDrawerGroupTabsID[index] == -1)
        {
            /*let RichReachLaunchScreenStoryBoard : UIStoryboard = UIStoryboard(name: "LaunchScreen", bundle: nil)
             let richReachLaunchScreen =  RichReachLaunchScreenStoryBoard.instantiateInitialViewController() as! UIViewController
             self.present(richReachLaunchScreen, animated: true, completion: nil)
             //self.navigationController?.pushViewController(beatyLineLaunchScreen, animated: true)
             
             //parameterizationDatabase.deleteEntries()
             
             APK = Bundle.main.bundleIdentifier!
             LeftDrawerViewController.leftDrawerGroupTabs.removeAll()
             LeftDrawerViewController.leftDrawerGroupTabsID.removeAll()
             
             let initializer = APKInitializer()
             initializer.getProperties()
             initializer.setProperties()
             
             super.viewDidLoad()
             
             leftDrawer.viewDidLoad()
             leftDrawer.tableView.reloadData()
             leftDrawer.selectTab(tabString: leftDrawer.leftDrawerTabsList[0].name)
             //leftDrawer.leftDrawerTabsList[0].type = LeftDrawerTabsType.Businesses.rawValue
             
             tabbar.viewDidLoad()
             
             ViewController.leftDrawerImageDownloaded = false
             ViewController.navImageDownloaded = false
             
             showView(tab: selectedTab, index: 0)
             richReachLaunchScreen.dismiss(animated: true, completion: nil)*/
            
            APK = Bundle.main.bundleIdentifier!
            clientID = ClientIDs.RichReach.rawValue
            businessID = BusinessIDs.RichReach.rawValue
            
            DispatchQueue.main.async(execute: {() -> Void in
                APKChanger.backToRichReach(viewController: self.currentViewController)
            })
            
            return
        }
        
        let selectedCell = self.tableView.cellForRow(at: indexPath) as! LeftDrawerViewCell
        
        var parentCount = -1
        var childCount = -1
        for t in self.leftDrawerTabsList
        {
            if(t.isParent)
            {
                parentCount += 1
            }
            
            if(t.isChild && t.showAtTabbar && t.isVissible)
            {
                childCount += 1
            }
            
            if(LeftDrawerViewController.leftDrawerGroupTabsID[indexPath.row] == t.id)
            {
                if(t.needsUserRegistration)
                {
                    if(localDatabase.isAPKBlocked(bussinessID: clientID))
                    {
                        let sb = UIStoryboard(name:"MessageDialog",bundle:nil)
                        let dialog = sb.instantiateInitialViewController()! as! MessageDialog
                        leftDrawer.present(dialog,animated:true)
                        dialog.setDialogView(title: NSLocalizedString("blockedTitle", comment: ""), description: NSLocalizedString("blockedDescription", comment: ""), buttonName: NSLocalizedString("Ok", comment: ""), dismissWhenClickOutside : false)
                        return
                    }
                    else if (!(localDatabase.isAPKRegistered(bussinessID: clientID))!)
                    {
                        let s = ShowRegistrationDialog()
                        s.viewController = leftDrawer
                        s.showRegistrationDialog()
                        return
                    }
                }
                
                if((t.type == LeftDrawerTabsType.ContactUs.rawValue || t.type == LeftDrawerTabsType.Feedback.rawValue) && (localDatabase.getAppUser() != nil && !localDatabase.getAppUser()!.hasVerifiedEmailAddress))
                {
                    let s = ShowRegistrationDialog()
                    s.viewController = leftDrawer
                    s.showRegistrationDialog(needEmailVerification : true)
                    return
                }
                
                if(t.type == LeftDrawerTabsType.SocialMedia.rawValue)
                {
                    
                    if(t.isExpanded)
                    {
                        if( indexPath.row == socialMediaIndex)
                        {
                            for _ in 1...Int(socialMedia.count/4)
                            {
                                LeftDrawerViewController.leftDrawerGroupTabs.remove(at: index + 1)
                                LeftDrawerViewController.leftDrawerGroupTabsID.remove(at: index + 1)
                            }
                            
                            t.isExpanded = false
                            self.tableView.reloadData()
                        }
                        else
                        {
                            return
                        }
                    }
                    else
                    {
                        if(socialMedia.count > 4)
                        {
                            for i in 1...Int(socialMedia.count/4)
                            {
                                
                                LeftDrawerViewController.leftDrawerGroupTabs.insert("", at: index + i)
                                LeftDrawerViewController.leftDrawerGroupTabsID.insert(t.id, at: index + i)
                            }
                            
                            scrollIndex = indexPath.row + Int(socialMedia.count/4) - 1
                            self.tableView.reloadData()
                            
                            colapseTabs(selectTabFlag: false, selectedTab: index)
                            t.isExpanded = true
                            
                            DispatchQueue.main.async(execute: {
                                
                                var indexPathTemp = IndexPath(row:  self.scrollIndex, section: 0)
                                
                                let cellRect = self.tableView.rectForRow(at: indexPathTemp)
                                let completelyVisible = self.tableView.bounds.contains(cellRect)
                                if (!completelyVisible) {
                                    indexPathTemp = IndexPath(row: indexPath.row, section: 0)
                                    
                                    if(indexPathTemp.row < LeftDrawerViewController.leftDrawerGroupTabs.count)
                                    {
                                        self.tableView.scrollToRow( at: indexPathTemp, at: .top , animated: true)
                                    }
                                }
                            })
                            
                            t.isExpanded = true
                        }
                        
                    }
                    
                    return
                }
                
                if(t.type == LeftDrawerTabsType.DirectLink.rawValue)
                {
                    //restartApp = false
                    UIApplication.shared.openURL(NSURL(string: t.link)! as URL)
                    leftDrawer.selectTab(tabString: leftDrawer.previousTab)
                    leftDrawer.currentTab = leftDrawer.previousTab

                    return
                }
                
                if(t.isChild)
                {
                    //colapseTabs(selectTabFlag : true, selectedTab: 0, closeTabs : false)
                    //colapseTabs(selectTabFlag : true, selectedTab: 0, closeTabs : true)
                    tabIndex = childCount
                    if(selectedTab.id != t.id)
                    {
                        stack.push(t)
                        showView(tab: t, index : childCount)
                    }
                    else
                    {
                        hideLeftDrawer()
                    }
                }
                else if(t.isParent)
                {
                    highlightedTabString = t.name
                    
                    if(!t.isExpanded)
                    {
                        selectedCell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_collapse")?.withRenderingMode(.alwaysTemplate)
                        selectedCell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                        
                        var i = 1
                        for r in relations
                        {
                            if(r.parentID == t.id)
                            {
                                for t in leftDrawerTabsList
                                {
                                    if(t.id == r.childID)
                                    {
                                        //if(r.childID != 8)
                                        //{
                                        if(t.isVissible)
                                        {
                                            LeftDrawerViewController.leftDrawerGroupTabs.insert(t.name, at: index + i)
                                            LeftDrawerViewController.leftDrawerGroupTabsID.insert(t.id, at: index + i)
                                            i += 1
                                            
                                            if(index + 1 <= socialMediaIndex)
                                            {
                                                socialMediaIndex += 1
                                            }
                                        }
                                        //}
                                        //else if (localDatabase.getAppUser()?.partnerID != 0)
                                        //{
                                        //    t.name = (localDatabase.getAppUser()?.partnerShortName)!
                                        //    leftDrawerGroupTabs.insert(t.name, at: index + i)
                                        //    i += 1
                                        //}
                                        
                                        break
                                    }
                                }
                            }
                        }
                        
                        scrollIndex = indexPath.row + i - 1
                        self.tableView.reloadData()
                        
                        colapseTabs(selectTabFlag: false, selectedTab: index)
                        t.isExpanded = true
                        DispatchQueue.main.async(execute: {
                            
                            var indexPathTemp = IndexPath(row:  self.scrollIndex, section: 0)
                            
                            let cellRect = self.tableView.rectForRow(at: indexPathTemp)
                            let completelyVisible = self.tableView.bounds.contains(cellRect)
                            if (!completelyVisible) {
                                indexPathTemp = IndexPath(row: indexPath.row, section: 0)
                                if(indexPathTemp.row < LeftDrawerViewController.leftDrawerGroupTabs.count)
                                {
                                    self.tableView.scrollToRow( at: indexPathTemp, at: .top , animated: true)
                                }
                            }
                        })
                    }
                    else
                    {
                        selectedCell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                        selectedCell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                        selectedCell.setSelected( true, animated: true)
                        
                        for r in relations
                        {
                            if(r.parentID == t.id && r.child.isVissible)
                            {
                                //if(r.childID != 8 || localDatabase.getAppUser()?.partnerID != 0)
                                //{
                                LeftDrawerViewController.leftDrawerGroupTabs.remove(at: index + 1)
                                LeftDrawerViewController.leftDrawerGroupTabsID.remove(at: index + 1)
                                //}
                                
                                if(index + 1 <= socialMediaIndex)
                                {
                                    socialMediaIndex -= 1
                                }
                            }
                        }
                        
                        
                        t.isExpanded = false
                    }
                    
                    selectTab(tabString: t.name)
                    self.tableView.reloadData()
                    
                    /*for cell in tableView.visibleCells as! [LeftDrawerViewCell] {
                        cell.backgroundColor = UIColor.clear
                    }*/
                    
                    
                    
                    if #available(iOS 11.0, *) {
                        print(UIScreen.main.bounds.size.height)
                        let window = UIApplication.shared.keyWindow
                        //let topPadding = window?.safeAreaInsets.top
                        let bottomPadding = window?.safeAreaInsets.bottom
                        self.view.frame.size.height = UIScreen.main.bounds.size.height - UIApplication.shared.statusBarFrame.height - (self.navigationController?.navigationBar.frame.size.height)! - bottomPadding!
                        self.tableView.frame.size.height = self.view.frame.size.height
                    }
                    else
                    {
                        self.view.frame.size.height = viewHeight
                        self.tableView.frame.size.height = self.view.frame.size.height
                        
                        if(!AppDelegate.isPotraitOrientation)
                        {
                            self.view.frame.size.height = UIScreen.main.bounds.size.height - UIApplication.shared.statusBarFrame.height - (self.navigationController?.navigationBar.frame.size.height)!
                            self.tableView.frame.size.height = self.view.frame.size.height
                        }
                    }
                    
                }
                else
                {
                    
                    
                    
                    //t.type = LeftDrawerTabsType.BeautyLine.rawValue
                    if(selectedTab.id != t.id)
                    {
                        stack.push(t)
                        if (showView(tab: t, index : parentCount))
                        {
                            highlightedTabString = t.name
                            colapseTabs(selectTabFlag: false, selectedTab: 0)
                            selectTab(tabString: selectedCell.leftDrawerLabel.text!)
                            previousTab = currentTab
                            currentTab = selectedCell.leftDrawerLabel.text!
                        }
              
                    }
                    else
                    {
                        hideLeftDrawer()
                    }
                }
                
                //scrollView.contentSize = CGSize(width: scrollView.frame.size.width, height: 10000)
                //tableView.frame = CGRect(x: tableView.frame.origin.x, y: tableView.frame.origin.y, width: tableView.frame.size.width, height: 700)
                //tableView.layoutIfNeeded()
                
                break
            }
            
            
        }
    }
    
    /// Colapse all tabs.
    ///
    /// - Parameters:
    ///   - selectTabFlag: If it is true, we have to highlight the tab with uncolapsed tabs,
    ///                    otherwise we don't have to do something
    ///   - selectedTab: The selected tab.
    func colapseTabs(selectTabFlag : Bool, selectedTab : Int, closeTabs : Bool = true )
    {
        var index = 0
        for t in leftDrawerTabsList
        {
            if(t.isExpanded)
            {
                for l in LeftDrawerViewController.leftDrawerGroupTabsID
                {
                    if l == t.id
                    {
                        index = LeftDrawerViewController.leftDrawerGroupTabsID.index(of: l)!
                    }
                }
                
                var expandedCell = LeftDrawerViewCell()
                
                if(self.tableView.cellForRow(at: IndexPath(row: index, section: 0)) != nil)
                {
                    expandedCell = self.tableView.cellForRow(at: IndexPath(row: index, section: 0)) as! LeftDrawerViewCell
                }
                else
                {
                    if(index < LeftDrawerViewController.leftDrawerGroupTabs.count)
                    {
                        self.tableView.scrollToRow(at: IndexPath(row: index, section: 0), at: .top, animated: false)
                    }
                    
                    expandedCell = self.tableView.cellForRow(at: IndexPath(row: index, section: 0)) as! LeftDrawerViewCell
                    
                    if(selectedTab < LeftDrawerViewController.leftDrawerGroupTabs.count)
                    {
                        self.tableView.scrollToRow(at: IndexPath(row: selectedTab, section: 0), at: .middle, animated: false)
                    }
                }
                
                
                expandedCell.leftDrawerExpand.image = UIImage(named: "ic_left_drawer_expand")?.withRenderingMode(.alwaysTemplate)
                expandedCell.leftDrawerExpand.tintColor = Colors.leftDrawerTintColor
                
                if(t.type == LeftDrawerTabsType.SocialMedia.rawValue)
                {
                    for _ in 1...Int(socialMedia.count/4)
                    {
                        LeftDrawerViewController.leftDrawerGroupTabs.remove(at: index + 1)
                        LeftDrawerViewController.leftDrawerGroupTabsID.remove(at: index + 1)
                    }
                }
                else
                {
                    for r in relations
                    {
                        if(r.parentID == t.id && r.child.isVissible)
                        {
                            //if (r.childID != 8 || localDatabase.getAppUser()?.partnerID != 0)
                            //{
                            
                            if(closeTabs)
                            {
                                LeftDrawerViewController.leftDrawerGroupTabs.remove(at: index + 1)
                                LeftDrawerViewController.leftDrawerGroupTabsID.remove(at: index + 1)
                                
                                if(index + 1 <= socialMediaIndex)
                                {
                                    socialMediaIndex -= 1
                                }
                            }
                            
                            if(expandedTabIndex > index)
                            {
                                scrollIndex -= 1
                            }
                            //}
                        }
                    }
                }
                
                if(closeTabs)
                {
                    t.isExpanded = false
                }
                
                tableView.reloadData()
                
                if(selectTabFlag)
                {
                    selectTab(tabString: expandedCell.leftDrawerLabel.text!)
                    previousTab = currentTab
                    currentTab = expandedCell.leftDrawerLabel.text!
                }
                
                
                break
            }
        }
    }
    
    
    /// Highlight tab with given string.
    ///
    /// - Parameter tabString: The name of tab we want to highlight.
    func selectTab(tabString : String)
    {
        var i = 0
        
        if(tableView.visibleCells != nil && tableView.visibleCells.count > 0 )
        {
            for cell in tableView.visibleCells as! [LeftDrawerViewCell]
            {
                if(cell.leftDrawerLabel != nil)
                {
                    if cell.leftDrawerLabel.text?.components(separatedBy: " (")[0] == tabString
                    {
                        cell.backgroundColor =  Colors.leftDrawerSelectedItemBackground
                        self.highlightedTabString = tabString
                    }
                    else
                    {
                        cell.backgroundColor = UIColor.clear
                        tableView.deselectRow(at: IndexPath(row: i, section: 0), animated: false)
                    }
                }
                i = i + 1
            }
        }
    }
}
