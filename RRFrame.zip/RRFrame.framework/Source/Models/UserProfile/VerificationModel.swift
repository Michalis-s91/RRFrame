//
//  VerificationModel.swift
//  RichReach2
//
//  Created by Eumbrella on 17/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class VerificationModel : Codable
{
    var index : Int!
    var type : Int!
    var title : TitleModel!
    var button : ButtonModel!
    var checkBox : CheckBoxModel!
    var id : Int!
    
    private enum CodingKeys : String, CodingKey {
        case index = "CellIndex"
        case type = "CellType"
        case title = "Title"
        case button = "Button"
        case checkBox = "CheckBox"
        case id = "Id"
    }
}
