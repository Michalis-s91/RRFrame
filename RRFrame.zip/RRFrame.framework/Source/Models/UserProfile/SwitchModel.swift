//
//  SwitchModel.swift
//  RichReach
//
//  Created by Eumbrella on 25/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class SwitchModel : Codable
{
    var id : Int!
    var title : String!
    var description : String!
    /*var titleTextSize : Int!
    var titleFont : String!
    var titleTextColor : String!
    var descriptionFont : String!
    var descriptionTextSize : Int!
    var descriptionTextColor : String!
    var tintColor : String!*/
    
    var fieldStyleID : Int!
    var fieldStyle : FieldStyleModel!
    var acceptType : Int!
    var isOn = false
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case title = "Title"
        case description = "Description"
        /*case titleTextSize = "TitleSize"
        case titleFont = "TitleFont"
        case titleTextColor = "TitleColor"
        case descriptionFont = "DescriptionFont"
        case descriptionTextSize = "DescriptionSize"
        case descriptionTextColor = "DescriptionColor"
        case tintColor = "SplitterColor"*/
        
        case fieldStyleID = "FieldStyleID"
        case acceptType = "AcceptType"
    }
}
