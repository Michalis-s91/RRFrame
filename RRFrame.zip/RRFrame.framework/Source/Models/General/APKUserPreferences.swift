//
//  APKUserPreferences.swift
//  RichReach
//
//  Created by Eumbrella on 04/03/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class APKUserPreferences
{
    var acceptNotifications : Bool! = false
    var acceptLocation : Bool! = false
}
