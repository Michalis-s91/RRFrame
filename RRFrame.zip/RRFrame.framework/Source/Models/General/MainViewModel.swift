//
//  MainViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 21/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Main view model class.
class MainViewModel
{
    static var displayWhiteLabelPartner : Bool!
    static var partnerName : String!
    static var hasWhiteLabel = false
}
