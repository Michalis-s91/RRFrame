//
//  StatusModel.swift
//  RichReach2
//
//  Created by Eumbrella on 27/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class StatusModel
{
    var isThemeSaved : Bool! = false
    var areLeftDrawerTabsSaved : Bool! = false
    var areStylesSaved : Bool! = false
    /*var areLeftDrawerStylesSaved : Bool! = false
    var areLeftDrawerChildStylesSaved : Bool! = false
    var isToastStyleSaved : Bool! = false
    var isTabBarStyleSaved : Bool! = false
    var isDialogStyleSaved : Bool! = false*/
    var areRelationsSaved : Bool! = false
    var isLeftDrawerImageSaved : Bool! = false
    var isNavImageSaved : Bool! = false
    
    var areGeneralViewsSaved : Bool! = false
    var areExpandableListViewsSaved : Bool! = false
    var areEmbededViewsSaved : Bool! = false
    var areEmbededViewsParametersSaved : Bool! = false
    var areCategoriesSaved : Bool! = false
    var areBrandsSaved : Bool! = false
    var areProductsSaved : Bool! = false
    var productsPageNo : Int! = 0
    var areBarcodesSaved : Bool! = false
    var barcodesPageNo : Int! = 0
    
    var isBarcodeViewSaved : Bool! = false
    var areContactUsTabRelationsSaved : Bool! = false
    var isContactUsViewSaved : Bool! = false
    var isPointsStatementSaved : Bool! = false
    var pointsStatementPageNo : Int = 1
    var areTicketsSaved : Bool! = false
    var isPointsStatementViewSaved : Bool! = false
    var isTicketViewSaved : Bool! = false
    var areTicketStylesSaved : Bool! = false
    var areGeneralSearchViewSaved : Bool! = false
    var isUserProfileViewSaved : Bool! = false
    var areUserProfileFieldsSaved : Bool! = false
    var areUserProfileFieldsStylesSaved : Bool! = false
    var areStoreLocatorParametersSaved : Bool! = false
    var areStoresSaved : Bool! = false
    var areSocialMediaSaved : Bool! = false
    var areHolidaysSaved : Bool! = false
    
    var areSplashScrennParametersSaved : Bool! = false
    var isNotAvailableViewSaved : Bool! = false
    var isBackgroundImageSaved : Bool! = false
    var isProductMenuSaved : Bool! = false
    var areProductMenuRelationsSaved : Bool! = false
    
    var isFirstViewSaved : Bool! = false
    
    var isOffersSaved : Bool! = false
    var isTermsSaved : Bool! = false
    var isRedemptionSaved: Bool! = false
    var isAboutSaved : Bool! = false
    var isHomeSaved : Bool! = false
    
    var areAuthorsSaved : Bool! = false
    var areArticlesSaved : Bool! = false
    var areProximityOffersSaved: Bool! = false
    
    var isAPKSaved : Bool! = false
    var lastUpdateDate : String! = ""
    var lastProductsSyncDate : String! = ""
}
