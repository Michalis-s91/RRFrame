//
//  ImageCacheModel.swift
//  BeautyLine
//
//  Created by Eumbrella on 20/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class ImageCacheModel
{
    var image : UIImage!
    var url : String!
    var photoModel : PhotoModel!
    var parentModel : ExpandableListParentModel!
    var articleModel : ArticleModel!
    
    init(image : UIImage, url : String, photoModel : PhotoModel! = nil, parentModel : ExpandableListParentModel! = nil, articleModel : ArticleModel! = nil)
    {
        self.image = image
        self.url = url
        self.photoModel = photoModel
        self.parentModel = parentModel
        self.articleModel = articleModel
    }
}
