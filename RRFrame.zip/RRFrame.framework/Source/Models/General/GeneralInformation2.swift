//
//  GeneralInformation2.swift
//  RichReach2
//
//  Created by Eumbrella on 16/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// GeneralInformation is used for creating a list for general information and are parameterised so the are reusable. The information list consits of different types
/// of information (e.g. image, title and description).
class GeneralInformation2 : Codable
{
    var type : Int!
    var index : Int!
    var id : Int!
    var startDate : String!
    var endDate : String!
    
    var tabID : Int!
    var photo : PhotoModel!
    var video : VideoModel!
    var carousel : CarouselModel!
    var text : TextModel!
    var pdf : PDFModel!
    var hour : [HourModel]!
    var title : TitleModel!
    var storeInfoHeader : StoreInfoHeaderModel!
    var product : ProductModel! = ProductModel()
    var article : ArticleModel!
    var share : ShareModel!
    
    var productItemCode : String!
    
    init()
    {
        
    }
    
    /// Constructor for image.
    ///
    /// - Parameters:
    ///   - type: Sets the correspond type.
    ///   - photo: Photo informations.
    init(type : Int , photo : PhotoModel)
    {
        self.type = type
        self.photo = photo
    }

    /// Constructor for text.
    ///
    /// - Parameters:
    ///   - type: Sets the correspond type.
    ///   - photo: Text informations.
    init(type : Int , text : TextModel)
    {
        self.type = type
        self.text = text
    }
    
    /// Constructor for video.
    ///
    /// - Parameters:
    ///   - type: Sets the correspond type.
    ///   - photo: Video informations.
    init(type : Int , video : VideoModel)
    {
        self.type = type
        self.video = video
    }
    
    /// Constructor for carousel.
    ///
    /// - Parameters:
    ///   - type: Sets the correspond type.
    ///   - photo: Carousel informations.
    init(type : Int , carousel : CarouselModel)
    {
        self.type = type
        self.carousel = carousel
    }
    
    
    
    private enum CodingKeys : String, CodingKey {
        case type = "Type"
        case photo = "Photo"
        case video = "Video"
        case carousel = "Carousel"
        case text = "Text"
        case pdf = "Pdf"
        case hour = "Hour"
        case title = "Title"
        //case article = "Article"
        case storeInfoHeader = "StoreInfoHeader"
        case index = "Index"
        case id = "Id"
        case tabID = "TabId"
        case startDate = "StartDate"
        case endDate = "EndDate"
        case productItemCode = "ProductItemCode"
    }
}
