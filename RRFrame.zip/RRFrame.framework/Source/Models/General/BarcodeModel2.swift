//
//  BarcodeModel2.swift
//  RichReach2
//
//  Created by Eumbrella on 29/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class BarcodeModel2 : Codable
{
    var prototype : Int!
    var backgroundColor : String!
    var pointsTextColor : String!
    var pointsTextSize : Int!
    var pointsFont : String!
    var infoTextColor : String!
    var infoTextSize : Int!
    var infoFont : String!
    var pointsType : Int!
    
    private enum CodingKeys : String, CodingKey {
        case prototype = "Prototype"
        case backgroundColor = "BackgroundColor"
        case pointsTextColor = "PointsTextColor"
        case pointsTextSize = "PointsTextSize"
        case pointsFont = "PointsFont"
        case infoTextColor = "InfoTextColor"
        case infoTextSize = "InfoTextSize"
        case infoFont = "InfoFont"
        case pointsType = "TypeID"
    }
}
