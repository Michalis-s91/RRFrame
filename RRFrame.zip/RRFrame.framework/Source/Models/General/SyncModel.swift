//
//  SyncModel.swift
//  RichReach
//
//  Created by Eumbrella on 12/12/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class SyncModel : Codable
{
    var updateAll : Bool! = false
    var updateHome : Bool! = false
    var updateAbout : Bool! = false
    var updateOffers: Bool! = false
    var updateTerms: Bool! = false
    var updateRedemption : Bool! = false
    var updateSplash: Bool! = false
    var updateAddresses: Bool! = false
    var updateProximityOffers: Bool! = false
    var updateStyles: Bool! = false
    var updateExpandable : Bool! = false
    var updateRestParameters : Bool! = false
    var updateProducts : Bool! = false
    var updateProfile : Bool! = false
    var updateAuthors : Bool! = false
    var updateBlogViews : Bool! = false
    
    var hasUpdateOnStore : Bool! = false
    var updateVersionName : String!
    var updateVersionCode : Int64!
    var isUpdateCritical : Bool! = false
    var updateVersionTitle : String! = ""
    var whatIsNew : String! = ""
    
    var currentDateTime : String!
    
    private enum CodingKeys : String, CodingKey {
        case updateAll = "ShouldUpdateAll"
        case updateHome = "ShouldUpdateHomeView"
        case updateAbout = "ShouldUpdateAboutView"
        case updateOffers = "ShouldUpdateOffersView"
        case updateTerms = "ShouldUpdateTermsAndConditionsView"
        case updateRedemption = "ShouldUpdateRedemptionsView"
        case updateSplash = "ShouldUpdateSplashView"
        case updateAddresses = "ShouldUpdateAddressesView"
        case updateProximityOffers = "ShouldUpdateProximityOffers"
        case updateStyles = "ShouldUpdateStyles"
        case updateExpandable = "ShouldUpdateExpandableViews"
        case updateRestParameters = "ShouldUpdateOtherParametersOrViews"
        case updateProducts = "ShouldUpdateProducts"
        case updateProfile = "ShouldUpdateAccountProfileView"
        case updateAuthors = "ShouldUpdateAuthors"
        case updateBlogViews = "ShouldUpdateBlogViews"
        
        case currentDateTime = "CurrentDateAndTime"
        
        case hasUpdateOnStore = "HasUpdateOnStore"
        case updateVersionName = "UpdateVersionName"
        case updateVersionCode = "UpdateVersionCode"
        case isUpdateCritical = "IsUpdateCritical"
        case updateVersionTitle = "UpdateVersionTitle"
        case whatIsNew = "WhatIsNew"
    }
}
