//
//  GeneralInformation.swift
//  RichReach2
//
//  Created by Eumbrella on 14/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// GeneralInformation is used for creating a list for information about an offer and partner. The information list consits of different types
/// of information (e.g. image, title and description) and is created based on available offer/partner information.
class GeneralInformation
{
    var type : Int!
    var title : String!
    var imageUrl : String!
    var description : String!
    
    var stores : [StoresInfo]!
    
    var originalPriceTitle : String!
    var originalPriceText : String!
    var offerDescriptionText : String!
    var offerNewPrice : String!
    
    var website : String!
    var isHasFacebookPage : Bool!
    var facebookPage : String!
    var facebookPageID : String!
    
    var appOfferID : Int!
    
    //Type 0 -> Title
    init(type : Int, title : String)
    {
        self.type = type
        self.title = title
    }
    
    //Type 1 -> Image
    init(type : Int , imageUrl : String)
    {
        self.type = type
        self.imageUrl = imageUrl
    }
    
    //Type 2 -> Description
    init(type : Int , title : String ,description : String!)
    {
        self.type = type
        self.title = title
        self.description = description
    }
    
    //Type 3 -> Discount
    init(type : Int , title : String , originalPriceTitle : String , originalPriceText : String , offerDescriptionText : String , offerNewPrice : String)
    {
        self.type = type
        self.title = title
        self.originalPriceTitle = originalPriceTitle
        self.originalPriceText = originalPriceText
        self.offerDescriptionText = offerDescriptionText
        self.offerNewPrice = offerNewPrice
    }

    //Type 4 -> Stores
    init(type : Int , title : String , stores : [StoresInfo]!)
    {
        self.type = type
        self.title = title
        self.stores = stores
    }
    
    //Type 5 -> Facebook
    init(type : Int , title : String! , website : String!, isHasFacebookPage : Bool, facebookPage: String!, facebookPageID : String!)
    {
        self.type = type
        self.title = title
        self.website = website
        self.isHasFacebookPage = isHasFacebookPage
        self.facebookPage = facebookPage
        self.facebookPageID = facebookPageID
    }
    
    //Type 6 -> Combo
    init(type : Int , appOfferID : Int)
    {
        self.type = type
        self.appOfferID = appOfferID
    }
    
}
