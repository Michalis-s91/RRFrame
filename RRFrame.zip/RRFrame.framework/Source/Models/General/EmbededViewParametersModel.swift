//
//  EmbededViewParameters.swift
//  RichReach2
//
//  Created by Eumbrella on 17/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class EmbededViewParametersModel : Codable
{
    var apk : String!
    var embededViewID : Int!
    var separatorHeight : Int!
    var separatorColor : String!
    var borderSize : Int!
    var borderColor : String!
    
    private enum CodingKeys : String, CodingKey {
        case apk = "APK"
        case embededViewID = "EmbededViewID"
        case separatorHeight = "SeparatorHeight"
        case separatorColor = "SeparatorColor"
        case borderSize = "BorderSize"
        case borderColor = "BorderColor"
    }
}
