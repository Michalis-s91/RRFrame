//
//  RightDrawerItem.swift
//  RichReach2
//
//  Created by Eumbrella on 03/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Holds information about right drawer item.
class RightDrawerItem
{
    var type : Int!
    var name : String!
    
    //Type 0 -> Switch
    init(type : Int, name : String)
    {
        self.type = type
        self.name = name
    }
}
