//
//  AppUser.swift
//  RichReach2
//
//  Created by Eumbrella on 14/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// AppUser is used for storing and retrieving information regarding the person who uses the app (e.g. phone number, name-surname, privileges, ...).
class AppUser: Codable {
    
    /* Registration related attributes */
    var phoneNumber : String! = ""
    var deviceID : String! = ""
    var receivedRegistrationVerificationCode : Bool! = false
    
    /* Preferred business related attributes */
    var preferredBusinessID : String! = ""
    var preferredBusinessName : String! = ""
    var preferredBusinessShortName : String! = ""
    var preferredBusinessImageUrl : String! = ""
    var displayPreferredBusiness : Bool!
    
    /* User Profile related attributes */
    var title : String!
    var titleID : Int!
    var name : String!
    var surname : String!
    var gender : Int!
    var emailAddress : String!
    var temporaryEmailAddress : String! = ""
    var province : String!
    var city : String!
    var homeAddress : String!
    var homeAddress2 : String!
    var houseNo : String!
    var postCode : String!
    var birthDate : String!
    var country : String!
    var communicationLanguage : String!
    var referedName : String!
    var flatHouseName : String!
    var languageID : Int!
    //var preferredLanguageID : Int!
    var isAdult : Bool! = false
    var shouldReceiveEmail : Bool! = false
    var shouldReceiveSms : Bool! = false
    var shouldReceiveLoyaltyCardNumberBySMS : Bool! = false
    var isLoyaltyUser : Bool! = false
    //var acountID : Int64! = 0
    
    var hasLoyaltyProfile = false
    var hasVerifiedEmailAddress = false
    var hasVerifiedPhoneNumber : Bool! = false
    var needEmailVerification : Bool! = true
    
    var phoneNumberCount : Int! = 0
    var emailAddressCount : Int! = 0
    
    var emailVerifiedIPAddress : String!
    var emailVerifiedDatetime : String!
    var mobilePhoneVerifiedIPAddress : String!
    var mobilePhoneVerifiedDatetime : String!
    
    /*Flags*/
    var isRegistered : Bool! = false
    var isPending : Bool!  = false
    var isPendingEmail : Bool! = false
    
    /* Telephony related attributes */
    var currentBalance : String!
    var lastBalanceSyncDate : String!
    
    /*Registration*/
    var networkOperator =  ""
    var hasUserReceivedRegistrationVerificationCode : Bool!
    var verificationTimeStamp : Date!
    var partnerCode : String!
    
    /*Promocode*/
    var isPromocodeApplied : Bool! = false
    var promocodeAppliedTimestamp : Date!
    var partnerID : Int! = 0
    var partnerImageUri : String!
    var partnerName : String!
    var partnerShortName : String!
    
    /*eOrdering details*/
    var hasAccessToOrdering : Bool!
    var isOrderCustomer : Bool!
    var defaultBrandID : Int!
    var displayWhiteLabelPartner : Bool! = false
    
    /*QuickNumbers Data*/
    var qNLastSync : Date!
    
    var isUserRegisteredToAPNS : Bool! = false
    var paremeterizationInitialized : Bool! = false
    
    var currentAppBuildVersion : Int! = 0
    
    /// Return if the user has received a registration verification code or not.
    ///
    /// - Returns: True if the user has received a registration verification code, otherwise false.
    func hasReceivedRegistrationVerificationCode() -> Bool
    {
        return receivedRegistrationVerificationCode
    }
}
