//
//  MonthModel.swift
//  RichReach2
//
//  Created by Eumbrella on 26/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// MonthModel holds two main properties: The month (e.g. January), the month's number (e.g. 01) and the number of days each month has.
class MonthModel {
    var month : String!
    var monthNumber : String!
    var numOfDays : Int!
    
    init(month : String, monthNumber : String, numOfDays : Int) {
        self.month = month
        self.monthNumber = monthNumber
        self.numOfDays = numOfDays
    }
}
