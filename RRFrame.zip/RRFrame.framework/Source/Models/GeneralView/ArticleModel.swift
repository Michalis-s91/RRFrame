//
//  ArticleModel.swift
//  RichReach
//
//  Created by Eumbrella on 25/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class ArticleModel : Codable
{
    var id : Int64!
    var image : String!
    var categoryID : Int!
    var category : String!
    var title : String!
    var url : String!
    
    var categoryFont : String!
    var categorySize : Int!
    var categoryColor : String!
    
    var titleFont : String!
    var titleSize : Int!
    var titleColor : String!
    
    var dateFont : String!
    var dateTextSize : Int!
    var dateTextColor : String!
    
    var publishDate : String!
    var expirationDate : String!
    
    var authorEmailAddress : String!
    
    var imageAspectRatio : Double!
    var imageData : Data! = Data()
    
    var articleItems : [GeneralInformation2]!
    var areItemsSaved = false
    var isImageLoaded = false
    var isArticleSaved = false
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case image = "ImageUrl"
        case title = "Title"
        case categoryID = "CategoryID"
        case url = "Url"
        case titleFont = "TitleFont"
        case titleSize = "TitleTextSize"
        case titleColor = "TitleTextColor"
        case categoryFont = "CategoryFont"
        case categorySize = "CategoryTextSize"
        case categoryColor = "CategoryTextColor"
        case dateFont = "DateFont"
        case dateTextSize = "DateTextSize"
        case dateTextColor = "DateTextColor"
        case publishDate = "PublishDate"
        case expirationDate = "ExpirationDate"
        case articleItems = "ArticleItems"
        case authorEmailAddress = "AuthorEmailAddress"
    }
}
