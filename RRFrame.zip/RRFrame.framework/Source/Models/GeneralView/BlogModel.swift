//
//  ArticleViewModel.swift
//  RichReach
//
//  Created by Eumbrella on 05/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class BlogModel : Codable
{
    var tabID : Int!
    var image : String!

    var title : String!
    var titleFont : String!
    var titleSize : Int!
    var titleColor : String!
    
    var imageAspectRatio : Double!
    var imageData : Data! = Data()
    
    var articleItems : [GeneralInformation2]!
    
    private enum CodingKeys : String, CodingKey {
        case tabID = "TabID"
        case image = "Image"
        case title = "Title"
        case titleFont = "TitleFont"
        case titleSize = "TitleSize"
        case titleColor = "TitleColor"
    }
}
