//
//  HourModel.swift
//  RichReach2
//
//  Created by Eumbrella on 25/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about store working hours.
class HourModel : Codable
{
    var day :  String!
    var daySize : Int!
    var dayColor : String!
    var dayFont : String!
    var hoursSize: Int!
    var hoursColor : String!
    var hoursFont : String!
    
    
    
    private enum CodingKeys : String, CodingKey {
        case day = "Day"
        //case hours = "Hours"
        case daySize = "DaySize"
        case dayColor = "DayColor"
        case dayFont = "DayFont"
        case hoursSize = "HoursSize"
        case hoursColor = "HoursColor"
        case hoursFont = "HoursFont"
    }
}
