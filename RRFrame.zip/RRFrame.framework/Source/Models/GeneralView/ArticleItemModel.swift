//
//  ArticleItemModel.swift
//  RichReach
//
//  Created by Eumbrella on 28/01/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class ArticleItemModel
{
    var articleID : Int64!
    var type : Int!
    var index : Int!
    var id : Int!
    var productItemCode : String!

    
    private enum CodingKeys : String, CodingKey {
        case type = "Type"
        case index = "Index"
        case id = "Id"
        case productItemCode = "Photo"
        case title = "Title"
        case article = "Article"
    }
}
