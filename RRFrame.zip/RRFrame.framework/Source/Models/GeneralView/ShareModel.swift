//
//  ShareModel.swift
//  RichReach
//
//  Created by Eumbrella on 11/02/2019.
//  Copyright © 2019 Eumbrella. All rights reserved.
//

import Foundation

class ShareModel
{
    var description : String!
    var descriptionFont : String!
    var descriptionTextColor : String!
    var descriptionTextSize : Int!
    var tintColor : String!
    
    var image : Data!
    var title : String!
    var url : String!
}
