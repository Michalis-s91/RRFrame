//
//  ButtonModel.swift
//  RichReach2
//
//  Created by Eumbrella on 11/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ButtonModel : Codable
{
    var id : Int!
    var name : String!
    var height : Int!
    var width : Int!
    var backgroundColor : String!
    var font : String!
    var textSize : Int!
    var textColor : String!
    var imageUrl : String!
    var borderWidth : Int!
    var borderColor : String!
    var tabID : Int!
    var buttonPosition : Int!
    var link : String!
    var cornerRadius : Double!
    
    private enum CodingKeys : String, CodingKey {
        case id = "Id"
        case name = "Name"
        case height = "Height"
        case width = "Width"
        case backgroundColor = "BackgroundColor"
        case font = "Font"
        case textSize = "NameTextSize"
        case textColor = "TextColor"
        case imageUrl = "ImageUrl"
        case borderWidth = "BorderWidth"
        case borderColor = "BorderColor"
        case tabID = "TabID"
        case buttonPosition = "ButtonPosition"
        case link = "Link"
        case cornerRadius = "CornerRadius"
    }
}
