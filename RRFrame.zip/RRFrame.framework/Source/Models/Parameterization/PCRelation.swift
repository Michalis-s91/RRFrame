//
//  PCRelation.swift
//  RichReach2
//
//  Created by Eumbrella on 18/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds data about a relation between parent tabs and child tabs. For example, "Offers" tab is parent of "Wish List" tab, so we have a relation between this two tabs
/// and the correspond data for this relation is to create an object of this class with this data : - parentID = the id of "Offers" tab
///                                                                                                 - childId = the id of "Wish List" tab
class PCRelation : Codable
{
    var parentID : Int!
    var childID : Int!
    
    var parent : Tab! = Tab()
    var child : Tab! = Tab()
    
    private enum CodingKeys : String, CodingKey {
        case parentID = "ParentID"
        case childID = "ChildID"
    }
}

