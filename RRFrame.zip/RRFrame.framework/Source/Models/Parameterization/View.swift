//
//  View.swift
//  RichReach2
//
//  Created by Eumbrella on 22/06/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class GeneralViewModel
{
    var apk : String!
    var index : Int!
    var type : Int!
    var id : Int!
    var tabID : Int!
    var startDate : String!
    var endDate : String!
}
