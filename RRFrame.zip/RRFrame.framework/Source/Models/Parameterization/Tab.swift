//
//  Tab.swift
//  RichReach2
//
//  Created by Eumbrella on 18/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds the data about style for specific left drawer tab or tab bar tab.
class Tab : Codable
{
    var id : Int!
    var name : String!
    var image : String!
    var type : Int!
    var parentID = -1
    var isChild  : Bool! = false
    var isParent : Bool! = false
    var isExpanded : Bool! = false
    var showAtTabbar : Bool! = false
    var separatorHeight : Int!
    var separatorColor : String!
    var link : String! = ""
    var isVissible : Bool! = false
    var borderColor : String!
    var borderSize : Int! = 0
    var socialMediaIndex = 0
    
    var storyboardName : String! = ""
    var viewID : String! = ""
    var needsUserRegistration : Bool!
    var tabType : Int!
    var hasBackgroundImage : Bool!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case name = "Name"
        case image = "Image"
        case type = "ViewType"
        case showAtTabbar = "ShowAtTabbar"
        case separatorHeight = "SeparatorHeight"
        case separatorColor = "SeparatorColor"
        case isVissible = "IsVissible"
        case borderColor = "BorderColor"
        case borderSize = "BorderSize"
        case needsUserRegistration = "NeedsUserRegistration"
        case tabType = "TabType"
        case hasBackgroundImage = "HasBackgroundImage"
    }
}

