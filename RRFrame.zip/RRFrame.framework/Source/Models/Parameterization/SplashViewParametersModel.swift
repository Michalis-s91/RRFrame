//
//  SplashViewParametersModel.swift
//  RichReach2
//
//  Created by Eumbrella on 15/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class SplashViewParametersModel : Codable
{
    var backgroundColor : String!
    var logo : String!
    var time  : Int!
    var textColor : String!
    var font : String!
    
    private enum CodingKeys : String, CodingKey {
        case backgroundColor = "BackgroundColor"
        case logo = "Logo"
        case time = "Time"
        case textColor = "TextColor"
        case font = "Font"
    }
}
