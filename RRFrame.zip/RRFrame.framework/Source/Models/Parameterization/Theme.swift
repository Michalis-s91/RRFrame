//
//  Theme.swift
//  RichReach2
//
//  Created by Eumbrella on 18/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds the data about application theme (e.g. the style of left drawer, the color of navigation bar etc.).
class Theme : Codable
{
    var leftDrawerStyle : Int!
    var leftDrawerChildStyle : Int!
    var tabBarStyle : Int!
    var toastStyle : Int!
    var navigationBarColor : String!
    var statusBarColor : String!
    var navigationBarTintColor : String!
    var showLeftDrawerImages : Bool!
    var navigationBarImage : String!
    var showLeftDrawerLines : Bool!
    var leftDrawerLineColor : String!
    var dialogsStyle : Int!
    var leftDrawerImage : String!
    
    var topPadding : Int!
    var leftDrawerShadowColor : String!
    var titleStyle : Int!
    var titleStyleModel : TitleModel!
    var backgroundImageUrl : String!
    
    var defaultTabID : Int!
    
    private enum CodingKeys : String, CodingKey {
        case leftDrawerStyle = "LeftDrawerStyle"
        case leftDrawerChildStyle = "LeftDrawerChildStyle"
        case tabBarStyle = "TabBarStyle"
        case toastStyle = "ToastStyle"
        case navigationBarColor = "NavigationBarColor"
        case statusBarColor = "StatusBarColor"
        case navigationBarTintColor = "NavigationBarTintColor"
        case showLeftDrawerImages = "ShowLeftDrawerImages"
        case navigationBarImage = "NavigationBarImage"
        case showLeftDrawerLines = "ShowLineAtLeftDrawer"
        case leftDrawerLineColor = "LeftDrawerLineColor"
        case dialogsStyle = "DialogsStyle"
        case leftDrawerImage = "LeftDrawerImage"
        
        case topPadding = "TopPadding"
        case leftDrawerShadowColor = "LeftDrawerShadowColor"
        case titleStyle = "TitleStyle"
        case titleStyleModel = "Title"
        case backgroundImageUrl = "BackgroundImageUrl"
        
        case defaultTabID = "DefaultTabID"
    }
}
