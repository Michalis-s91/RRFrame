//
//  SignupBonusModel.swift
//  RichReach2
//
//  Created by Eumbrella on 13/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class SignupBonusModel : Codable
{
    var image : String!
    var startDateString : String!
    var endDateString : String!
    var imageData : Data!
    var startDate : Date!
    var endDate : Date!
    
    private enum CodingKeys : String, CodingKey {
        case image = "ImageURL"
        case startDateString = "ValidFromDate"
        case endDateString = "ValidToDate"
    }
}
