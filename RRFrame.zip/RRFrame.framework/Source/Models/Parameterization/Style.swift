//
//  Style.swift
//  RichReach2
//
//  Created by Eumbrella on 18/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Holds data for styling a specifi view. For example, we can use the class to specify the style of left drawer (e.g. the font of tabs, the background color etc.).
class Style : Codable
{
    var id : Int!
    var backgroundColor : String!
    var textColor : String!
    var font : String!
    var selectedColor : String!
    var tintColor : String!
    var bold : Bool!
    var italic : Bool!
    var textSize : Float!
    var lineColor : String!
    var topPadding : Int!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case backgroundColor = "BackgroundColor"
        case textColor = "TextColor"
        case font = "Font"
        case selectedColor = "SelectedColor"
        case tintColor = "TintColor"
        case bold = "Bold"
        case italic = "Italic"
        case textSize = "TextSize"
        case lineColor = "LineColor"
        case topPadding = "TopPadding"
    }
}
