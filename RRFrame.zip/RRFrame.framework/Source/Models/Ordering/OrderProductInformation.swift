//
//  OrderProductInformation.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// The following class is for the GetOrderProductInformation API call.
class OrderProductInformation : NSObject
{
    var extendedDescription : String!
    var erpReferenceCode : String!
    var storesList : [CustomerBrandStores]!
    

    /// Deserialize object.
    ///
    /// - Parameter str: The string to deserialize
    func deserialize(str : String)
    {
        do
        {
            let JSONData = str.data(using: String.Encoding.utf8, allowLossyConversion: false)
            
            let JSONDictionary = try JSONSerialization.jsonObject(with: JSONData!, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
            
            // Loop
            for (key, value) in JSONDictionary {
                let keyName = key as! String
                let keyValue: String = value as! String
                
                self.setValue(keyValue, forKey: keyName)
            }
        }
        catch
        {
            
        }
    }
}
