//
//  UserDefaultOptions.swift
//  RichReach2
//
//  Created by Eumbrella on 16/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Used for receiving the user default options from our server.
class UserDefaultOptions : Codable
{
    var HasAccessToOrdering : Bool!
    var IsOrderCustomer : Bool!
}
