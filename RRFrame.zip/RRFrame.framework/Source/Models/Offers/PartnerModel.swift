//
//  PartnerModel.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// PartnerModel holds the model for partners view.
class PartnerModel {
    var id : Int!
    var administratorID : Int64!
    var partnerID : Int!
    var name : String!
    var shortName : String!
    private var information : String!
    var Information : String!
    {
        get
        {
            if(self.information != nil)
            {
                return self.information
            }
            else
            {
                return nil
            }
        }
        
        set (information)
        {
            if(information != nil)
            {
                self.information = replaceBackslashSpecialCharacters(str: information)
            }
            else
            {
                self.information = nil
            }
        }
    }
    var isRoot : Bool = false
    var imageUri : String!
    var imageLargeUri : String!
    var storeInfo : [StoresInfo]!
    var website : String!
    var facebookPage : String!
    var facebookPageID : String!
    var optInDate : Date!
    var isLoyalty : Bool = false
    var loyaltyPoints : String!
    var optInType : String!
    private var isFavourite : Bool!
    var IsFavourite : Bool
    {
        get
        {
            return self.isFavourite
        }
        set (favourite)
        {
            self.isFavourite = favourite
            
            if(isFavourite)
            {
                optInType = NSLocalizedString("OptInTypeFavourite", comment: "")
            }
            else
            {
                optInType = NSLocalizedString("OptInTypeNone", comment: "")
            }
        }
    }
    private var isOptInVisible : Bool!
    var IsOptInVisible : Bool
    {
        get
        {
            if (optInDate == nil)
            {
                return false
            }
            else
            {
                return true
            }
        }
    }
    
    var isBranded : Bool! = false
    var isEmbeded : Bool! = false
    var apkCode : String! = ""
    var isUserEmbededAppTester : Bool! = false
    var industryID = 0
    var industryName = ""
    
}
