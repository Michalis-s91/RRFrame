//
//  OfferItemModel.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// OfferItemModel holds information about offer item.
class OfferItemModel
{
    var itemID : Int!
    var name : String!
    var imageUrl : String!
    var isNotTheLastItem = true
}
