//
//  OptInHistoryModel.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// OptInHistoryModel holds the model for OptIn view.
class OptInHistoryModel
{
    var name : String
    var timeStamp : String
    var isFavourite : Bool
    
    init(name : String, timeStamp : String, isFavourite : Bool)
    {
        self.name = name
        self.timeStamp = timeStamp
        self.isFavourite = isFavourite
    }
    
}
