//
//  StoresInfo.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// StoresInfo holds the model for partners stores. Partners stores are been displayed at partners information view.
class StoresInfo : Codable
{
    var name : String
    var address : String
    var phone : String
    var latitude : String
    var longitude : String
    
    
    /// Constructor. Initialises the properties of class.
    ///
    /// - Parameters:
    ///   - name: The name of store.
    ///   - address: Thre address of store.
    ///   - phone: The phone number of store.
    ///   - latitude: The latitude of store.
    ///   - longitude: The longitude of store.
    init (name : String, address : String, phone: String, latitude: String, longitude: String)
    {
        self.name = name
        self.address = address
        self.phone = phone
        self.latitude = latitude
        self.longitude = longitude
    }
        
    private enum CodingKeys : String, CodingKey {
        case name = "Description"
        case address = "Address"
        case phone = "PhoneNumber"
        case latitude = "Latitude"
        case longitude = "Longitude"
    }
}
