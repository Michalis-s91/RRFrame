//
//  PromotionModel.swift
//  RichReach2
//
//  Created by Eumbrella on 06/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class PromotionModel : Codable
{
    var couponCode : String!
    var imageUrl : String!
    var barcode : String!
    var firstValidDate : String!
    var lastValidDate : String!
    var shortDescription : String!
    var extendedDescription : String!
    var termsAndConditions : String!
    var isSeen : Bool!
    
    private enum CodingKeys : String, CodingKey {
        case couponCode = "CouponCode"
        case barcode = "Barcode"
        case firstValidDate = "FirstValidDate"
        case lastValidDate = "LastValidDate"
        case imageUrl = "ImageUrl"
        case shortDescription = "ShortDescription"
        case extendedDescription = "ExtendedDescription"
        case termsAndConditions = "TermsAndConditions"
        case isSeen = "IsSeen"
    }
}
