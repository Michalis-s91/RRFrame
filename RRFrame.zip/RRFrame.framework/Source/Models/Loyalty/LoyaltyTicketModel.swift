//
//  LoyaltyTicketModel.swift
//  RichReach2
//
//  Created by Eumbrella on 14/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds the data for loyalty ticket.
class LoyaltyTicketModel
{
    var rowSerial : Int!
    var ticketFlag : String!
    var ticketNo : String!
    var transDate : String!
    var previousPoints : String!
    var redeemedPoints : String!
    var earnedPoints : String!
    var totalPoints : String!
    var shop : String!
    var discountAmount : String!
    var vatPercentage : String!
    var vatAmount : String!
    var amountWithVAT : String!
    var barcode : String!
    private var quantity : String!
    var Quantity : String!
    {
        get
        {
            return self.quantity
        }
        
        set (quantity)
        {
            self.quantity = getUpdatedDecimalStr(str : quantity)
        }
    }
    var price : String!
    var lineDiscountAmount : String!
    private var lineVATPurcentage : String!
    var LineVATPurcentage : String!
    {
        get
        {
            return self.lineVATPurcentage
        }
        
        set (lineVATPurcentage)
        {
            self.lineVATPurcentage = getUpdatedDecimalStr(str: lineVATPurcentage)
        }
    }
    var lineVATAmount : String!
    var lineAmountWithVAT : String!
    var description : String!
    
    /// Uses the input decimal string to create and return an updated string that does not contain any decimal points in case its value can be exactly divided by 1.
    /// Examples:
    /// If the input string is 1.00 the function returns 1.
    /// If the input string is 1.25 the function returns 1.25.
    ///
    /// - Parameter str: The input string.
    /// - Returns: The updated decimal in string format.
    private func getUpdatedDecimalStr(str : String) -> String
    {
        let dValue = Double(str)!
        
        if (dValue.truncatingRemainder(dividingBy: 1.0) == 0)
        {
            return String(format :"%.0f", dValue)
        }
        else
        {
            return String(format : "%.2f", dValue)
        }
    }
    
    var ERPReference : Int64!
}
