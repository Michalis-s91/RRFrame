//
//  TicketView.swift
//  RichReach2
//
//  Created by Eumbrella on 31/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class TicketView : Codable
{
    var headerBackgroundColor : String!
    var headerTextColor : String!
    var headerTextSize : Int!
    var headerFont : String!
    var detailsBackgroundColor : String!
    var detailsTextColor : String!
    var detailsTextSize : Int!
    var detailsFont : String!
    var ticketStyle : Int!
    var ticketStyle2 : Int!
    var ticketStyleModel : TicketStyle!
    var ticketStyleModel2 : TicketStyle!
    
    private enum CodingKeys : String, CodingKey {
        case headerBackgroundColor = "HeaderBackgroundColor"
        case headerTextColor = "HeaderTextColor"
        case headerTextSize = "HeaderTextSize"
        case headerFont = "HeaderFont"
        case detailsBackgroundColor = "DetailsBackgroundColor"
        case detailsTextColor = "DetailsTextColor"
        case detailsTextSize = "DetailsTextSize"
        case detailsFont = "DetailsFont"
        case ticketStyle = "TicketStyle"
        case ticketStyle2 = "TicketStyle2"
    }
}
