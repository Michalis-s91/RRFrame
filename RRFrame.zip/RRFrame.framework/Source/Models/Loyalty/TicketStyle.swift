//
//  TicketStyle.swift
//  RichReach2
//
//  Created by Eumbrella on 31/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class TicketStyle : Codable
{
    var id : Int!
    var backgroundColor : String!
    var textSize : Int!
    var font : String!
    var textColor : String!
    
    private enum CodingKeys : String, CodingKey {
        case id  = "ID"
        case backgroundColor = "BackgroundColor"
        case textSize = "TicketTextSize"
        case font = "Font"
        case textColor = "TextColor"
    }
}
