//
//  LoyaltyStatementModel.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds the data for points statement.
class LoyaltyStatementModel : Hashable
{
    var hashValue: Int
    
    static func == (lhs: LoyaltyStatementModel, rhs: LoyaltyStatementModel) -> Bool {
        return lhs.ticketNo == rhs.ticketNo
    }
    
    var rowSerial : Int!
    var ticketNo : String!
    var transDate : String!
    var amount : String!
    var rewardPoints : String!
    var redemptionPoints : String!
    var balance : String!

    init()
    {
        hashValue = 0
    }
    
    init(rowSerial : String!, ticketNo : String!, transDate : String!, amount : String!, rewardPoints : String!, redemptionPoints : String!, balance : String!)
    {
        self.rowSerial = Int(rowSerial)
        self.ticketNo = ticketNo
        self.transDate = transDate
        self.amount = amount
        self.rewardPoints = rewardPoints
        self.redemptionPoints = redemptionPoints
        self.balance = balance
        self.hashValue = 0
    }
}
