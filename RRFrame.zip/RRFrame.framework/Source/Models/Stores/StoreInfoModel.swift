//
//  StoreInfoModel.swift
//  RichReach2
//
//  Created by Eumbrella on 21/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about a store.
class StoreInfoModel
{
    var address : String!
    var openHours : [Double]! = []
    var closeHours : [Double]! = []
    /*var dailyOpenHour : Double?
     var dailyCloseHour : Double!
     var saturdayOpenHour : Double!
     var saturdayCloseHour : Double!
     var sundayOpenHour : Double!
     var sundayCloseHour : Double!*/
    //var header : GeneralInformation2!
    //var options : [String] = []
    
    var name : String!
    var phone : String!
    var latitude : String!
    var longitude : String!
    
    var isOptionsDisplayed = false
}
