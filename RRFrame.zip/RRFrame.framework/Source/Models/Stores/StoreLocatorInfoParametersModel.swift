//
//  StoreLocatorInfoModel.swift
//  RichReach2
//
//  Created by Eumbrella on 27/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class StoreLocatorInfoParametersModel : Codable
{
    var textFont : String!
    var sizeOfText : Int!
    var textColor : String!
    var tintColor : String!
    var borderSize : Int!
    var borderColor : String!
    var titleBackgroundColor : String!
    var titleTextColor : String!
    var titleTextSize : Int!
    var titleFont : String!
    
    private enum CodingKeys : String, CodingKey {
        case textFont = "TextFont"
        case sizeOfText = "SizeOfText"
        case textColor = "TextColor"
        case tintColor = "TintColor"
        case borderSize = "BorderSize"
        case borderColor = "BorderColor"
        case titleBackgroundColor = "TitleBackgroundColor"
        case titleTextColor = "TitleTextColor"
        case titleTextSize = "TitleTextSize"
        case titleFont = "TitleFont"
    }
}
