//
//  StoreInfoHeaderModel.swift
//  RichReach2
//
//  Created by Eumbrella on 29/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Holds information for header at store information view.
class StoreInfoHeaderModel : Codable
{
    var address : String!
    var phone : String!
    var textSize : Int!
    var font : String!
    var textColor : String!
    
    private enum CodingKeys : String, CodingKey {
        case address = "Address"
        case phone = "Phone"
        case textSize = "TextSize"
        case font = "Font"
        case textColor = "TextColor"
    }
}
