//
//  CityModel.swift
//  RichReach2
//
//  Created by Eumbrella on 23/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Holds stores informations for specific city of a specific business.
class CityModel
{
    var cityName : String!
    var stores : [StoreModel] = []
}
