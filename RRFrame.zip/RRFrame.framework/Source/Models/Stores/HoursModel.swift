//
//  HoursModel.swift
//  RichReach2
//
//  Created by Eumbrella on 28/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class HoursModel : Codable
{
    var addressID : Int!
    
    var monStartTime1 : String!
    var monEndTime1 : String!
    var monStartTime2 : String!
    var monEndTime2 : String!
    
    var tueStartTime1 : String!
    var tueEndTime1 : String!
    var tueStartTime2 : String!
    var tueEndTime2 : String!
    
    var wedStartTime1 : String!
    var wedEndTime1 : String!
    var wedStartTime2 : String!
    var wedEndTime2 : String!
    
    var thuStartTime1 : String!
    var thuEndTime1 : String!
    var thuStartTime2 : String!
    var thuEndTime2 : String!
    
    var friStartTime1 : String!
    var friEndTime1 : String!
    var friStartTime2 : String!
    var friEndTime2 : String!
    
    var satStartTime1 : String!
    var satEndTime1 : String!
    var satStartTime2 : String!
    var satEndTime2 : String!
    
    var sunStartTime1 : String!
    var sunEndTime1 : String!
    var sunStartTime2 : String!
    var sunEndTime2 : String!
    
    private enum CodingKeys : String, CodingKey {
        case addressID = "AddressID"
        
        case monStartTime1 = "MonStartTime1"
        case monEndTime1 = "MonEndTime1"
        case monStartTime2 = "MonStartTime2"
        case monEndTime2 = "MonEndTime2"
        
        case tueStartTime1 = "TueStartTime1"
        case tueEndTime1 = "TueEndTime1"
        case tueStartTime2 = "TueStartTime2"
        case tueEndTime2 = "TueEndTime2"
        
        case wedStartTime1 = "WedStartTime1"
        case wedEndTime1 = "WedEndTime1"
        case wedStartTime2 = "WedStartTime2"
        case wedEndTime2 = "WedEndTime2"
        
        case thuStartTime1 = "ThuStartTime1"
        case thuEndTime1 = "ThuEndTime1"
        case thuStartTime2 = "ThuStartTime2"
        case thuEndTime2 = "ThuEndTime2"
        
        case friStartTime1 = "FriStartTime1"
        case friEndTime1 = "FriEndTime1"
        case friStartTime2 = "FriStartTime2"
        case friEndTime2 = "FriEndTime2"
        
        case satStartTime1 = "SatStartTime1"
        case satEndTime1 = "SatEndTime1"
        case satStartTime2 = "SatStartTime2"
        case satEndTime2 = "SatEndTime2"
        
        case sunStartTime1 = "SunStartTime1"
        case sunEndTime1 = "SunEndTime1"
        case sunStartTime2 = "SunStartTime2"
        case sunEndTime2 = "SunEndTime2"
    }
}
