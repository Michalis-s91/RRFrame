//
//  YearlyShopHolidaysModel.swift
//  RichReach2
//
//  Created by Eumbrella on 05/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class YearlyShopHolidaysModel : Codable
{
    var addressID : Int!
    var holidayDate : String!
    var startTime1 : String!
    var endTime1 : String!
    var startTime2 : String!
    var endTime2 : String!
    
    private enum CodingKeys : String, CodingKey {
        case addressID = "AddressID"
        case holidayDate = "HolidayDate"
        case startTime1 = "StartTime1"
        case endTime1 = "EndTime1"
        case startTime2 = "StartTime2"
        case endTime2 = "EndTime2"
    }
}
