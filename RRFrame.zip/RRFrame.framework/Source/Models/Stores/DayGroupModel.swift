//
//  DayGroupModel.swift
//  RichReach2
//
//  Created by Eumbrella on 28/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class DayGroupModel
{
    var days : [String]! = []
    var daysInInt : [Int]! = []
    var startTime1 : String!
    var endTime1 : String!
    var startTime2 : String!
    var endTime2 : String!
}
