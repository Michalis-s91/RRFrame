//
//  ExpandableListItemModel.swift
//  RichReach2
//
//  Created by Eumbrella on 08/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ExpandableListItemModel
{
    var type : Int!
    var isExpanded : Bool! =  false
    var parentModel :  ExpandableListParentModel!
    var storeModel : StoreModel!
    var searchModel : SearchModel!
    var categoryModel : CategoryModel!
    var categoryModel2 : ProductMenuModel!
    var productModel : ProductModel!
}
