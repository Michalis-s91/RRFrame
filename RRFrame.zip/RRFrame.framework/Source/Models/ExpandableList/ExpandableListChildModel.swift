//
//  ExpandableListChildModel.swift
//  RichReach2
//
//  Created by Eumbrella on 07/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ExpandableListChildModel
{
    var type : Int!
    //var parent : ExpandableListChildModel!
    //var childs : [ExpandableListChildModel]!
    
    var storeModel : StoreModel!
    //var searchModel : SearchModel!
    var categoryModel : CategoryModel!
    var categoryModel2 : ProductMenuModel!
}
