//
//  CategoryStyleModel.swift
//  RichReach2
//
//  Created by Eumbrella on 19/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class StyleModel : Codable
{
    var id : Int!
    var textSize : Int!
    var textColor : String!
    var font : String!
    var backgroundColor : String!
    var tintColor : String!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case textSize = "TextTextSize"
        case textColor = "TextColor"
        case font = "Font"
        case backgroundColor = "BackgroundColor"
        case tintColor = "TintColor"
    }
}
