//
//  SarchModel.swift
//  RichReach2
//
//  Created by Eumbrella on 07/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class SearchModel
{
    var type : Int!
    
    var backgroundColor : String!
    var font : String!
    var textSize : Int!
    var textColor : String!
    var tintColor : String!
}
