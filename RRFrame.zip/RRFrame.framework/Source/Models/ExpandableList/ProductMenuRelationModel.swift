//
//  ProductMenuRelationModel.swift
//  RichReach2
//
//  Created by Eumbrella on 17/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ProductMenuRelationModel : Codable
{
    var clientID : Int64!
    var id : Int!
    var menuStructureID : Int!
    var typeData : Int!
    var typeDescription : String!
    var relatedCode : String!
    
    private enum CodingKeys : String, CodingKey {
        case clientID = "ClientID"
        case id = "ID"
        case menuStructureID = "MenuStructureID"
        case typeData = "TypeData"
        case typeDescription = "TypeDescription"
        case relatedCode = "RelatedCode"
    }
}
