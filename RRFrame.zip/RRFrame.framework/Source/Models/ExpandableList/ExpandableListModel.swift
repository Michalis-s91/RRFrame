//
//  ExpandableListViewModel.swift
//  RichReach2
//
//  Created by Eumbrella on 13/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ExpandableListModel : Codable
{
    var id : Int!
    var apk : String!
    var tabID : Int!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case apk = "APK"
        case tabID = "TabID"
    }
}
