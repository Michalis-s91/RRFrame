//
//  ContactUsTabRelation.swift
//  RichReach2
//
//  Created by Eumbrella on 29/08/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ContactUsTabRelation : Codable
{
    var tabID : Int!
    var contactUsViewID : Int!
    
    private enum CodingKeys : String, CodingKey {
        case tabID = "TabID"
        case contactUsViewID = "ContactUsViewID"
    }
}
