//
//  RoundCornerns.swift
//  RichReach2
//
//  Created by Eumbrella on 13/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/**
 * Rounds input corners of UIView.
 * @param corners The corners we want to round.
 * @param radius The radious of rounded corners.
 * @param view The UIView we want to round the corners.
 * @return The UIView with rounded corners.
 */
func roundCorners(_ corners: UIRectCorner, radius: CGFloat, view : UIView) {
    let path = UIBezierPath(roundedRect: view.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
    let mask = CAShapeLayer()
    mask.path = path.cgPath
    view.layer.mask = mask
    view.layer.masksToBounds = true
}
