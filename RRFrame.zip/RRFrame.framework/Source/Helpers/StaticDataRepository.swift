//
//  StaticDataRepository.swift
//  RichReach2
//
//  Created by Eumbrella on 21/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Helper for holding statics variables.
class StaticDataRepository {
    
    /// Get support types in a from of ArrayList<String>.
    ///
    /// - Returns: Support types.
    static func getSupportTypesStrings() -> [SingleTextModel]
    {
        var supportTypesStrings = [SingleTextModel]()
        supportTypesStrings.append(SingleTextModel(textStr : "Suggestion"))
        supportTypesStrings.append(SingleTextModel(textStr : "Feature Request"))
        supportTypesStrings.append(SingleTextModel(textStr : "Information Request"))
        supportTypesStrings.append(SingleTextModel(textStr : "Complaint"))
        supportTypesStrings.append(SingleTextModel(textStr : "Bug"))
        supportTypesStrings.append(SingleTextModel(textStr : "Other"))

        return supportTypesStrings
    }
    
    static func getSupportTypesStrings(types : [String]) -> [SingleTextModel]
    {
        var supportTypesStrings = [SingleTextModel]()
        
        for t in types
        {
            supportTypesStrings.append(SingleTextModel(textStr : t))
        }
        
        return supportTypesStrings
    }
    
    /// Returns a list that contains the possible user genders (male or female).
    ///
    /// - Returns: A list that contains the possible user genders (male or female).
    static func getUserGenders() -> [SingleTextModel]
    {
        var genders = [SingleTextModel]()
        genders.append(SingleTextModel(textStr : "Male"))
        genders.append(SingleTextModel(textStr : "Female"))
    
        return genders
    }
    
    /// Returns a list that contains the provinces of Cyprus.
    ///
    /// - Returns: A list that contains the provinces of Cyprus.
    static func getProvinces() -> [SingleTextModel]
    {
        var provinces = [SingleTextModel]()
        provinces.append(SingleTextModel(textStr : "Nicosia"))
        provinces.append(SingleTextModel(textStr : "Limassol"))
        provinces.append(SingleTextModel(textStr : "Larnaca"))
        provinces.append(SingleTextModel(textStr : "Paphos"))
        provinces.append(SingleTextModel(textStr : "Famagusta"))
    
        return provinces
    }
    
    /// Returns a list that contains all months.
    ///
    /// - Returns: A list that contains all months.
    static func getMonths() -> [SingleTextModel]!
    {
        return getMonths(fromMonth: 1, toMonth: 2)
    }
    
    /// Returns a list that contains months based on the user input values.
    ///
    /// - Parameters:
    ///   - fromMonth: The "from" month.
    ///   - toMonth: The "to" month.
    /// - Returns: A list that contains months based on the user input values.
    static func getMonths(fromMonth : Int, toMonth : Int) -> [SingleTextModel]!
    {
        if (fromMonth < 1 || toMonth > 12)
        {
            return nil
        }
        
        var allMonths : [SingleTextModel] = []
        
        allMonths.append( SingleTextModel(id: 1,textStr: "January"))
        allMonths.append( SingleTextModel(id: 2,textStr: "February"))
        allMonths.append( SingleTextModel(id: 3,textStr: "March"))
        allMonths.append( SingleTextModel(id: 4,textStr: "April"))
        allMonths.append( SingleTextModel(id: 5,textStr: "May"))
        allMonths.append( SingleTextModel(id: 6,textStr: "June"))
        allMonths.append( SingleTextModel(id: 7,textStr: "July"))
        allMonths.append( SingleTextModel(id: 8,textStr: "August"))
        allMonths.append( SingleTextModel(id: 9,textStr: "September"))
        allMonths.append( SingleTextModel(id: 10,textStr: "October"))
        allMonths.append( SingleTextModel(id: 11,textStr: "November"))
        allMonths.append( SingleTextModel(id: 12,textStr: "December"))
        
        var months : [SingleTextModel] = []
        
        if(fromMonth <= toMonth)
        {
            for  m in allMonths
            {
                if(m.id >= fromMonth && m.id <= toMonth)
                {
                    months.append(m)
                }
            }
        }
        else
        {
            for month in fromMonth...12
            {
                for m in allMonths
                {
                    if(m.id == month)
                    {
                        months.append(m)
                    }

                }
            }
            
            for month in 1...toMonth
            {
                for m in allMonths
                {
                    if(m.id == month)
                    {
                        months.append(m)
                    }
                }
            }
        }
        
        return months
    }
}
