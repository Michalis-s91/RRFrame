//
//  LocalAsyncTask.swift
//  RichReach2
//
//  Created by Eumbrella on 27/07/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class LocalTask : CustomTask
{
    
//    init (viewController : ViewController!, action : @escaping Runnable, displayToast : Bool = false, isSynchronizationTimerEnabled : Bool = true, elapsedSecondsToDisplayMessage : Int = 3 ){
//        super.init(viewController: viewController, action: action, displayToast: displayToast, isSynchronizationTimerEnabled: isSynchronizationTimerEnabled, elapsedSecondsToDisplayMessage: elapsedSecondsToDisplayMessage)
//    }
    
    /// Checks whether there is an active internet connection and if so it runs the task action.
    func start() {
//        if(notAvailableView != nil)
//        {
//            super.notAvailableView.view.removeFromSuperview()
//            super.notAvailableView.removeFromParentViewController()
//        }
        
        runAsync()
    }
    
    func runAsync(){
        do {
            DispatchQueue.global(qos: .background).async {
                self.startSynchronizationTimer()
                
                DispatchQueue.main.async(execute: {() -> Void in
                    if(self.container != nil && self.container.subviews.count > 2)
                    {
                        self.container.subviews[self.container.subviews.count - 1].removeFromSuperview()
                    }
                })
                
                self.action()
                
                self.stopSynchronizationTimer()
                usleep(300000)
                
                if (self.displayToast)
                {
                    self.displayToastMessage(message: self.successMessage)
                }
            }
        }
        catch
        {
            self.stopSynchronizationTimer()
            
            if (self.failureAction != nil && self.viewController != nil)
            {
                DispatchQueue.main.async {
                    super.failureAction()
                }
            }
            
            if (self.displayToast)
            {
                self.displayToastMessage(message: self.errorMessage)
            }
        }
    }
}

