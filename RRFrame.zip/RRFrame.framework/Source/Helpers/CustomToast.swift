//
//  CustomToasClass.swift
//  RichReach2
//
//  Created by Eumbrella on 15/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Provides customised Toast class. Instead of the Android default toast, our implementation uses a Popup Window that
/// is displayed on the top of the screen. Our toast implementation (popup window) comes with a button that allows the
/// user to close the message that is displayed.
class CustomToast {
    var yOffset : Int = 0
    var duration = 4 //default duration
    var timer : CustomCountDownTimer!
    var hasImage = false
    var viewController: UIViewController!
    var dialog : CustomToastDialog!
    
    static let TOAST_LENGTH_LONG = 4
    static let TOAST_LENGTH_SHORT = 3
    
    
    /// Constructor for setting view controller.
    ///
    /// - Parameter viewController: The view controller.
    func setToast (viewController : UIViewController!)
    {
        self.viewController = viewController
    }
    
    
    /// Constructor for simple custom toast (no image is displayed).
    ///
    /// - Parameters:
    ///   - viewController: The view controller.
    ///   - message: The message to be displayed.
    func setToast (viewController : UIViewController! ,message: String){
        self.viewController = viewController
        setView(message : message)
    }
    
    
    /// Constructor for simple custom toast (no image is displayed) with specified duration.
    ///
    /// - Parameters:
    ///   - viewController: The view controller.
    ///   - message: The message to be displayed.
    ///   - duration: The toast duration in seconds.
    func setToast (viewController : UIViewController! ,message: String, duration: Int){
        self.viewController = viewController
        self.duration = duration
        setView(message: message)
    }
    
    /// Sets the custom toast view.
    ///
    /// - Parameter message: he message of toast.
    func setView(message: String)
    {
        let sb = UIStoryboard(name:"ToastDialog",bundle:nil)
        self.dialog = sb.instantiateInitialViewController() as? CustomToastDialog
        self.dialog.message = message
        self.dialog.view.frame = CGRect(x: 0, y: -((dialog.toastDialogView?.frame.height)!), width: UIScreen.main.bounds.size.width, height: (dialog.toastDialogView?.frame.height)! )
        
    }
    
    /// Displays the customised toast.
    func show(){
        UIView.animate(withDuration: 0.3) {
            self.dialog.view.frame = CGRect(x: 0, y:0, width: UIScreen.main.bounds.size.width, height: (self.dialog.dialogView?.frame.height)! )
            UIApplication.shared.keyWindow?.addSubview(self.dialog.view)
            self.timer = CustomCountDownTimer(duration: self.duration, interval: 0.5, dialog: self.dialog)
        }
    }
    
    /// Stops the timer and closes the popupWindow.
    func close(){
        if (timer != nil)
        {
            timer.stopTimer()
            
            UIView.animate(withDuration: 0.3, animations: {
                //self.dialog.view.frame = CGRect(x: 0, y: -((self.dialog.toastDialogView?.frame.height)!), width: UIScreen.main.bounds.size.width, height: (self.dialog.toastDialogView?.frame.height)! )
                
                if(AppDelegate.isPotraitOrientation)
                {
                    self.dialog.view.frame = CGRect(x: 0, y: -((self.dialog.toastDialogView?.frame.height)!), width: UIScreen.main.bounds.size.width, height: (self.dialog.toastDialogView?.frame.height)! )
                }
                else
                {
                    self.dialog.view.frame = CGRect(x: 0, y: -UIScreen.main.bounds.size.width, width: UIScreen.main.bounds.size.height, height: (self.dialog.toastDialogView?.frame.height)! )
                }
            })
            
            

            //dialog.removeFromParentViewController()
        }
    }

}
