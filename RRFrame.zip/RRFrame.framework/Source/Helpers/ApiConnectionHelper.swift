//
//  ApiConnectionHelper.swift
//  RichReach2
//
//  Created by Eumbrella on 21/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/**
 * Remove quotes characters from input string
 * @param message The string we have to process.
 * @return String without quotes.
 */
func removeQuotesCharacters(message : String) -> String
{
    if(!isNullOrEmpty( string : message))
    {
        return message.replacingOccurrences(of: "\"", with: " ")
    }
    
    return message
}

