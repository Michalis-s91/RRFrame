//
//  SynchronizationTimer.swift
//  RichReach2
//
//  Created by Eumbrella on 16/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Synchronization timer is a timer that allows us to apply certain events when network related operations take place.
/// For example, if network synchronization (e.g. offers loading) takes more that a particular amount of time, we could
/// display a toast or a loading spinner to tell the user to wait.
class SynchronizationTimer{
    var viewController : ViewController!
    var timer : Timer!
    var toast : CustomToast!
    var activityIndicator : UIActivityIndicatorView!
    
    var elapsedSeconds = 0
    var elapsedSecondsToDisplayMessage : Int?
    var shouldDisplayActivityIndicator = false
    var shouldDisplayToast = true
    
    var hasTimerStopped = false
    var timerLock = NSObject()
    var synchronized = Synchronized()
    var activityIndicatorViewController : ActivityIndicatorViewController!
    
    init(viewController : ViewController!, elapsedSecondsToDisplayMessage : Int, toastMessage : String){
        self.viewController = viewController
        self.elapsedSecondsToDisplayMessage = elapsedSecondsToDisplayMessage
        toast = CustomToast()
        toast.setToast(viewController : viewController, message : toastMessage, duration: 20 )
        timer = Timer()
    }
    
    /// Sets whether the custom toast should be displayed or not.
    ///
    /// - Parameter shouldDisplayToast: The flag that indicates whether the custom toast should be displayed or not.
    func shouldDisplayCustomToast(shouldDisplayToast : Bool){
        self.shouldDisplayToast = shouldDisplayToast
    }

    /// Schedule timer and specifies what the synchronization timer does during the specified time interval.
    /// Specifically, when the elapsed number of seconds is reached, it displays the toast message along with
    /// the progress bar in case there is one.
    func start(){
        DispatchQueue.main.async(execute: {() -> Void in
            self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self,   selector: (#selector(SynchronizationTimer.updateTimer)), userInfo: nil, repeats: true)
        })
        
    }
    
    /// Updates timer and checks elapsed time.
    @objc func updateTimer(){
        elapsedSeconds += 1

        
        if (elapsedSeconds == 1)
        {
            if (shouldDisplayActivityIndicator)
            {
                if (activityIndicator == nil)
                {
                    let storyBoard = UIStoryboard(name:"ActivityIndicatorView",bundle:nil)
                    activityIndicatorViewController = storyBoard.instantiateInitialViewController() as? ActivityIndicatorViewController

                    //print(viewController.container?.frame.size.height)
                    activityIndicatorViewController.view.frame =  CGRect(x: 0, y: 0, width: (viewController.container?.frame.size.width)!, height: (viewController.container?.frame.size.height)!)
                    
                    activityIndicatorViewController.willMove(toParentViewController: viewController)
                    viewController.container?.addSubview((activityIndicatorViewController.view)!)
                    //viewController.addChildViewController(activityIndicatorViewController)
                    activityIndicatorViewController.didMove(toParentViewController: viewController)
                    activityIndicator = activityIndicatorViewController.activityIndicator
                    
                    displayActivityIndicator()
                }
            }
        }
        
        if (shouldDisplayToast && elapsedSeconds == elapsedSecondsToDisplayMessage)
        {
            displayToast()
        }
    }
    
    /// Specifies what the synchronization timer does when it stops (stops the timer, closes the toast message and in
    /// case there is an active progressbar it stops it and set the activity's view back to visible).
    func stop()
    {
        synchronized.synchronize(obj: timerLock)
        {
            while (timer == nil)
            {
                
            }
            timer.invalidate()
            hasTimerStopped = true
        }
        
        if (shouldDisplayActivityIndicator)
        {
            hideActivityIndicator()
        }
        
        hideToast()
        
        elapsedSeconds = 0
    }
    
    /// Sets whether the task should display the activity andicator or not.
    ///
    /// - Parameter shouldDisplayActivityIndicator: A flag that indicates whether the activity andicator  should be displayed or not.
    func setShouldDisplayActivityIndicator (shouldDisplayActivityIndicator : Bool){
        self.shouldDisplayActivityIndicator = shouldDisplayActivityIndicator
        
        if(shouldDisplayActivityIndicator)
        {
            elapsedSecondsToDisplayMessage = 5
        }
    }
    
    /// Displays the toast message to the user.
    func displayToast(){
        DispatchQueue.main.async(execute: {() -> Void in
            self.synchronized.synchronize(obj: self.timerLock)
            {
                if (!self.hasTimerStopped)
                {
                    self.toast.show()
                }
            }
        })
    }
    
    /// Hides the toast that is currently being displayed.
    private func hideToast(){
        DispatchQueue.main.async(execute: {() -> Void in
            self.toast.close()
        })
    }
    
    /// Starts animating activity indicator.
    func displayActivityIndicator() {
        DispatchQueue.main.async(execute: {() -> Void in
            self.synchronized.synchronize (obj: self.timerLock)
            {
                if (!self.hasTimerStopped)
                {
                    self.activityIndicator.startAnimating()
                }
            }
        })
    }
    
    /// Hides activity indicator.
    private func hideActivityIndicator(){
        if (activityIndicator != nil)
        {
            DispatchQueue.main.async(execute: {() -> Void in
                self.activityIndicator.stopAnimating()
                self.activityIndicatorViewController.view.removeFromSuperview()
            })
            

        }
    }
}
