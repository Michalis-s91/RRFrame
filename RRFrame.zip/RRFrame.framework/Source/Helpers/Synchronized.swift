//
//  Synchronized.swift
//  RichReach2
//
//  Created by Eumbrella on 16/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Helper for synchronization.
class Synchronized{
    /// Synchronize code in closure.
    ///
    /// - Parameters:
    ///   - obj: The object we use to synchronize code.
    ///   - closure: The synchronized code.
    func synchronize(obj: AnyObject, closure: ()->())
    {
        objc_sync_enter(obj)
        closure()
        objc_sync_exit(obj)
    }
}
