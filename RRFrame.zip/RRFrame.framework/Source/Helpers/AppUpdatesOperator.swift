//
//  AppUpdatesOperator.swift
//  BeautyLine
//
//  Created by Eumbrella on 10/12/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class AppUpdatesOperator
{
    static func updateApp()
    {
        let appUser = localDatabase.getAppUser()
        
        if(appUser != nil)
        {
            let appUserBuildVersion : Int! = appUser?.currentAppBuildVersion == nil ? 0 : appUser?.currentAppBuildVersion
            
            if(APK == APKsEnum.BeautyLine.rawValue && appUserBuildVersion < 105)
            {
                do{
                    try loyaltyDB.database.run(loyaltyDB.pointsStatementTable.drop())
                    try loyaltyDB.createPointsStatementTable()
                    statusModel.pointsStatementPageNo = 1
                }catch{}
            }
            
            /*if((Bundle.main.bundleIdentifier == APKsEnum.BeautyLine.rawValue && appUserBuildVersion < 113)
                || (Bundle.main.bundleIdentifier == APKsEnum.RichReach.rawValue && appUserBuildVersion < 124))
            {
                do{
                    try viewsDB.database.run(viewsDB.expanableListParentsTable.drop())
                    try viewsDB.createExpanableListParentsTable()
                    statusModel.areExpandableListViewsSaved = false
                    statusDB.insertStatus(status : statusModel, apk : APK)
                }catch{}
            }*/
            
            appUser?.currentAppBuildVersion = Int(Bundle.main.infoDictionary?["CFBundleVersion"]  as! String)
            localDatabase.updateAppUser(appUser: appUser!)
        }
    }
}
