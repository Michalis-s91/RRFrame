//
//  SpecialCharacterReplacer.swift
//  RichReach2
//
//  Created by Eumbrella on 05/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/**
 * Replace new line special characters with the proper characters.
 */
public func replaceBackslashSpecialCharacters(str : String) -> String!
{
    var result : String!
    
    if (!isNullOrEmpty(string: str))
    {
        //replacingOccurrences(of: "\\n", with: "\n")
        result = str
        result = result.replacingOccurrences(of: "\\n", with: "\n")
        result = result.replacingOccurrences(of: "\\r", with: "\r")
        result = result.replacingOccurrences(of: "\\0", with: "\0")
        //result = str.replacingOccurrences(of: "\\b", with: "b")
        //result = str.replacingOccurrences(of: "\\f", with: "f")
        result = result.replacingOccurrences(of: "\\t", with: "\t")
        result = result.replacingOccurrences(of: "\\\"", with: "\"")
        result = result.replacingOccurrences(of: "\\\'", with: "\'")
    }
    
    return result
}
