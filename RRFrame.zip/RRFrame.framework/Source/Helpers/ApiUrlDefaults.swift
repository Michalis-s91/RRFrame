//
//  ApiUrlDefaults.swift
//  BeautyLine
//
//  Created by Eumbrella on 28/11/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

class ApiUrlDefaults
{
    static var URL = "http://93.109.209.42/RichReachWebApplication/api/"
    static var REGISTRATION_URL = "\(URL)RegistrationApi/"
}
