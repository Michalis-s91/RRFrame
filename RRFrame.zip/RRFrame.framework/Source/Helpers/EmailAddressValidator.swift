//
//  EmailAddressValidator.swift
//  RichReach2
//
//  Created by Eumbrella on 27/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

let pattern = "[A-Z0-9a-z._%+-][A-Z0-9a-z._%+-]+@[A-Za-z0-9.-][A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"

/// Returns whether the input address is a valid email address or not.
///
/// - Parameter address: The email address to check.
/// - Returns: True if the input address is a valid email address, otherwise false.
func isEmailAddressValid(address : String) -> Bool
{
    let emailTest = NSPredicate(format:"SELF MATCHES %@", pattern)
    return emailTest.evaluate(with: address)
}

