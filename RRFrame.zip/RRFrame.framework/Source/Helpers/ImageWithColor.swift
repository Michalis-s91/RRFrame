//
//  ImageWithColor.swift
//  RichReach2
//
//  Created by Eumbrella on 23/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit
/**
 * Helper for making an image with color.
 */
class ImageWithColor {
    /**
     * Creates image with inpout color and returns that image.
     * @param color The color of image.
     * @param size The size of image.
     * @return The image with color.
     */
    class func imageWithColor(color: UIColor, size: CGSize = CGSize(width: 60, height: 60)) -> UIImage {
        let rect = CGRect(x: 0,y: 0, width: size.width,height: size.height)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        
        context!.setFillColor(color.cgColor)
        context!.fill(rect)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        return image!
    }
}
