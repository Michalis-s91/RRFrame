//
//  Protocols.swift
//  RichReach2
//
//  Created by Eumbrella on 11/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// Called when a modal view controlles is dismissed.
protocol ModalViewControllerDelegate:class {
    func dismissed()
}

/// Called when user select yes on YesNoMessageDialog.
protocol YesEventHandler:class {
    func yesRaised()
}

/// Called when user select no on YesNoMessageDialog.
protocol NoEventHandler:class {
    func noRaised()
}

/// Called when user click on "OK" on MessageDialog.
protocol OkEventHandler:class {
    func okClicked()
}

/// Called when registration completed.
protocol RegistrationCompletedtHandler:class {
    func registrationCompleted()
}

/// Called when preferred partned is added.
protocol AddPreferredPartner:class {
    func addPreferredPartner()
}

/// Called when use click on notification.
protocol NotificationClicked {
    func notificationClicked()
}

protocol Canceller {
    var _shouldCancel : Bool {get set}
    
    func setShouldCancel(shouldCancel : Bool) -> Void
    func shouldCancel() -> Bool
}
