//
//  CustomCountDownTimer.swift
//  RichReach2
//
//  Created by Eumbrella on 15/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// The purpose of this class is to provide a CountDownTimer that is used in order to set our own toast duration.
class CustomCountDownTimer {
    var dialog : CustomToastDialog!
    var duration : Double = 0.0
    var timer = Timer()
    var interval : Double = 0.0
    var isTimerRunning = false
    
    init (duration: Int, interval : Double, dialog : CustomToastDialog){
        self.dialog = dialog
        self.duration = Double(duration)
        self.interval = interval
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(interval), target: self,   selector: (#selector(CustomCountDownTimer.updateTimer)), userInfo: nil, repeats: true)
    }
    
    
    /// Calculates duration and when time passes the dialog is been dismissed.
    @objc func updateTimer(){
        duration = duration - interval
        if duration == 0
        {
            timer.invalidate()
            dialog.dismissDialog()
        }
    }
    
    /// Stops the timer.
    func stopTimer()
    {
        timer.invalidate()
    }
    
}
