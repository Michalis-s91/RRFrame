//
//  TabView.swift
//  RichReach2
//
//  Created by Eumbrella on 07/05/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// Custom UIView that is been used for custom tabbar
class TabView: UIView {
    var image : UIImageView!
    var label : UILabel!
}
