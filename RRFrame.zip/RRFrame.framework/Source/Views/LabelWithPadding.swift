//
//  LabelWithPadding.swift
//  RichReach2
//
//  Created by Eumbrella on 03/09/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

class LabelWithPadding : UILabel {
    var leftPadding  = 0
    var rightPadding = 5
    
    override func drawText(in rect: CGRect) {
        let insets = UIEdgeInsets.init(top: 0, left: CGFloat(leftPadding), bottom: 0, right: CGFloat(rightPadding))
        super.drawText(in: UIEdgeInsetsInsetRect(rect, insets))
    }
}
