//
//  CustomBarButtonItem.swift
//  RichReach2
//
//  Created by Eumbrella on 26/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit


/// Custom bar button item.
class CustomBarButtonItem: UIBarButtonItem {

    override func awakeFromNib() {
        super.awakeFromNib()
        
        //tintColor = Colors.navigationBarTintColor
        //TODO: Code for our button
    }
}
