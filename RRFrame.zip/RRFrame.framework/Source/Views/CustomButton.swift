//
//  CustomButton.swift
//  RichReach2
//
//  Created by Eumbrella on 03/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import UIKit

/// CustomButton is a custom UIButton that is been displayed in our custom dialogs.
class CustomButton: UIButton {
    var isSelectionColorTransparent = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = Colors.trasnparent
        setTitleColor(Colors.dialogTextColor, for: UIControlState.normal)
        titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        layer.cornerRadius = 0
        
        //TODO: Code for our button
    }
    
    override var isHighlighted: Bool
    {
        get
        {
            return super.isHighlighted
        }
        
        set(value)
        {
            super.isHighlighted = value
            let state = value ? UIControlState.highlighted : UIControlState.normal
            setBackgroundColor(state: state)
        }
    }
    
    /// Sets the button background color based on its current control state.
    ///
    /// - Parameter state: The button's current control state.
    private func setBackgroundColor (state : UIControlState)
    {
        switch (state)
        {
        case UIControlState.normal:
            UIView.animate(withDuration: 0.4, animations: {
                self.backgroundColor = Colors.trasnparent
            })
        case UIControlState.highlighted:
            
            UIView.animate(withDuration: 0.4, animations: {
                if(self.isSelectionColorTransparent)
                {
                    self.backgroundColor = Colors.trasnparent
                }
                else
                {
                    self.backgroundColor = Colors.dialogSelectionColor
                }
            })
        default :
            break
        }
    }
}
