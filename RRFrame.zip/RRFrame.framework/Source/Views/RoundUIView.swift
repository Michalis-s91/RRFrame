//
//  RoundUIView.swift
//  RichReach2
//
//  Created by Eumbrella on 23/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//
import UIKit


/// Custom button with rounded corners and a border.
@IBDesignable
class RoundUIView: UIButton {
    
    @IBInspectable var borderColor: UIColor = UIColor.white {
        didSet {
            self.layer.borderColor = borderColor.cgColor
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 2.0 {
        didSet {
            self.layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            self.layer.cornerRadius = cornerRadius
        }
    }
}
