//
//  NotificationsWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 26/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for notifications. Sends requests for getting notifications and pushed notifications.
class NotificationsWebApi
{
    private static let  START_CHAR : Character = "["
    private static let END_CHAR : Character = "]"
    private static let SPLIT_CHAR : Character = "|"
    private static let PARAMETER_SPLIT_CHAR : Character = ","
    
    /// Accesses the Web API to get the notifications that the user has received through APNS.
    ///
    /// - Parameters:
    ///   - userPhoneNumber:  The user's telephone number.
    ///   - pageToLoad: The page to be loaded.
    /// - Returns: A list that contains the notifications.
    static func getNotifications(userPhoneNumber : String, pageToLoad : Int) -> [NotificationModel]!
    {
        let httpRequest = HttpRequest()
        
        do
        {
            if(APK == APKsEnum.RichReach.rawValue)
            {
                try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetNotificationsWithPaging/",params: "ClientTelephone=\(userPhoneNumber)&PageNumber=\(pageToLoad)")
            }
            else
            {
                try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetBusinessNotificationsWithPaging/",params: "ClientTelephone=\(userPhoneNumber)&PageNumber=\(pageToLoad)&BusinessID=\(businessID == nil ? "" : String(businessID!) )")
            }
            
            return try unPackNotifications(packageString: httpRequest.requestResponse)
        }
        catch
        {
            return nil
        }
    }
    
    /// Unpacks the input string into a list of notifications.
    ///
    /// - Parameter packageString: The packed string.
    /// - Returns: A list that contains the notifications that have been unpacked.
    /// - Throws: error
    static func unPackNotifications(packageString : String) throws -> [NotificationModel]!
    {
        if (!isNullOrEmpty(string: packageString))
        {
            var notifications : [NotificationModel] = []
            
            do
            {
                let startIndex = packageString.index(of: START_CHAR)
                let endIndex = packageString.index(of: END_CHAR)
                
                if(startIndex == nil || endIndex == nil)
                {
                    throw Errors.error
                }
                
                let substring = packageString[startIndex! + 1..<endIndex!]
                let tokens = substring.split(separator: SPLIT_CHAR, omittingEmptySubsequences: false)
                
                for  token in tokens
                {
                    if (!isNullOrEmpty(string: String(token)))
                    {
                        var subTokens = token.split(separator : PARAMETER_SPLIT_CHAR)
                        
                        let notification = NotificationModel()
                        notification.campaignID = Int64(String(subTokens[0]))
                        notification.message = String(subTokens[1])
                        notification.partnerName = String(subTokens[2])
                        notification.partnerImageUri = String(subTokens[3])
                        notification.TimeStampString = String(subTokens[4])
                        
                        if (String(subTokens[5]) == "1")
                        {
                            notification.IsSeen = true
                        }
                        else
                        {
                            notification.IsSeen = false
                        }
                        
                        notifications.append(notification)
                    }
                }
                
                return notifications
            }
            catch
            {
                
            }
        }
        
        return nil
    }
    
    /// Calls Web API to get pushed notifications offers and returns them in a list.
    ///
    /// - Parameters:
    ///   - userPhone: The user's telephone number.
    ///   - campaingID: The campaign ID.
    ///   - pageNumber: The page number to be loaded.
    /// - Returns: A list that contains pushed notifications offers.
    static func getPushNotificationOffers(userPhone : String!, campaingID : Int64, pageNumber : Int) -> [OfferModel]!
    {
        let httpRequest = HttpRequest()
        
        do
        {
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetPushNotificationOffers/",params: "ClientTelephone=\(userPhone ?? "")&CampaignID=\(campaingID)&PageNumber=\(pageNumber)")
            
            return try OffersFormatter.unPackPartnerOffers(packageString: httpRequest.requestResponse, localDB: localDatabase)
        }
        catch
        {
            return nil
        }
    }
    
    static func getNotificationOffers(userPhone : String!, pageNumber : Int) -> [OfferModel]!
    {
        let httpRequest = HttpRequest()
        
        do
        {
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/OffersApi/GetCampaignOffersV2/",params: "ApkID=\(businessID!)&PageNumber=\(pageNumber)&PhoneNumber=\(userPhone ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let notificationOffers = try decoder.decode(NotificationsOffersList.self, from : (response.data(using: .utf8))!)
                
                if(notificationOffers != nil && notificationOffers.notificationsOffersList != nil)
                {
                    for n in notificationOffers.notificationsOffersList
                    {
                        let offerType = n.offerType
                        
                        if (offerType == OfferTypeEnum.GeneralOffer.rawValue)
                        {
                            n.isGeneralOffer = true
                        }
                        else
                        {
                            n.isGeneralOffer = false
                        }
                        
                        if (offerType == OfferTypeEnum.PriceListOffer.rawValue)
                        {
                            n.isPriceListOffer = true
                        }
                        else
                        {
                            n.isPriceListOffer = false
                        }
                        
                        if (offerType == OfferTypeEnum.SetOffer.rawValue)
                        {
                            n.isSetOffer = true
                        }
                        else
                        {
                            n.isSetOffer = false
                        }
                        
                        if (offerType == OfferTypeEnum.NoPriceToShow.rawValue)
                        {
                            n.isNoPriceToShowOffer = true
                        }
                        else
                        {
                            n.isNoPriceToShowOffer = false
                        }
                    }
                }
                return notificationOffers.notificationsOffersList
            }
        }
        catch
        {
            print(error)
            return nil
        }
        
        return nil
    }
    
    static func getPromotionNotificationOffers(userPhone : String!) throws -> [PromotionModel]!
    {
        let httpRequest = HttpRequest()
        
        do
        {
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/NotificationsApi/GetUserCoupons/",params: "PhoneNumber=\(userPhone ?? "")&BusinessID=\(clientID!)")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let promotionNotification = try decoder.decode(PromotionNotificationList.self, from : (response.data(using: .utf8))!)
                
                return promotionNotification.promotionNotificationList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    static func updateUserCouponStatus(userPhone : String!, couponCode : String!, barcode : String!) throws
    {
        let httpRequest = HttpRequest()
        
        do
        {
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/NotificationsApi/UpdateUserCouponStatusToSeen",params: "PhoneNumber=\(userPhone ?? "")&BusinessID=\(clientID!)&CouponCode=\(couponCode ?? "")&Barcode=\(barcode ?? "")")
        }
        catch
        {
            print(error)
            throw Errors.error
        }
    }
    
    static func getUserActiveCouponsCount(userPhone : String!) -> Int
    {
        let httpRequest = HttpRequest()
        
        do
        {
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/NotificationsApi/GetUserActiveCouponsCount/",params: "PhoneNumber=\(userPhone ?? "")&BusinessID=\(clientID!)")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response) && response.isNumeric)
            {
                return Int(response)!
            }
        }
        catch
        {
            return 0
        }
        
        return 0
    }
    
    static func getNotificationsCountersInfo(userPhone : String!) -> NotificationsCountersInfo!
    {
        let httpRequest = HttpRequest()
        
        do
        {
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/NotificationsApi/GetNotificationCountersInfo",params: "PhoneNumber=\(userPhone ?? "")&ApkID=\(businessID!)")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let notificationsCountersInfo = try decoder.decode(NotificationsCountersInfo.self, from : (response.data(using: .utf8))!)
                
                return notificationsCountersInfo
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }
    
    
}

class PromotionNotificationList : Codable
{
    var promotionNotificationList : [PromotionModel]!
    
    private enum CodingKeys : String, CodingKey {
        case promotionNotificationList = "UserCouponsList"
    }
}

class NotificationsOffersList : Codable
{
    var notificationsOffersList : [OfferModel]!
    
    private enum CodingKeys : String, CodingKey {
        case notificationsOffersList = "OffersList"
    }
}

class NotificationsCountersInfo : Codable
{
    var allUnseen : Int!
    var unseenCampaigns : Int!
    var unseenCoupons : Int!
    
    private enum CodingKeys : String, CodingKey {
        case allUnseen = "AllUnseen"
        case unseenCampaigns = "UnseenCampaigns"
        case unseenCoupons = "UnseenCoupons"
    }
}
