//
//  UserProfileWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 27/02/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for updating user profile data to server.
class UserProfileWebApi
{
    /// Updates user's profile information on server.
    ///
    /// - Parameter userProfile: The object that holds the user's profile information.
    static func updateUserProfile(userProfile : UserProfileModel) throws
    {
        do
        {
            //print("\(ApiUrlDefaults.REGISTRATION_URL)UpdateUserProfile?PhoneNumber=\(userProfile.phoneNumber ?? "")&Name=\(userProfile.name ?? "" )&Surname=\(userProfile.surname ?? "" )\(userProfile.gender == nil ? "&Gender=null" : "&Gender=" + String(userProfile.gender))\((userProfile.emailAddress == nil) ? "&EmailAddress=" : "&EmailAddress=" + userProfile.emailAddress )\(userProfile.province == nil ? "&Province=null" : "&Province=" + userProfile.province )\(userProfile.city == nil ? "&City=" : "&City=" + userProfile.city)\(userProfile.homeAddress == nil ? "&HomeAddress=null" : "&HomeAddress=" + userProfile.homeAddress )\(userProfile.postCode == nil ? "&PostCode=" : "&PostCode=" +  userProfile.postCode )\(userProfile.birthDate == nil ? "&BirthDate=null" : "&BirthDate=" + userProfile.birthDate)&ApkID=\(businessID!)")
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)UpdateUserProfile/",params: "PhoneNumber=\(userProfile.phoneNumber ?? "")&Name=\(userProfile.name ?? "" )&Surname=\(userProfile.surname ?? "" )\(userProfile.gender == nil ? "" : "&Gender=" + String(userProfile.gender))\((userProfile.emailAddress == nil) ? "" : "&EmailAddress=" + userProfile.emailAddress )\(userProfile.province == nil ? "" : "&Province=" + userProfile.province )\(userProfile.city == nil ? "" : "&City=" + userProfile.city)\(userProfile.homeAddress == nil ? "" : "&HomeAddress=" + userProfile.homeAddress )\(userProfile.postCode == nil ? "" : "&PostCode=" +  userProfile.postCode )\(userProfile.birthDate == nil ? "" : "&BirthDate=" + userProfile.birthDate)\(userProfile.titleID == nil ? "" : "&Title=" + String(userProfile.titleID))")
        }
        catch
        {
            print(error)
            throw Errors.error
        }
    }
    
    /*static func updateUserProfile2(userProfile : AppUser, acceptNews : AcceptNewsModel, udpateAcceptNews : Bool) throws
    {
        do
        {
            let httpRequest = HttpRequest()

            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)UpdateUserProfile/",params: "PhoneNumber=\(userProfile.phoneNumber ?? "")&Name=\(userProfile.name ?? "" )&Surname=\(userProfile.surname ?? "" )\(userProfile.gender == nil ? "" : "&Gender=" + String(userProfile.gender + 1))\((userProfile.emailAddress == nil) ? "" : "&EmailAddress=" + userProfile.emailAddress )\(userProfile.province == nil ? "" : "&Province=" + userProfile.province )\(userProfile.city == nil ? "" : "&City=\(userProfile.city ?? "")")\(userProfile.homeAddress == nil ? "" : "&HomeAddress=" + userProfile.homeAddress )\(userProfile.postCode == nil ? "" : "&PostCode=" +  userProfile.postCode)\(userProfile.birthDate == nil ? "" : "&BirthDate=\(userProfile.birthDate ?? "")")&AcceptNews1=\(acceptNews.acceptNews1!)&AcceptNews2=\(acceptNews.acceptNews2!)&AcceptNews3=\(acceptNews.acceptNews3!)&AcceptNews4=\(acceptNews.acceptNews4!)&AcceptNews5=\(acceptNews.acceptNews5!)&AcceptNews6=\(acceptNews.acceptNews6!)&AcceptNews7=\(acceptNews.acceptNews7!)&AcceptNews8=\(acceptNews.acceptNews8!)&ApkID=\(businessID!)&ShouldUpdateCustomerBalanceFields=\(true)&BusinessID=\(clientID!)&AddressLine2=\(userProfile.homeAddress2 ?? "")\(userProfile.titleID == nil ? "" : "&Title=" + String(userProfile.titleID))")
        }
        catch
        {
            print(error)
            throw Errors.error
        }
    }*/
    
    static func updateUserProfile2(userProfile : AppUser, acceptNews : AcceptNewsModel, udpateAcceptNews : Bool, isNewRegistration : Bool) throws -> UpdateUserProfileOutputData!
    {
        do
        {
            let httpRequest = HttpRequest()
            print("PhoneNumber=\(userProfile.phoneNumber ?? "")&Name=\(userProfile.name ?? "" )&Surname=\(userProfile.surname ?? "" )\(userProfile.gender == nil ? "" : "&Gender=" + String(userProfile.gender + 1))\((userProfile.emailAddress == nil) ? "" : "&EmailAddress=" + userProfile.emailAddress! )\(userProfile.province == nil ? "" : "&Province=" + userProfile.province! )\(userProfile.city == nil ? "" : "&City=\(userProfile.city ?? "")")\(userProfile.homeAddress == nil ? "" : "&HomeAddress=" + userProfile.homeAddress! )\(userProfile.postCode == nil ? "" : "&PostCode=" +  userProfile.postCode!)\(userProfile.birthDate == nil ? "" : "&BirthDate=\(userProfile.birthDate ?? "")")&AcceptNews1=\(acceptNews.acceptNews1!)&AcceptNews2=\(acceptNews.acceptNews2!)&AcceptNews3=\(acceptNews.acceptNews3!)&AcceptNews4=\(acceptNews.acceptNews4!)&AcceptNews5=\(acceptNews.acceptNews5!)&AcceptNews6=\(acceptNews.acceptNews6!)&AcceptNews7=\(acceptNews.acceptNews7!)&AcceptNews8=\(acceptNews.acceptNews8!)&ApkID=\(businessID!)&ShouldUpdateCustomerBalanceFields=\(true)&BusinessID=\(clientID!)&IsNewRegistration=\(isNewRegistration)&AddressLine2=\(userProfile.homeAddress2 ?? "")\(userProfile.titleID == nil ? "" : "&Title=" + String(userProfile.titleID))\(userProfile.houseNo == nil ? "" : "&HouseNumber=" + userProfile.houseNo!)\(userProfile.flatHouseName == nil ? "" : "&HouseName=" + userProfile.flatHouseName!)\(userProfile.referedName == nil ? "" : "&PreferredName=" + userProfile.referedName!)\(userProfile.languageID == nil ? "" : "&PreferredLanguageID=\(userProfile.languageID!)")\("&IsAdult=\(userProfile.isAdult!)")\("&ShouldReceiveEmail=\(userProfile.shouldReceiveEmail!)")\("&ShouldReceiveSms=\(userProfile.shouldReceiveSms!)")\("&ShouldReceiveNotifications=\(apkUserPreferences.acceptNotifications!)")\("&ShouldReceiveLoyaltyCardNumberBySMS=\(userProfile.shouldReceiveLoyaltyCardNumberBySMS!)\(userProfile.emailVerifiedIPAddress == nil ? "" : "&EmailVerifiedIPAddress=" + userProfile.emailVerifiedIPAddress!)\(userProfile.emailVerifiedDatetime == nil ? "" : "&EmailVerifiedDatetime=" + userProfile.emailVerifiedDatetime!)\(userProfile.mobilePhoneVerifiedIPAddress == nil ? "" : "&MobilePhoneVerifiedIPAddress=" + userProfile.mobilePhoneVerifiedIPAddress!)\(userProfile.mobilePhoneVerifiedDatetime == nil ? "" : "&MobilePhoneVerifiedDatetime=" + userProfile.mobilePhoneVerifiedDatetime!)\(userProfile.country == nil ? "" : "&Country=" + userProfile.country!)\("&HasVerifiedPhoneNumber=\(userProfile.hasVerifiedPhoneNumber!)")\("&HasVerifiedEmailAddress=\(userProfile.hasVerifiedEmailAddress)")\("&HasAcceptedTermsAndConditions=\(localDatabase.isAPKAccepted(bussinessID: clientID)!)")")")
            
            
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)UpdateUserProfile_V2/",params: "PhoneNumber=\(userProfile.phoneNumber ?? "")&Name=\(userProfile.name ?? "" )&Surname=\(userProfile.surname ?? "" )\(userProfile.gender == nil ? "" : "&Gender=" + String(userProfile.gender + 1))\((userProfile.emailAddress == nil) ? "" : "&EmailAddress=" + userProfile.emailAddress! )\(userProfile.province == nil ? "" : "&Province=" + userProfile.province! )\(userProfile.city == nil ? "" : "&City=\(userProfile.city ?? "")")\(userProfile.homeAddress == nil ? "" : "&HomeAddress=" + userProfile.homeAddress! )\(userProfile.postCode == nil ? "" : "&PostCode=" +  userProfile.postCode!)\(userProfile.birthDate == nil ? "" : "&BirthDate=\(userProfile.birthDate ?? "")")&AcceptNews1=\(acceptNews.acceptNews1!)&AcceptNews2=\(acceptNews.acceptNews2!)&AcceptNews3=\(acceptNews.acceptNews3!)&AcceptNews4=\(acceptNews.acceptNews4!)&AcceptNews5=\(acceptNews.acceptNews5!)&AcceptNews6=\(acceptNews.acceptNews6!)&AcceptNews7=\(acceptNews.acceptNews7!)&AcceptNews8=\(acceptNews.acceptNews8!)&ApkID=\(businessID!)&ShouldUpdateCustomerBalanceFields=\(true)&BusinessID=\(clientID!)&IsNewRegistration=\(isNewRegistration)&AddressLine2=\(userProfile.homeAddress2 ?? "")\(userProfile.titleID == nil ? "" : "&Title=" + String(userProfile.titleID))\(userProfile.houseNo == nil ? "" : "&HouseNumber=" + userProfile.houseNo!)\(userProfile.flatHouseName == nil ? "" : "&HouseName=" + userProfile.flatHouseName!)\(userProfile.referedName == nil ? "" : "&PreferredName=" + userProfile.referedName!)\(userProfile.languageID == nil ? "" : "&PreferredLanguageID=\(userProfile.languageID!)")\("&IsAdult=\(userProfile.isAdult!)")\("&ShouldReceiveEmail=\(userProfile.shouldReceiveEmail!)")\("&ShouldReceiveSms=\(userProfile.shouldReceiveSms!)")\("&ShouldReceiveNotifications=\(apkUserPreferences.acceptNotifications!)")\("&ShouldReceiveLoyaltyCardNumberBySMS=\(userProfile.shouldReceiveLoyaltyCardNumberBySMS!)\(userProfile.emailVerifiedIPAddress == nil ? "" : "&EmailVerifiedIPAddress=" + userProfile.emailVerifiedIPAddress!)\(userProfile.emailVerifiedDatetime == nil ? "" : "&EmailVerifiedDatetime=" + userProfile.emailVerifiedDatetime!)\(userProfile.mobilePhoneVerifiedIPAddress == nil ? "" : "&MobilePhoneVerifiedIPAddress=" + userProfile.mobilePhoneVerifiedIPAddress!)\(userProfile.mobilePhoneVerifiedDatetime == nil ? "" : "&MobilePhoneVerifiedDatetime=" + userProfile.mobilePhoneVerifiedDatetime!)\(userProfile.country == nil ? "" : "&Country=" + userProfile.country!)\("&HasVerifiedPhoneNumber=\(userProfile.hasVerifiedPhoneNumber!)")\("&HasVerifiedEmailAddress=\(userProfile.hasVerifiedEmailAddress)")\("&HasAcceptedTermsAndConditions=\(localDatabase.isAPKAccepted(bussinessID: clientID)!)")")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let outputData = try decoder.decode(UpdateUserProfileOutputData.self, from : (response.data(using: .utf8))!)
                
                return outputData
            }
            
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    static func getUserProfile(clientID : Int64, phoneNumber : String!, emailAddress : String!) -> UserProfileModel2!
    {
        do
        {
            let httpRequest = HttpRequest()
            
            try httpRequest.post3(url: "http://www.eumbrellacorp.com/webapi/eorderingapi/GetBLCustomerInfo?ClientID=\(String(clientID))&Mobile=\(phoneNumber ?? "")&Email=\(emailAddress ?? "")", params: "")
            

            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let userProfile = try decoder.decode(UserProfileModel2.self, from : (response.data(using: .utf8))!)
                
                /*if(phoneNumber == "99367677")
                {
                    userProfile.blocked = 1
                }*/
                
                return userProfile
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    static func getUserProfile2(clientID : Int64, phoneNumber : String!, emailAddress : String!, mustUserBelongToBusiness : Bool!, apkID : Int!, timeout : Double) -> UserProfileModel2!
    {
        do
        {
            let httpRequest = HttpRequest()
            
            /*var clientIDTemp = clientID
            var apkIDTemp = apkID
            
            if(clientID == ClientIDs.HollandAndBarrett.rawValue)
            {
                clientIDTemp = ClientIDs.BeautyLine.rawValue
                apkIDTemp = BusinessIDs.BeautyLine.rawValue
            }*/
            
            try httpRequest.post3(url: "\(ApiUrlDefaults.REGISTRATION_URL)GetUserProfile_V2", params: "BusinessID=\(String(clientID))&PhoneNumber=\(phoneNumber ?? "")&MustUserBelongToBusiness=\(mustUserBelongToBusiness!)&ApkID=\(apkID!)", timeout: timeout)
            
            
            let response = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            print(response)
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let userProfile = try decoder.decode(UserProfileModel2.self, from : (response.data(using: .utf8))!)
                
                return userProfile
            }
        }
        catch
        {
            print(error)
            //throw Errors.error
        }
        
        return nil
    }
    
    
    
    static func getUserPointsBalance(clientID : Int64, phoneNumber : String!) -> PointsBalanceModel!
    {
        do
        {
            let httpRequest = HttpRequest()
            
            /*var clientIDTemp = clientID
            
            if(clientID == ClientIDs.HollandAndBarrett.rawValue)
            {
                clientIDTemp = ClientIDs.BeautyLine.rawValue
            }*/
            
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/loyaltyapi/GetCustomerPointsBalance?ClientID=\(String(clientID))&Mobile=\(phoneNumber ?? "")", params: "")
            
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let pointsBalance = try decoder.decode(PointsBalanceModel.self, from : (response.data(using: .utf8))!)
                
                return pointsBalance
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    static func verifyEmailAddress(phoneNumber : String, emailAddress : String)
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "\(ApiUrlDefaults.REGISTRATION_URL)UpdateUserEmailAddress",params: "PhoneNumber=\(phoneNumber ?? "")&EmailAddress=\(emailAddress ?? "")")
            
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
    }
    
    
    /// Post requset for getting user profile view.
    ///
    /// - Returns: The user profile view.
    static func getUserProfileView() throws -> UserProfileView!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplication/api/ParametersApi/GetApkUserProfileForm",params: "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let userProfileView = try decoder.decode(UserProfileView.self, from : (response.data(using: .utf8))!)
                
                return userProfileView
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    static func getBusinessPhoneNumberCount(phoneNumber : String!) -> Int!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplicationTest/api/RegistrationApi/GetBusinessPhoneNumberCount",params: "BusinessID=\(clientID!)&PhoneNumber=\(phoneNumber ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                return Int(response)
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    static func getBusinessEmailAddressCount(emailAddress : String!) -> Int!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplicationTest/api/RegistrationApi/GetBusinessEmailAddressCount",params: "BusinessID=\(clientID!)&EmailAddress=\(emailAddress ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                return Int(response)
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    static func getBusinessPhoneNumberEmailAddressCount(phoneNumber : String!) -> Int!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplicationTest/api/RegistrationApi/GetBusinessPhoneNumberEmailAddressCount",params: "BusinessID=\(clientID!)&PhoneNumber=\(phoneNumber ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                return Int(response)
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    
    /// Post requset for getting verification view.
    ///
    /// - Returns: The user profile view.
    /*static func getVerificationView() throws -> [VerificationModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetVerifyView",params: "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let verificationView = try decoder.decode(VerificationView.self, from : (response.data(using: .utf8))!)
                
                return verificationView.verificationViewList
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    /// Post requset for getting user profile view.
    ///
    /// - Returns: The user profile view.
    static func getUserProfileView() throws -> [UserProfileCellModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetUserProfile",params: "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let userProfileView = try decoder.decode(UserProfileView.self, from : (response.data(using: .utf8))!)
                
                return userProfileView.userProfileViewList
            }
        }
        catch
        {
            print((error))
            //throw Errors.error
        }
        
        return nil
    }
    
    /// Post requset for getting user profile fields.
    ///
    /// - Returns: The user profile fields.
    static func getUserProfileFields() throws -> [FieldModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetFields",params: "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let fields = try decoder.decode(Fields.self, from : (response.data(using: .utf8))!)
                
                return fields.fieldsList
            }
        }
        catch
        {
            print((error))
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post requset for getting user profile fields styles.
    ///
    /// - Returns: The user profile fields styles.
    static func getUserProfileFieldsStyles() throws -> [FieldStyleModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetFieldStyles",params: "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let fieldsStyles = try decoder.decode(FieldsStyles.self, from : (response.data(using: .utf8))!)
                
                return fieldsStyles.fieldsStylesList
            }
        }
        catch
        {
            print((error))
            throw Errors.error
        }
        
        return nil
    }*/
}

/// Helper classes for deserialisation.
class UpdateUserProfileOutputData : Codable
{
    var isOperationSuccessful : Bool!
    var reponseHeader : String!
    var responseBody : String!
    var exceptionMessage : String!
    var hasActiveCoupon : Bool! = false
    
    private enum CodingKeys : String, CodingKey {
        case isOperationSuccessful = "IsOperationSuccessful"
        case reponseHeader = "ReponseHeader"
        case responseBody = "ResponseBody"
        case exceptionMessage = "ExceptionMessage"
        case hasActiveCoupon = "HasActiveCoupon"
    }
}


class UserProfileView : Codable
{
    var userProfileViewList : [UserProfileCellModel]!
    var fieldsList : [FieldModel]!
    var fieldsStylesList : [FieldStyleModel]!
    var verificationViewList : [VerificationModel]!
    var checkBoxGroupsList : [CheckBoxGroup]!
    
    
    private enum CodingKeys : String, CodingKey {
        case userProfileViewList = "UserProfileItemsList"
        case fieldsList = "UserProfileFieldsList"
        case fieldsStylesList = "UserProfileFieldStylesList"
        case verificationViewList = "VerificationViewItemsList"
        case checkBoxGroupsList = "CheckBoxGroupsList"
    }
}

class CheckBoxGroup : Codable
{
    var groupID : Int!
    var checkBoxItemsList : [Int]!
    var checkBoxRelationsList : [CheckBoxGroupRelation]!
    
    
    private enum CodingKeys : String, CodingKey {
        case groupID = "GroupID"
        case checkBoxItemsList = "CheckBoxItemsList"
        case checkBoxRelationsList = "CheckBoxRelationsList"
    }
}

class CheckBoxGroupRelation : Codable
{
    var groupID : Int!
    var validationFailedHeader : String!
    var validationFailedMessage : String!
    
    private enum CodingKeys : String, CodingKey {
        case groupID = "GroupID"
        case validationFailedHeader  = "ValidationFailedHeader"
        case validationFailedMessage = "ValidationFailedMessage"
    }
}


class PointsBalanceModel : Codable
{
    var points : Double!
    var amount : Double!
    
    private enum CodingKeys : String, CodingKey {
        case points = "Point"
        case amount = "Amount"
    }
}
