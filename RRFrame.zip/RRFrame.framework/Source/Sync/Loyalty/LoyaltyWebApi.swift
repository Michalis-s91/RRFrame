//
//  LoyaltyWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 13/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for loyalty. Sends request for getting loyalty tickets, points statement, and parameters for points statement view and ticket view.
class LoyaltyWebApi
{
    private static let  START_CHAR : Character = "["
    private static let END_CHAR : Character = "]"
    private static let SPLIT_CHAR : Character = "|"
    private static let PARAMETER_SPLIT_CHAR : Character = ","
    
    
    /// Send request for points statement for specific partner and return the statement.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - partnerID: The partner id.
    ///   - pageToLoad: The page to load.
    /// - Returns: A list of PointsStatementModel objects(points statement).
    static func getPointsStatement(userPhone : String!, partnerID : Int64, pageToLoad : Int) throws -> [LoyaltyStatementModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/LoyaltyApi/GetCustomerPointsStatement?ClientID=" + String(partnerID) + "&Mobile=\(userPhone ?? "")&PageNo=\(String(pageToLoad))",params:"")
            return try unPackPointsStatement(packageString: httpRequest.requestResponse)
        }
        catch
        {
            throw Errors.error
        }
        
        //return nil
    }

    static func getPointsStatementNew(userPhone : String!, partnerID : Int64, pageToLoad : Int, date : Date!) throws -> [LoyaltyStatementModel]!
    {
        do
        {
            /*var partnerIDTemp = partnerID
            if(partnerID == ClientIDs.HollandAndBarrett.rawValue)
            {
                partnerIDTemp = ClientIDs.BeautyLine.rawValue
            }*/
            
            let httpRequest = HttpRequest()
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyyMMdd"
            
            let date = date != nil ? dateFormatter.string(from: date) : nil
            
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/LoyaltyApi/GetCustomerPointsStatementDate?ClientID=" + String(partnerID) + "&Mobile=\(userPhone ?? "")&PageNo=\(String(pageToLoad))&SynchronizationDate=\(date ?? "")",params:"")
            return try unPackPointsStatement(packageString: httpRequest.requestResponse)
        }
        catch
        {
            throw Errors.error
        }
        
        //return nil
    }
    
    /// Unpack input string and return a list of StatementData.
    ///
    /// - Parameter packageString: The input(unpack) string.
    /// - Returns: A list of StatementData objects.
    /// - Throws: error
    static func unPackPointsStatement(packageString : String) throws -> [LoyaltyStatementModel]!
    {
        if(!packageString.contains(SPLIT_CHAR))
        {
            return nil
        }
        
        do
        {
            var tupleList : [LoyaltyStatementModel] = []
            let startIndex = packageString.index(of: START_CHAR)
            let endIndex = packageString.index(of: END_CHAR)
            
            if(startIndex == nil || endIndex == nil)
            {
                throw Errors.error
            }
            
            let substring = packageString[startIndex! + 1..<endIndex!]
            let tokens = substring.split(separator: SPLIT_CHAR)
            
            for t in tokens
            {
                if (!isNullOrEmpty(string: String(t)))
                {
                    var subTokens = t.split(separator: PARAMETER_SPLIT_CHAR)
                    tupleList.append(LoyaltyStatementModel(rowSerial: String(subTokens[0]),ticketNo: String(subTokens[1]),transDate: String(subTokens[2]),amount: String(subTokens[3]),rewardPoints: String(subTokens[4]),redemptionPoints: String(subTokens[5]),balance: String(subTokens[6])))
                }
            }
            
            return tupleList
        }
        catch
        {
            
        }
        return nil
    }
    
    
    /// Send request for loyalty tickets for specific partner ID.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - partnerID: The user phone number.
    ///   - ticketNo: The ticket number.
    /// - Returns: A list of LoyaltyTicketModel objects(loyalty tickets).
    static func getLoyaltyTicket(userPhone : String, partnerID: Int64, ticketNo: String) throws -> [LoyaltyTicketModel]
    {
        /*var partnerIDTemp = partnerID
        if(partnerID == ClientIDs.HollandAndBarrett.rawValue)
        {
            partnerIDTemp = ClientIDs.BeautyLine.rawValue
        }*/
        
        var response : String! = nil
        
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/LoyaltyApi/GetCustomerTicket?ClientID=" + String(partnerID) + "&Mobile=" + userPhone + "&Ticket=" + ticketNo, params:"")
            //print("http://www.eumbrellacorp.com/webapi/LoyaltyApi/GetCustomerTicket?ClientID=" + String(partnerID) + "&Mobile=" + userPhone + "&Ticket=" + ticketNo)
            response = httpRequest.requestResponse
        }
        catch
        {
            throw Errors.error
        }
        
        var responseList : [LoyaltyTicketModel] = []
        
        if(!isNullOrEmpty(string : response))
        {
            var lineArray = response?.split(separator : "]")
            for i in 0..<(lineArray?.count)!
            {
                let lineRecord = String(lineArray![i])
                if (!isNullOrEmpty(string: lineRecord) && lineRecord.count > 20)
                {
                    var fieldArray = lineRecord.split(separator: SPLIT_CHAR, omittingEmptySubsequences: false)
                    if (fieldArray.count > 16)
                    {
                        let o = LoyaltyTicketModel()
                        o.ticketFlag = "L"
                        o.rowSerial = i
                        o.ticketNo = ticketNo
                        o.transDate = String(fieldArray[1])
                        o.previousPoints = String(fieldArray[2])
                        o.redeemedPoints = String(fieldArray[3])
                        o.earnedPoints = String(fieldArray[4])
                        o.totalPoints = String(fieldArray[5])
                        o.shop = String(fieldArray[6])
                        o.discountAmount = String(fieldArray[7])
                        o.vatPercentage = String(fieldArray[8])
                        o.vatAmount = String(fieldArray[9])
                        o.amountWithVAT = String(fieldArray[10])
                        o.barcode = String(fieldArray[11])
                        o.Quantity = String(fieldArray[12])
                        o.price = String(fieldArray[13])
                        o.lineDiscountAmount = String(fieldArray[14])
                        o.LineVATPurcentage = String(fieldArray[15])
                        o.lineVATAmount = String(fieldArray[16])
                        o.lineAmountWithVAT = String(fieldArray[17])
                        o.description = String(fieldArray[18])
                        
                        responseList.append(o)
                    }
                }
            }
        }
        return responseList
    }
    
    /// Post request for getting points statement view parameters.
    ///
    /// - Returns: The points statement view parameters.
    static func getPointsStamentView() throws -> PointsStatementView!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetPointsStatementView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let pointsStamentView = try decoder.decode(PointsStatementView.self, from : (response.data(using: .utf8))!)
                
                return pointsStamentView
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting ticket view parameters.
    ///
    /// - Returns: The ticket view parameters.
    static func getTicketView() throws -> TicketView!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetTicketView",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let ticketView = try decoder.decode(TicketView.self, from : (response.data(using: .utf8))!)
                
                return ticketView
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting ticket styles.
    ///
    /// - Returns: The ticket styles.
    static func getTicketStyles() throws -> [TicketStyle]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetTicketStyles",params:  "apkName=\(APK ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let ticketStyles = try decoder.decode(TicketStyles.self, from : (response.data(using: .utf8))!)
                
                return ticketStyles.ticketStylesList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
}

/// Helper class for saving ticket styles.
class TicketStyles : Codable
{
    var ticketStylesList : [TicketStyle]!
    
    private enum CodingKeys : String, CodingKey {
        case ticketStylesList  = "TicketStyle_list"
    }
}
