//
//  ParameterizationWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 19/04/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for getting parameterised parameters for the app, like left drawer tabs, toast style etc.
class ParameterizationWebApi
{
    
    /// Post requset for getting theme using input APK.
    ///
    /// - Parameter apk: The APK.
    /// - Returns: The theme.
    static func getTheme(apk : String!) throws -> Theme!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplication/api/ParametersApi/GetApkTheme",params: "ApkName=\(apk ?? "")")
            
            let response = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let theme = try decoder.decode(Theme.self, from : (response.data(using: .utf8))!)
                
                return theme
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
    
    
    /// Post request for getting deafult tabs.
    ///
    /// - Returns: The default tabs.
    static func getDefaultTabs() -> [Tab]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetDefaultTabs",params: "")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let defaultTabs = try decoder.decode(DeafaultTabs.self, from : (response.data(using: .utf8))!)
                
                return defaultTabs.defaultTabsList
            }
        }
        catch
        {
        }
        
        return nil
    }
    
    
    /// Post request for gettting left drawer tabs links using input APK.
    ///
    /// - Parameter apk: The APK.
    /// - Returns: Left drawer tabs links.
    static func getLeftDrawerTabsLinks(apk : String!) throws -> [LinkModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetLeftDrawerTabLinks",params:  "apkName=\(apk ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let leftDrawerTabsLinks = try decoder.decode(LeftDrawerTabsLinks.self, from : (response.data(using: .utf8))!)
                
                return leftDrawerTabsLinks.leftDrawerTabsLinksList
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for gettting left drawer tabs using input APK.
    ///
    /// - Parameter apk: The APK.
    /// - Returns: Left drawer tabs.
    static func getLeftDrawerTabs(apk : String!) throws -> [Tab]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetLeftDrawerTabs",params:  "apkName=\(apk ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let leftDrawerTabs = try decoder.decode(LeftDrawerTabs.self, from : (response.data(using: .utf8))!)
                
                return leftDrawerTabs.leftDrawerTabsList
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
    
    
    /// Post request for getting styles using input APK.
    ///
    /// - Parameter apk: The APK.
    /// - Returns: The styles.
    static func getStyles(apk : String!) throws -> Styles!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetStyles",params:  "apkName=\(apk ?? "")")
            
            let response  = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let styles = try decoder.decode(Styles.self, from : (response.data(using: .utf8))!)
                
                return styles
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    /// Post request for getting parent-child relations of left drawer tabs.
    ///
    /// - Parameter apk: The APK.
    /// - Returns: The parent-child relations.
    static func getRelations (apk : String!) throws -> [PCRelation]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetRelations",params:  "apkName=\(apk ?? "")")
            
            let response  =  getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let relations = try decoder.decode(Relations.self, from : (response.data(using: .utf8))!)
                
                return relations.relationsList
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
    
    static func getSocialMedia(apk : String!) throws ->  [SocialMediaModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/GetSocialMedia",params:  "apkName=\(apk ?? "")")
            
            let response  =  getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let socialMedia = try decoder.decode(SocialMedia.self, from : (response.data(using: .utf8))!)
                
                return socialMedia.socialMediaList
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
    
    static func needUpdate(apk : String!, lastUpdate : String!) throws ->  UpdateStatus!
    {
        do
        {
            var lastUpdateTemp = ""
            
            if(!isNullOrEmpty(string: lastUpdate))
            {
                lastUpdateTemp = lastUpdate
            }
            
            let httpRequest = HttpRequest()
            
            try httpRequest.post3(url: "http://93.109.209.42/paraWebService/ParameterizationTestWebApi.asmx/getUpdateStatus",params: "apkName=\(apk ?? "")&date=\(lastUpdateTemp ?? "")")
            
            let response  =  getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let updateStatus = try decoder.decode(UpdateStatus.self, from : (response.data(using: .utf8))!)
                
                return updateStatus
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
    
    static func needUpdate2(apk : String!, lastUpdate : String!) throws ->  SyncModel!
    {
        do
        {
            var lastUpdateTemp = ""
            
            if(!isNullOrEmpty(string: lastUpdate))
            {
                lastUpdateTemp = lastUpdate
            }
            
            let httpRequest = HttpRequest()
            
            let currentAppVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
            let currentAppBuildVersion = Bundle.main.infoDictionary?["CFBundleVersion"]  as! String
            
            var appUser = localDatabase.getAppUser()
            var phoneNumber = ""
            
            if(appUser != nil)
            {
                phoneNumber = !isNullOrEmpty(string: appUser?.phoneNumber) ? (appUser?.phoneNumber)! : ""
            }
            
            print("ApkName=\(apk ?? "")&LastUpdateDate=\(lastUpdateTemp ?? "")&ApkBuildVersion=\(currentAppBuildVersion == nil ? "" : (currentAppBuildVersion ?? "") )&ApkVersionStr=\(currentAppVersion == nil ? "" : (currentAppVersion ?? ""))&PhoneNumber=\(phoneNumber ?? "")&ApkID=\(businessID!)&PhoneType=\(PhoneType.iOS.rawValue)")
            
            try httpRequest.post3(url: "http://93.109.209.42/RichReachWebApplication/api/ParametersApi/GetApkSyncInfo_V2/",params: "ApkName=\(apk ?? "")&LastUpdateDate=\(lastUpdateTemp ?? "")&ApkBuildVersion=\(currentAppBuildVersion == nil ? "" : (currentAppBuildVersion ?? "") )&ApkVersionStr=\(currentAppVersion == nil ? "" : (currentAppVersion ?? ""))&PhoneNumber=\(phoneNumber ?? "")&ApkID=\(businessID!)&PhoneType=\(PhoneType.iOS.rawValue)" , timeout: 3)
            // throw Errors.error
            let response  =  getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            //throw Errors.error
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let syncModel = try decoder.decode(SyncModel.self, from : (response.data(using: .utf8))!)
                
                return syncModel
            }
        }
        catch
        {
            print(error)
            throw Errors.error
        }
        
        return nil
    }
    
    static func getSignupBonus() throws ->  SignupBonusModel!
    {
        do
        {
            let httpRequest = HttpRequest()
            
            try httpRequest.post3(url: "http://www.eumbrellacorp.com/webapi/loyaltyapi/getsignupparameters?Clientid=\(clientID!)",params: "")
            
            let response  =  getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let signupBonus = try decoder.decode(SignupBonus.self, from : (response.data(using: .utf8))!)
                
                if(signupBonus.parameters != nil && signupBonus.parameters.count > 0)
                {
                    return signupBonus.parameters[0]
                }
                else
                {
                    return nil
                }
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
    
    static func createAndGetOfferCoupon(userPhone: String!, couponCode: String!, offerGivenStoreID : Int!, offerID : Int!) throws -> CouponStatus!
    {
        do
        {
            let httpRequest = HttpRequest()
            
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/OffersApi/CreateAndGetOfferCoupon", params: "PhoneNumber=\(userPhone ?? "")&CouponCode=\("PROXTRIG01")&ApkID=\(businessID!)&BusinessID=\(clientID!)&StoreID=\(2185)&OfferID=\(10)")
            
            let response  =  getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if(!isNullOrEmpty(string: response))
            {
                let decoder = JSONDecoder()
                let couponStatus = try decoder.decode(CouponStatus.self, from : (response.data(using: .utf8))!)
                
                return couponStatus
            }
        }
        catch
        {
            throw Errors.error
        }
        
        return nil
    }
}


/// Helper class for saving styles.
class Styles : Codable
{
    var leftDrawerStyle : [Style]!
    var leftDrawerChildStyle : [Style]!
    var tabBarStyle : [Style]!
    var toastStyle : [Style]!
    var dialogStyle : [Style]!
    
    private enum CodingKeys : String, CodingKey {
        case leftDrawerStyle = "LeftDrawerStyleList"
        case leftDrawerChildStyle = "LeftDrawerChildStyleList"
        case tabBarStyle = "TabBarStyleList"
        case toastStyle = "ToastStyleList"
        case dialogStyle = "DialogStyleList"
    }
}

/// Helper classes for deserialisation.
class DeafaultTabs : Codable
{
    var defaultTabsList : [Tab]!
    
    private enum CodingKeys : String, CodingKey {
        case defaultTabsList = "DefaultTabsList"
    }
}

class LinkModel : Codable
{
    var id : Int!
    var link : String!
    
    private enum CodingKeys : String, CodingKey {
        case id = "ID"
        case link = "Link"
    }
}

class LeftDrawerTabsLinks : Codable
{

    var leftDrawerTabsLinksList : [LinkModel]!
    
    private enum CodingKeys : String, CodingKey {
        case leftDrawerTabsLinksList = "LeftDrawerLinksList"
    }
}

class LeftDrawerTabs : Codable
{
    var leftDrawerTabsList : [Tab]!
    
    private enum CodingKeys : String, CodingKey {
        case leftDrawerTabsList = "LeftDrawerList"
    }
}

class Relations : Codable
{
    var relationsList : [PCRelation]!
    
    private enum CodingKeys : String, CodingKey {
        case relationsList = "ParentchildrelationList"
    }
}

class SocialMedia : Codable
{
    var socialMediaList : [SocialMediaModel]!
    
    private enum CodingKeys : String, CodingKey {
        case socialMediaList = "Social_Media_List"
    }
}

class UpdateStatus : Codable
{
    var needsUpdate : Bool!
    var dateTime : String!
    
    private enum CodingKeys : String, CodingKey {
        case needsUpdate = "needsUpdate"
        case dateTime = "DateTime"
    }
}

class SignupBonus : Codable
{
    var parameters : [SignupBonusModel]!
    
    private enum CodingKeys : String, CodingKey {
        case parameters = "Parameters"
    }
}

class CouponStatus : Codable
{
    var couponStatusType : Int!
    var firstValidDate : String!
    var lastValidDate : String!
    
    private enum CodingKeys : String, CodingKey{
        case couponStatusType = "CouponStatusType"
        case firstValidDate = "FirstValidDate"
        case lastValidDate = "LastValidDate"
    }
    
}
