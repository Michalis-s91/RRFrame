//
//  OrderProductsWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation


/// OrderProductsWebApi is the web api for ordering products. It loads the order product information, gets offer availability and posts offer availability request.
class OrderProductsWebApi
{
    /// Gets and returns the order product information.
    ///
    /// - Parameter productID: The product ID.
    /// - Returns: The order product information.
    static func getOrderProductInformation(productID : Int64) -> OrderProductInformation!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.eumbrellacorp.com/webapi/eOrderingApi/GetExtDescrAndStores?ProductID=\(productID)",params: "")
            let taskResponseString = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if (!isNullOrEmpty(string: taskResponseString))
            {
                let productInformation = OrderProductInformation()
                productInformation.deserialize(str: taskResponseString)
                return productInformation
            }
            
        }
        catch
        {
        }
        
        return nil
    }
    
    /// Gets offer availability.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone.
    ///   - appOfferID: The application offer ID.
    /// - Returns: The response of request.
    static func getOfferAvailability(userPhone : String! , appOfferID : Int) -> OfferAvailability!
    {
        var apiResponse : String! = nil
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetOfferAvailability/",params: "ClientTelephone=\(userPhone ?? "")&AppOfferID=\(appOfferID)")
            apiResponse = httpRequest.requestResponse
        }
        catch
        {
            
        }
        
        var addresses : [StoresInfo] = []
        var offerDuration = ""
        var extendedDescription = ""
        var termsAndConditions = ""
        
        if (!isNullOrEmpty(string: apiResponse))
        {
            print(apiResponse)
            let addressesData = OffersFormatter.unPackPartnerInformation(packageString: apiResponse!)
            var cnt = 0
            if (addressesData != nil)
            {
                for h in addressesData!
                {
                    if (cnt == (addressesData?.count)! - 1)
                    {
                        offerDuration = h.item1
                        extendedDescription = h.item2
                        termsAndConditions = h.item3
                    }
                    else
                    {
                        let storesInfo = StoresInfo(name: h.item1,address: h.item2,phone: h.item3,latitude: h.item4,longitude: h.item5)
                        addresses.append(storesInfo)
                    }
                    
                    cnt += 1
                }
            }
        }
        
        return OfferAvailability(duration: offerDuration, extendedDescription: extendedDescription, termsAndConditions: termsAndConditions, stores: addresses)
    }
    
    static func getOfferInformation(campaignID : Int64!, phoneNumber : String , storeOfferForAppID : Int!) -> OfferInformation!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/OffersApi/GetOfferInformation/",params: "CampaignID=\(campaignID == nil  ? "" : String(campaignID!) ?? "")&PhoneNumber=\(phoneNumber ?? "")&StoreOfferForAppID=\(storeOfferForAppID!)")
            
            let taskResponseString = getUpdatedJsonStr(inputString: httpRequest.requestResponse)
            
            if (!isNullOrEmpty(string: taskResponseString))
            {
                let decoder = JSONDecoder()
                let offerInformation = try decoder.decode(OfferInformation.self,  from : (taskResponseString.data(using: .utf8))!)
                
                return offerInformation
            }
        }
        catch
        {
            print(error)
        }
        
        return nil
    }

}

class OfferInformation : Codable
{
    var stores : [StoresInfo]!
    var termsAndConditions : String!
    var extendedDescription : String!
    var duration : String!
    
    private enum CodingKeys : String, CodingKey {
        case duration = "Duration"
        case extendedDescription  = "ExtendedDescription"
        case termsAndConditions  = "TermsAndConditions"
        case stores = "Stores"
    }
}

class AddressInformation : Codable
{
    var description : String!
    var address : String!
    var phoneNumber : String!
    var latitude : String!
    var longtitude : String!
    
    private enum CodingKeys : String, CodingKey {
        case description = "Description"
        case address = "Address"
        case phoneNumber = "PhoneNumber"
        case latitude = "Latitude"
        case longtitude = "Longtitude"
    }
}
