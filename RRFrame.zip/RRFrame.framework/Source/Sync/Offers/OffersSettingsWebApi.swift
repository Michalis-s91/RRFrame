//
//  OffersSettingsWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 21/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

 /// Web api for offers settings. Sends request for verifying input partner code.
class OffersSettingsWebApi
{
    /// Post request for verifying input partner code.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone number.
    ///   - partnerCode: The partner code.
    /// - Returns: The response of request.
    static func verifyPartnerCode(userPhone : String!, partnerCode : String) -> String!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/VerifyPartnerCode/",params: "ClientTelephone=\(userPhone ?? "")&PartnerCode=\(partnerCode)")
            return removeQuotesCharacters(message: httpRequest.requestResponse)
        }
        catch
        {
            
        }
        
        return nil
    }
}
