//
//  OfferItemsWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 27/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// OfferItemsWebApi is the web api for offer items. It loads offer items and post offer items request for combo offers.
class OfferItemsWebApi
{
    /// Loads offer items.
    ///
    /// - Parameters:
    ///   - userPhone: The user phone.
    ///   - appOfferID: The application offer ID.
    /// - Returns: The list with offer items.
    static func getOfferItems(userPhone : String!, appOfferID : Int) -> [OfferItemModel]!
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetComboOfferSet/",params: "ClientTelephone=\(userPhone ?? "")&AppOfferID=\(appOfferID)")
            let apiResponse = httpRequest.requestResponse
            var responseList : [OfferItemModel] = []
            if (!isNullOrEmpty(string: apiResponse))
            {
                let partnersData = try OffersFormatter.unPackComboOfferItems(packageString: apiResponse!)
                if (partnersData != nil)
                {
                    for p in partnersData!
                    {
                        let offerItemModel = OfferItemModel()
                        offerItemModel.itemID = p.itemID
                        offerItemModel.name = p.name
                        offerItemModel.imageUrl = p.imageUrl
                        
                        responseList.append(offerItemModel)
                    }
                }
            }
            return responseList
        }
        catch
        {
            
        }
        
        return nil
    }
    
    static func markCampaignAsOpened(campaignID : Int64!, phoneNumber : String)
    {
        do
        {
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://93.109.209.42/RichReachWebApplication/api/OffersApi/MarkCampaignAsOpened/",params: "CampaignID=\(campaignID == nil  ? "" : String(campaignID!) ?? "")&PhoneNumber=\(phoneNumber ?? "")")
        }
        catch
        {
            print(error)
        }
    }
}
