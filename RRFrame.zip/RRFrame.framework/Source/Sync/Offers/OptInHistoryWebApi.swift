//
//  OptInHistoryWebApi.swift
//  RichReach2
//
//  Created by Eumbrella on 12/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Web api for opt in history. Sends request for getting opt in history.
class OptInHistoryWebApi
{
    static var lock = NSObject()
    
    /// Post request for opt in and return user opt in history in a list.
    ///
    /// - Parameter userPhone: The user phone number.
    /// - Returns: User opt in history in a list.
    static func getPartnersOptInHistory(userPhone : String!) -> [OptInHistoryModel]!
    {
        do
        {
            objc_sync_enter(lock)
            let httpRequest = HttpRequest()
            try httpRequest.post(url: "http://www.commtor.com/webapi/PartnersApi/GetPartnersOptInHistory/",params: "ClientTelephone=\(userPhone ?? "")")
            objc_sync_exit(lock)
            return try OffersFormatter.unPackOptInHistory(packageString: httpRequest.requestResponse)
        }
        catch
        {
            objc_sync_exit(lock)
        }
        return nil
    }
}
