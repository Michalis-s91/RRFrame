//
//  OfferAvailability.swift
//  RichReach2
//
//  Created by Eumbrella on 09/03/2018.
//  Copyright © 2018 Eumbrella. All rights reserved.
//

import Foundation

/// Holds information about offers availability.
class OfferAvailability
{
    var duration : String!
    var extendedDescription : String!
    var termsAndConditions : String!
    var stores : [StoresInfo]
    
    
    /// Constructor. Initialises the object properties.
    ///
    /// - Parameters:
    ///   - duration: The duration of availability.
    ///   - extendedDescription: The extended description.
    ///   - termsAndConditions: Terms and conditions.
    ///   - stores: The stores.
    init(duration : String, extendedDescription : String, termsAndConditions : String, stores : [StoresInfo] )
    {
        self.duration = duration
        self.extendedDescription = extendedDescription
        self.termsAndConditions = termsAndConditions
        self.stores = stores
    }
}
