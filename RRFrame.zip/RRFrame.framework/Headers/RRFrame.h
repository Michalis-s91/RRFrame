//
//  RRFrame.h
//  RRFrame
//
//  Created by George Rousou on 19/09/2019.
//  Copyright © 2019 George Rousou. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RRFrame.
FOUNDATION_EXPORT double RRFrameVersionNumber;

//! Project version string for RRFrame.
FOUNDATION_EXPORT const unsigned char RRFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RRFrame/PublicHeader.h>


